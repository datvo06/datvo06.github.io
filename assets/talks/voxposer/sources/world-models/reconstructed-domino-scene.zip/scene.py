"""RoboTL components copied into each generated, independently loadable program."""
from robotl.ops.syntax import Pose, assert_transform
import effectful.handlers.jax.numpy as jnp
from robotl.ops import joints, shapes
from robotl.ops.syntax import Material, Origin, Port, defcomponent

@defcomponent
def Box(self, size, mass, friction, color):
    dx, dy, dz = size
    self.shape = shapes.centered_cube(dx, dy, dz)
    self.material = Material(density=mass / (dx * dy * dz), friction=friction, color=jnp.array(color))
    self.base = self.place(Port())

@defcomponent
def Scene(self):
    self.base = self.place(Port())
    self._origin = joints.Weld(Origin.base, self.base)
    self.object_0 = Box([0.15, 0.07, 0.029], 0.05, 0.5, (0.4392156862745098, 0.5098039215686274, 0.5764705882352941, 1.0))
    assert_transform(self.base, self.object_0.base, Pose(pos=[-0.1409120187772796, 0.12100181875858207, 0.9070938021217694], rv=[0.9431604150986678, -0.21446189082435188, -1.615949577614846]))
    self.object_1 = Box([0.15, 0.07, 0.029], 0.05, 0.5, (0.2196078431372549, 0.5254901960784314, 0.4392156862745098, 1.0))
    assert_transform(self.base, self.object_1.base, Pose(pos=[0.03905061903255885, 0.17482463988300517, 0.8035097430456191], rv=[-1.015430593245924, 1.4835572023862982, -0.7311963949528967]))

def factory():
    return Scene()

"""A deformable lattice block in a fan's wind, with a light and a heavy domino behind it.

The scene is the first Guided MPC environment from the lattice-wind plan: a table, a fixed
fan blowing along +x, the fidget-lattice slab as a MuJoCo ``flex`` built from a tetrahedral
mesh of its actual struts (see ``prepare_lattice.py``), two rigid dominoes downstream that
differ only in mass, and an optional pair of squeeze plates standing in for the hand. The
task is to let enough wind through the lattice to topple the light domino while the heavy
one stays upright; how much gets through depends on which material axis of the lattice
faces the fan and on how the block is deformed.

Airflow is a reduced, quasi-steady model owned by this module and applied through MuJoCo's
control callback at every physics step. It is a declared synthetic closure, not a
calibrated one: the fan field, the attenuation law and the wake mixing below are the
quantities ``calibrate_wind.py`` is meant to fit against bench or CFD references, and
nothing here has been checked against either. Everything the model needs is read from the
current ``MjData``; it keeps no state of its own, so candidate rollouts from one snapshot
cannot influence each other.

Frames follow the existing BabyRobot fan simulator: x downstream, y lateral, z up, the
table top at z = 0, the fan outlet at the origin. The lattice keeps the generator's
material axes (x the ball's long axis, y its short axis, z the print direction); an
``Orientation`` says which of them points downstream and which points up.

Run the demonstration (paired light/heavy trials, the joint scene, position swaps, two
lattice orientations, the sealed control and the free block) with

    uv run python experiments/lattice_wind/lattice_wind.py demo \\
        --mesh artifacts/lattice_wind/slab.msh --out artifacts/lattice_wind/demo

and turn a saved recording into a video with ``... render recording.npz video.mp4``.
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import math
import sys
import time
from collections.abc import Iterator
from dataclasses import dataclass, field, replace
from pathlib import Path
from types import TracebackType
from typing import Annotated, Any, Literal

import mujoco
import numpy as np
from prepare_lattice import TetMesh, read_gmsh, sha256
from pydantic import ConfigDict, Field, TypeAdapter
from pydantic.dataclasses import dataclass as validated
from scipy.ndimage import gaussian_filter

AIR_DENSITY = 1.2  # kg/m^3
GRAVITY = 9.81
# MuJoCo scales contact stiffness with the colliding body's mass, and a lattice vertex
# weighs micrograms, so at the default 20 ms time constant plates and table would sink
# millimetres into the block; one timestep keeps penetration below the vertex radius
# under the discrete integrator.
CONTACT_TIMECONST_S = 0.001
PIN_HEIGHT_M = 0.0015  # the bottom layer of vertices, when the fixture holds the block
# A domino deeper into the wind than this has left the workspace the model covers.
X_HAT = np.array([1.0, 0.0, 0.0])
Z_HAT = np.array([0.0, 0.0, 1.0])

MaterialAxis = Literal["+x", "-x", "+y", "-y", "+z", "-z"]
_AXIS_VECTORS: dict[str, np.ndarray] = {
    "+x": np.array([1.0, 0, 0]),
    "-x": np.array([-1.0, 0, 0]),
    "+y": np.array([0, 1.0, 0]),
    "-y": np.array([0, -1.0, 0]),
    "+z": np.array([0, 0, 1.0]),
    "-z": np.array([0, 0, -1.0]),
}


# --------------------------------------------------------------------------------------
# Configuration: everything an episode depends on, serialisable so a recording can
# rebuild its own scene. The classes are pydantic dataclasses: field types carry the
# physical ranges, ``__post_init__`` the cross-field constraints, and a recording's JSON
# is parsed by the same contract that built the episode.
# --------------------------------------------------------------------------------------

STRICT = ConfigDict(allow_inf_nan=False)
Finite = Annotated[float, Field(allow_inf_nan=False)]
Positive = Annotated[float, Field(gt=0, allow_inf_nan=False)]
NonNegative = Annotated[float, Field(ge=0, allow_inf_nan=False)]
Fraction = Annotated[float, Field(ge=0, le=1)]
Name = Annotated[str, Field(min_length=1)]


@validated(frozen=True, config=STRICT)
class Orientation:
    """Which material axis of the lattice points downstream (+x) and which points up (+z)."""

    downstream: MaterialAxis = "+z"
    up: MaterialAxis = "+y"

    def __post_init__(self) -> None:
        if self.downstream[1] == self.up[1]:
            raise ValueError(
                f"downstream {self.downstream} and up {self.up} must be different axes"
            )

    def rotation(self) -> np.ndarray:
        """World-from-material rotation matrix."""
        d, u = _AXIS_VECTORS[self.downstream], _AXIS_VECTORS[self.up]
        lateral = np.cross(u, d)
        return np.stack([d, lateral, u])

    def quat(self) -> np.ndarray:
        q = np.zeros(4)
        mujoco.mju_mat2Quat(q, self.rotation().ravel())
        return q


@validated(frozen=True, config=STRICT)
class LatticeMaterial:
    """Elastic struts with damping. Synthetic until compression measurements fit them."""

    young_pa: Positive = 1.0e6
    poisson: Annotated[float, Field(ge=0, lt=0.5)] = 0.35
    damping: NonNegative = 0.02
    edge_damping: NonNegative = 0.05
    radius_m: Positive = (
        0.0005  # contact radius around each vertex; struts are about 1 mm
    )
    friction: NonNegative = 0.8


@validated(frozen=True, config=STRICT)
class Lattice:
    mesh: Name  # path to the Gmsh file prepare_lattice.py wrote
    mass_kg: Positive
    orientation: Orientation = Orientation()
    x_m: Finite = 0.20
    y_m: Finite = 0.0
    material: LatticeMaterial = LatticeMaterial()
    # Vertices within this height of the bottom face are pinned to the table: the
    # non-occluding fixture that holds the block for airflow calibration. Zero leaves the
    # block free, as the task does.
    pin_height_m: NonNegative = 0.0
    # Half-widths (x, y) of the upstream region the block has to stay inside.
    region_half_m: tuple[Positive, Positive] = (0.08, 0.10)


@validated(frozen=True, config=STRICT)
class Domino:
    """An upright box; ``thickness_m`` faces the wind. Mass is the only thing the task varies."""

    name: Name
    mass_kg: Positive
    x_m: Finite
    y_m: Finite
    thickness_m: Positive = 0.012
    width_m: Positive = 0.024
    height_m: Positive = 0.080
    friction: NonNegative = 0.5

    def tipping_force_n(self) -> float:
        """Static tipping threshold for a horizontal force at mid-height: the weight's
        moment about the downwind base edge, m g (b / 2), over the lever arm H / 2,
        with b the thickness and H the full height, so m g b / H."""
        return self.mass_kg * GRAVITY * (self.thickness_m / 2) / (self.height_m / 2)

    def sliding_force_n(self) -> float:
        return self.friction * self.mass_kg * GRAVITY


@validated(frozen=True, config=STRICT)
class FanPulse:
    """Prescribed fan speed over the episode: ramp up, hold, exponential spin-down."""

    speed_mps: NonNegative = 12.0
    on_s: NonNegative = 1.0
    hold_s: NonNegative = 0.8
    rise_s: Positive = 0.15
    tau_s: Positive = 0.3

    def speed(self, t: float) -> float:
        if t < self.on_s:
            return 0.0
        if t < self.on_s + self.hold_s:
            return self.speed_mps * min(1.0, (t - self.on_s) / self.rise_s)
        return self.speed_mps * math.exp(-(t - self.on_s - self.hold_s) / self.tau_s)

    @property
    def end_s(self) -> float:
        """When the spin-down has decayed to 5%: the end of the gust for acceptance."""
        return self.on_s + self.hold_s + 3 * self.tau_s


@validated(frozen=True, config=STRICT)
class FanJet:
    """The empty-fan field u0 at unit exit speed: a round jet whose radius grows linearly
    and whose centreline speed falls to keep the momentum flux, with a soft edge."""

    radius_m: Positive = 0.05
    height_m: NonNegative = 0.045
    spread: NonNegative = 0.10  # radius growth per metre downstream
    edge: Positive = 0.15  # tanh edge width as a fraction of the local radius

    def axial(self, points: np.ndarray) -> np.ndarray:
        """Axial speed at ``points`` [N, 3] for an exit speed of 1 m/s."""
        x = np.maximum(points[..., 0], 0.0)
        r = self.radius_m + self.spread * x
        rho = np.hypot(points[..., 1], points[..., 2] - self.height_m)
        centreline = self.radius_m / r
        return centreline * 0.5 * (1.0 - np.tanh((rho - r) / (self.edge * r)))


@validated(frozen=True, config=STRICT)
class Airflow:
    """The reduced lattice/wake closure. Every number here is a calibration target."""

    density: Positive = AIR_DENSITY
    # Transmission along a ray falls as exp(-attenuation * solid length crossed).
    attenuation_per_m: NonNegative = 55.0
    lattice_cd: NonNegative = 0.6  # drag coefficient of the struts' windward surface
    domino_cd: NonNegative = 1.2
    mixing: NonNegative = 0.08  # wake blur radius growth per metre past the rear face
    cell_m: Positive = 0.004  # voxel size along x and ray column size across (y, z)
    x_range_m: tuple[Finite, Finite] = (0.0, 0.70)
    y_range_m: tuple[Finite, Finite] = (-0.16, 0.16)
    z_range_m: tuple[Finite, Finite] = (0.0, 0.16)
    # Transmission of a skin wrapped over the block's envelope, applied once on entry.
    # 1 is the bare lattice; 0 is the matched sealed control, which still lets the flow
    # pass around the block's outside.
    skin_transmission: Fraction = 1.0

    def __post_init__(self) -> None:
        for name, (lo, hi) in (
            ("x", self.x_range_m),
            ("y", self.y_range_m),
            ("z", self.z_range_m),
        ):
            if lo >= hi:
                raise ValueError(f"{name}_range_m must be increasing, got {(lo, hi)}")


@validated(frozen=True, config=STRICT)
class Squeeze:
    """Two plates that close across the lateral axis to a gap, and optionally let go.

    They stand edge-on to the wind outside the jet while parked; while closed they are
    rigid occluders the airflow model shadows.
    """

    gap_m: Positive
    close_at_s: NonNegative = 0.1
    close_over_s: Positive = 0.4
    release_at_s: NonNegative | None = None
    park_gap_m: Positive = 0.5
    # Thick enough that a lattice vertex cannot cross a plate's midplane and be pushed
    # out of the far side.
    plate_half_m: tuple[Positive, Positive, Positive] = (0.06, 0.010, 0.06)
    kp: Positive = 30000.0
    kv: NonNegative = 600.0

    def __post_init__(self) -> None:
        if self.park_gap_m <= self.gap_m:
            raise ValueError(
                f"park_gap_m {self.park_gap_m} must exceed gap_m {self.gap_m}"
            )
        if self.release_at_s is not None and self.release_at_s < self.close_at_s:
            raise ValueError("release_at_s must not precede close_at_s")

    def closing_gap(self, t: float) -> float:
        closing = min(1.0, max(0.0, (t - self.close_at_s) / self.close_over_s))
        return self.park_gap_m + (self.gap_m - self.park_gap_m) * closing

    def gap(self, t: float) -> float:
        """The commanded gap: closing from the park gap, then opening again from
        whatever gap had been reached when release was asked for."""
        if self.release_at_s is None or t < self.release_at_s:
            return self.closing_gap(t)
        held = self.closing_gap(self.release_at_s)
        opening = min(1.0, (t - self.release_at_s) / self.close_over_s)
        return held + (self.park_gap_m - held) * opening


@validated(frozen=True, config=STRICT)
class Acceptance:
    """Task thresholds, fixed before evaluation (the plan's proposed benchmark values)."""

    fallen_deg: Annotated[float, Field(gt=0, le=90)] = 60.0
    upright_deg: NonNegative = 10.0
    footprint_m: Positive = 0.005
    settle_s: NonNegative = 1.0

    def __post_init__(self) -> None:
        if self.upright_deg >= self.fallen_deg:
            raise ValueError(
                f"upright_deg {self.upright_deg} must be below fallen_deg {self.fallen_deg}"
            )


@validated(frozen=True, config=STRICT)
class Scene:
    lattice: Lattice
    dominoes: tuple[Domino, ...]
    fan: FanPulse = FanPulse()
    jet: FanJet = FanJet()
    airflow: Airflow = Airflow()
    squeeze: Squeeze | None = None
    acceptance: Acceptance = Acceptance()
    timestep_s: Positive = 0.001
    record_hz: Positive = 60.0
    # Constraint-solver iterations. The discrete integrator's flex M+K solve shares them,
    # and a strut lattice needs well over MuJoCo's default 100 before it converges.
    solver_iterations: Annotated[int, Field(gt=0)] = 500
    # Downstream stations (metres past the block's rear face) where velocity profiles are
    # recorded for calibration.
    stations_m: tuple[NonNegative, ...] = (0.05, 0.10, 0.20, 0.25)

    def __post_init__(self) -> None:
        names = [d.name for d in self.dominoes]
        if len(set(names)) != len(names):
            raise ValueError(f"domino names must be unique, got {names}")

    @property
    def duration_s(self) -> float:
        return self.fan.end_s + self.acceptance.settle_s + 0.2

    def to_json(self) -> str:
        return json.dumps(dataclasses.asdict(self), indent=1)

    @classmethod
    def from_json(cls, text: str) -> Scene:
        return SCENE_JSON.validate_json(text)


SCENE_JSON = TypeAdapter(Scene)


# --------------------------------------------------------------------------------------
# The MuJoCo model.
# --------------------------------------------------------------------------------------


def _camera_xyaxes(position: np.ndarray, target: np.ndarray) -> str:
    forward = target - position
    forward /= np.linalg.norm(forward)
    right = np.cross(forward, Z_HAT)
    right /= np.linalg.norm(right)
    up = np.cross(right, forward)
    return " ".join(f"{v:.5f}" for v in (*right, *up))


def _box_faces(
    half: np.ndarray, counts: tuple[int, int, int]
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Sample points, outward normals and patch areas over the six faces of a box, in its frame."""
    points, normals, areas = [], [], []
    for axis in range(3):
        others = [a for a in range(3) if a != axis]
        n0, n1 = counts[others[0]], counts[others[1]]
        g0 = (np.arange(n0) + 0.5) / n0 * 2 * half[others[0]] - half[others[0]]
        g1 = (np.arange(n1) + 0.5) / n1 * 2 * half[others[1]] - half[others[1]]
        patch = (2 * half[others[0]]) * (2 * half[others[1]]) / (n0 * n1)
        for sign in (1.0, -1.0):
            for a in g0:
                for b in g1:
                    p = np.zeros(3)
                    p[axis] = sign * half[axis]
                    p[others[0]], p[others[1]] = a, b
                    n = np.zeros(3)
                    n[axis] = sign
                    points.append(p)
                    normals.append(n)
                    areas.append(patch)
    return np.array(points), np.array(normals), np.array(areas)


@dataclass
class DominoIndex:
    body: int
    geom: int
    points: np.ndarray  # [S, 3] face samples in the body frame
    normals: np.ndarray  # [S, 3]
    areas: np.ndarray  # [S]


@dataclass(frozen=True)
class Plates:
    """MuJoCo ids of the squeeze plates, (negative-y, positive-y)."""

    bodies: tuple[int, int]
    geoms: tuple[int, int]
    actuators: tuple[int, int]


@dataclass
class Model:
    """A compiled scene plus the indices the airflow model and observers need."""

    scene: Scene
    mj: mujoco.MjModel
    mesh: TetMesh
    mesh_sha256: str  # of the file the flex was built from
    rest_volumes: np.ndarray  # [E]
    faces: np.ndarray  # [F, 3] boundary triangles, wound outward
    face_element: np.ndarray  # [F] the element each boundary triangle belongs to
    vertex_bodies: np.ndarray  # [V] body id per lattice vertex (0 when pinned)
    vertex_dofs: np.ndarray  # [V] first dof per vertex, -1 when pinned
    dominoes: list[DominoIndex]
    table_geom: int
    plates: Plates | None
    # Unit-speed fan field on the voxel grid, and the grid itself.
    u0: np.ndarray  # [nx, ny, nz]
    origin: np.ndarray  # lower corner of the voxel grid
    shape: tuple[int, int, int]

    @property
    def cell(self) -> float:
        return self.scene.airflow.cell_m

    def voxel(self, points: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Voxel indices of ``points`` [..., 3] and which of them lie inside the grid."""
        idx = np.floor((points - self.origin) / self.cell).astype(np.int64)
        inside = np.all((idx >= 0) & (idx < np.array(self.shape)), axis=-1)
        return idx, inside

    def clamp(self, idx: np.ndarray) -> np.ndarray:
        return np.clip(idx, 0, np.array(self.shape) - 1)


def _scene_xml(scene: Scene, mesh: TetMesh, pins: np.ndarray) -> str:
    lat, mat = scene.lattice, scene.lattice.material
    R = lat.orientation.rotation()
    world_extent = np.abs(R) @ mesh.extents
    z_centre = world_extent[2] / 2 + mat.radius_m
    quat = " ".join(f"{v:.8f}" for v in lat.orientation.quat())
    pin_xml = f'<pin id="{" ".join(str(i) for i in pins)}"/>' if pins.size else ""
    dominoes = "\n".join(
        f'<body name="{d.name}" pos="{d.x_m} {d.y_m} {d.height_m / 2}">'
        f'<freejoint name="{d.name}"/>'
        f'<geom name="{d.name}" type="box" size="{d.thickness_m / 2} {d.width_m / 2} {d.height_m / 2}" '
        f'mass="{d.mass_kg}" friction="{d.friction} 0.005 0.0001" rgba="{_domino_rgba(d)}"/>'
        f"</body>"
        for d in scene.dominoes
    )
    plates = actuators = ""
    if scene.squeeze is not None:
        sq = scene.squeeze
        hx, hy, hz = sq.plate_half_m
        # The plates clear the table and the pinned bottom layer, so neither table friction
        # nor world-fixed vertices take the squeeze.
        z_plate = hz + 2 * PIN_HEIGHT_M
        plates = "".join(
            f'<body name="plate_{side}" pos="{lat.x_m} {lat.y_m + sign * sq.park_gap_m / 2} {z_plate}">'
            f'<joint name="plate_{side}" type="slide" axis="0 1 0" damping="1"/>'
            f'<geom name="plate_{side}" type="box" size="{hx} {hy} {hz}" mass="0.1" friction="0.8" '
            f'material="glass"/>'
            f"</body>"
            for side, sign in (("neg", -1), ("pos", 1))
        )
        actuators = "".join(
            f'<position name="plate_{side}" joint="plate_{side}" kp="{sq.kp}" kv="{sq.kv}"/>'
            for side in ("neg", "pos")
        )
    # Cameras, lights and the table grid are laid out in units of the layout's span, fan
    # face to the far domino, so a scaled scene is framed like the full one.
    far_x = max(
        [d.x_m + d.height_m for d in scene.dominoes],
        default=lat.x_m + world_extent[0],
    )
    span = far_x
    look_at = np.array([far_x / 2, 0.0, world_extent[2] / 2])
    block = np.array([lat.x_m, lat.y_m, z_centre])
    # The squeeze plates park half their park gap out to either side, so no camera
    # looks at the block from straight beside it; the plan view looks straight down.
    cameras = {
        "iso": (look_at + span * np.array([-1.0, -0.55, 0.75]), look_at, 40),
        "block": (block + max(world_extent) * np.array([-2.6, -1.2, 1.8]), block, 36),
        "rear": (look_at + span * np.array([0.9, 0.25, 0.7]), look_at, 42),
    }
    camera_xml = "".join(
        f'<camera name="{name}" pos="{p[0]:.5f} {p[1]:.5f} {p[2]:.5f}" '
        f'xyaxes="{_camera_xyaxes(p, target)}" fovy="{fovy}"/>'
        for name, (p, target, fovy) in cameras.items()
    ) + (
        f'<camera name="top" pos="{look_at[0]:.5f} 0 {1.2 * span:.5f}" '
        f'xyaxes="1 0 0 0 1 0" fovy="40"/>'
    )
    key = look_at + span * np.array([-0.4, -0.8, 1.6])
    fill = look_at + span * np.array([1.0, 0.8, 1.0])
    key_dir = " ".join(
        f"{v:.4f}" for v in (look_at - key) / np.linalg.norm(look_at - key)
    )
    fill_dir = " ".join(
        f"{v:.4f}" for v in (look_at - fill) / np.linalg.norm(look_at - fill)
    )
    return f"""
<mujoco model="lattice_wind">
  <option timestep="{scene.timestep_s}" integrator="discrete" solver="CG" iterations="{scene.solver_iterations}" density="0" viscosity="0"/>
  <visual>
    <global offwidth="1920" offheight="1080"/>
    <headlight ambient="0.25 0.25 0.27" diffuse="0.3 0.3 0.3" specular="0.1 0.1 0.1"/>
    <quality shadowsize="4096" offsamples="8"/>
    <rgba haze="0.9 0.93 0.97 1"/>
  </visual>
  <asset>
    <texture name="sky" type="skybox" builtin="gradient" rgb1="0.62 0.72 0.86" rgb2="0.96 0.97 0.99" width="512" height="512"/>
    <texture name="grid" type="2d" builtin="checker" rgb1="0.87 0.86 0.84" rgb2="0.80 0.79 0.77" width="256" height="256"/>
    <material name="table" texture="grid" texuniform="true" texrepeat="{5 / span:.4f} {5 / span:.4f}" reflectance="0.08" specular="0.2" shininess="0.2"/>
    <material name="paint" specular="0.4" shininess="0.5"/>
    <material name="glass" rgba="0.75 0.85 0.95 0.35" specular="0.6" shininess="0.8"/>
    <material name="steel" rgba="0.22 0.23 0.26 1" specular="0.5" shininess="0.6"/>
  </asset>
  <worldbody>
    <light name="key" pos="{key[0]:.4f} {key[1]:.4f} {key[2]:.4f}" dir="{key_dir}" directional="true" castshadow="true" diffuse="0.75 0.73 0.70" specular="0.3 0.3 0.3"/>
    <light name="fill" pos="{fill[0]:.4f} {fill[1]:.4f} {fill[2]:.4f}" dir="{fill_dir}" directional="true" castshadow="false" diffuse="0.25 0.27 0.30" specular="0 0 0"/>
    <geom name="table" type="plane" size="{3 * span:.4f} {2 * span:.4f} 0.02" material="table" friction="{mat.friction} 0.005 0.0001"/>
    {_fan_xml(scene.jet)}
    <flexcomp name="lattice" type="gmsh" file="lattice.msh" dim="3" pos="{lat.x_m} {lat.y_m} {z_centre:.6f}"
              quat="{quat}" mass="{lat.mass_kg}" radius="{mat.radius_m}" rgba="0.95 0.55 0.15 1">
      <edge damping="{mat.edge_damping}"/>
      <elasticity young="{mat.young_pa}" poisson="{mat.poisson}" damping="{mat.damping}"/>
      <contact selfcollide="none" friction="{mat.friction}" priority="1" solref="{CONTACT_TIMECONST_S} 1"/>
      {pin_xml}
    </flexcomp>
    {dominoes}
    {plates}
    {camera_xml}
  </worldbody>
  <actuator>{actuators}</actuator>
</mujoco>"""


def _fan_xml(jet: FanJet) -> str:
    """Visual-only fan: a housing behind the blade plane, a hub and a rim of capsules,
    all in units of the jet radius; the blades are drawn at render time so they can
    turn. Nothing here collides or moves."""
    r, h = jet.radius_m, jet.height_m
    rim = "".join(
        f'<geom type="capsule" fromto="{-0.1 * r:.5f} {1.06 * r * math.cos(a):.5f} {h + 1.06 * r * math.sin(a):.5f} '
        f'{-0.1 * r:.5f} {1.06 * r * math.cos(b):.5f} {h + 1.06 * r * math.sin(b):.5f}" '
        f'size="{0.06 * r:.5f}" material="steel" contype="0" conaffinity="0"/>'
        for a, b in zip(
            np.linspace(0, 2 * math.pi, 25)[:-1],
            np.linspace(0, 2 * math.pi, 25)[1:],
            strict=True,
        )
    )
    return (
        f'<geom name="fan" type="cylinder" pos="{-1.1 * r:.5f} 0 {h}" quat="0.7071068 0 0.7071068 0" '
        f'size="{r} {0.6 * r:.5f}" material="steel" contype="0" conaffinity="0"/>'
        f'<geom name="hub" type="cylinder" pos="{-0.4 * r:.5f} 0 {h}" quat="0.7071068 0 0.7071068 0" '
        f'size="{0.18 * r:.5f} {0.3 * r:.5f}" material="steel" contype="0" conaffinity="0"/>'
        + rim
    )


def _domino_rgba(d: Domino) -> str:
    return "0.2 0.55 0.9 1" if "light" in d.name else "0.75 0.2 0.2 1"


def build(scene: Scene) -> Model:
    mesh_path = Path(scene.lattice.mesh)
    mesh = read_gmsh(mesh_path)
    rest_volumes = mesh.volumes
    if np.any(rest_volumes <= 0):
        raise ValueError(
            f"{mesh_path} has {int((rest_volumes <= 0).sum())} non-positive tetrahedra"
        )
    faces, face_element = mesh.boundary()
    up = _AXIS_VECTORS[scene.lattice.orientation.up]
    height = mesh.nodes @ up
    pins = (
        np.flatnonzero(height <= height.min() + scene.lattice.pin_height_m)
        if scene.lattice.pin_height_m > 0
        else np.array([], dtype=int)
    )
    xml = _scene_xml(scene, mesh, pins)
    mj = mujoco.MjModel.from_xml_string(xml, {"lattice.msh": mesh_path.read_bytes()})
    vertex_bodies = mj.flex_vertbodyid[
        mj.flex_vertadr[0] : mj.flex_vertadr[0] + mj.flex_vertnum[0]
    ].copy()
    vertex_dofs = mj.body_dofadr[vertex_bodies].copy()
    vertex_dofs[vertex_bodies == 0] = -1
    # The vectorised force write assumes each free vertex has three slide joints along the
    # world axes, which is how flexcomp builds a full-dof flex under the worldbody.
    free = vertex_bodies[vertex_dofs >= 0]
    if np.any(mj.body_dofnum[free] != 3) or np.any(mj.body_quat[free] != [1, 0, 0, 0]):
        raise ValueError("lattice vertices are not world-aligned slide bodies")
    dominoes = []
    for d in scene.dominoes:
        body = mujoco.mj_name2id(mj, mujoco.mjtObj.mjOBJ_BODY, d.name)
        geom = mujoco.mj_name2id(mj, mujoco.mjtObj.mjOBJ_GEOM, d.name)
        pts, nrm, areas = _box_faces(mj.geom_size[geom], (2, 3, 6))
        dominoes.append(DominoIndex(body, geom, pts, nrm, areas))
    plates = None
    if scene.squeeze is not None:

        def pair(kind: mujoco.mjtObj) -> tuple[int, int]:
            return mujoco.mj_name2id(mj, kind, "plate_neg"), mujoco.mj_name2id(
                mj, kind, "plate_pos"
            )

        plates = Plates(
            pair(mujoco.mjtObj.mjOBJ_BODY),
            pair(mujoco.mjtObj.mjOBJ_GEOM),
            pair(mujoco.mjtObj.mjOBJ_ACTUATOR),
        )
    air = scene.airflow
    origin = np.array([air.x_range_m[0], air.y_range_m[0], air.z_range_m[0]])
    shape = tuple(
        int(round((hi - lo) / air.cell_m))
        for lo, hi in (air.x_range_m, air.y_range_m, air.z_range_m)
    )
    centres = (
        origin
        + (
            np.stack(np.meshgrid(*[np.arange(n) for n in shape], indexing="ij"), -1)
            + 0.5
        )
        * air.cell_m
    )
    u0 = scene.jet.axial(centres)
    return Model(
        scene=scene,
        mj=mj,
        mesh=mesh,
        mesh_sha256=sha256(mesh_path),
        rest_volumes=rest_volumes,
        faces=faces,
        face_element=face_element,
        vertex_bodies=vertex_bodies,
        vertex_dofs=vertex_dofs,
        dominoes=dominoes,
        table_geom=mujoco.mj_name2id(mj, mujoco.mjtObj.mjOBJ_GEOM, "table"),
        plates=plates,
        u0=u0,
        origin=origin,
        shape=(shape[0], shape[1], shape[2]),
    )


# --------------------------------------------------------------------------------------
# Airflow: a pure function of (model, data) returning the loads for this instant.
# --------------------------------------------------------------------------------------


@dataclass
class Flow:
    """The transmitted-flow field for one instant.

    ``transmission`` is the fraction of the empty-fan speed arriving at each voxel after
    crossing whatever solid lies upstream in its column (exclusive of the voxel itself);
    ``passed`` includes the voxel. ``speed`` is the fan exit speed now.
    """

    speed: float
    transmission: np.ndarray  # [nx, ny, nz]
    passed: np.ndarray  # [nx, ny, nz]
    rear_x: float  # downstream face of the block, where wake mixing starts
    # The block's envelope on the grid: entry slab index and (y, z) cell ranges, and the
    # windward face area the sealing skin covers when ``skin_transmission`` is below 1.
    entry: tuple[int, slice, slice]
    envelope_face_m2: float

    def slab(self, model: Model, x: float) -> np.ndarray:
        """Transmission over (y, z) at downstream position ``x``, blurred by the wake."""
        air = model.scene.airflow
        i = int(np.clip((x - model.origin[0]) / air.cell_m, 0, model.shape[0] - 1))
        sigma = air.mixing * max(0.0, x - self.rear_x) / air.cell_m
        if sigma <= 0:
            return self.passed[i]
        return gaussian_filter(self.passed[i], sigma, mode="constant", cval=1.0)


@dataclass
class Loads:
    """Forces the airflow applies this instant, and the diagnostics behind them."""

    flow: Flow
    vertex_forces: np.ndarray  # [V, 3]
    lattice_force: np.ndarray  # [3] resultant on the lattice
    domino_points: list[np.ndarray]  # per domino [S, 3] world sample positions
    domino_forces: list[np.ndarray]  # per domino [S, 3]


def lattice_state(model: Model, data: mujoco.MjData) -> tuple[np.ndarray, np.ndarray]:
    """Vertex positions and velocities, [V, 3] each."""
    adr, num = model.mj.flex_vertadr[0], model.mj.flex_vertnum[0]
    positions = data.flexvert_xpos[adr : adr + num]
    velocities = data.cvel[model.vertex_bodies, 3:]
    return positions, velocities


def _occluder_boxes(
    model: Model, data: mujoco.MjData
) -> list[tuple[np.ndarray, np.ndarray]]:
    """World AABBs of rigid bodies the air cannot pass: the squeeze plates."""
    if model.plates is None:
        return []
    boxes = []
    for geom in model.plates.geoms:
        half = np.abs(data.geom_xmat[geom].reshape(3, 3)) @ model.mj.geom_size[geom]
        boxes.append((data.geom_xpos[geom] - half, data.geom_xpos[geom] + half))
    return boxes


def flow_field(model: Model, data: mujoco.MjData) -> Flow:
    air = model.scene.airflow
    positions, _ = lattice_state(model, data)
    centroids = positions[model.mesh.tets].mean(axis=1)
    idx, inside = model.voxel(centroids)
    flat = np.ravel_multi_index(idx[inside].T, model.shape)
    # Element volume deposited per voxel over the column's cross-section is the solid
    # path length the column's air crosses in that voxel, whatever the cell size.
    solid_length = np.bincount(
        flat, weights=model.rest_volumes[inside], minlength=int(np.prod(model.shape))
    )
    solid_length = solid_length.reshape(model.shape) / air.cell_m**2
    factor = np.exp(-air.attenuation_per_m * solid_length)
    low, high = positions.min(0), positions.max(0)
    lo, hi = model.clamp(model.voxel(low)[0]), model.clamp(model.voxel(high)[0])
    entry: tuple[int, slice, slice] = (
        int(lo[0]),
        slice(lo[1], hi[1] + 1),
        slice(lo[2], hi[2] + 1),
    )
    # A skin on the envelope scales what enters the block, struts of the entry slab
    # included; the skin itself takes the load in :func:`loads`.
    factor[entry] *= air.skin_transmission
    for box_lo, box_hi in _occluder_boxes(model, data):
        a, b = model.voxel(box_lo)[0], model.voxel(box_hi)[0]
        a, b = np.maximum(a, 0), np.minimum(b, np.array(model.shape) - 1)
        if np.all(b >= a):
            factor[a[0] : b[0] + 1, a[1] : b[1] + 1, a[2] : b[2] + 1] = 0.0
    passed = np.cumprod(factor, axis=0)
    transmission = np.empty_like(passed)
    transmission[0] = 1.0
    transmission[1:] = passed[:-1]
    transmission[entry] *= air.skin_transmission
    return Flow(
        speed=model.scene.fan.speed(float(data.time)),
        transmission=transmission,
        passed=passed,
        rear_x=float(high[0]),
        entry=entry,
        envelope_face_m2=float((high[1] - low[1]) * (high[2] - low[2])),
    )


def _drag(density: float, cd: float, area: np.ndarray, u_rel: np.ndarray) -> np.ndarray:
    """Quadratic drag ½ ρ C_D A |u| u for relative air velocities ``u_rel`` [N, 3]."""
    magnitude = np.linalg.norm(u_rel, axis=-1, keepdims=True)
    return 0.5 * density * cd * area[:, None] * magnitude * u_rel


def loads(model: Model, data: mujoco.MjData) -> Loads:
    air = model.scene.airflow
    flow = flow_field(model, data)
    positions, velocities = lattice_state(model, data)
    tets = model.mesh.tets
    centroids = positions[tets].mean(axis=1)
    element_velocity = velocities[tets].mean(axis=1)
    idx, inside = model.voxel(centroids)
    incident = np.zeros(len(tets))
    flat = tuple(idx[inside].T)
    incident[inside] = flow.speed * model.u0[flat] * flow.transmission[flat]
    u_rel = incident[:, None] * X_HAT - element_velocity
    # Each element is loaded over its boundary triangles that face the relative flow,
    # projected onto it: the windward surface of the struts as the mesh resolves it,
    # independent of the airflow grid.
    a, b, c = (positions[model.faces[:, i]] for i in range(3))
    face_normal = 0.5 * np.cross(b - a, c - a)
    owner_flow = u_rel[model.face_element]
    direction = owner_flow / np.maximum(
        np.linalg.norm(owner_flow, axis=1, keepdims=True), 1e-12
    )
    windward = np.maximum(0.0, -np.einsum("ij,ij->i", face_normal, direction))
    area = np.bincount(model.face_element, weights=windward, minlength=len(tets))
    element_force = _drag(air.density, air.lattice_cd, area, u_rel)
    vertex_forces = np.zeros((len(positions), 3))
    for corner in range(4):
        for axis in range(3):
            vertex_forces[:, axis] += np.bincount(
                tets[:, corner],
                weights=element_force[:, axis] / 4,
                minlength=len(positions),
            )
    lattice_force = element_force.sum(axis=0)
    if air.skin_transmission < 1.0:
        # The sealing skin is a plate over the envelope's windward face, loaded by the
        # flow arriving at the entry slab and carried by the vertices of that slab.
        i, ys, zs = flow.entry
        upstream = (
            flow.passed[i - 1, ys, zs] if i > 0 else np.ones_like(model.u0[i, ys, zs])
        )
        arriving = flow.speed * model.u0[i, ys, zs] * upstream
        front = positions[:, 0] < positions[:, 0].min() + air.cell_m
        velocity = velocities[front].mean(axis=0)
        u_rel = float(np.sqrt(np.mean(arriving**2))) * X_HAT - velocity
        covered = (1.0 - air.skin_transmission) * flow.envelope_face_m2
        skin_force = _drag(
            air.density, air.lattice_cd, np.array([covered]), u_rel[None]
        )[0]
        vertex_forces[front] += skin_force / int(front.sum())
        lattice_force = lattice_force + skin_force
    domino_points, domino_forces = [], []
    for dom in model.dominoes:
        R = data.xmat[dom.body].reshape(3, 3)
        points = data.xpos[dom.body] + dom.points @ R.T
        normals = dom.normals @ R.T
        omega, v_com = data.cvel[dom.body, :3], data.cvel[dom.body, 3:]
        v = v_com + np.cross(omega, points - data.subtree_com[dom.body])
        slab = flow.slab(model, float(data.xpos[dom.body, 0]))
        pidx, pinside = model.voxel(points)
        u = np.zeros(len(points))
        u[pinside] = (
            flow.speed
            * model.u0[tuple(pidx[pinside].T)]
            * slab[pidx[pinside, 1], pidx[pinside, 2]]
        )
        u_rel = u[:, None] * X_HAT - v
        magnitude = np.linalg.norm(u_rel, axis=1)
        direction = u_rel / np.maximum(magnitude, 1e-12)[:, None]
        projected = np.maximum(0.0, -np.einsum("ij,ij->i", normals, direction))
        domino_points.append(points)
        domino_forces.append(
            _drag(air.density, air.domino_cd, dom.areas * projected, u_rel)
        )
    return Loads(
        flow=flow,
        vertex_forces=vertex_forces,
        lattice_force=lattice_force,
        domino_points=domino_points,
        domino_forces=domino_forces,
    )


def apply_loads(model: Model, data: mujoco.MjData, current: Loads) -> None:
    """Write ``current`` into ``data.qfrc_applied``; this module owns all applied forces."""
    data.qfrc_applied[:] = 0.0
    data.xfrc_applied[:] = 0.0
    free = model.vertex_dofs >= 0
    dofs = model.vertex_dofs[free]
    forces = current.vertex_forces[free]
    for axis in range(3):
        data.qfrc_applied[dofs + axis] += forces[:, axis]
    zero = np.zeros(3)
    for dom, points, forces_d in zip(
        model.dominoes, current.domino_points, current.domino_forces, strict=True
    ):
        for point, force in zip(points, forces_d, strict=True):
            if force.any():
                mujoco.mj_applyFT(
                    model.mj, data, force, zero, point, dom.body, data.qfrc_applied
                )


class AirflowCallback:
    """The control callback: airflow loads every time MuJoCo evaluates forward dynamics.

    Install around a whole episode, or around every candidate rollout from a snapshot;
    registration is process-global, so only one scene may be stepped at a time and the
    scene is stepped in its own process when a planner needs many.
    """

    def __init__(self, model: Model):
        self.model = model
        self.last: Loads | None = None

    def __call__(self, mj: mujoco.MjModel, data: mujoco.MjData) -> None:
        self.last = loads(self.model, data)
        apply_loads(self.model, data, self.last)

    def __enter__(self) -> AirflowCallback:
        if mujoco.get_mjcb_control() is not None:
            raise RuntimeError(
                "another control callback is installed; airflow cannot compose with it"
            )
        mujoco.set_mjcb_control(self)
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        mujoco.set_mjcb_control(None)


def plate_targets(squeeze: Squeeze, gap: float) -> np.ndarray:
    """Joint targets putting the plates' inner faces at y = ±gap/2."""
    travel = squeeze.park_gap_m / 2 - gap / 2 - squeeze.plate_half_m[1]
    return np.array([travel, -travel])


def set_controls(model: Model, data: mujoco.MjData) -> None:
    if model.scene.squeeze is None:
        return
    assert model.plates is not None
    data.ctrl[list(model.plates.actuators)] = plate_targets(
        model.scene.squeeze, model.scene.squeeze.gap(float(data.time))
    )


# --------------------------------------------------------------------------------------
# Observations, diagnostics, recordings and acceptance.
# --------------------------------------------------------------------------------------


@dataclass(frozen=True)
class BlockShape:
    """The lattice's pose and extents along its tracked material axes.

    This is the privileged geometric sensor the pilot gives the agent: a best-fit rigid
    rotation of the rest mesh onto the current vertices, and the extents measured along
    those rotated axes. Sorting extents would lose which material axis is which.
    """

    centre: np.ndarray  # [3]
    rotation: np.ndarray  # [3, 3] world-from-material
    extents: np.ndarray  # [3] along material x, y, z


def block_shape(model: Model, positions: np.ndarray) -> BlockShape:
    rest = model.mesh.nodes - model.mesh.nodes.mean(axis=0)
    centre = positions.mean(axis=0)
    H = rest.T @ (positions - centre)
    U, _, Vt = np.linalg.svd(H)
    R = (U @ Vt).T
    if np.linalg.det(R) < 0:
        U[:, -1] *= -1
        R = (U @ Vt).T
    local = (positions - centre) @ R
    return BlockShape(centre, R, local.max(axis=0) - local.min(axis=0))


def tilt_rad(xmat: np.ndarray) -> float:
    """Angle between a body's z axis and vertical."""
    return float(np.arccos(np.clip(xmat.reshape(3, 3)[2, 2], -1.0, 1.0)))


def domino_contacts(model: Model, data: mujoco.MjData) -> list[bool]:
    """Per domino, whether anything but the table touches it now."""
    touched = [False] * len(model.dominoes)
    geoms = data.contact.geom[: data.ncon]
    for g1, g2 in geoms:
        for k, dom in enumerate(model.dominoes):
            if dom.geom in (g1, g2):
                other = g2 if g1 == dom.geom else g1
                if other != model.table_geom:
                    touched[k] = True
    return touched


def block_in_region(model: Model, positions: np.ndarray) -> bool:
    lat = model.scene.lattice
    centre = positions.mean(axis=0)
    return bool(
        abs(centre[0] - lat.x_m) <= lat.region_half_m[0]
        and abs(centre[1] - lat.y_m) <= lat.region_half_m[1]
    )


def station_speeds(model: Model, flow: Flow, x: float) -> np.ndarray:
    """Axial air speed over the (y, z) grid at downstream position ``x``."""
    i = int(model.clamp(model.voxel(np.array([x, 0.0, 0.0]))[0])[0])
    return flow.speed * model.u0[i] * flow.slab(model, x)


def through_flux(
    model: Model,
    flow: Flow,
    positions: np.ndarray,
    domino: DominoIndex,
    data: mujoco.MjData,
) -> float:
    """Volume flux (m^3/s) leaving the block's rear face on the columns that feed ``domino``.

    Columns are the voxel cells whose (y, z) lie both inside the block's lateral footprint
    and inside the domino's windward face footprint. The sealed control makes this zero.
    """
    air = model.scene.airflow
    lo, hi = positions.min(0), positions.max(0)
    half = model.mj.geom_size[domino.geom]
    d_pos = data.xpos[domino.body]
    y_lo, y_hi = max(lo[1], d_pos[1] - half[1]), min(hi[1], d_pos[1] + half[1])
    z_lo, z_hi = max(lo[2], 0.0), min(hi[2], d_pos[2] + half[2])
    if y_hi <= y_lo or z_hi <= z_lo:
        return 0.0
    i, j0, k0 = model.clamp(model.voxel(np.array([hi[0], y_lo, z_lo]))[0])
    _, j1, k1 = model.clamp(model.voxel(np.array([hi[0], y_hi, z_hi]))[0])
    cells = (slice(j0, j1 + 1), slice(k0, k1 + 1))
    speeds = flow.speed * model.u0[i][cells] * flow.passed[i][cells]
    return float(speeds.sum() * air.cell_m**2)


def rear_transmission(model: Model, flow: Flow, positions: np.ndarray) -> float:
    """Mean transmission over the block's rear face: the open-path share of its footprint."""
    lo = model.clamp(model.voxel(positions.min(0))[0])
    hi = model.clamp(model.voxel(positions.max(0))[0])
    return float(flow.passed[hi[0], lo[1] : hi[1] + 1, lo[2] : hi[2] + 1].mean())


@dataclass
class Recording:
    """Everything an episode measured, at ``Scene.record_hz``.

    Observations the agent may see: ``time_s``, ``block_centre_m``, ``block_rotation``,
    ``lattice_dimensions_m``, ``domino_fall_rad``, ``domino_pos_m``, ``plate_gap_m``.
    Evaluator diagnostics: ``cube_force_N``, ``through_flux_m3ps``,
    ``rear_transmission`` (mean transmission over the block's rear face),
    ``downstream_velocity_mps`` (at ``Scene.stations_m`` past the block's rear face, on
    the (y, z) grid), ``domino_touched`` and ``block_in_region``. ``reference_state``
    is the full physics state (time, qpos, qvel) at ``reference_frame``, the first frame
    at peak fan speed, so a fit can re-evaluate the airflow closure in the deformed,
    moving scene it saw, plates included. ``mesh_sha256`` names the lattice file the
    episode was built from; :func:`rebuild` refuses a different file at the same path.
    ``qpos`` is kept only when ``replay`` was requested, for rendering.
    """

    scene: Scene
    mesh_sha256: str
    time_s: np.ndarray
    block_centre_m: np.ndarray
    block_rotation: np.ndarray
    lattice_dimensions_m: np.ndarray
    domino_fall_rad: np.ndarray  # [T, D]
    domino_pos_m: np.ndarray  # [T, D, 3]
    plate_gap_m: np.ndarray
    plate_force_N: np.ndarray  # [T, 2] actuator forces on the plates
    fan_speed_mps: np.ndarray
    cube_force_N: np.ndarray
    through_flux_m3ps: np.ndarray  # [T, D]
    rear_transmission: np.ndarray  # [T]
    downstream_velocity_mps: np.ndarray  # [T, stations, ny, nz]
    domino_touched: np.ndarray  # [T, D] bool
    # Extremes over the physics steps since the previous frame, for acceptance: the
    # greatest tilt over every step, and over the steps inside the settling window only
    # (NaN when a frame covered none) the least tilt and the greatest drift.
    domino_fall_max_rad: np.ndarray  # [T, D]
    settling_fall_min_rad: np.ndarray  # [T, D]
    settling_drift_max_m: np.ndarray  # [T, D]
    gust_flux_max_m3ps: np.ndarray  # [T, D], gust steps only
    block_in_region: np.ndarray  # [T] bool
    reference_frame: int
    reference_state: np.ndarray  # mjSTATE_FULLPHYSICS at reference_frame
    qpos: np.ndarray | None
    wall_s: float
    versions: dict[str, str] = field(default_factory=dict)

    def save(self, path: Path) -> None:
        payload: dict[str, Any] = {
            k: v
            for k, v in dataclasses.asdict(self).items()
            if isinstance(v, np.ndarray)
        }
        payload.update(
            scene_json=np.array(self.scene.to_json()),
            mesh_sha256=np.array(self.mesh_sha256),
            versions_json=np.array(json.dumps(self.versions)),
            wall_s=np.array(self.wall_s),
            reference_frame=np.array(self.reference_frame),
        )
        np.savez_compressed(path, **payload)

    @classmethod
    def load(cls, path: Path) -> Recording:
        with np.load(path, allow_pickle=False) as z:
            arrays = {k: z[k] for k in z.files}
        scene = Scene.from_json(str(arrays.pop("scene_json")))
        mesh_sha256 = str(arrays.pop("mesh_sha256"))
        versions = json.loads(str(arrays.pop("versions_json")))
        wall = float(arrays.pop("wall_s"))
        reference = int(arrays.pop("reference_frame"))
        qpos = arrays.pop("qpos", None)
        return cls(
            scene=scene,
            mesh_sha256=mesh_sha256,
            reference_frame=reference,
            qpos=qpos,
            wall_s=wall,
            versions=versions,
            **arrays,
        )


def rebuild(rec: Recording) -> Model:
    """The recording's scene, built from the same lattice file it was made with."""
    model = build(rec.scene)
    if model.mesh_sha256 != rec.mesh_sha256:
        raise ValueError(
            f"{rec.scene.lattice.mesh} is not the mesh this recording was made with "
            f"(sha256 {model.mesh_sha256[:12]} vs {rec.mesh_sha256[:12]})"
        )
    return model


@dataclass(frozen=True)
class Verdict:
    """The task acceptance criteria, each judged over the post-gust settling window."""

    light_fell: bool
    heavy_stood: bool
    no_contact: bool
    block_in_region: bool
    through_flux: bool
    light_max_fall_deg: float
    heavy_max_fall_deg: float
    heavy_drift_m: float
    peak_flux_light_m3ps: float

    @property
    def accepted(self) -> bool:
        return (
            self.light_fell
            and self.heavy_stood
            and self.no_contact
            and self.block_in_region
            and self.through_flux
        )


def judge(rec: Recording, light: str = "light", heavy: str = "heavy") -> Verdict:
    names = [d.name for d in rec.scene.dominoes]
    li, hi = names.index(light), names.index(heavy)
    acc = rec.scene.acceptance
    # The recorder accumulated the settling-window extremes on exactly the physics
    # steps inside the window, so the verdict does not depend on the recording rate;
    # NaN marks frames that covered no window step.
    settling_min = np.degrees(rec.settling_fall_min_rad[:, li])
    settling_drift = rec.settling_drift_max_m[:, hi]
    fall_max = np.degrees(rec.domino_fall_max_rad)
    seen = ~np.isnan(settling_min)
    gust_flux = rec.gust_flux_max_m3ps[:, li]
    peak_flux = float(np.nanmax(gust_flux)) if (~np.isnan(gust_flux)).any() else 0.0
    # Contacts, the heavy domino's tilt and the block's region are judged over the whole
    # episode: a plate that knocks a domino during preparation must not be laundered by
    # the gust.
    return Verdict(
        light_fell=bool(seen.any() and np.all(settling_min[seen] >= acc.fallen_deg)),
        heavy_stood=bool(
            np.all(fall_max[:, hi] <= acc.upright_deg)
            and seen.any()
            and np.all(settling_drift[seen] <= acc.footprint_m)
        ),
        no_contact=not bool(rec.domino_touched.any()),
        block_in_region=bool(rec.block_in_region.all()),
        through_flux=peak_flux > 0.0,
        light_max_fall_deg=float(fall_max[:, li].max()),
        heavy_max_fall_deg=float(fall_max[:, hi].max()),
        heavy_drift_m=float(np.nanmax(settling_drift)) if seen.any() else 0.0,
        peak_flux_light_m3ps=peak_flux,
    )


# --------------------------------------------------------------------------------------
# Stepping.
# --------------------------------------------------------------------------------------


def versions() -> dict[str, str]:
    return {
        "mujoco": mujoco.__version__,
        "numpy": np.__version__,
        "python": sys.version.split()[0],
    }


@dataclass
class Frame:
    """What a recorded frame carries besides the state: the loads at that instant, and
    what the acceptance criteria need from every physics step since the previous frame:
    per domino whether anything but the table touched it, its greatest tilt over all
    those steps, its least tilt and greatest drift over the steps that fell inside the
    settling window (NaN when none did), and whether the block stayed inside its region
    throughout."""

    loads: Loads
    touched: list[bool]
    fall_max: np.ndarray  # [D] rad, every step
    settling_fall_min: np.ndarray  # [D] rad, settling-window steps only
    settling_drift_max: np.ndarray  # [D] m, settling-window steps only
    gust_flux_max: (
        np.ndarray
    )  # [D] m^3/s through the lattice towards each domino, gust steps only
    block_inside: bool


def episode_frames(
    model: Model, data: mujoco.MjData, callback: AirflowCallback, duration_s: float
) -> Iterator[Frame]:
    """Step to ``duration_s``, yielding every recorded frame."""
    scene = model.scene
    every = max(1, int(round(1.0 / (scene.record_hz * scene.timestep_s))))
    steps = int(round(duration_s / scene.timestep_s))
    # A physics step belongs to the settling window when its time lies within half a
    # step of it, so a zero settle time still judges the step at the end of the gust.
    half_step = scene.timestep_s / 2
    settling_end = scene.fan.end_s + scene.acceptance.settle_s + half_step
    settling = (scene.fan.end_s - half_step, settling_end)
    gust = (scene.fan.on_s - half_step, scene.fan.end_s + half_step)
    count = len(model.dominoes)
    touched = [False] * count
    fall_max = np.zeros(count)
    settling_fall_min = np.full(count, np.nan)
    settling_drift_max = np.full(count, np.nan)
    gust_flux_max = np.full(count, np.nan)
    inside = True
    start_xy: np.ndarray | None = None

    def note(time: float) -> None:
        """Observe the state MuJoCo's kinematics currently describe, which is the state
        at ``time``: after ``mj_step`` the clock has advanced but positions, contacts
        and the callback's loads still belong to the step that was just integrated."""
        nonlocal inside, start_xy
        positions, _ = lattice_state(model, data)
        for i, now in enumerate(domino_contacts(model, data)):
            touched[i] = touched[i] or now
        inside = inside and block_in_region(model, positions)
        tilt = np.array([tilt_rad(data.xmat[d.body]) for d in model.dominoes])
        xy = np.array([data.xpos[d.body, :2] for d in model.dominoes]).reshape(count, 2)
        if start_xy is None:
            start_xy = xy.copy()
        np.maximum(fall_max, tilt, out=fall_max)
        if settling[0] <= time <= settling[1]:
            np.fmin(settling_fall_min, tilt, out=settling_fall_min)
            drift = np.linalg.norm(xy - start_xy, axis=1)
            np.fmax(settling_drift_max, drift, out=settling_drift_max)
        if gust[0] <= time <= gust[1]:
            assert callback.last is not None, "airflow callback has not run this step"
            flow = callback.last.flow
            flux = [
                through_flux(model, flow, positions, d, data) for d in model.dominoes
            ]
            np.fmax(gust_flux_max, np.array(flux).reshape(count), out=gust_flux_max)

    for k in range(steps + 1):
        # The final state is always a frame, so nothing that happened after the last
        # regular frame goes unrecorded.
        framed = k % every == 0 or k == steps
        if framed:
            set_controls(model, data)
            mujoco.mj_forward(model.mj, data)
            note(float(data.time))
            assert callback.last is not None
            yield Frame(
                loads=callback.last,
                touched=touched,
                fall_max=fall_max.copy(),
                settling_fall_min=settling_fall_min.copy(),
                settling_drift_max=settling_drift_max.copy(),
                gust_flux_max=gust_flux_max.copy(),
                block_inside=inside,
            )
            touched = [False] * count
            fall_max.fill(0.0)
            settling_fall_min.fill(np.nan)
            settling_drift_max.fill(np.nan)
            gust_flux_max.fill(np.nan)
            inside = True
        if k < steps:
            set_controls(model, data)
            mujoco.mj_step(model.mj, data)
            # A step that started from a frame's state has nothing new to observe:
            # the state it describes went into that frame, not the next one.
            if not framed:
                note(float(data.time) - scene.timestep_s)


def run_episode(
    scene: Scene, *, replay: bool = False, progress: bool = False
) -> Recording:
    model = build(scene)
    data = mujoco.MjData(model.mj)
    per_episode = (
        "scene",
        "mesh_sha256",
        "wall_s",
        "versions",
        "reference_frame",
        "reference_state",
    )
    frames: dict[str, list] = {
        k: [] for k in Recording.__dataclass_fields__ if k not in per_episode
    }
    stations = scene.stations_m
    reference_frame, reference_state = 0, np.zeros(0)
    t0 = time.perf_counter()
    with AirflowCallback(model) as callback:
        for k, frame in enumerate(
            episode_frames(model, data, callback, scene.duration_s)
        ):
            current = frame.loads
            positions, _ = lattice_state(model, data)
            if k == 0 or current.flow.speed > frames["fan_speed_mps"][reference_frame]:
                reference_frame, reference_state = k, snapshot(model, data)
            shape = block_shape(model, positions)
            frames["time_s"].append(float(data.time))
            frames["block_centre_m"].append(shape.centre)
            frames["block_rotation"].append(shape.rotation)
            frames["lattice_dimensions_m"].append(shape.extents)
            frames["domino_fall_rad"].append(
                [tilt_rad(data.xmat[d.body]) for d in model.dominoes]
            )
            frames["domino_pos_m"].append(
                [data.xpos[d.body].copy() for d in model.dominoes]
            )
            gap = np.nan
            force = np.full(2, np.nan)
            if scene.squeeze is not None:
                assert model.plates is not None
                neg, pos = model.plates.bodies
                gap = (
                    float(data.xpos[pos, 1] - data.xpos[neg, 1])
                    - 2 * scene.squeeze.plate_half_m[1]
                )
                force = data.actuator_force[list(model.plates.actuators)].copy()
            frames["plate_gap_m"].append(gap)
            frames["plate_force_N"].append(force)
            frames["fan_speed_mps"].append(current.flow.speed)
            frames["cube_force_N"].append(current.lattice_force)
            frames["through_flux_m3ps"].append(
                [
                    through_flux(model, current.flow, positions, d, data)
                    for d in model.dominoes
                ]
            )
            frames["rear_transmission"].append(
                rear_transmission(model, current.flow, positions)
            )
            frames["downstream_velocity_mps"].append(
                np.stack(
                    [
                        station_speeds(model, current.flow, current.flow.rear_x + s)
                        for s in stations
                    ]
                ).astype(np.float16)
            )
            frames["domino_touched"].append(frame.touched)
            frames["domino_fall_max_rad"].append(frame.fall_max)
            frames["settling_fall_min_rad"].append(frame.settling_fall_min)
            frames["settling_drift_max_m"].append(frame.settling_drift_max)
            frames["gust_flux_max_m3ps"].append(frame.gust_flux_max)
            frames["block_in_region"].append(frame.block_inside)
            if replay:
                frames["qpos"].append(data.qpos.astype(np.float32))
            if progress and k % int(scene.record_hz) == 0:
                print(
                    f"  t={data.time:5.2f}s fan={current.flow.speed:5.2f} m/s "
                    f"falls={np.degrees(frames['domino_fall_rad'][-1]).round(0).tolist()}",
                    flush=True,
                )
    arrays = {k: np.asarray(v) for k, v in frames.items() if k != "qpos"}
    return Recording(
        scene=scene,
        mesh_sha256=model.mesh_sha256,
        reference_frame=reference_frame,
        reference_state=reference_state,
        qpos=np.asarray(frames["qpos"]) if replay else None,
        wall_s=time.perf_counter() - t0,
        versions=versions(),
        **arrays,
    )


def rollout(model: Model, state0: np.ndarray, controls: np.ndarray) -> np.ndarray:
    """Open-loop rollout from a full-physics snapshot: ``controls`` [T, nu] gives the
    plate targets per step, and the result is qpos [T, nq]. The same physics the episode
    runs, in the form a planner's candidate evaluation calls it."""
    data = mujoco.MjData(model.mj)
    mujoco.mj_setState(model.mj, data, state0, FULL_PHYSICS)
    out = np.empty((len(controls), model.mj.nq))
    with AirflowCallback(model):
        for t, u in enumerate(controls):
            data.ctrl[:] = u
            mujoco.mj_step(model.mj, data)
            out[t] = data.qpos
    return out


FULL_PHYSICS = int(mujoco.mjtState.mjSTATE_FULLPHYSICS)


def snapshot(model: Model, data: mujoco.MjData) -> np.ndarray:
    state = np.empty(mujoco.mj_stateSize(model.mj, FULL_PHYSICS))
    mujoco.mj_getState(model.mj, data, state, FULL_PHYSICS)
    return state


# --------------------------------------------------------------------------------------
# Rendering a recording.
# --------------------------------------------------------------------------------------


# Air moves at metres per second across a layout a few decimetres long, so markers at
# the closure's speed would cross a video frame between two images. Tracers and the fan
# blades are drawn at this fraction of the air speed; the bodies move in real time.
TRACER_SLOWDOWN = 20.0
TRACERS_PER_FRAME = 40.0  # seeded at the fan exit per frame at full fan speed
VIEWS = (("iso", "top"), ("block", "rear"))  # rows of the rendered grid
CLEAR_VIEWS = frozenset({"block"})  # the close-up shows the lattice, not the air


@dataclass
class Tracers:
    """Massless markers of the closure's speed field, for rendering only: seeded over
    the fan exit, carried downstream at the local transmitted speed (with the wake
    blurred the way :meth:`Flow.slab` sees it), dropped where the air stops or leaves
    the grid. Their length and brightness follow the local speed."""

    model: Model
    rng: np.random.Generator
    pos: np.ndarray = field(default_factory=lambda: np.zeros((0, 3)))
    speed: np.ndarray = field(default_factory=lambda: np.zeros(0))

    def advance(self, flow: Flow, dt: float) -> None:
        model, air, jet = self.model, self.model.scene.airflow, self.model.scene.jet
        u_ref = model.scene.fan.speed_mps
        if u_ref <= 0:
            return
        xs = model.origin[0] + (np.arange(model.shape[0]) + 0.5) * air.cell_m
        field_u = flow.speed * model.u0 * np.stack([flow.slab(model, x) for x in xs])
        count = self.rng.poisson(TRACERS_PER_FRAME * flow.speed / u_ref)
        radius = 0.9 * jet.radius_m * np.sqrt(self.rng.random(count))
        angle = self.rng.uniform(0.0, 2 * np.pi, count)
        seeds = np.column_stack(
            [
                np.full(count, model.origin[0] + 0.5 * air.cell_m),
                radius * np.cos(angle),
                jet.height_m + radius * np.sin(angle),
            ]
        )
        pos = np.vstack([self.pos, seeds])
        idx, inside = model.voxel(pos)
        local = np.zeros(len(pos))
        local[inside] = field_u[tuple(model.clamp(idx[inside]).T)]
        pos[:, 0] += local * dt / TRACER_SLOWDOWN
        keep = inside & (local > 0.03 * u_ref)
        self.pos, self.speed = pos[keep], local[keep]

    def draw(self, view: mujoco.MjvScene) -> None:
        jet = self.model.scene.jet
        u_ref = self.model.scene.fan.speed_mps
        for p, u in zip(self.pos, self.speed, strict=True):
            if view.ngeom >= view.maxgeom:
                return
            strength = min(1.0, u / u_ref)
            half = jet.radius_m * (0.03 + 0.15 * strength)
            geom = view.geoms[view.ngeom]
            mujoco.mjv_initGeom(
                geom,
                mujoco.mjtGeom.mjGEOM_CAPSULE,
                np.zeros(3),
                np.zeros(3),
                np.eye(3).ravel(),
                np.array([0.55, 0.75, 1.0, 0.10 + 0.5 * strength], dtype=np.float32),
            )
            mujoco.mjv_connector(
                geom,
                mujoco.mjtGeom.mjGEOM_CAPSULE,
                0.018 * jet.radius_m,
                p - [half, 0.0, 0.0],
                p + [half, 0.0, 0.0],
            )
            view.ngeom += 1


def draw_blades(view: mujoco.MjvScene, jet: FanJet, angle: float) -> None:
    """Three pitched blades on the fan hub at rotor ``angle`` about the jet axis."""
    r = jet.radius_m
    centre = np.array([-0.25 * r, 0.0, jet.height_m])
    pitch = 0.5
    twist = np.array(
        [
            [math.cos(pitch), -math.sin(pitch), 0.0],
            [math.sin(pitch), math.cos(pitch), 0.0],
            [0.0, 0.0, 1.0],
        ]
    )
    for i in range(3):
        phi = angle + i * 2 * math.pi / 3
        spin = np.array(
            [
                [1.0, 0.0, 0.0],
                [0.0, math.cos(phi), -math.sin(phi)],
                [0.0, math.sin(phi), math.cos(phi)],
            ]
        )
        if view.ngeom >= view.maxgeom:
            return
        mujoco.mjv_initGeom(
            view.geoms[view.ngeom],
            mujoco.mjtGeom.mjGEOM_BOX,
            np.array([0.03 * r, 0.16 * r, 0.36 * r]),
            centre + spin @ np.array([0.0, 0.0, 0.58 * r]),
            (spin @ twist).ravel(),
            np.array([0.16, 0.16, 0.18, 1.0], dtype=np.float32),
        )
        view.ngeom += 1


def render(
    rec: Recording, out: Path, fps: int = 30, width: int = 960, height: int = 540
) -> None:
    """A ``VIEWS`` grid of the replay, with the air tracers and the turning blades at
    ``TRACER_SLOWDOWN``; ``width`` and ``height`` are per view."""
    import mediapy  # noqa: PLC0415  # rendering is optional on the physics hosts

    if rec.qpos is None:
        raise ValueError("recording has no qpos; run the episode with replay=True")
    model = rebuild(rec)
    data = mujoco.MjData(model.mj)
    # Frames are picked by recorded time, since the recorder rounds its interval to
    # whole physics steps and the nominal rate would drift the playback speed.
    wanted = np.arange(0.0, rec.time_s[-1] + 0.5 / fps, 1.0 / fps)
    picks = np.unique(np.searchsorted(rec.time_s, wanted).clip(0, len(rec.time_s) - 1))
    tracers = Tracers(model, np.random.default_rng(0))
    angle = 0.0
    frames = []
    with mujoco.Renderer(model.mj, height=height, width=width) as renderer:
        for k in picks:
            data.qpos[:] = rec.qpos[k]
            data.time = rec.time_s[k]
            mujoco.mj_forward(model.mj, data)
            flow = flow_field(model, data)
            tracers.advance(flow, 1.0 / fps)
            angle += flow.speed / model.scene.jet.radius_m / TRACER_SLOWDOWN / fps
            rows = []
            for row in VIEWS:
                views = []
                for cam in row:
                    renderer.update_scene(data, camera=cam)
                    draw_blades(renderer.scene, model.scene.jet, angle)
                    if cam not in CLEAR_VIEWS:
                        tracers.draw(renderer.scene)
                    views.append(renderer.render().copy())
                rows.append(np.concatenate(views, axis=1))
            frames.append(np.concatenate(rows, axis=0))
    out.parent.mkdir(parents=True, exist_ok=True)
    mediapy.write_video(out, frames, fps=fps)


# --------------------------------------------------------------------------------------
# The demonstration scenes.
# --------------------------------------------------------------------------------------

OPEN = Orientation(
    downstream="+z", up="+y"
)  # print direction into the wind: open channels
CLOSED = Orientation(downstream="+x", up="+z")  # the ball's long axis into the wind


def dominoes(
    light_y: float = 0.02, heavy_y: float = -0.02, x: float = 0.45
) -> tuple[Domino, Domino]:
    return (Domino("light", 0.012, x, light_y), Domino("heavy", 0.060, x, heavy_y))


def default_scene(mesh: Path, mass_kg: float, orientation: Orientation = OPEN) -> Scene:
    return Scene(
        lattice=Lattice(str(mesh), mass_kg, orientation=orientation),
        dominoes=dominoes(),
    )


def scaled(scene: Scene, factor: float) -> Scene:
    """The scene's geometry shrunk by ``factor`` around the fan outlet, for a block cut
    smaller than the slab: lengths scale with the factor, rigid masses with its cube, the
    attenuation per metre with its inverse so a block of the same lattice keeps the same
    transmission across its own thickness, and the fan speed with its square root so
    drag (area times speed squared) keeps its ratio to the tipping thresholds (mass
    times length). Times and the lattice itself are left alone."""
    s = factor

    def domino(d: Domino) -> Domino:
        return replace(
            d,
            mass_kg=d.mass_kg * s**3,
            x_m=d.x_m * s,
            y_m=d.y_m * s,
            thickness_m=d.thickness_m * s,
            width_m=d.width_m * s,
            height_m=d.height_m * s,
        )

    air = scene.airflow
    squeeze = scene.squeeze
    if squeeze is not None:
        squeeze = replace(
            squeeze,
            gap_m=squeeze.gap_m * s,
            park_gap_m=squeeze.park_gap_m * s,
            plate_half_m=(
                squeeze.plate_half_m[0] * s,
                squeeze.plate_half_m[1] * s,
                squeeze.plate_half_m[2] * s,
            ),
        )
    return replace(
        scene,
        lattice=replace(
            scene.lattice,
            x_m=scene.lattice.x_m * s,
            y_m=scene.lattice.y_m * s,
            region_half_m=(
                scene.lattice.region_half_m[0] * s,
                scene.lattice.region_half_m[1] * s,
            ),
        ),
        dominoes=tuple(domino(d) for d in scene.dominoes),
        fan=replace(scene.fan, speed_mps=scene.fan.speed_mps * math.sqrt(s)),
        jet=replace(
            scene.jet, radius_m=scene.jet.radius_m * s, height_m=scene.jet.height_m * s
        ),
        airflow=replace(
            air,
            attenuation_per_m=air.attenuation_per_m / s,
            cell_m=air.cell_m * s,
            x_range_m=(air.x_range_m[0] * s, air.x_range_m[1] * s),
            y_range_m=(air.y_range_m[0] * s, air.y_range_m[1] * s),
            z_range_m=(air.z_range_m[0] * s, air.z_range_m[1] * s),
        ),
        squeeze=squeeze,
        acceptance=replace(
            scene.acceptance, footprint_m=scene.acceptance.footprint_m * s
        ),
        stations_m=tuple(x * s for x in scene.stations_m),
    )


def demo_cases(
    mesh: Path,
    mass_kg: float,
    scale: float = 1.0,
    material: LatticeMaterial = LatticeMaterial(),
    timestep_s: float = 0.001,
    solver_iterations: int = 500,
) -> dict[str, Scene]:
    """The build-order item 4 set: paired trials, the joint scene, swaps, orientations,
    the sealed control and the free block. ``scale`` is the block's size relative to the
    92 mm slab the default geometry was laid out for."""
    base = default_scene(mesh, mass_kg, OPEN)
    base = replace(
        base,
        lattice=replace(base.lattice, material=material),
        timestep_s=timestep_s,
        solver_iterations=solver_iterations,
    )
    fixed = replace(base, lattice=replace(base.lattice, pin_height_m=PIN_HEIGHT_M))
    cases = {
        "paired_light_open": replace(
            fixed, dominoes=(Domino("light", 0.012, 0.45, 0.0),)
        ),
        "paired_heavy_open": replace(
            fixed, dominoes=(Domino("heavy", 0.060, 0.45, 0.0),)
        ),
        "joint_open": fixed,
        "joint_open_swapped": replace(
            fixed, dominoes=dominoes(light_y=-0.02, heavy_y=0.02)
        ),
        "joint_closed": replace(
            fixed, lattice=replace(fixed.lattice, orientation=CLOSED)
        ),
        "joint_open_sealed": replace(
            fixed, airflow=replace(fixed.airflow, skin_transmission=0.0)
        ),
        "joint_open_free": base,
        "joint_open_squeezed": replace(
            fixed, squeeze=Squeeze(gap_m=0.070, close_at_s=0.1, release_at_s=None)
        ),
        # The free block is squeezed to two thirds of its width before the fan starts,
        # then let go mid-gust: the light domino should stand while it is squeezed and
        # fall once the lattice has sprung back open.
        "squish": replace(
            base,
            fan=replace(base.fan, on_s=0.8, hold_s=2.2),
            squeeze=Squeeze(
                gap_m=0.060, close_at_s=0.1, close_over_s=0.5, release_at_s=1.8
            ),
        ),
    }
    return {name: scaled(scene, scale) for name, scene in cases.items()}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    sub = parser.add_subparsers(dest="command", required=True)
    demo = sub.add_parser("demo", help="run the domino demonstration cases")
    demo.add_argument(
        "--mesh", type=Path, required=True, help="the .msh prepare_lattice.py wrote"
    )
    demo.add_argument(
        "--mass",
        type=float,
        default=None,
        help="block mass in kg; default from the mesh volume",
    )
    demo.add_argument("--out", type=Path, required=True)
    demo.add_argument(
        "--scale",
        type=float,
        default=1.0,
        help="block size relative to the 92 mm slab; shrinks the scene around the fan",
    )
    demo.add_argument(
        "--young",
        type=float,
        default=LatticeMaterial().young_pa,
        help="strut Young's modulus, Pa",
    )
    demo.add_argument(
        "--timestep", type=float, default=0.001, help="physics timestep, s"
    )
    demo.add_argument(
        "--iterations",
        type=int,
        default=500,
        help="constraint and flex solver iterations",
    )
    demo.add_argument("--only", nargs="*", default=None, help="case names to run")
    demo.add_argument("--replay", action="store_true", help="keep qpos for rendering")
    demo.add_argument(
        "--render", action="store_true", help="also write a video per case"
    )
    rend = sub.add_parser("render", help="render a saved recording")
    rend.add_argument("recording", type=Path)
    rend.add_argument("video", type=Path)
    args = parser.parse_args(argv)
    if args.command == "render":
        render(Recording.load(args.recording), args.video)
        return 0
    mass = args.mass if args.mass is not None else estimated_mass(args.mesh)
    args.out.mkdir(parents=True, exist_ok=True)
    results = {}
    cases = demo_cases(
        args.mesh,
        mass,
        args.scale,
        material=LatticeMaterial(young_pa=args.young),
        timestep_s=args.timestep,
        solver_iterations=args.iterations,
    )
    for name, scene in cases.items():
        if args.only and name not in args.only:
            continue
        print(f"== {name}", flush=True)
        rec = run_episode(scene, replay=args.replay or args.render, progress=True)
        rec.save(args.out / f"{name}.npz")
        summary = {
            "wall_s": rec.wall_s,
            "max_fall_deg": dict(
                zip(
                    [d.name for d in scene.dominoes],
                    np.degrees(rec.domino_fall_rad.max(axis=0)).round(1).tolist(),
                    strict=True,
                )
            ),
            "peak_cube_force_N": float(np.linalg.norm(rec.cube_force_N, axis=1).max()),
            "cube_impulse_Ns": float(np.trapezoid(rec.cube_force_N[:, 0], rec.time_s)),
            "peak_through_flux_m3ps": rec.through_flux_m3ps.max(axis=0).tolist(),
            "final_dimensions_m": rec.lattice_dimensions_m[-1].round(4).tolist(),
        }
        if len(scene.dominoes) == 2:
            summary["verdict"] = dataclasses.asdict(judge(rec))
        results[name] = summary
        print(json.dumps(summary, indent=1), flush=True)
        if args.render:
            render(rec, args.out / f"{name}.mp4")
    (args.out / "summary.json").write_text(
        json.dumps({"versions": versions(), "cases": results}, indent=1) + "\n"
    )
    return 0


def estimated_mass(mesh: Path, density_kg_m3: float = 1100.0) -> float:
    """Mass from the mesh volume at a TPU-like density: a synthetic stand-in for weighing."""
    return float(read_gmsh(mesh).volumes.sum() * density_kg_m3)


if __name__ == "__main__":
    sys.exit(main())

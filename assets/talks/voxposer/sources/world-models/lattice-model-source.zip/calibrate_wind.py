"""Calibration sweeps for the lattice-wind airflow closure, and the fit that consumes them.

``sweep`` runs the development cases the plan asks for before any fidelity claim: four
material orientations (one symmetry pair), three compressions set by the squeeze plates,
two fan speeds, plus the empty-fan and sealed-lattice controls, each with the block held
by the pinned-base fixture. Every case writes a recording and a summary of lattice load,
impulse, rear-face transmission and downstream profiles. ``refine`` halves the timestep
and the airflow cell on the baseline case and reports the change in impulse and
downstream speed against the 5% development gate. ``fit`` adjusts the closure's
attenuation, lattice drag coefficient and wake mixing so the model reproduces reference
recordings in the physical state they were taken; those references are meant to come
from bench or CFD cases, and until they do the only fits are self-consistency checks on
records this same model produced. ``plots`` draws the figures behind a sweep.

    uv run python experiments/lattice_wind/calibrate_wind.py sweep \\
        --mesh artifacts/lattice_wind/slab.msh --out artifacts/lattice_wind/sweep --workers 8
    uv run python experiments/lattice_wind/calibrate_wind.py plots \\
        --sweep artifacts/lattice_wind/sweep --out artifacts/lattice_wind/sweep/plots

Cases run in separate processes because MuJoCo's control callback is process-global.
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import sys
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, replace
from itertools import product
from pathlib import Path

import lattice_wind as lw
import mujoco
import numpy as np
from prepare_lattice import read_gmsh
from scipy.optimize import least_squares

ORIENTATIONS: dict[str, lw.Orientation] = {
    "z+": lw.Orientation("+z", "+y"),
    "z-": lw.Orientation("-z", "+y"),
    "x+": lw.Orientation("+x", "+z"),
    "y+": lw.Orientation("+y", "+z"),
}
COMPRESSIONS = (1.0, 0.85, 0.70)
SPEEDS_MPS = (8.0, 12.0)
REFINEMENT_GATE = 0.05
# Residual scales for the fit: a tenth of a newton on the block, a metre per second in the wake.
FORCE_SCALE_N = 0.1
SPEED_SCALE_MPS = 1.0


@dataclass(frozen=True)
class Case:
    """One development case: which way the lattice faces, how far it is squeezed across
    the lateral axis (as a fraction of its rest width), and the fan speed."""

    name: str
    orientation: str
    compression: float
    speed_mps: float
    skin_transmission: float = 1.0
    lattice_y_m: float = (
        0.0  # 0.12 parks the block outside the jet: the empty-fan control
    )
    timestep_s: float = 0.001
    cell_m: float = 0.004


@dataclass(frozen=True)
class CaseSummary:
    """What a sweep keeps per case besides its recording, all at the reference frame
    unless the name says otherwise."""

    case: Case
    impulse_Ns: float
    peak_force_N: float
    rear_transmission: float
    station_mean_mps: list[float]
    dimensions_m: list[float]
    plate_force_N: float
    max_fall_deg: list[float]
    wall_s: float


@dataclass(frozen=True)
class ClosureParameters:
    """The free parameters of the airflow closure. A fit changes these and nothing else
    about a record's airflow: its skin, grid and density stay as recorded."""

    attenuation_per_m: float
    lattice_cd: float
    mixing: float

    @classmethod
    def of(cls, air: lw.Airflow) -> ClosureParameters:
        return cls(air.attenuation_per_m, air.lattice_cd, air.mixing)

    def apply(self, air: lw.Airflow) -> lw.Airflow:
        return replace(
            air,
            attenuation_per_m=self.attenuation_per_m,
            lattice_cd=self.lattice_cd,
            mixing=self.mixing,
        )

    def log(self) -> np.ndarray:
        """The fit searches in log space, so a parameter it is to adjust must be
        strictly positive to start with; zero is a valid closure but not a fit start."""
        values = (self.attenuation_per_m, self.lattice_cd, self.mixing)
        if min(values) <= 0:
            raise ValueError(
                f"fit parameters must be positive to start a fit, got {self}"
            )
        return np.log(values)

    @classmethod
    def from_log(cls, x: np.ndarray) -> ClosureParameters:
        a, c, m = np.exp(x)
        return cls(float(a), float(c), float(m))


def development_cases() -> list[Case]:
    cases = [
        Case(f"{o}_c{int(c * 100)}_u{int(u)}", o, c, u)
        for o, c, u in product(ORIENTATIONS, COMPRESSIONS, SPEEDS_MPS)
    ]
    cases.append(Case("empty_u12", "z+", 1.0, 12.0, lattice_y_m=0.12))
    cases.append(Case("sealed_z+_u12", "z+", 1.0, 12.0, skin_transmission=0.0))
    return cases


def case_scene(case: Case, mesh: Path, mass_kg: float) -> lw.Scene:
    orientation = ORIENTATIONS[case.orientation]
    rest_width = float((np.abs(orientation.rotation()) @ read_gmsh(mesh).extents)[1])
    base = lw.default_scene(mesh, mass_kg, orientation)
    squeeze = None
    if case.compression < 1.0:
        squeeze = lw.Squeeze(
            gap_m=case.compression * rest_width, close_at_s=0.1, close_over_s=0.5
        )
    return replace(
        base,
        lattice=replace(
            base.lattice, pin_height_m=lw.PIN_HEIGHT_M, y_m=case.lattice_y_m
        ),
        fan=replace(base.fan, speed_mps=case.speed_mps, on_s=1.0),
        airflow=replace(
            base.airflow, skin_transmission=case.skin_transmission, cell_m=case.cell_m
        ),
        squeeze=squeeze,
        acceptance=lw.Acceptance(settle_s=0.3),
        timestep_s=case.timestep_s,
    )


def footprint_cells(scene: lw.Scene, mesh: Path) -> tuple[slice, slice]:
    """(y, z) cell ranges of the block's rest envelope on the airflow grid."""
    extent = np.abs(scene.lattice.orientation.rotation()) @ read_gmsh(mesh).extents
    air = scene.airflow
    y0 = int((scene.lattice.y_m - extent[1] / 2 - air.y_range_m[0]) / air.cell_m)
    y1 = int((scene.lattice.y_m + extent[1] / 2 - air.y_range_m[0]) / air.cell_m)
    z1 = int((extent[2] - air.z_range_m[0]) / air.cell_m)
    return slice(max(y0, 0), y1 + 1), slice(0, z1 + 1)


def summarize(case: Case, rec: lw.Recording, mesh: Path) -> CaseSummary:
    ref = rec.reference_frame
    ys, zs = footprint_cells(rec.scene, mesh)
    profiles: np.ndarray = rec.downstream_velocity_mps[ref].astype(np.float64)
    return CaseSummary(
        case=case,
        impulse_Ns=float(np.trapezoid(rec.cube_force_N[:, 0], rec.time_s)),
        peak_force_N=float(np.linalg.norm(rec.cube_force_N, axis=1).max()),
        rear_transmission=float(rec.rear_transmission[ref]),
        station_mean_mps=[float(p[ys, zs].mean()) for p in profiles],
        dimensions_m=rec.lattice_dimensions_m[ref].round(5).tolist(),
        plate_force_N=float(np.nan_to_num(rec.plate_force_N[ref]).min()),
        max_fall_deg=np.degrees(rec.domino_fall_rad.max(axis=0)).round(1).tolist(),
        wall_s=rec.wall_s,
    )


def run_case(job: tuple[Case, str, float, str]) -> CaseSummary:
    case, mesh, mass_kg, out = job
    scene = case_scene(case, Path(mesh), mass_kg)
    rec = lw.run_episode(scene)
    rec.save(Path(out) / f"{case.name}.npz")
    summary = summarize(case, rec, Path(mesh))
    print(json.dumps({case.name: dataclasses.asdict(summary)}), flush=True)
    return summary


def run_cases(
    cases: list[Case], mesh: Path, mass_kg: float, out: Path, workers: int
) -> dict[str, CaseSummary]:
    out.mkdir(parents=True, exist_ok=True)
    jobs = [(case, str(mesh), mass_kg, str(out)) for case in cases]
    with ProcessPoolExecutor(max_workers=workers) as pool:
        return {summary.case.name: summary for summary in pool.map(run_case, jobs)}


def report_json(
    path: Path, header: dict[str, object], results: dict[str, CaseSummary]
) -> None:
    cases = {name: dataclasses.asdict(summary) for name, summary in results.items()}
    path.write_text(json.dumps({**header, "cases": cases}, indent=1) + "\n")


def sweep(mesh: Path, mass_kg: float, out: Path, workers: int) -> dict[str, object]:
    results = run_cases(development_cases(), mesh, mass_kg, out, workers)
    header: dict[str, object] = {
        "versions": lw.versions(),
        "mesh": str(mesh),
        "mass_kg": mass_kg,
        "symmetry_pair_impulse_Ns": {
            "z+": results["z+_c100_u12"].impulse_Ns,
            "z-": results["z-_c100_u12"].impulse_Ns,
        },
    }
    report_json(out / "sweep.json", header, results)
    return header


def refine(mesh: Path, mass_kg: float, out: Path, workers: int) -> dict[str, object]:
    """The numerical development gate: impulse and downstream speed under refinement."""
    baseline = Case("baseline", "z+", 1.0, 12.0)
    cases = [
        baseline,
        replace(baseline, name="half_timestep", timestep_s=baseline.timestep_s / 2),
        replace(baseline, name="half_cell", cell_m=baseline.cell_m / 2),
    ]
    results = run_cases(cases, mesh, mass_kg, out, workers)
    ref = results["baseline"]

    def relative(a: float, b: float) -> float:
        return float(abs(a - b) / max(abs(b), 1e-12))

    changes = {
        name: {
            "impulse": relative(results[name].impulse_Ns, ref.impulse_Ns),
            "station1_speed": relative(
                results[name].station_mean_mps[1], ref.station_mean_mps[1]
            ),
        }
        for name in ("half_timestep", "half_cell")
    }
    header: dict[str, object] = {
        "versions": lw.versions(),
        "gate": REFINEMENT_GATE,
        "passes": all(
            v < REFINEMENT_GATE for c in changes.values() for v in c.values()
        ),
        "relative_changes": changes,
    }
    report_json(out / "refine.json", header, results)
    return header


def reference_data(model: lw.Model, rec: lw.Recording) -> mujoco.MjData:
    """The scene in the physical state of the record's reference frame: lattice shape
    and velocity, dominoes, and the squeeze plates where they stood."""
    data = mujoco.MjData(model.mj)
    mujoco.mj_setState(model.mj, data, rec.reference_state, lw.FULL_PHYSICS)
    mujoco.mj_forward(model.mj, data)
    return data


def fit_airflow(
    records: list[lw.Recording], initial: ClosureParameters
) -> ClosureParameters:
    """Least squares over the closure's free parameters against the records' lattice
    load and downstream profiles at their reference frames, each record evaluated in
    its own recorded state with its own fixed airflow settings."""
    models = [lw.rebuild(rec) for rec in records]
    datas = [
        reference_data(model, rec) for model, rec in zip(models, records, strict=True)
    ]

    def residuals(x: np.ndarray) -> np.ndarray:
        params = ClosureParameters.from_log(x)
        parts = []
        for rec, model, data in zip(records, models, datas, strict=True):
            model.scene = replace(rec.scene, airflow=params.apply(rec.scene.airflow))
            current = lw.loads(model, data)
            ref = rec.reference_frame
            force = (
                current.lattice_force[0] - rec.cube_force_N[ref, 0]
            ) / FORCE_SCALE_N
            parts.append(np.atleast_1d(force))
            for k, station in enumerate(rec.scene.stations_m):
                predicted = lw.station_speeds(
                    model, current.flow, current.flow.rear_x + station
                )
                recorded = rec.downstream_velocity_mps[ref, k]
                parts.append(((predicted - recorded) / SPEED_SCALE_MPS).ravel())
        return np.concatenate(parts)

    solution = least_squares(residuals, initial.log(), x_scale="jac")
    if not solution.success:
        raise RuntimeError(f"closure fit did not converge: {solution.message}")
    return ClosureParameters.from_log(solution.x)


# --------------------------------------------------------------------------------------
# Plots. Categorical hues in a fixed order per orientation; one blue ramp for speed maps.
# --------------------------------------------------------------------------------------

SERIES = {"z+": "#2a78d6", "z-": "#eb6834", "x+": "#1baf7a", "y+": "#eda100"}
BLUE_RAMP = ["#ffffff", "#cde2fb", "#86b6ef", "#3987e5", "#1c5cab"]


def plots(sweep_dir: Path, out: Path) -> None:
    import matplotlib  # noqa: PLC0415  # plotting is optional on the physics hosts

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt  # noqa: PLC0415
    from matplotlib.colors import LinearSegmentedColormap  # noqa: PLC0415

    out.mkdir(parents=True, exist_ok=True)
    report = json.loads((sweep_dir / "sweep.json").read_text())
    cases: dict[str, dict] = report["cases"]
    mesh = Path(report["mesh"])

    def recording(name: str) -> lw.Recording:
        return lw.Recording.load(sweep_dir / f"{name}.npz")

    fig, ax = plt.subplots(figsize=(7, 3.6))
    for key, color in SERIES.items():
        rec = recording(f"{key}_c100_u12")
        ax.plot(
            rec.time_s,
            rec.cube_force_N[:, 0],
            color=color,
            linewidth=1.6,
            label=f"{key} downstream",
        )
    ax.set_xlabel("time (s)")
    ax.set_ylabel("lattice load along x (N)")
    ax.set_title("Lattice load at 12 m/s, uncompressed")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(out / "force_vs_time.png", dpi=150)
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(9, 3.6))
    for key, color in SERIES.items():
        names = [f"{key}_c{int(c * 100)}_u12" for c in COMPRESSIONS]
        impulses = [cases[n]["impulse_Ns"] for n in names]
        transmissions = [cases[n]["rear_transmission"] for n in names]
        style = dict(color=color, linewidth=1.6, markersize=5, label=key)
        axes[0].plot(COMPRESSIONS, impulses, "o-", **style)
        axes[1].plot(COMPRESSIONS, transmissions, "o-", **style)
    axes[0].set_ylabel("impulse on the lattice (N s)")
    axes[1].set_ylabel("rear-face transmission")
    for ax in axes:
        ax.set_xlabel("gap / rest width")
        ax.invert_xaxis()
        ax.grid(alpha=0.25)
    axes[0].legend(frameon=False, title="downstream axis")
    fig.suptitle("Compression sweep at 12 m/s")
    fig.tight_layout()
    fig.savefig(out / "impulse_vs_compression.png", dpi=150)
    plt.close(fig)

    panels = [(k, f"{k}_c100_u12") for k in SERIES]
    panels += [("sealed z+", "sealed_z+_u12"), ("empty fan", "empty_u12")]
    station = 1
    maps: list[tuple[lw.Recording, np.ndarray]] = []
    for _, name in panels:
        rec = recording(name)
        speeds = rec.downstream_velocity_mps[rec.reference_frame, station]
        maps.append((rec, speeds.astype(np.float64)))
    vmax = max(float(m.max()) for _, m in maps)
    cmap = LinearSegmentedColormap.from_list("blue_ramp", BLUE_RAMP)
    fig, axes = plt.subplots(2, 3, figsize=(10, 5.6), sharex=True, sharey=True)
    for ax, (label, _), (rec, speeds) in zip(axes.ravel(), panels, maps, strict=True):
        air = rec.scene.airflow
        extent = [
            air.y_range_m[0] * 100,
            air.y_range_m[1] * 100,
            air.z_range_m[0] * 100,
            air.z_range_m[1] * 100,
        ]
        image = ax.imshow(
            speeds.T, origin="lower", extent=extent, cmap=cmap, vmin=0.0, vmax=vmax
        )
        ax.set_title(label, fontsize=10)
        ys, zs = footprint_cells(rec.scene, mesh)
        y0 = (air.y_range_m[0] + ys.start * air.cell_m) * 100
        y1 = (air.y_range_m[0] + ys.stop * air.cell_m) * 100
        z1 = zs.stop * air.cell_m * 100
        ax.plot(
            [y0, y1, y1, y0, y0],
            [0, 0, z1, z1, 0],
            color="#444444",
            linewidth=0.8,
            linestyle="--",
        )
    for ax in axes[-1]:
        ax.set_xlabel("y (cm)")
    for ax in axes[:, 0]:
        ax.set_ylabel("z (cm)")
    station_cm = rec.scene.stations_m[station] * 100
    fig.colorbar(
        image,
        ax=axes.ravel().tolist(),
        label=f"axial speed {station_cm:.0f} cm behind the block (m/s)",
    )
    fig.suptitle("Downstream speed at the fan's peak; dashed: block footprint")
    fig.savefig(out / "downstream_profiles.png", dpi=150)
    plt.close(fig)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("sweep", "refine"):
        p = sub.add_parser(name)
        p.add_argument("--mesh", type=Path, required=True)
        p.add_argument(
            "--mass",
            type=float,
            default=None,
            help="block mass in kg; default from the mesh volume",
        )
        p.add_argument("--out", type=Path, required=True)
        p.add_argument("--workers", type=int, default=4)
    p = sub.add_parser("fit")
    p.add_argument("--records", type=Path, nargs="+", required=True)
    p.add_argument(
        "--out", type=Path, required=True, help="JSON file for the fitted parameters"
    )
    p = sub.add_parser("plots")
    p.add_argument("--sweep", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)
    if args.command in ("sweep", "refine"):
        mass = args.mass if args.mass is not None else lw.estimated_mass(args.mesh)
        run = sweep if args.command == "sweep" else refine
        print(json.dumps(run(args.mesh, mass, args.out, args.workers), indent=1))
    elif args.command == "fit":
        records = [lw.Recording.load(p) for p in args.records]
        fitted = fit_airflow(records, ClosureParameters.of(records[0].scene.airflow))
        args.out.write_text(json.dumps(dataclasses.asdict(fitted), indent=1) + "\n")
        print(json.dumps(dataclasses.asdict(fitted), indent=1))
    else:
        plots(args.sweep, args.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""Turn a fidget-lattice surface mesh into the tetrahedral mesh the wind scene simulates.

BabyRobot's ``assets/fidget_cube`` generator cuts a block out of the Transforming Fidget
Ball and writes an STL in millimetres. That surface is printable but not a finite-element
mesh: struts meet along non-manifold edges and the caps sit on the struts as separate
shells. fTetWild meshes such a soup robustly: it fills the volume within an envelope of
the input surface, merges the junctions, and keeps the pores empty. This script runs it,
keeps the connected lattice, converts to metres, checks the openings survived, and writes
a Gmsh 4.1 file that MuJoCo's ``<flexcomp type="gmsh">`` loads, plus a JSON record of the
provenance the experiments store with their results.

    uv run --with pytetwild --with pyvista --with rtree \\
        python experiments/lattice_wind/prepare_lattice.py \\
        ~/Downloads/fidget_slab_92x92x46.stl artifacts/lattice_wind/slab --edge-mm 2.5

The MakerWorld licence forbids redistributing the ball or anything cut from it, so
generated geometry stays under the ignored ``artifacts/`` directory.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import asdict, dataclass
from importlib.metadata import version
from pathlib import Path

import numpy as np
import trimesh
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components

MM_PER_M = 1000.0
# Rays through a block that hit nothing: the straight channels air can jet through.
OPEN_RAYS = 2000


@dataclass(frozen=True)
class TetMesh:
    """Tetrahedra over ``nodes`` (metres), every element positively oriented."""

    nodes: np.ndarray  # [n, 3]
    tets: np.ndarray  # [m, 4]

    @property
    def volumes(self) -> np.ndarray:
        a, b, c, d = (self.nodes[self.tets[:, i]] for i in range(4))
        return np.einsum("ij,ij->i", np.cross(b - a, c - a), d - a) / 6.0

    @property
    def extents(self) -> np.ndarray:
        return self.nodes.max(0) - self.nodes.min(0)

    def boundary(self) -> tuple[np.ndarray, np.ndarray]:
        """Triangles that belong to exactly one tetrahedron, wound outward, and the
        index of the tetrahedron each belongs to."""
        corners = self.tets[:, [[1, 2, 3], [0, 3, 2], [0, 1, 3], [0, 2, 1]]].reshape(
            -1, 3
        )
        key = np.sort(corners, axis=1)
        _, first, counts = np.unique(key, axis=0, return_index=True, return_counts=True)
        single = first[counts == 1]
        return corners[single], single // 4

    def boundary_faces(self) -> np.ndarray:
        return self.boundary()[0]

    def surface(self) -> trimesh.Trimesh:
        return trimesh.Trimesh(self.nodes, self.boundary_faces(), process=False)


@dataclass(frozen=True)
class Provenance:
    """What the experiments record next to every result that used this mesh."""

    source: str
    source_sha256: str
    source_extents_mm: list[float]
    source_faces: int
    edge_length_mm: float
    epsilon_rel: float
    optimized: bool
    nodes: int
    tets: int
    volume_cm3: float
    extents_m: list[float]
    dropped_components: list[int]
    open_fraction_source: list[float]
    open_fraction_tets: list[float]
    pytetwild_version: str
    mesh_sha256: str


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tetrahedralize(
    surface: trimesh.Trimesh,
    edge_length_mm: float,
    epsilon_rel: float,
    threads: int,
    optimize: bool,
) -> tuple[TetMesh, str]:
    """fTetWild on the surface soup, oriented positively, still in the source's
    millimetres, and the mesher's version for the provenance record.

    ``optimize`` runs fTetWild's quality passes, which take most of its time on this
    many struts; without them the mesh is valid but its elements are worse shaped.
    """
    import pytetwild  # noqa: PLC0415  # only the preparation step needs fTetWild; the scene does not

    nodes, tets = pytetwild.tetrahedralize(
        np.asarray(surface.vertices, dtype=np.float64),
        np.asarray(surface.faces, dtype=np.int32),
        edge_length_abs=edge_length_mm,
        epsilon=epsilon_rel,
        optimize=optimize,
        num_threads=threads,
    )
    mesh = TetMesh(nodes, tets.astype(np.int64))
    flipped = mesh.volumes < 0
    tets = mesh.tets.copy()
    tets[flipped, 2], tets[flipped, 3] = mesh.tets[flipped, 3], mesh.tets[flipped, 2]
    return TetMesh(nodes, tets), f"pytetwild {version('pytetwild')}"


def connected(mesh: TetMesh) -> tuple[TetMesh, list[int]]:
    """The largest vertex-connected piece, and the tet counts of the pieces dropped.

    The generator already keeps only pieces attached to the block, so anything separate
    here is a sliver fTetWild closed on its own; it would fall off the lattice in
    simulation and is left out.
    """
    rows: np.ndarray = np.repeat(np.arange(len(mesh.tets)), 4)
    incidence = coo_matrix(
        (np.ones(rows.size), (rows, mesh.tets.ravel())),
        shape=(len(mesh.tets), len(mesh.nodes)),
    )
    _, labels = connected_components(incidence @ incidence.T, directed=False)
    counts = np.bincount(labels)
    largest = int(counts.argmax())
    keep = labels == largest
    dropped: list[int] = sorted(np.delete(counts, largest).tolist(), reverse=True)
    used, inverse = np.unique(mesh.tets[keep], return_inverse=True)
    return TetMesh(mesh.nodes[used], inverse.reshape(-1, 4)), dropped


def open_fraction(
    surface: trimesh.Trimesh, rays: int = OPEN_RAYS, seed: int = 0
) -> list[float]:
    """Per axis, the share of parallel rays through the bounding box that hit no solid.

    This is the projected openness of the straight channels. It is a geometric property
    of the lattice, not a flow quantity, and it is what the tetrahedral mesh must keep.
    """
    caster = trimesh.ray.ray_triangle.RayMeshIntersector(surface)
    lo, hi = surface.bounds
    margin = 0.02 * (hi - lo)
    rng = np.random.default_rng(seed)
    out = []
    for axis in range(3):
        origins = rng.uniform(lo + margin, hi - margin, size=(rays, 3))
        origins[:, axis] = lo[axis] - margin[axis]
        directions = np.zeros((rays, 3))
        directions[:, axis] = 1.0
        hit = caster.intersects_any(origins, directions)
        out.append(float(1.0 - hit.mean()))
    return out


def write_gmsh(path: Path, mesh: TetMesh) -> None:
    """Gmsh 4.1 ASCII with one node block and one tetrahedron block, as MuJoCo reads it."""
    n, m = len(mesh.nodes), len(mesh.tets)
    lines = [
        "$MeshFormat",
        "4.1 0 8",
        "$EndMeshFormat",
        "$Nodes",
        f"1 {n} 1 {n}",
        f"3 1 0 {n}",
    ]
    lines += [str(i) for i in range(1, n + 1)]
    lines += [f"{x:.9g} {y:.9g} {z:.9g}" for x, y, z in mesh.nodes]
    lines += ["$EndNodes", "$Elements", f"1 {m} 1 {m}", f"3 1 4 {m}"]
    lines += [
        f"{i} {a} {b} {c} {d}" for i, (a, b, c, d) in enumerate(mesh.tets + 1, start=1)
    ]
    lines += ["$EndElements", ""]
    path.write_text("\n".join(lines))


def read_gmsh(path: Path) -> TetMesh:
    """The inverse of :func:`write_gmsh`, for the files it wrote."""
    tokens = path.read_text().split("\n")
    at = tokens.index("$Nodes") + 1
    n = int(tokens[at].split()[1])
    nodes = np.array(
        [
            [float(v) for v in line.split()]
            for line in tokens[at + 2 + n : at + 2 + 2 * n]
        ]
    )
    at = tokens.index("$Elements") + 1
    m = int(tokens[at].split()[1])
    tets = (
        np.array(
            [[int(v) for v in line.split()[1:]] for line in tokens[at + 2 : at + 2 + m]]
        )
        - 1
    )
    return TetMesh(nodes, tets)


@dataclass(frozen=True)
class MeshTolerances:
    """How far meshing may change the lattice before the mesh is refused."""

    # Tetrahedra dropped as separate pieces, relative to the tetrahedra kept.
    dropped_fraction: float = 0.01
    # Change in the open-ray fraction along any material axis.
    openness: float = 0.05


def check(record: Provenance, tolerances: MeshTolerances = MeshTolerances()) -> None:
    """Raise unless the mesh kept the lattice connected and its openings as they were.

    A mesh that sheds whole struts or closes channels would simulate a different object
    than the one printed, so it is not published as this lattice.
    """
    problems = []
    dropped = sum(record.dropped_components)
    if dropped > tolerances.dropped_fraction * record.tets:
        problems.append(
            f"{dropped} tetrahedra in {len(record.dropped_components)} separate pieces "
            f"dropped against {record.tets} kept"
        )
    for axis, before, after in zip(
        "xyz", record.open_fraction_source, record.open_fraction_tets, strict=True
    ):
        if abs(after - before) > tolerances.openness:
            problems.append(
                f"open-ray fraction along {axis} went from {before:.3f} to {after:.3f}"
            )
    if problems:
        raise ValueError("meshing changed the lattice: " + "; ".join(problems))


def prepare(
    source: Path,
    out: Path,
    edge_length_mm: float,
    epsilon_rel: float,
    threads: int,
    optimize: bool = True,
    tolerances: MeshTolerances = MeshTolerances(),
) -> Provenance:
    surface = trimesh.load(source, force="mesh")
    print(
        f"{source.name}: {len(surface.faces)} faces, {surface.extents.round(1).tolist()} mm",
        flush=True,
    )
    raw, mesher = tetrahedralize(
        surface, edge_length_mm, epsilon_rel, threads, optimize
    )
    mesh_mm, dropped = connected(raw)
    centre = (mesh_mm.nodes.min(0) + mesh_mm.nodes.max(0)) / 2
    mesh = TetMesh((mesh_mm.nodes - centre) / MM_PER_M, mesh_mm.tets)
    out.parent.mkdir(parents=True, exist_ok=True)
    # The mesh is staged next to its final name and published only once accepted, so a
    # scene never finds an unchecked file, and a failed run never replaces an accepted one.
    msh = out.with_suffix(".msh")
    staging = out.with_suffix(".msh.tmp")
    try:
        write_gmsh(staging, mesh)
        record = Provenance(
            source=str(source),
            source_sha256=sha256(source),
            source_extents_mm=surface.extents.round(3).tolist(),
            source_faces=int(len(surface.faces)),
            edge_length_mm=edge_length_mm,
            epsilon_rel=epsilon_rel,
            optimized=optimize,
            nodes=int(len(mesh.nodes)),
            tets=int(len(mesh.tets)),
            volume_cm3=float(mesh.volumes.sum() * 1e6),
            extents_m=mesh.extents.round(6).tolist(),
            dropped_components=dropped,
            open_fraction_source=open_fraction(surface),
            open_fraction_tets=open_fraction(mesh.surface()),
            pytetwild_version=mesher,
            mesh_sha256=sha256(staging),
        )
        try:
            check(record, tolerances)
        except ValueError:
            out.with_suffix(".rejected.json").write_text(
                json.dumps(asdict(record), indent=1) + "\n"
            )
            raise
        staging.replace(msh)
    finally:
        staging.unlink(missing_ok=True)
    out.with_suffix(".json").write_text(json.dumps(asdict(record), indent=1) + "\n")
    return record


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Tetrahedralize a fidget-lattice STL for the wind scene."
    )
    parser.add_argument("source", type=Path, help="the generator's STL, in millimetres")
    parser.add_argument(
        "out", type=Path, help="output path without suffix; writes .msh and .json"
    )
    parser.add_argument(
        "--edge-mm", type=float, default=2.5, help="fTetWild target edge length"
    )
    parser.add_argument(
        "--epsilon",
        type=float,
        default=1e-3,
        help="surface envelope, relative to the diagonal",
    )
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument(
        "--no-optimize",
        action="store_true",
        help="skip fTetWild's quality passes (development meshes)",
    )
    args = parser.parse_args(argv)
    record = prepare(
        args.source,
        args.out,
        args.edge_mm,
        args.epsilon,
        args.threads,
        optimize=not args.no_optimize,
    )
    print(
        f"{args.out}.msh: {record.nodes} nodes, {record.tets} tets, {record.volume_cm3:.1f} cm^3, "
        f"open fractions {np.round(record.open_fraction_source, 3).tolist()} -> "
        f"{np.round(record.open_fraction_tets, 3).tolist()}, dropped {record.dropped_components}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

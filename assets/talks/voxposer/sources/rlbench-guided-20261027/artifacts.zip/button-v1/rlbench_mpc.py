"""Native RLBench process boundary for executed controls and predictive rollouts."""

import argparse
import hashlib
import json
import os
import sys
from contextlib import ExitStack
from pathlib import Path
from typing import Annotated, Literal, TextIO

import imageio.v2 as imageio
import numpy as np
import rlbench
from imageio.plugins.ffmpeg import FfmpegFormat
from pydantic import BaseModel, Field, TypeAdapter
from pyrep.const import ObjectType
from pyrep.objects.joint import Joint
from pyrep.objects.shape import Shape
from pyrep.objects.vision_sensor import VisionSensor
from rlbench import tasks
from rlbench.action_modes.action_mode import MoveArmThenGripper
from rlbench.action_modes.arm_action_modes import EndEffectorPoseViaPlanning
from rlbench.action_modes.gripper_action_modes import Discrete
from rlbench.environment import Environment

type JSON = dict[str, JSON] | list[JSON] | str | float | int | bool | None
type FiniteFloat = Annotated[float, Field(allow_inf_nan=False)]
type Action = tuple[
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    Literal[0, 1],
]


class ObjectState(BaseModel):
    pose: list[FiniteFloat]
    velocity: list[FiniteFloat]
    parent: str | None
    joint: list[FiniteFloat] | None = None


class EpisodeState(BaseModel):
    objects: dict[str, ObjectState]
    q: list[FiniteFloat]
    targets: list[FiniteFloat]
    tip: list[FiniteFloat]
    target: list[FiniteFloat]
    grasped: list[str]
    attachment_parents: list[str | None]
    gripper_memory: list[list[FiniteFloat | None]]
    gripper_command: Literal[0, 1]
    actuating: bool
    settle: int
    condition_progress: list[int]
    button_joint: FiniteFloat | None
    steps: int


class ReplayRequest(BaseModel):
    prefix: list[Action]
    expected: EpisodeState
    tolerance: Annotated[float, Field(gt=0, allow_inf_nan=False)]


class ProposeRequest(ReplayRequest):
    operation: Literal["propose"]
    horizon: int


class RolloutRequest(ReplayRequest):
    operation: Literal["rollout"]
    candidate: Annotated[list[Action], Field(min_length=1)]
    guidance: dict
    weights: dict[str, float]


class StepRequest(BaseModel):
    operation: Literal["step"]
    action: Action


class StateRequest(BaseModel):
    operation: Literal["state"]


class CloseRequest(BaseModel):
    operation: Literal["close"]


class NativeEpisode:
    """Own one unmodified Panda scene and the state of single-step actuation."""

    def __init__(self, task_name: str, seed: int, resources: ExitStack):
        np.random.seed(seed)
        self.env = Environment(
            MoveArmThenGripper(EndEffectorPoseViaPlanning(), Discrete()),
            headless=True,
            shaped_rewards=False,
        )
        resources.callback(self.env.shutdown)
        self.env.launch()
        self.task = self.env.get_task(getattr(tasks, task_name))
        self.variation = self.task.sample_variation()
        self.descriptions, self.initial_observation = self.task.reset()
        self.scene = self.env._scene
        self.arm = self.scene.robot.arm
        self.gripper = self.scene.robot.gripper
        self.task_name = task_name
        self.dt = self.env._pyrep.get_simulation_timestep()
        self.steps = 0
        self.command = 1
        self.actuating = False
        self.settle = 0
        self.writer: FfmpegFormat.Writer | None = None
        self.execution: TextIO | None = None
        self.camera = VisionSensor("cam_front")
        self.objects = {
            obj.get_name(): obj
            for root in (self.arm, self.gripper, self.task._task.get_base())
            for obj in root.get_objects_in_tree(exclude_base=False)
        }
        if task_name == "TakeLidOffSaucepan":
            self.target = Shape("saucepan_lid_grasp_point")
            self.initial_target = self.target.get_position().copy()
        else:
            self.target = Shape("target_button_topPlate")
            self.button_joint = Joint("target_button_joint")
            self.initial_joint = self.task._task.goal_condition._original_pos
            self.initial_target = self.target.get_position().copy()
        self.initial_tip_quaternion = self.arm.get_tip().get_quaternion().tolist()

    def state(self) -> dict:
        """Expose native observations and Python memory needed to verify replay."""
        objects = {}
        for name, obj in self.objects.items():
            parent = obj.get_parent()
            item = {
                "pose": obj.get_pose().tolist(),
                "velocity": np.concatenate(obj.get_velocity()).tolist(),
                "parent": None if parent is None else parent.get_name(),
            }
            if obj.get_type() == ObjectType.JOINT:
                joint = Joint(obj.get_handle())
                item["joint"] = [
                    joint.get_joint_position(),
                    joint.get_joint_velocity(),
                    joint.get_joint_target_position(),
                    joint.get_joint_target_velocity(),
                ]
            objects[name] = item
        return {
            "objects": objects,
            "q": self.arm.get_joint_positions(),
            "targets": self.arm.get_joint_target_positions(),
            "tip": self.arm.get_tip().get_pose().tolist(),
            "target": self.target.get_position().tolist(),
            "grasped": [obj.get_name() for obj in self.gripper.get_grasped_objects()],
            "attachment_parents": [
                None if obj is None else obj.get_name()
                for obj in self.gripper._old_parents
            ],
            "gripper_memory": [self.gripper._prev_positions, self.gripper._prev_vels],
            "gripper_command": self.command,
            "actuating": self.actuating,
            "settle": self.settle,
            "condition_progress": [
                c._current_condition_index for c in self.task._task._success_conditions
            ],
            "button_joint": (
                self.button_joint.get_joint_position()
                if self.task_name == "PushButton"
                else None
            ),
            "steps": self.steps,
        }

    def metadata(self) -> dict:
        root = Path(rlbench.__file__).parent
        task_file = root / "tasks" / (self.task.get_name() + ".py")
        model_file = root / "task_ttms" / (self.task.get_name() + ".ttm")
        return {
            "task": self.task_name,
            "variation": self.variation,
            "instruction": self.descriptions[0],
            "dt": self.dt,
            "initial_target": self.initial_target.tolist(),
            "initial_joint": self.initial_joint
            if self.task_name == "PushButton"
            else None,
            "initial_tip_quaternion": self.initial_tip_quaternion,
            "seed_translation_limit_m": 0.10,
            "joint_intervals": self.arm.get_joint_intervals()[1],
            "target_color": (
                Shape("push_button_target").get_color()
                if self.task_name == "PushButton"
                else None
            ),
            "hashes": {
                str(path.relative_to(root)): hashlib.sha256(
                    path.read_bytes()
                ).hexdigest()
                for path in (root / "task_design.ttt", task_file, model_file)
            },
            "waypoints": {
                name: self.objects[name].get_pose().tolist()
                for name in self.objects
                if name.startswith("waypoint")
            },
            "pid": os.getpid(),
        }

    def record(self, output: Path, resources: ExitStack) -> None:
        imageio.imwrite(output / "initial-128.png", self.initial_observation.front_rgb)
        self.camera.set_resolution([640, 640])
        imageio.imwrite(output / "initial.png", self.rgb())
        self.writer = imageio.get_writer(str(output / "episode.mp4"), fps=1 / self.dt)
        resources.callback(self.writer.close)
        self.execution = resources.enter_context((output / "execution.jsonl").open("w"))

    def rgb(self) -> np.ndarray:
        self.camera.handle_explicitly()
        return (np.clip(self.camera.capture_rgb(), 0, 1) * 255).astype(np.uint8)

    def step(self, action: Action) -> dict:
        """Execute exactly one physics step with native servo and grasp semantics."""
        requested = action[7]
        if requested != self.command:
            if self.actuating or self.settle:
                raise ValueError("Cannot interrupt native gripper actuation/settling")
            current_open = all(x > 0.9 for x in self.gripper.get_open_amount())
            self.command = requested
            if requested != int(current_open):
                if requested == 0:
                    for obj in self.task._task.get_graspable_objects():
                        self.gripper.grasp(obj)
                else:
                    self.gripper.release()
                self.actuating = True
        self.arm.set_joint_target_positions(action[:7])
        if self.actuating:
            self.actuating = not self.gripper.actuate(self.command, velocity=0.2)
            if not self.actuating and self.command == 1:
                self.settle = 10
        elif self.settle:
            self.settle -= 1
        self.scene.step()
        self.steps += 1
        success, terminate = self.task._task.success()
        result = {
            "step": self.steps,
            "action": action,
            "success": bool(success),
            "terminate": bool(terminate),
            "arm_collision": bool(self.arm.check_arm_collision()),
            "state": self.state(),
        }
        if self.writer is not None:
            self.writer.append_data(self.rgb())
        if self.execution is not None:
            self.execution.write(json.dumps(result) + "\n")
            self.execution.flush()
        return result

    def guidance(self) -> dict:
        """Build authored stage objectives from privileged native object poses."""
        tip = self.arm.get_tip().get_position()
        target = self.target.get_position().copy()
        if self.task_name == "TakeLidOffSaucepan":
            if self.gripper.get_grasped_objects():
                stage = "lift"
                target = tip + np.array(
                    [0, 0, max(0, self.initial_target[2] + 0.15 - target[2])]
                )
                gripper = 0
            elif np.linalg.norm(tip - target) < 0.02:
                stage, gripper = "grasp", 0
            else:
                stage, gripper = "approach", self.command
        else:
            aligned = np.linalg.norm(tip[:2] - target[:2]) < 0.02
            stage, gripper = ("press" if aligned else "approach"), 0
            target[2] += -0.01 if aligned else 0.10
        return {"stage": stage, "target": target.tolist(), "gripper": gripper}

    def propose(self, horizon: int) -> dict:
        guidance = self.guidance()
        tip = self.arm.get_tip().get_position()
        delta = np.asarray(guidance["target"]) - tip
        ik_target = tip + delta * min(1.0, 0.10 / max(np.linalg.norm(delta), 1e-12))
        q = self.arm.solve_ik_via_jacobian(
            ik_target, quaternion=self.initial_tip_quaternion
        )
        return {
            "guidance": guidance,
            "joint_goal": q,
            "ik_target": ik_target.tolist(),
            "horizon": horizon,
        }


def compare_state(
    actual: JSON, expected: JSON, tolerance: float, path: str = ""
) -> float:
    """Reject mismatched replay before using a candidate prediction."""
    if isinstance(expected, dict) and isinstance(actual, dict):
        if actual.keys() != expected.keys():
            raise ValueError(f"Replay keys mismatch at {path}")
        return max(
            compare_state(actual[k], v, tolerance, path + "." + k)
            for k, v in expected.items()
        )
    if isinstance(expected, list) and isinstance(actual, list):
        if len(actual) != len(expected):
            raise ValueError(f"Replay length mismatch at {path}")
        return max(
            (
                compare_state(a, b, tolerance, f"{path}[{i}]")
                for i, (a, b) in enumerate(zip(actual, expected))
            ),
            default=0.0,
        )
    if (
        isinstance(expected, (float, int))
        and isinstance(actual, (float, int))
        and not isinstance(expected, bool)
    ):
        error = abs(float(actual) - expected)
        if not np.isfinite(error) or error > tolerance:
            raise ValueError(f"Replay mismatch at {path}: {actual} vs {expected}")
        return error
    if actual != expected:
        raise ValueError(f"Replay mismatch at {path}: {actual} vs {expected}")
    return 0.0


def objective(state: dict, guidance: dict, metadata: dict, weights: dict) -> float:
    tip = np.asarray(state["tip"][:3])
    guide = np.sum((tip - guidance["target"]) ** 2)
    if metadata["task"] == "TakeLidOffSaucepan":
        task = max(0, metadata["initial_target"][2] + 0.15 - state["target"][2]) ** 2
        grasp = float(guidance["stage"] in ("grasp", "lift") and not state["grasped"])
    else:
        task = (
            max(0, 0.003 - abs(state["button_joint"] - metadata["initial_joint"])) ** 2
        )
        grasp = 0.0
    return float(
        weights["guidance"] * guide + weights["task"] * task + weights["grasp"] * grasp
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--task", choices=["TakeLidOffSaucepan", "PushButton"], required=True
    )
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--request", type=Path)
    parser.add_argument("--response", type=Path)
    args = parser.parse_args()
    if args.request is not None and args.response is None:
        parser.error("--request requires --response")
    request = (
        TypeAdapter(ProposeRequest | RolloutRequest).validate_json(
            args.request.read_text()
        )
        if args.request is not None
        else None
    )
    with ExitStack() as resources:
        episode = NativeEpisode(args.task, args.seed, resources)
        metadata = episode.metadata()
        if request is not None:
            for action in request.prefix:
                episode.step(action)
            replay_error = compare_state(
                episode.state(),
                request.expected.model_dump(exclude_unset=True),
                request.tolerance,
            )
            if isinstance(request, ProposeRequest):
                response = episode.propose(request.horizon)
            else:
                trajectory = [episode.step(action) for action in request.candidate]
                costs = [
                    objective(
                        frame["state"], request.guidance, metadata, request.weights
                    )
                    for frame in trajectory
                ]
                response = {
                    "cost": float(np.mean(costs) + costs[-1]),
                    "feasible": not any(frame["arm_collision"] for frame in trajectory),
                    "trajectory": trajectory,
                }
            response["replay_error"] = replay_error
            response["pid"] = os.getpid()
            args.response.write_text(json.dumps(response) + "\n")
        else:
            if args.output is not None:
                episode.record(args.output, resources)
            print(
                "MPC_JSON "
                + json.dumps({"metadata": metadata, "state": episode.state()}),
                flush=True,
            )
            for line in sys.stdin:
                live_request = TypeAdapter(
                    StepRequest | StateRequest | CloseRequest
                ).validate_json(line)
                if isinstance(live_request, StepRequest):
                    response = episode.step(live_request.action)
                elif isinstance(live_request, StateRequest):
                    response = episode.state()
                else:
                    if args.output is not None:
                        imageio.imwrite(args.output / "final.png", episode.rgb())
                    break
                print("MPC_JSON " + json.dumps(response), flush=True)


if __name__ == "__main__":
    main()

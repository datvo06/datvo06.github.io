"""Run guided sampling MPC through isolated native RLBench prediction processes."""

import argparse
import gzip
import hashlib
import inspect
import json
import os
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack
from pathlib import Path
from typing import Annotated

import jax.random as jr
import numpy as np
from numpy.typing import NDArray
from pydantic import BaseModel, Field
from robotl.handlers.mujoco.control.planners import softmax_weights
from robotl.handlers.mujoco.control.plans import colored_noise

type Positive = Annotated[float, Field(gt=0, allow_inf_nan=False)]
type Nonnegative = Annotated[float, Field(ge=0, allow_inf_nan=False)]


class Config(BaseModel):
    horizon: Annotated[int, Field(ge=2)] = 32
    candidates: Annotated[int, Field(ge=2)] = 8
    rounds: Annotated[int, Field(ge=1)] = 2
    execute_steps: Annotated[int, Field(ge=1)] = 8
    sigma: Nonnegative = 0.04
    noise_color: Nonnegative = 2.0
    decay: Annotated[float, Field(gt=0, le=1, allow_inf_nan=False)] = 0.5
    temperature: Positive = 0.1
    damping: Annotated[float, Field(ge=0, lt=1, allow_inf_nan=False)] = 0.1
    max_velocity: Positive = 1.0
    max_acceleration: Positive = 4.0
    replay_tolerance: Positive = 1e-5
    guidance_weight: Nonnegative = 100.0
    task_weight: Nonnegative = 200.0
    grasp_weight: Nonnegative = 2.0


def project(
    proposed: NDArray[np.float64],
    previous: NDArray[np.float64],
    velocity: NDArray[np.float64],
    intervals: NDArray[np.float64],
    dt: float,
    config: Config,
) -> NDArray[np.float64]:
    """Project arm targets onto position, speed and acceleration intersections."""
    result = proposed.copy()
    for t in range(len(result)):
        # Reserve one step plus continuous braking distance before each limit.
        distance_lower = np.maximum(previous - intervals[:, 0], 0)
        distance_upper = np.maximum(intervals.sum(axis=1) - previous, 0)
        braking = config.max_acceleration * dt
        speed_lower = (
            np.sqrt(braking**2 + 2 * config.max_acceleration * distance_lower) - braking
        )
        speed_upper = (
            np.sqrt(braking**2 + 2 * config.max_acceleration * distance_upper) - braking
        )
        lower = np.maximum.reduce(
            [
                previous - np.minimum(config.max_velocity, speed_lower) * dt,
                previous + velocity * dt - config.max_acceleration * dt**2,
            ]
        )
        upper = np.minimum.reduce(
            [
                previous + np.minimum(config.max_velocity, speed_upper) * dt,
                previous + velocity * dt + config.max_acceleration * dt**2,
            ]
        )
        if np.any(lower > upper + 1e-10):
            raise ValueError("No bounded joint target exists for this proposal")
        result[t, :7] = np.clip(result[t, :7], lower, upper)
        velocity = (result[t, :7] - previous) / dt
        previous = result[t, :7]
    return result


class NativeProcess:
    """Own the live simulator subprocess and its line-oriented JSON channel."""

    def __init__(self, command: list[str], output: Path, resources: ExitStack):
        self.log = resources.enter_context((output / "native.log").open("w"))
        self.process = subprocess.Popen(
            command + ["--output", str(output)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=self.log,
            text=True,
            bufsize=1,
        )
        assert self.process.stdin is not None and self.process.stdout is not None
        self.input = self.process.stdin
        self.output = self.process.stdout
        resources.callback(self.close)
        self.initial = self.read()

    def read(self) -> dict:
        for line in self.output:
            if line.startswith("MPC_JSON "):
                return json.loads(line[len("MPC_JSON ") :])
            self.log.write(line)
            self.log.flush()
        raise RuntimeError(f"Native process exited with code {self.process.wait()}")

    def request(self, request: dict) -> dict:
        self.input.write(json.dumps(request) + "\n")
        self.input.flush()
        return self.read()

    def close(self) -> None:
        try:
            if self.process.poll() is None:
                try:
                    self.input.write('{"operation":"close"}\n')
                    self.input.flush()
                except BrokenPipeError:
                    pass
                try:
                    self.process.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    self.process.terminate()
                    try:
                        self.process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        self.process.kill()
                        self.process.wait()
        finally:
            try:
                self.input.close()
            except BrokenPipeError:
                pass
            finally:
                self.output.close()


def predict(command: list[str], directory: Path, name: str, request: dict) -> dict:
    """Replay the executed prefix in a fresh simulator, retaining all evidence."""
    input_path = directory / (name + ".request.json")
    output_path = directory / (name + ".response.json")
    input_path.write_text(json.dumps(request) + "\n")
    started = time.perf_counter()
    with (directory / (name + ".log")).open("w") as log:
        subprocess.run(
            command + ["--request", str(input_path), "--response", str(output_path)],
            stdout=log,
            stderr=subprocess.STDOUT,
            check=True,
            timeout=180,
        )
    response = json.loads(output_path.read_text())
    response["wall_s"] = time.perf_counter() - started
    with gzip.open(str(output_path) + ".gz", "wt") as archive:
        json.dump(response, archive)
    output_path.unlink()
    return response


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--task", choices=["TakeLidOffSaucepan", "PushButton"], required=True
    )
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--budget", type=int)
    parser.add_argument("--config", type=Path)
    args = parser.parse_args()
    config = (
        Config.model_validate_json(args.config.read_text()) if args.config else Config()
    )
    budget = (
        args.budget
        if args.budget is not None
        else {
            "TakeLidOffSaucepan": 278,
            "PushButton": 236,
        }[args.task]
    )
    if budget < 1 or args.workers < 1:
        parser.error("budget and workers must be positive")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    rollouts = output / "rollouts"
    rollouts.mkdir()
    script_dir = Path(__file__).resolve().parent
    command = [
        "bash",
        str(script_dir / "run_voxposer.sh"),
        "rlbench_mpc.py",
        "--task",
        args.task,
        "--seed",
        str(args.seed),
    ]
    for filename in ("run_guided_mpc_rlbench.py", "rlbench_mpc.py", "run_voxposer.sh"):
        shutil.copy2(script_dir / filename, output / filename)
    optimizer_sources = {}
    for function in (softmax_weights, colored_noise):
        source = Path(inspect.getfile(function))
        shutil.copy2(source, output / ("robotl-" + source.name))
        optimizer_sources[function.__name__] = {
            "file": str(source),
            "sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        }
    settings = {
        **config.model_dump(),
        "task": args.task,
        "seed": args.seed,
        "budget": budget,
        "workers": args.workers,
        "sampler": "RoboTL colored_noise + softmax_weights; native adapter MPPI rounds",
        "constraints": "Native joint intervals; bounded target speed/acceleration; native arm collision collection",
        "model": "Fresh CoppeliaSim 4.1.0 scenes, replay executed prefix, native dynamics",
        "privileged": "Object poses, task grasp status, button joint, native model rollouts; authored objectives",
        "optimizer_pid": os.getpid(),
        "robotl_sources": optimizer_sources,
    }
    (output / "config.json").write_text(json.dumps(settings, indent=2) + "\n")
    started = time.perf_counter()
    executed: list[list[float]] = []
    frames = []
    elite = None
    seed_costs = []
    selection_costs = []
    model_steps = 0
    replay_steps = 0
    planning_wall = 0.0
    key = jr.PRNGKey(args.seed)
    weights = {
        "guidance": config.guidance_weight,
        "task": config.task_weight,
        "grasp": config.grasp_weight,
    }
    result = {"task": args.task, "seed": args.seed, "status": "running"}
    try:
        with ExitStack() as resources:
            live = NativeProcess(command, output, resources)
            pool = resources.enter_context(ThreadPoolExecutor(max_workers=args.workers))
            diagnostics = resources.enter_context(
                (output / "optimization.jsonl").open("w")
            )
            metadata = live.initial["metadata"]
            state = live.initial["state"]
            (output / "initial-state.json").write_text(
                json.dumps(live.initial, indent=2) + "\n"
            )
            expected_instruction = {
                "TakeLidOffSaucepan": "take lid off the saucepan",
                "PushButton": "push the teal button",
            }[args.task]
            if metadata["instruction"] != expected_instruction:
                raise ValueError(
                    f"Unexpected task variation: {metadata['instruction']}"
                )
            dt = metadata["dt"]
            intervals = np.asarray(metadata["joint_intervals"])
            previous = np.asarray(state["targets"])
            velocity = np.zeros(7)
            while len(executed) < budget:
                plan_started = time.perf_counter()
                step = len(executed)
                prefix = {
                    "prefix": executed,
                    "expected": state,
                    "tolerance": config.replay_tolerance,
                }
                proposal = predict(
                    command,
                    rollouts,
                    f"{step:04d}-proposal",
                    {
                        **prefix,
                        "operation": "propose",
                        "horizon": config.horizon,
                    },
                )
                replay_steps += len(executed)
                guidance = proposal["guidance"]
                horizon = min(config.horizon, budget - step)
                seed = np.tile(
                    [*proposal["joint_goal"], guidance["gripper"]], (horizon, 1)
                )
                seed = project(seed, previous, velocity, intervals, dt, config)
                mean = seed.copy()
                best = seed.copy()
                best_cost = float("inf")
                first_seed_cost = None
                all_rounds = []
                for iteration in range(config.rounds):
                    population = [seed.copy()]
                    if iteration:
                        population.append(best.copy())
                    elif elite is not None:
                        carried = np.concatenate(
                            [elite, np.repeat(elite[-1:], horizon, axis=0)]
                        )[:horizon]
                        carried[:, 7] = seed[:, 7]
                        population.append(
                            project(carried, previous, velocity, intervals, dt, config)
                        )
                    while len(population) < config.candidates:
                        key, sample_key = jr.split(key)
                        noise = np.asarray(
                            colored_noise(sample_key, (horizon, 7), config.noise_color)
                        )
                        candidate = mean.copy()
                        candidate[:, :7] += (
                            config.sigma * config.decay**iteration * noise
                        )
                        candidate[:, 7] = seed[:, 7]
                        if state["gripper_command"] == 1 and guidance["gripper"] == 0:
                            delay = 2 * (len(population) % 4)
                            candidate[:delay, 7] = 1
                        population.append(
                            project(
                                candidate, previous, velocity, intervals, dt, config
                            )
                        )
                    requests = [
                        {
                            **prefix,
                            "operation": "rollout",
                            "candidate": candidate.tolist(),
                            "guidance": guidance,
                            "weights": weights,
                        }
                        for candidate in population
                    ]
                    names = [
                        f"{step:04d}-r{iteration}-c{i:02d}"
                        for i in range(len(population))
                    ]
                    predictions = list(
                        pool.map(
                            lambda item: predict(command, rollouts, item[0], item[1]),
                            zip(names, requests),
                        )
                    )
                    model_steps += horizon * len(population)
                    replay_steps += len(executed) * len(population)
                    costs = np.array([p["cost"] for p in predictions])
                    feasible = np.array(
                        [p["feasible"] for p in predictions]
                    ) & np.isfinite(costs)
                    if first_seed_cost is None:
                        first_seed_cost = float(costs[0]) if feasible[0] else None
                    indices = np.flatnonzero(feasible)
                    if not len(indices):
                        raise RuntimeError(
                            "No collision-free candidate in the evaluated population"
                        )
                    selected = int(indices[np.argmin(costs[indices])])
                    if costs[selected] < best_cost:
                        best, best_cost = (
                            population[selected].copy(),
                            float(costs[selected]),
                        )
                    probability = np.asarray(
                        softmax_weights(costs[indices], config.temperature)
                    )
                    weighted = np.einsum(
                        "b,bta->ta", probability, np.asarray(population)[indices, :, :7]
                    )
                    mean[:, :7] = (
                        config.damping * mean[:, :7] + (1 - config.damping) * weighted
                    )
                    all_rounds.append(
                        {
                            "round": iteration,
                            "candidate_artifacts": names,
                            "costs": costs.tolist(),
                            "feasible": feasible.tolist(),
                            "selected": selected,
                            "weights": probability.tolist(),
                            "weight_indices": indices.tolist(),
                            "replay_errors": [p["replay_error"] for p in predictions],
                        }
                    )
                unchanged = live.request({"operation": "state"})
                if unchanged != state:
                    raise RuntimeError("Planning mutated the live state")
                elapsed = time.perf_counter() - plan_started
                planning_wall += elapsed
                record = {
                    "step": step,
                    "guidance": guidance,
                    "rounds": all_rounds,
                    "seed_cost": first_seed_cost,
                    "selected_cost": best_cost,
                    "improved_seed": first_seed_cost is not None
                    and best_cost < first_seed_cost - 1e-9,
                    "selected_controls": best.tolist(),
                    "planning_wall_s": elapsed,
                    "live_state_sha256": hashlib.sha256(
                        json.dumps(state, sort_keys=True).encode()
                    ).hexdigest(),
                    "live_unchanged": True,
                }
                diagnostics.write(json.dumps(record) + "\n")
                diagnostics.flush()
                seed_costs.append(first_seed_cost)
                selection_costs.append(best_cost)
                count = min(config.execute_steps, horizon)
                for action in best[:count]:
                    control = action.tolist()
                    frame = live.request({"operation": "step", "action": control})
                    frames.append(frame)
                    executed.append(control)
                    velocity = (action[:7] - previous) / dt
                    previous = action[:7].copy()
                    state = frame["state"]
                    if frame["arm_collision"]:
                        raise RuntimeError("Executed arm collision despite prediction")
                elite = best[count:]
                if not len(elite):
                    elite = best[-1:]
                print(
                    json.dumps(
                        {
                            "steps": len(executed),
                            "stage": guidance["stage"],
                            "success": frames[-1]["success"],
                            "seed_cost": first_seed_cost,
                            "selected_cost": best_cost,
                            "planning_wall_s": elapsed,
                        }
                    ),
                    flush=True,
                )
            result.update(status="completed", metadata=metadata, final_state=state)
    except Exception as error:
        result.update(status="error", error=f"{type(error).__name__}: {error}")
        raise
    finally:
        result.update(
            physics_steps=len(executed),
            success_any=any(frame["success"] for frame in frames),
            success_final=bool(frames and frames[-1]["success"]),
            first_success_step=next((f["step"] for f in frames if f["success"]), None),
            wall_s=time.perf_counter() - started,
            planning_wall_s=planning_wall,
            model_prediction_steps=model_steps,
            model_replay_steps=replay_steps,
            replans=len(seed_costs),
            seed_costs=seed_costs,
            selected_costs=selection_costs,
        )
        (output / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()

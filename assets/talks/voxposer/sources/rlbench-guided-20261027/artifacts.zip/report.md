# Guided MPC on the two original RLBench tasks

Both seed-0 Guided MPC episodes reached native RLBench success and retained it through the full execution cap. The saucepan lid remained grasped 14.95 cm above its initial height. The button ended with 4.10 mm displacement, above its native 3 mm threshold.

| Task | Method | Any native success | Final native success | Steps | First success |
| --- | --- | --- | --- | --- | --- |
| TakeLidOffSaucepan | Original VoxPoser | Yes | No | 278 recorded | Not saved |
| TakeLidOffSaucepan | Guided MPC | Yes | Yes | 278 total | 167 (8.35 s) |
| PushButton, teal | Original VoxPoser | No | No | 236 recorded | None |
| PushButton, teal | Guided MPC | Yes | Yes | 236 total | 70 (3.50 s) |

The new saucepan predicate stayed true from step 167 through 278; grasp began at step 159. The button predicate stayed true from step 70 through 236. Button acceptance is natively latched, but its final joint displacement independently still exceeded the threshold. These are one episode per task, not success-rate estimates. Full outcomes and independently derived checks are in [comparison.json](comparison.json), [saucepan audit](saucepan-v1/audit.json) and [button audit](button-v1/audit.json).

| Guided MPC task | Simulation | Wall time | Planning wall time | Replans | Prediction steps | Prefix-replay steps |
| --- | --- | --- | --- | --- | --- | --- |
| Saucepan | 13.90 s | 1,571.23 s (26.2 min) | 1,470.03 s | 35 | 17,024 | 80,920 |
| Button | 11.80 s | 1,057.61 s (17.6 min) | 982.17 s | 30 | 14,336 | 59,160 |

Prediction/replay counts exclude simulator initialization. Simulation pauses during planning; this implementation is not real-time. The original VoxPoser wall times, 13.94 s and 9.81 s, are cached-program replays excluding initial LLM generation and are not comparable end-to-end performance measurements.

The controller uses a native CoppeliaSim dynamics model, with a new RLBench adapter around RoboTL's actual `colored_noise` and `softmax_weights` functions. The imported sources were archived from RoboTL revision `e7649429ef5b80d02461a7500be164770a7c00ae`; their complete files, loaded paths and hashes are saved with each run. MuJoCo-specific planner/rollout classes were not transplanted into RLBench.

At each replan, an IK solve proposes a joint goal toward the current task objective, limited to a 10 cm Cartesian advance. The sampler constructs eight candidate sequences and performs two rounds of native dynamic prediction, finite-feasible cost weighting and elite retention. It executes eight controls, shifts the remaining plan, observes the new state and repeats. The horizon is 32 steps (1.6 s), truncated at the remaining budget. Gaussian perturbations use 0.04 rad initial scale, temporal noise exponent 2, round decay 0.5, softmax temperature 0.1 and mean damping 0.1. Binary gripper proposals include delayed closure. IK supplies a seed; the simulator evaluates the sequences before selection.

Guidance approaches the lid handle, closes within 2 cm, then lifts and retains it 15 cm above its initial height. Button guidance approaches 10 cm above the plate and presses toward 1 cm below it once horizontally aligned. The stage objective uses weights 100 for tip guidance, 200 for task error and 2 for missing grasp. A trajectory costs its mean state cost plus terminal cost. This is an excerpt of the actual authored [objective program](saucepan-v1/rlbench_mpc.py), also saved verbatim with the button run:

```python
    guide = np.sum((tip - guidance["target"]) ** 2)
    if metadata["task"] == "TakeLidOffSaucepan":
        task = max(0, metadata["initial_target"][2] + 0.15 - state["target"][2]) ** 2
        grasp = float(guidance["stage"] in ("grasp", "lift") and not state["grasped"])
    else:
        task = (
            max(0, 0.003 - abs(state["button_joint"] - metadata["initial_joint"])) ** 2
        )
        grasp = 0.0
    return float(
        weights["guidance"] * guide + weights["task"] * task + weights["grasp"] * grasp
    )
```

These programs are authored, not LLM-generated. The first button replan selected cost 53.8179776460 versus seed cost 56.8125355956. The first four selected controls are shown below, with two arm coordinates and the gripper command excerpted and rounded to six decimals. The [full evaluated candidate](button-v1/rollouts/0000-r1-c03.request.json), [original prediction](button-v1/rollouts/0000-r1-c03.response.json.gz) and [executed trace](button-v1/execution.jsonl) retain all values.

| Control | Joint 1 target (rad) | Joint 2 target (rad) | Gripper (1=open) |
| --- | --- | --- | --- |
| 0 | -0.005282 | 0.164533 | 1 |
| 1 | -0.020565 | 0.144533 | 1 |
| 2 | -0.045847 | 0.134533 | 1 |
| 3 | -0.061129 | 0.114533 | 1 |

Optimization reduced feasible-seed cost in 27/30 button replans and 17/35 saucepan replans. In another 11 saucepan replans, the seed violated native arm-collision checks and a feasible alternative was selected. These are within-replan predictive improvements, not evidence from a seed-only closed-loop ablation.

Joint targets obey the native intervals, a 1 rad/s target-speed bound and a 4 rad/s$^2$ target-acceleration bound, with braking distance reserved near joint limits. These are command bounds, not measured physical-motion bounds. Native servo settings, collision geometry and physics were retained; all candidate frames used the native arm collision collection. Neither executed episode registered an arm collision. Native gripper attachment semantics are preserved, including RLBench's proximity-based attachment mechanism.

Each prediction used a fresh simulator process and replayed the executed prefix. This avoids relying on RLBench's configuration-tree snapshot, which omits Python condition progress and gripper bookkeeping. All candidate-start replay checks had zero measured error, including object/joint state, motor targets, attachment parents, gripper memory and native condition progress. All 65 planning calls left the live state unchanged. An independent audit matched every executed physical/control/success snapshot to its selected prediction: 236 button steps and 278 saucepan steps.

A post-run audit found historical gripper-memory aliasing in six selected prediction frames per task. The executed logs, physical predictions, costs and native outcomes were unaffected. Commit `eb7ebc5` copies these lists; the [delayed-closure regression](check-memory/checks.json) passes exact eight-frame prediction/execution equality and zero prefix-replay error. Original prediction files remain intact; [corrected diagnostic replays](diagnostic-memory-fix/) are separate. The earlier [setup check](check-v1/proposal.log) failed before execution because its Jacobian IK target was too distant; the 10 cm seed limit resolved that before both full trials.

The comparison preserves the Panda arm, parallel gripper, task models, CoppeliaSim 4.1.0, dt 0.05 s, PyRep revision `8f420be8064b1970aae18a9cfbc978dfb15747ef`, RLBench revision `02720bba4c73fe02eb75df946b8791b806028a9d` and native acceptance. Actual variations were saucepan 0 and button 12; the button base was RGB `[0, 0.5, 0.5]`. Both original-resolution initial images differed from the references by at most 2/255 per RGB channel, with mean absolute error about 0.048/255. Model hashes and complete new initial states are saved. The original numeric initial state was not saved, so exact full-state identity remains unverified.

There are three material comparison differences. The controller receives privileged object poses, grasp status and button-joint state, plus oracle simulator predictions; VoxPoser used segmented point clouds. Full simulator/Python state is exposed for replay verification. Task source and native waypoint poses were inspected for audit and diagnosis; waypoint poses are recorded but not used by the executed controller. It commands bounded joint targets with simultaneous arm/gripper motion, whereas VoxPoser requested Cartesian paths and discrete gripper actions. Finally, the original recorder counted scene callbacks and missed native gripper-actuation steps, while sampling success at completed actions. The new 278/236 caps count every executed physics step and sample native success every step. Thus the physical task is reproduced, but observation/action access and total reference interaction accounting are not matched. This evidence supports these two executions, not a general claim of algorithmic superiority.

The [saucepan comparison video](saucepan-voxposer-left-guided-right.mp4) and [button comparison video](button-voxposer-left-guided-right.mp4) put original VoxPoser on the left and Guided MPC on the right. The originals were 128px and are enlarged only for layout; the new 640px recordings come from the actual executed trajectories. Original video checksums match the immutable [reference manifest](reference/manifest.json). Individual new videos are [saucepan](saucepan-v1/episode.mp4) and [button](button-v1/episode.mp4). Per-run configs, saved programs, execution logs and all candidate diagnostics accompany them.

Coding and coordination stayed on `datnguyen@dats-macbook-pro`. Trials ran concurrently as `amberli@polly` under `/home/amberli/Marc/guided-mpc-rlbench-20261027`; `rolly` was offline on two access checks. Other jobs and the original dirty checkout were left untouched. Neither the second Mac nor the decommissioned Mac ran experiments. All artifacts are under ignored local `results/` and the private Linux run directory; the live slide decks were not edited.

The implementation branch is `codex/guided-mpc-rlbench`, with [draft PR #4](https://github.com/datvo06/guided-mpc-baselines/pull/4). Commit `e6a3c16` exactly matches the frozen trial controller sources; `a7fd945` tightens configuration/provenance, and `eb7ebc5` fixes diagnostic snapshots. Ruff, mypy, focused native checks and the delayed-closure regression pass. Only one full-budget episode per task was run; no longer diagnostic episode or large sweep was needed.

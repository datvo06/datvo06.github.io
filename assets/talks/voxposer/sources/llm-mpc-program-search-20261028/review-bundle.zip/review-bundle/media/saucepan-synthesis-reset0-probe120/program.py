
from dataclasses import dataclass
from math import sqrt
from mpc_program import Action, CartesianProposal, JointProposal, ProgramObservation, Proposals


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def dist(a, b):
    return sqrt(sum((x-y)*(x-y) for x, y in zip(a, b)))


@dataclass(frozen=True)
class State:
    phase: str
    last_grasped: bool
    object_start_z: float


class SaucepanLidProgram:
    def init(self, observation: ProgramObservation, instruction: str) -> State:
        return State('approach_above', observation.grasped, observation.object_pose[2])

    def advance(self, state: State, action: Action, observation: ProgramObservation) -> State:
        obj = observation.object_pose[:3]
        tip = observation.tip[:3]
        xy_err = dist(obj[:2], tip[:2])
        z_above = obj[2] + 0.10
        z_err = abs(tip[2] - z_above)
        close_xy = xy_err < 0.035
        if observation.grasped:
            phase = 'lift'
        elif state.phase == 'approach_above':
            phase = 'descend' if (close_xy and z_err < 0.04) else 'approach_above'
        elif state.phase == 'descend':
            phase = 'close' if (xy_err < 0.03 and abs(tip[2] - (obj[2] + 0.02)) < 0.035) else 'descend'
        elif state.phase == 'close':
            phase = 'lift'
        else:
            phase = state.phase
        return State(phase, observation.grasped, state.object_start_z)

    def proposals(self, state: State, observation: ProgramObservation) -> Proposals:
        ox, oy, oz, oqx, oqy, oqz, oqw = observation.object_pose
        tx, ty, tz, *_ = observation.tip
        # keep tool orientation roughly fixed; task likely tolerant and adapter handles short steps
        quat = observation.tip[3:]
        if state.phase == 'approach_above':
            target = (ox, oy, oz + 0.12)
            grip = 1
        elif state.phase == 'descend':
            target = (ox, oy, oz + 0.02)
            grip = 1
        elif state.phase == 'close':
            target = (ox, oy, oz + 0.02)
            grip = 0
        else:  # lift
            target = (ox, oy, oz + 0.22)
            grip = 0 if observation.grasped else 1
        props = [CartesianProposal(target=target, quaternion=quat, gripper=grip)]
        # fallback joint hold can help if IK fails
        props.append(JointProposal(actions=((*observation.joint_targets, grip),)))
        return tuple(props)

    def trajectory_cost(self, initial: State, states: tuple[State, ...], observations: tuple[ProgramObservation, ...]) -> float:
        if not observations:
            return 0.0
        o = observations[-1]
        obj = o.object_pose[:3]
        tip = o.tip[:3]
        xy = dist(obj[:2], tip[:2])
        if o.grasped:
            return -(obj[2] - initial.object_start_z) + 0.1 * xy
        phase = states[-1].phase if states else initial.phase
        if phase == 'approach_above':
            return xy + abs(tip[2] - (obj[2] + 0.12))
        if phase == 'descend':
            return xy + 0.5 * abs(tip[2] - (obj[2] + 0.02))
        return xy + 0.02


program = SaucepanLidProgram()


from dataclasses import dataclass
from typing import Literal

from mpc_program import CartesianProposal, ProgramObservation, Proposals


@dataclass(frozen=True)
class State:
    target: tuple[float, float, float]
    quat: tuple[float, float, float, float]


class ButtonProgram:
    def init(self, observation: ProgramObservation, instruction: str) -> State:
        obj = observation.object_pose
        target = (obj[0], obj[1], obj[2] + 0.03)
        quat = (0.0, 1.0, 0.0, 0.0)
        return State(target=target, quat=quat)

    def advance(self, state: State, action, observation: ProgramObservation) -> State:
        obj = observation.object_pose
        if observation.button_displacement is not None and observation.button_displacement > 0.015:
            target = (obj[0], obj[1], obj[2] + 0.05)
        else:
            target = (obj[0], obj[1], obj[2] + 0.01)
        return State(target=target, quat=state.quat)

    def proposals(self, state: State, observation: ProgramObservation) -> Proposals:
        return (CartesianProposal(target=state.target, quaternion=state.quat, gripper=1),)

    def trajectory_cost(self, initial: State, states, observations) -> float:
        if not observations:
            return 0.0
        obs = observations[-1]
        obj = obs.object_pose
        tip = obs.tip
        dx = tip[0] - obj[0]
        dy = tip[1] - obj[1]
        dz = tip[2] - (obj[2] + 0.01)
        d2 = dx*dx + dy*dy + dz*dz
        bd = obs.button_displacement or 0.0
        return d2 - 10.0 * bd


program = ButtonProgram()

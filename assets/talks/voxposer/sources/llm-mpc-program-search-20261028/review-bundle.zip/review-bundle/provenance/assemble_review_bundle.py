"""Collect exact private pilot sources, outcomes, provenance and review media."""

import hashlib
import json
import shutil
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "rolly"
OUTPUT = ROOT / "review-bundle"
REMOTE = Path("/home/datnguyen/Marc/guided-mpc-program-search-20261028/results")
REFERENCE = "14e08062d8e1caa9a8a06609bb66b9104ba761bfec5d474c8b97d5ee106ff8b1"
NEUTRAL = "8b268ec02f4842cd1cfab8c8b0dcb3b6dab909d9579fa4c7fcb57dea887a4b4a"


def copy(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if source.read_bytes() == target.read_bytes():
            return
        target.unlink()
    shutil.copy2(source, target)
    assert hashlib.sha256(source.read_bytes()).digest() == hashlib.sha256(target.read_bytes()).digest()


def usage(path: Path) -> dict:
    with sqlite3.connect(path) as db:
        charged, confirmed, unsettled = db.execute("SELECT SUM(COALESCE(actual,reserved)),SUM(COALESCE(actual,0)),COUNT(*) FILTER (WHERE actual IS NULL) FROM work").fetchone()
        maximum, deadline = db.execute("SELECT steps,deadline FROM limits").fetchone()
    return {"charged_steps": charged, "confirmed_steps": confirmed, "unsettled_reservations": unsettled, "maximum_steps": maximum, "deadline_epoch": deadline}


def native_final(result: dict) -> bool:
    return result.get("native_success_final", result["success_final"])


def episode(result: dict, reset: int, sampling: int, requested: int, full_cap: int) -> dict:
    return {"reset_seed": reset, "sampling_seed": sampling, "requested_cap": requested, "executed_steps": result["physics_steps"], "status": result["status"], "native_any": result["success_any"], "native_final": native_final(result), "primary_full_task_success": bool(result["status"] == "completed" and result["physics_steps"] == full_cap and native_final(result)) if requested == full_cap else None, "final_success_start_step": result.get("final_success_start_step"), "wall_s": result.get("wall_s"), "simulator_steps": result.get("total_simulator_steps"), "model_steps": result.get("model_prediction_steps"), "replay_steps": result.get("model_replay_steps"), "initialization_steps": result.get("initialization_steps"), "error": result.get("error"), "artifact_path": result.get("artifact_path")}


def media(label: str, artifact: Path, *, cap: int, source_hash: str) -> dict:
    destination = OUTPUT / "media" / label
    for name in ("episode.mp4", "program.py", "program.sha256", "config.json", "result.json", "initial-state.json", "execution.jsonl", "initial.png", "final.png"):
        path = artifact / name
        if path.exists():
            copy(path, destination / name)
    assert hashlib.sha256((destination / "program.py").read_bytes()).hexdigest() == source_hash
    config = json.loads((destination / "config.json").read_text())
    assert config["budget"] == cap
    return {"label": label, "path": str(destination.relative_to(OUTPUT)), "requested_cap": cap, "reset_seed": config["seed"], "sampling_seed": config["sampling_seed"], "source_hash": source_hash, "video_present": (destination / "episode.mp4").exists()}


def find_case(study: str, digest: str, reset: int, cap: int) -> Path:
    matches = []
    for path in (INPUT / study / "programs" / digest).glob("trial-*/config.json"):
        config = json.loads(path.read_text())
        if config["seed"] == reset and config["budget"] == cap:
            matches.append(path.parent)
    assert len(matches) == 1, (study, digest, reset, cap, matches)
    return matches[0]


OUTPUT.mkdir(exist_ok=True)
summary = {"code_commit": "301196c", "draft_pr": "https://github.com/datvo06/guided-mpc-baselines/pull/7", "model": "openrouter/openai/gpt-5.4", "protocol": {"training_cases": [[0,101],[1,102],[2,103],[3,104]], "heldout_cases": [[4,201],[5,202],[6,203],[7,204]], "candidate_limit": 4, "case_attempt_limit": 8, "search_step_limit": 800000, "search_wall_limit_s": 14400}, "studies": {}, "reference_training": {}, "heldout": {}, "media": [], "private_store": {"dataset": "datvo06/guided-mpc-baseline-results", "private_verified": True, "upload_status": "blocked", "reason": "HTTP 403: private storage limit reached; no public upload, deletion or paid upgrade attempted"}}
for task, cap in (("button",236),("saucepan",278)):
    for condition in ("improvement", "synthesis"):
        name = f"{condition}-{task}"
        directory = INPUT / name
        selection = json.loads((directory / "selection.json").read_text())
        allowance = usage(directory / "allowance.sqlite")
        start = allowance["deadline_epoch"] - 14400
        terminal = (directory / "selection.json").stat().st_mtime
        study = {"selection": selection, "allowance": allowance, "wall_elapsed_s": terminal-start, "started_utc": datetime.fromtimestamp(start,timezone.utc).isoformat(), "terminal_utc": datetime.fromtimestamp(terminal,timezone.utc).isoformat(), "programs": [], "case_wall_sum_s": 0}
        with sqlite3.connect(directory / "study.sqlite") as db:
            for order, digest in db.execute("SELECT rowid,hash FROM programs ORDER BY rowid"):
                source = directory / "programs" / digest / "program.py"
                assert hashlib.sha256(source.read_bytes()).hexdigest() == digest
                copy(source, OUTPUT / "sources" / (digest + ".py"))
                trials = []
                for trial_id, reset, sampling, requested, raw in db.execute("SELECT id,reset,sampling,cap,result FROM trials WHERE hash=? ORDER BY reset,sampling,id", (digest,)):
                    assert raw is not None
                    result = json.loads(raw)
                    record = episode(result, reset, sampling, requested, cap)
                    record["trial_id"] = trial_id
                    trials.append(record)
                    study["case_wall_sum_s"] += result.get("wall_s",0)
                    artifact = directory / "programs" / digest / f"trial-{trial_id}"
                    for filename in ("result.json", "config.json", "execution.jsonl", "initial-state.json", "program.sha256"):
                        if (artifact / filename).exists():
                            copy(artifact / filename, OUTPUT / "studies" / name / "trials" / f"trial-{trial_id}" / filename)
                full = [r for r in trials if r["requested_cap"] == cap and (r["status"] == "failed" or (r["status"] == "completed" and r["executed_steps"] == cap))]
                eligible = {(r["reset_seed"], r["sampling_seed"]) for r in full} == {(0,101),(1,102),(2,103),(3,104)}
                study["programs"].append({"order": order, "source_hash": digest, "source": f"sources/{digest}.py", "authorship": "authored reference" if digest == REFERENCE else "authored neutral scaffold" if digest == NEUTRAL else "LLM revision" if condition == "improvement" else "LLM synthesis", "selected": digest == selection["source_hash"], "eligible_full_training": eligible, "primary_success_count_out_of_four": sum(r["primary_full_task_success"] for r in full) if eligible else None, "status": "unevaluated" if not trials else "full_training" if eligible else "probe_only_or_incomplete", "trials": trials})
        for path in directory.iterdir():
            if path.is_file() and path.suffix in (".json", ".jsonl", ".py", ".md", ".txt", ".sqlite"):
                copy(path, OUTPUT / "studies" / name / path.name)
            elif path.is_dir() and path.name.startswith("code"):
                for source in path.rglob("*"):
                    if source.is_file() and "__pycache__" not in source.parts:
                        copy(source, OUTPUT / "studies" / name / source.relative_to(directory))
        summary["studies"][name] = study
    reference = INPUT / f"reference-{task}"
    outcomes = []
    for path in sorted(reference.glob("case-*/result.json")):
        result = json.loads(path.read_text())
        config = json.loads((path.parent / "config.json").read_text())
        result["artifact_path"] = str(REMOTE / path.parent.relative_to(INPUT))
        outcomes.append(episode(result,config["seed"],config["sampling_seed"],config["budget"],cap))
    summary["reference_training"][task] = {"cases": outcomes, "allowance": usage(reference / "allowance.sqlite")}
    heldout = INPUT / f"heldout-{task}"
    if (heldout / "outcomes.json").exists():
        data = json.loads((heldout / "outcomes.json").read_text())
        heldout_allowance = usage(heldout / "allowance.sqlite")
        summary["heldout"][task] = {"status": "finished", "physical_episodes": data["physical_episodes"], "allowance": heldout_allowance, "wall_elapsed_s": (heldout / "outcomes.json").stat().st_mtime - (heldout_allowance["deadline_epoch"] - 14400), "case_wall_sum_s": sum(row["result"]["wall_s"] for row in data["outcomes"]), "cases": [{**episode(row["result"],row["reset"],row["sampling"],cap,cap), "conditions": row["conditions"], "source_hash": row["source_hash"], "episode_id": row["episode_id"]} for row in data["outcomes"]]}
        for path in heldout.rglob("*"):
            if path.is_file() and "rollouts" not in path.parts and "__pycache__" not in path.parts and path.suffix in (".json", ".jsonl", ".py", ".sqlite", ".sh"):
                copy(path, OUTPUT / f"heldout-{task}" / path.relative_to(heldout))
        for candidate in data["outcomes"]:
            success = candidate["result"]["status"] == "completed" and candidate["result"]["physics_steps"] == cap and native_final(candidate["result"])
            artifact = INPUT / Path(candidate["result"]["artifact_path"]).relative_to(REMOTE)
            summary["media"].append(media(f"heldout-{task}-{'success' if success else 'failure'}-reset{candidate['reset']}", artifact, cap=cap, source_hash=candidate["source_hash"]))
    else:
        summary["heldout"][task] = {"status": "running"}

summary["media"].extend([
    media("button-reset3-reference-full236", INPUT / "reference-button/case-3-104", cap=236, source_hash=REFERENCE),
    media("button-reset3-revision-full236", find_case("improvement-button", "561011071f9c95eca3bd8f1afcf9a75c2cd5fc2ea4597ff70b55dcbf859d134b",3,236), cap=236, source_hash="561011071f9c95eca3bd8f1afcf9a75c2cd5fc2ea4597ff70b55dcbf859d134b"),
    media("button-synthesis-reset0-probe80", find_case("synthesis-button", "c9e7e81f36f693db46ae7e987cb4aef3560bec0669e5cfbe0ab289c4e5fbd91c",0,80), cap=80, source_hash="c9e7e81f36f693db46ae7e987cb4aef3560bec0669e5cfbe0ab289c4e5fbd91c"),
    media("saucepan-synthesis-reset0-probe120", find_case("synthesis-saucepan", "92ebde77862023783c9462071b30758f726faf315022d9a5feb43f335e506819",0,120), cap=120, source_hash="92ebde77862023783c9462071b30758f726faf315022d9a5feb43f335e506819"),
])
for name in ("transport-button-frozen", "transport-saucepan-frozen", "component-profile-v2"):
    for path in (INPUT / name).glob("*.json"):
        copy(path, OUTPUT / "profiles" / name / path.name)
for name in ("heldout-source-audit.json", "parent-scoring-timing.txt", "parent-review-probe-budget.txt"):
    copy(INPUT / name, OUTPUT / "provenance" / name)
copy(ROOT / "reference-extraction.json", OUTPUT / "checks/reference-extraction.json")
for name in ("check-extraction", "check-final-interface"):
    copy(INPUT / name / "checks.json", OUTPUT / "checks" / (name + ".json"))
for name in ("focused-tests.log", "changed-contract-tests.log", "runtime-tests.log"):
    copy(INPUT / name, OUTPUT / "checks" / name)
for name in ("pid-namespace-native-check", "pid-namespace-native-check-v2"):
    copy(INPUT / name / "result.json", OUTPUT / "checks" / (name + ".json"))
summary["search_totals"] = {"case_attempts": sum(len(p["trials"]) for s in summary["studies"].values() for p in s["programs"]), "charged_steps": sum(s["allowance"]["charged_steps"] for s in summary["studies"].values()), "confirmed_steps": sum(s["allowance"]["confirmed_steps"] for s in summary["studies"].values()), "unsettled_reservations": sum(s["allowance"]["unsettled_reservations"] for s in summary["studies"].values())}
(OUTPUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({"bundle": str(OUTPUT), "search_totals": summary["search_totals"], "heldout": {k:v["status"] for k,v in summary["heldout"].items()}, "media": len(summary["media"])}))

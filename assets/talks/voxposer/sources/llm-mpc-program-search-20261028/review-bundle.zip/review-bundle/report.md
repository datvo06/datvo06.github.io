# LLM Guided MPC pilot

The implementation now runs frozen Python programs through RLBench, with typed program state, generated objectives and action proposals, and native task acceptance. The bounded search pilots did not improve the selected controller. Both improvement studies selected the unchanged authored reference. Both from-scratch studies exhausted their eight case attempts on diagnostic probes and ended with incomplete search.

[Draft PR #7](https://github.com/datvo06/guided-mpc-baselines/pull/7) contains the implementation, with no result artifacts. It is based on PR #4 and remains unmerged. The commits are `1ff5d2f`, `a8e6c82`, `a3ed990`, `e2fe890`, and `301196c`. The machine-readable [summary](summary.json) records every submitted source, case outcome, allowance and artifact location.

Held-out primary success was 2/4 for button and 1/4 for saucepan. Their sources and cases were frozen after all four search sessions terminated. The two selected sources are byte-identical to the reference, so each task used four physical episodes with explicit reference/improvement aliases. They provide no evidence of LLM improvement.

## Training results

Each task used reset seeds 0, 1, 2 and 3, paired with sampling seeds 101, 102, 103 and 104. Numeric initial states and scene/source hashes were frozen and checked, in addition to the seeds. The button cap is 236 executed steps; the saucepan cap is 278. Primary success requires the native predicate at the full task cap. A declared planning failure is a resolved failed case even if native success occurred earlier. Predicted cost never determines task success.

| Study | Full-cap training evidence | Selection |
| --- | --- | --- |
| Button improvement | Authored reference 3/4; generated revision 2/4 | Unchanged reference |
| Saucepan improvement | Authored reference 3/4; generated revision only ran 80-step probes | Unchanged reference |
| Button synthesis | Four 40-step scaffold probes, then four requested 80-step generated probes | Incomplete search |
| Saucepan synthesis | Four 120-step probes, then four requested 120-step probes that failed planning at step 0 | Incomplete search |

For button improvement, the reference succeeded on resets 0, 2 and 3, with final uninterrupted success starting at steps 80, 79 and 88. Reset 1 failed planning at step 136. The generated revision succeeded on resets 0 and 2, starting at steps 92 and 98; reset 1 failed planning at step 128, and reset 3 completed without native success. The reference wins on primary success count.

For saucepan improvement, the reference had native success at some point on all four cases, but reset 0 ended without it. Resets 1, 2 and 3 succeeded at the cap. All four 80-step revision probes had false native any/final predicates. Those probes cannot establish a full-task failure rate or qualify the revision for selection.

The synthesized button program had no native success in its 80-step probes; reset 1 failed planning after 56 executed steps. The first synthesized saucepan program completed all four 120-step probes without native success. The second failed to produce a feasible proposal at initialization on all four cases. Both studies saved a third source before its evaluation was rejected by the attempt limit. The sources remain available as unevaluated artifacts. These outcomes do not establish that synthesis cannot produce a successful full-budget program.

## Programs and videos

The selected [authored reference](sources/14e08062d8e1caa9a8a06609bb66b9104ba761bfec5d474c8b97d5ee106ff8b1.py) has SHA256 `14e08062d8e1caa9a8a06609bb66b9104ba761bfec5d474c8b97d5ee106ff8b1`. All exact submitted programs, including unevaluated sources, are in [sources](sources), with authorship and evaluation status in [summary.json](summary.json). No generated source was manually repaired.

| Example | Exact program | Video | Observed outcome |
| --- | --- | --- | --- |
| Button reset 3, reference, 236 steps | [Reference](media/button-reset3-reference-full236/program.py) | [Video](media/button-reset3-reference-full236/episode.mp4) | Native any/final true, full-cap success |
| Button reset 3, revision, 236 steps | [LLM revision](media/button-reset3-revision-full236/program.py) | [Video](media/button-reset3-revision-full236/episode.mp4) | Native any/final false |
| Button reset 0, synthesis, 80 steps | [LLM program](media/button-synthesis-reset0-probe80/program.py) | [Video](media/button-synthesis-reset0-probe80/episode.mp4) | Native any/final false; diagnostic probe |
| Saucepan reset 0, synthesis, 120 steps | [LLM program](media/saucepan-synthesis-reset0-probe120/program.py) | [Video](media/saucepan-synthesis-reset0-probe120/episode.mp4) | Native any/final false; diagnostic probe |

The saucepan synthesis provides a concrete typed-state example. Its exact state declaration is:

```python
@dataclass(frozen=True)
class State:
    phase: str
    last_grasped: bool
    object_start_z: float
```

The [full program](sources/92ebde77862023783c9462071b30758f726faf315022d9a5feb43f335e506819.py) advances through approach, descend, close and lift phases, proposes both a Cartesian motion and a joint hold, and scores predicted trajectories using object height and tip distance. This is an actual agent-generated program, including its unused helpers and policy mistakes. Its objective did not produce observed native success during the recorded probes.

For example, the generated objective rewards lifting an attached object using this exact branch:

```python
        if o.grasped:
            return -(obj[2] - initial.object_start_z) + 0.1 * xy
```

The native acceptance predicate remains outside this objective.

## Held-out results

All eight physical episodes finished. Each row is shared by the reference and selected-improvement labels because the frozen program bytes, task, case and evaluator configuration are identical. Synthesis has no selected program and is absent from this comparison. No revision was allowed after these outcomes were opened.

| Task | Reset / sampling seed | Status | Executed / cap | Native any | Raw native final | Primary success | Simulator steps | Wall seconds |
| --- | --- | --- | ---: | --- | --- | --- | ---: | ---: |
| Button | 4 / 201 | Completed | 236 / 236 | True | True | True | 78,842 | 985.57 |
| Button | 5 / 202 | Planning failure | 64 / 236 | False | False | False | 9,412 | 277.90 |
| Button | 6 / 203 | Completed | 236 / 236 | True | True | True | 78,842 | 1,645.63 |
| Button | 7 / 204 | Planning failure | 184 / 236 | True | True | False | 50,482 | 760.57 |
| Saucepan | 4 / 201 | Completed | 278 / 278 | False | False | False | 104,182 | 1,730.69 |
| Saucepan | 5 / 202 | Completed | 278 / 278 | True | True | True | 104,182 | 1,752.82 |
| Saucepan | 6 / 203 | Completed | 278 / 278 | False | False | False | 104,182 | 1,703.17 |
| Saucepan | 7 / 204 | Completed | 278 / 278 | True | False | False | 104,182 | 1,753.17 |

Button reset 7 retained a true native predicate when planning failed at step 184. Its primary score is false because it did not complete the cap. Saucepan reset 7 reached native success transiently, then lost it by the cap. Thus native-any counts are 3/4 for button and 2/4 for saucepan, while primary counts are 2/4 and 1/4.

Button native success is latched by RLBench. A true final native predicate therefore does not establish sustained physical depression; final button displacement is a separate diagnostic in the recorded observations.

All eight [held-out videos and their exact source/config/result records](media) are included. The button distinction is visible in [reset 7](media/heldout-button-failure-reset7/episode.mp4); the saucepan transient outcome is [reset 7](media/heldout-saucepan-failure-reset7/episode.mp4). Full frozen manifests and condition aliases are in [heldout-button](heldout-button) and [heldout-saucepan](heldout-saucepan).

Each held-out task had a separate 1,600,000-step, four-hour allowance and four parallel case workers. Button charged and confirmed 217,578 simulator steps; saucepan charged and confirmed 416,728. The combined 634,306 steps cover eight physical episodes, with zero unsettled reservations. Shared condition labels do not double this compute. Elapsed wall times were 1,647.11 s and 1,754.60 s; summed case wall times were 3,669.67 s and 6,939.85 s.

## Budgets and compute

Each study allowed four distinct sources, eight case attempts, 800,000 simulator steps and four hours. Each evaluation dispatches all four training cases. The LLM search agent used `openrouter/openai/gpt-5.4` with an 8,192-token response limit through the existing Effectful Agent/Skill framework. Actual initial contexts, conversations, sources and sanitized training feedback are retained in [studies](studies).

| Study | Case attempts | Charged simulator steps | Confirmed simulator steps | Elapsed wall seconds | Sum of case wall seconds |
| --- | ---: | ---: | ---: | ---: | ---: |
| Button improvement | 8 | 531,096 | 530,796 | 5,178.92 | 6,943.10 |
| Saucepan improvement | 8 | 465,776 | 465,776 | 4,125.85 | 8,155.26 |
| Button synthesis | 8 | 60,236 | 60,236 | 997.84 | 1,834.44 |
| Saucepan synthesis | 8 | 95,568 | 95,568 | 1,339.42 | 2,576.91 |
| Total | 32 | 1,152,676 | 1,152,376 | Not additive across parallel studies | 19,509.71 |

One historical button reservation of 300 steps remains conservatively charged. The improvement-button case records total 530,942 simulator steps, including 146 partial steps inside that reservation; the ledger confirms 530,796 and charges 531,096. Saved partial execution provides additional evidence without silently refunding or settling uncertain work. Simulator counts include initialization, prediction, replay and live execution. Per-case breakdowns are in the summary. Elapsed wall time includes launch repairs and a documented pause; parallel case times must not be interpreted as study elapsed time.

The four-case diagnostic batches consumed all eight attempts in both synthesis studies. This is a limitation of the pilot protocol and agent budget use. No budget was extended and no incomplete source was manually selected. Reference training, held-out evaluation and profiling have separate allowances or measured-work records; they are not included in the search total above. Some early development probes lack the final accounting instrumentation, so this report does not claim an exact total for all development compute.

The independent fixed-reference training check used a separate 1,600,000-step, four-hour allowance per task. Button charged 267,062 steps and confirmed 266,762, with one conservative unsettled reservation; saucepan charged and confirmed 416,728. Both had three full-cap successes out of four. Their summed case wall times were 3,436.51 s and 6,829.99 s. The button reset-1 record retains its original `error` status and structured no-feasible-proposal evidence; the later selection clarification did not rewrite this raw reference episode.

## Runtime and transport

Native prediction retains fresh subprocesses and JSON files. Live `NativeProcess.request` remains JSON IPC. Typed Python state stays in the program worker and is reconstructed from explicit permitted observation/action prefixes; it is never constrained to JSON. The trusted evaluator removes replay internals, acceptance flags and benchmark waypoints before generated programs receive observations. Generated agents receive training feedback only, with no held-out cases or credentials.

| Frozen transport screen | JSON fresh median | Binary fresh median | Reused interpreter median |
| --- | ---: | ---: | ---: |
| Button | 2.919 s | 2.970 s | 2.752 s |
| Saucepan | 2.969 s | 2.959 s | 2.688 s |

Each mode ran six sequential requests with one worker, an eight-step prediction and an empty replay prefix, using A/B/A twice and exact native-response comparisons. Reuse retained the interpreter but created a fresh simulator scene per request. The first JSON requests reached maxima of 6.325 s and 6.424 s. This short screen does not establish throughput under growing replay prefixes. Binary transport showed no material advantage, so no alternate production transport was retained. See the exact [button](profiles/transport-button-frozen) and [saucepan](profiles/transport-saucepan-frozen) measurements.

The separate [component profile](profiles/component-profile-v2) measured 30 live read-only state requests per task: median JSON IPC was about 1.140 ms for button and 0.892 ms for saucepan. Ten repeated isolated double evaluations, including the determinism check, took about 0.228 s each. Saved end-to-end planning snapshots had medians about 31.40 s and 49.63 s, respectively; these contain varying replay prefixes and are not paired transport microbenchmarks. The measurements support retaining JSON without assuming transport is the bottleneck.

## Validation and provenance

Reference extraction was checked first against saved historical outputs: all 560 saucepan and 480 button candidate costs matched exactly, and guidance matched every saved replan. This checks extraction, not a new native success trial. Native checks then compared prediction, live execution and replay, including command rejection boundaries. Typed-state checks covered A/B/A independence, resumed versus uninterrupted state, dataclasses with arrays, previous-state mutation, and sandbox access. Focused allowance, selection, interrupted-attempt recovery, process cleanup and held-out freeze/deduplication checks passed. The final native lifecycle smoke executed eight steps and charged/confirmed 316 simulator steps. Three focused scientific reviewers reviewed ownership, native/runtime behavior and experimental selection/accounting. Broad tests and CI were not run.

The scoring clarification was written at 16:03:47 EDT, after the unchanged reference was submitted at 16:01:38 EDT and after an observed fixed-reference planning failure. It preceded any generated revision or held-out result. It counts an explicitly declared planning failure during a full requested-cap attempt as a resolved failed case, including when an earlier native predicate was true. The [timing note](provenance/parent-scoring-timing.txt) and original records are preserved. The running reference-only study was migrated with structured feasibility evidence, archived code/config/database snapshots and unchanged allowance; no episode was rerun or refunded.

Initial broker launches exposed bubblewrap FD support and provider schema incompatibilities. Their failed provenance was preserved, and the same study allowance was resumed through the actual Effectful workflow. Later source normalization for held-out evaluation changed the display-lifecycle guard in all snapshots and observation documentation/result aggregation in the saucepan improvement snapshot. The [source audit](provenance/heldout-source-audit.json) records exact diffs. Each study's `heldout-normalization.json` records original, normalized and unchanged protected hashes, for example [button improvement](studies/improvement-button/heldout-normalization.json). Original training bytes remain in `code-before-heldout-normalization` and per-trial source copies. Normalized held-out files are not represented as the files that ran training.

## Artifacts and limits

Full native archives remain on `rolly` under `/home/datnguyen/Marc/guided-mpc-program-search-20261028/results`. The filtered local mirror is `/Users/datnguyen/Marc/guided-mpc-program-search/results/rolly`. This compact bundle contains exact programs, selected videos, full outcome/accounting metadata and provenance; it omits bulky candidate rollout archives. The original historical reference results and videos were preserved. No updated slides have been published.

The complete archives are `training-final-20261028.tar.gz` and `heldout-final-20261028.tar.gz` in that `rolly` result directory. [Archive locations and SHA256 checksums](provenance/archive-locations.json) also identify the original synthesis snapshots retained on this Mac. The compact review ZIP is `/Users/datnguyen/Marc/guided-mpc-program-search-agent/review-bundle-20261028.zip`; its checksum is recorded beside it and in the external final report. The [media audit](checks/media.json) verifies all 12 videos at 640 by 640 pixels, frame counts equal to executed steps, and exact program hashes.

Uploading to the existing private dataset `datvo06/guided-mpc-baseline-results` failed with HTTP 403, “Private storage limit reached for user datvo06.” The dataset's private setting was verified. Upload remains incomplete; no public alternative, deletion or paid upgrade was used. Local and `rolly` copies remain available for parent review.

This is a small privileged-observation, oracle-simulator pilot on two tasks. Native RLBench/PyRep grasping uses proximity-based attachment, so these trials do not establish contact-accurate grasping or transfer to a real robot. The pilot establishes execution of real LLM program search and exposes its budget/failure behavior. It does not establish improved control or broad synthesis capability. The selected programs are authored references, and the two synthesis conditions have no qualifying full-budget candidate.

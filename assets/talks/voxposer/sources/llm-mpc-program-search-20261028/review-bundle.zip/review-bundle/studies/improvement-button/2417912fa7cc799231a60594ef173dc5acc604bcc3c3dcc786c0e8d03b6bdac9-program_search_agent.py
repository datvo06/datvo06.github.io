"""Effectful synthesis session in an isolated training-only filesystem."""

import argparse
import json
import resource
from multiprocessing.connection import Connection
from pathlib import Path

from effectful.handlers.llm import Agent, Skill
from effectful.handlers.llm.harness import harness
from effectful.handlers.llm.harness.hooks import completion
from effectful.ops.semantics import handler
from effectful.ops.types import NotHandled
from litellm import ModelResponse
from litellm.utils import type_to_response_format_param


class ProgramEvaluator:
    """Training access to fixed native task acceptance and shared allowances.

    Write a complete Python module exporting ``program`` to a file in /work.
    The mpc_program module documents the interface. State may be any deterministic
    typed Python value, including dataclasses and arrays. Only observations,
    actual actions and explicit state determine behavior; no RNG or clock access.
    Generic IK advances at most 10 cm per solve; proposals are projected to joint,
    speed and acceleration bounds. There are eight candidates, two rounds,
    32 predicted steps and eight executed steps per solve, at 0.05 seconds.
    Native final-step task acceptance ranks candidates independently of cost.
    Grasp attachment is native proximity-based. A complete training evaluation
    requires all four cases at the episode cap. Short probes cannot be selected.
    Limits: four distinct programs, eight training episodes, four hours and
    800,000 simulator steps including initialization, predictions and replay.
    Failed attempts are charged. Use the REPL for diagnostics and inspection.
    """

    def __init__(self, connection: Connection):
        self._connection = connection

    def evaluate(self, path: Path, steps: int | None = None) -> dict:
        """Evaluate a saved source on four training cases, or a shorter probe.

        Return native outcomes and permitted execution traces. The host freezes
        source before evaluation and selects only complete full-cap candidates.
        """
        self._connection.send_bytes(
            json.dumps(
                {"operation": "evaluate", "source": path.read_text(), "steps": steps}
            ).encode()
        )
        response = json.loads(self._connection.recv_bytes())
        if "error" in response:
            raise ValueError(response["error"])
        return response


class ProgramSearchAgent(Agent):
    """Design a controller program using the typed interface and native feedback.

    Inspect /app/mpc_program.py and /starting.py in the REPL. Save revisions in
    /work. Inspect /history for prior submitted sources, training feedback,
    permitted initial observations and remaining allowance when resuming.
    Evaluate through the supplied evaluator. Explain choices from
    observed outcomes. Return the path of the best fully evaluated program.
    """

    @Skill.define
    def improve(
        self, evaluator: ProgramEvaluator, instruction: str, starting_program: Path
    ) -> Path:
        """Improve native final-step task success within the evaluator's allowance."""
        raise NotHandled


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fd", type=int, required=True)
    parser.add_argument("--instruction", required=True)
    args = parser.parse_args()
    resource.setrlimit(resource.RLIMIT_CPU, (300, 300))
    resource.setrlimit(resource.RLIMIT_AS, (4 * 1024**3, 4 * 1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE, (16 * 1024**2, 16 * 1024**2))
    resource.setrlimit(resource.RLIMIT_NOFILE, (128, 128))
    resource.setrlimit(resource.RLIMIT_NPROC, (0, 0))
    with Connection(args.fd) as connection:

        def complete(**kwargs) -> ModelResponse:
            if "response_format" in kwargs:
                kwargs["response_format"] = type_to_response_format_param(
                    kwargs["response_format"]
                )
            connection.send_bytes(
                json.dumps({"operation": "completion", "arguments": kwargs}).encode()
            )
            response = json.loads(connection.recv_bytes())
            if "error" in response:
                raise RuntimeError(response["error"])
            return ModelResponse(**response)

        with (
            handler(
                harness(
                    model="host-owned",
                    eval_provider="builtin",
                    type_checker="none",
                    tool_collection="none",
                    num_retries=2,
                    render=True,
                    dump_system_prompt="/work/system-prompt.md",
                )
            ),
            handler({completion: complete}),
        ):
            result = ProgramSearchAgent().improve(
                ProgramEvaluator(connection), args.instruction, Path("/starting.py")
            )
        connection.send_bytes(
            json.dumps(
                {
                    "operation": "finished",
                    "returned": str(result),
                    "system_prompt": Path("/work/system-prompt.md").read_text(),
                }
            ).encode()
        )


if __name__ == "__main__":
    main()

"""Host-owned training evaluations and Effectful completion brokerage."""

import argparse
import hashlib
import json
import os
import shutil
import signal
import sqlite3
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from multiprocessing import Pipe
from pathlib import Path
from typing import Literal

import litellm
from dotenv import load_dotenv
from program_budget import Allowance, AllowanceExhausted
from program_evaluation import program_observation
from pydantic import (
    BaseModel,
    Field,
    TypeAdapter,
    ValidationError,
    ValidationInfo,
    model_validator,
)

TRAINING_CASES = ((0, 101), (1, 102), (2, 103), (3, 104))
HELD_OUT_CASES = ((4, 201), (5, 202), (6, 203), (7, 204))
EPISODE_CAPS = {"TakeLidOffSaucepan": 278, "PushButton": 236}
INSTRUCTIONS = {
    "TakeLidOffSaucepan": "take lid off the saucepan",
    "PushButton": "push the teal button",
}


class EvaluationRequest(BaseModel):
    operation: Literal["evaluate"]
    source: str = Field(max_length=128000)
    steps: int | None = None

    @model_validator(mode="after")
    def check_probe(self, info: ValidationInfo):
        if self.steps is not None and not 1 <= self.steps <= info.context["cap"]:
            raise ValueError("Probe length must be within the episode cap")
        return self


class CompletionRequest(BaseModel):
    operation: Literal["completion"]
    arguments: dict


class FinishedRequest(BaseModel):
    operation: Literal["finished"]
    returned: str
    system_prompt: str


def read_execution(path: Path) -> tuple[list[dict], bool]:
    """Recover flushed records after interruption; reject corrupt complete records."""
    raw = path.read_text() if path.exists() else ""
    complete, separator, trailing = raw.rpartition("\n")
    return (
        [json.loads(line) for line in complete.splitlines()] if separator else [],
        bool(trailing),
    )


def run_case(
    source: Path,
    output: Path,
    task: str,
    reset_seed: int,
    sampling_seed: int,
    steps: int,
    allowance: Allowance,
    runner: Path,
    frozen_case: Path | None = None,
) -> dict:
    """Execute one fixed-budget case with a hard wall deadline for its process tree."""
    command = [
        sys.executable,
        str(runner),
        "--task",
        task,
        "--seed",
        str(reset_seed),
        "--sampling-seed",
        str(sampling_seed),
        "--program",
        str(source),
        "--output",
        str(output),
        "--budget",
        str(steps),
        "--workers",
        "2",
        "--allowance",
        str(allowance.path),
    ]
    if frozen_case is not None:
        command += ["--case", str(frozen_case)]
    timed_out = False
    with (
        output.with_suffix(".log").open("w") as log,
        subprocess.Popen(
            command, stdout=log, stderr=log, start_new_session=True
        ) as process,
    ):
        try:
            process.wait(timeout=allowance.remaining_s())
        except (subprocess.TimeoutExpired, AllowanceExhausted):
            timed_out = True
        finally:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
            process.wait()
    result_path = output / "result.json"
    if result_path.exists():
        result = json.loads(result_path.read_text())
    else:
        execution = output / "execution.jsonl"
        frames, truncated = read_execution(execution)
        result = {
            "status": "wall_limit" if timed_out else "process_error",
            "returncode": process.returncode,
            "success_any": any(f["success"] for f in frames),
            "success_final": bool(frames and frames[-1]["success"]),
            "physics_steps": len(frames),
            "partial_work": True,
            "truncated_record": truncated,
        }
    result["artifact_path"] = str(output)
    return result


def select(db_path: Path, cap: int) -> str | None:
    """Select only a frozen source evaluated on every full-budget training case."""
    candidates = []
    with closing(sqlite3.connect(db_path)) as db:
        for order, source_hash in db.execute(
            "SELECT rowid, hash FROM programs ORDER BY rowid"
        ):
            outcomes = []
            for reset, sampling in TRAINING_CASES:
                rows = db.execute(
                    "SELECT result FROM trials WHERE hash=? AND reset=? AND sampling=? AND cap=? AND result IS NOT NULL ORDER BY id DESC",
                    (source_hash, reset, sampling, cap),
                ).fetchall()
                full = [json.loads(r[0]) for r in rows]
                full = [
                    r
                    for r in full
                    if r["status"] == "completed" and r["physics_steps"] == cap
                ]
                if not full:
                    break
                outcomes.append(full[0])
            if len(outcomes) != len(TRAINING_CASES):
                continue
            rank = (
                -sum(r["success_final"] for r in outcomes),
                sum(
                    r["final_success_start_step"] if r["success_final"] else cap
                    for r in outcomes
                ),
                sum(r["model_prediction_steps"] for r in outcomes),
                order,
            )
            candidates.append((rank, source_hash))
    return min(candidates)[1] if candidates else None


class ProgramStudy:
    """Own immutable submissions and training-only selection outside the agent."""

    def __init__(self, output: Path, task: str, cases: Path):
        self.output = output
        self.task = task
        self.allowance = Allowance(output / "allowance.sqlite")
        self.database = output / "study.sqlite"
        self.cases = cases

    def evaluate(self, source: str, steps: int | None) -> dict:
        cap = EPISODE_CAPS[self.task]
        budget = cap if steps is None else steps
        source_hash = hashlib.sha256(source.encode()).hexdigest()
        with closing(sqlite3.connect(self.database, timeout=30)) as db, db:
            db.execute("BEGIN IMMEDIATE")
            known = db.execute(
                "SELECT hash FROM programs WHERE hash=?", (source_hash,)
            ).fetchone()
            if known is None:
                if db.execute("SELECT COUNT(*) FROM programs").fetchone()[0] >= 4:
                    raise AllowanceExhausted(
                        "Four distinct candidate programs already submitted"
                    )
                db.execute("INSERT INTO programs VALUES (?)", (source_hash,))
        directory = self.output / "programs" / source_hash
        directory.mkdir(parents=True, exist_ok=True)
        program = directory / "program.py"
        if program.exists():
            if program.read_text() != source:
                raise ValueError("Immutable program source differs")
        else:
            program.write_text(source)
            program.chmod(0o444)

        def evaluate_case(case: tuple[int, int]) -> dict:
            reset, sampling = case
            self.allowance.remaining_s()
            with closing(sqlite3.connect(self.database, timeout=30)) as db, db:
                db.execute("BEGIN IMMEDIATE")
                previous = db.execute(
                    "SELECT result FROM trials WHERE hash=? AND reset=? AND sampling=? AND cap=? AND result IS NOT NULL ORDER BY id DESC",
                    (source_hash, reset, sampling, budget),
                ).fetchone()
                if previous is not None:
                    return json.loads(previous[0])
                if db.execute("SELECT COUNT(*) FROM trials").fetchone()[0] >= 8:
                    raise AllowanceExhausted(
                        "Eight training episode attempts already reserved"
                    )
                trial_id = db.execute(
                    "INSERT INTO trials (hash,reset,sampling,cap) VALUES (?,?,?,?)",
                    (source_hash, reset, sampling, budget),
                ).lastrowid
            trial = directory / f"trial-{trial_id}"
            result = run_case(
                program,
                trial,
                self.task,
                reset,
                sampling,
                budget,
                self.allowance,
                self.output / "code" / "run_guided_mpc_rlbench.py",
                self.cases / f"{reset}-{sampling}.json",
            )
            with closing(sqlite3.connect(self.database)) as db, db:
                db.execute(
                    "UPDATE trials SET result=? WHERE id=?",
                    (json.dumps(result), trial_id),
                )
            return result

        with ThreadPoolExecutor(2) as pool:
            outcomes = list(pool.map(evaluate_case, TRAINING_CASES))
        # Native private replay data stays in the evaluator's artifact tree.
        feedback = []
        for result in outcomes:
            case = {
                k: result.get(k)
                for k in (
                    "status",
                    "success_any",
                    "success_final",
                    "physics_steps",
                    "final_success_start_step",
                    "total_simulator_steps",
                    "wall_s",
                    "error",
                )
            }
            artifact = Path(result["artifact_path"])
            initial_path = artifact / "initial-state.json"
            if initial_path.exists():
                initial = json.loads(initial_path.read_text())
                case["initial"] = program_observation(
                    initial["state"], initial["metadata"]
                ).model_dump()
                execution = artifact / "execution.jsonl"
                case["execution"] = (
                    [
                        {
                            "action": frame["action"],
                            "observation": program_observation(
                                frame["state"], initial["metadata"]
                            ).model_dump(),
                        }
                        for frame in read_execution(execution)[0]
                    ]
                    if execution.exists()
                    else []
                )
            feedback.append(case)
        response = {
            "source_hash": source_hash,
            "cases": feedback,
            "allowance": self.allowance.usage(),
        }
        history = self.output / "agent-history"
        (history / (source_hash + ".py")).write_text(source)
        (history / (source_hash + ".json")).write_text(json.dumps(response) + "\n")
        return response


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", choices=EPISODE_CAPS, required=True)
    parser.add_argument(
        "--condition", choices=("improvement", "synthesis"), required=True
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--credentials", type=Path)
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--revision", required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    script = Path(__file__).resolve().parent
    if not output.exists():
        output.mkdir(parents=True)
        Allowance.create(output / "allowance.sqlite", 800000, 4 * 3600)
        with closing(sqlite3.connect(output / "study.sqlite")) as db, db:
            db.execute("CREATE TABLE programs (hash TEXT PRIMARY KEY)")
            db.execute(
                "CREATE TABLE trials (id INTEGER PRIMARY KEY, hash TEXT, reset INTEGER, sampling INTEGER, cap INTEGER, result TEXT)"
            )
        shutil.copytree(
            script, output / "code", ignore=shutil.ignore_patterns("__pycache__")
        )
        shutil.copytree(args.cases, output / "cases")
        hashes = {
            p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (output / "code").iterdir()
            if p.is_file()
        }
        (output / "config.json").write_text(
            json.dumps(
                {
                    "task": args.task,
                    "condition": args.condition,
                    "model": args.model,
                    "parent_revision": args.revision,
                    "source_hashes": hashes,
                    "case_hashes": {
                        p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in (output / "cases").iterdir()
                        if p.is_file()
                    },
                    "max_completion_tokens": 8192,
                    "training": TRAINING_CASES,
                    "held_out": HELD_OUT_CASES,
                    "variation": 0 if args.task == "TakeLidOffSaucepan" else 12,
                },
                indent=2,
            )
            + "\n"
        )
    else:
        config = json.loads((output / "config.json").read_text())
        if (config["task"], config["condition"], config["model"]) != (
            args.task,
            args.condition,
            args.model,
        ):
            raise ValueError("Resume configuration differs from frozen study")
        if any(
            hashlib.sha256((output / "code" / name).read_bytes()).hexdigest() != digest
            for name, digest in config["source_hashes"].items()
        ):
            raise ValueError("Frozen evaluator code changed")
        if any(
            hashlib.sha256((output / "cases" / name).read_bytes()).hexdigest() != digest
            for name, digest in config["case_hashes"].items()
        ):
            raise ValueError("Frozen case artifacts changed")
    if args.credentials:
        load_dotenv(args.credentials)
    study = ProgramStudy(output, args.task, output / "cases")
    script = output / "code"
    public_history = output / "agent-history"
    public_history.mkdir(exist_ok=True)
    (public_history / "allowance.json").write_text(
        json.dumps(study.allowance.usage()) + "\n"
    )
    (public_history / "initial-observations.json").write_text(
        json.dumps(
            [
                program_observation(case["state"], case["metadata"]).model_dump()
                for case in (
                    json.loads((study.cases / f"{reset}-{sampling}.json").read_text())
                    for reset, sampling in TRAINING_CASES
                )
            ]
        )
        + "\n"
    )
    parent, child = Pipe()
    command = [
        "bwrap",
        "--die-with-parent",
        "--unshare-all",
        "--new-session",
        "--clearenv",
        "--proc",
        "/proc",
        "--dev",
        "/dev",
        "--tmpfs",
        "/tmp",
        "--tmpfs",
        "/work",
        "--preserve-fds",
        str(child.fileno() - 2),
    ]
    for directory in dict.fromkeys(
        ["/usr", "/lib", "/lib64", sys.base_prefix, sys.prefix]
    ):
        command += ["--ro-bind", directory, directory]
    for name in ("mpc_program.py", "program_search_agent.py"):
        command += ["--ro-bind", str(script / name), "/app/" + name]
    initial = script / (
        "reference_program.py"
        if args.condition == "improvement"
        else "neutral_program.py"
    )
    if not (output / "initial-program.py").exists():
        (output / "initial-program.py").write_bytes(initial.read_bytes())
    command += [
        "--ro-bind",
        str(public_history),
        "/history",
        "--ro-bind",
        str(initial),
        "/starting.py",
        "--chdir",
        "/work",
        "--setenv",
        "PYTHONPATH",
        str(
            Path(sys.prefix)
            / "lib"
            / f"python{sys.version_info.major}.{sys.version_info.minor}"
            / "site-packages"
        ),
        "--setenv",
        "OPENBLAS_NUM_THREADS",
        "1",
        str(Path(sys.executable).resolve()),
        "/app/program_search_agent.py",
        "--fd",
        str(child.fileno()),
        "--instruction",
        INSTRUCTIONS[args.task],
    ]
    status = "incomplete"
    try:
        with (
            (output / "agent.log").open("a") as log,
            (output / "conversation.jsonl").open("a") as history,
            subprocess.Popen(
                command,
                pass_fds=(child.fileno(),),
                stdout=log,
                stderr=log,
                start_new_session=True,
            ) as process,
        ):
            child.close()
            try:
                while parent.poll(study.allowance.remaining_s()):
                    raw = parent.recv_bytes(2 * 1024**2)
                    try:
                        parsed = TypeAdapter(
                            EvaluationRequest | CompletionRequest | FinishedRequest
                        ).validate_json(raw, context={"cap": EPISODE_CAPS[args.task]})
                    except ValidationError:
                        parent.send_bytes(
                            json.dumps(
                                {"error": "Invalid request or probe length"}
                            ).encode()
                        )
                        continue
                    message = parsed.model_dump()
                    history.write(json.dumps({"request": message}) + "\n")
                    history.flush()
                    if message["operation"] == "finished":
                        (output / "system-prompt.md").write_text(
                            message["system_prompt"]
                        )
                        status = "agent_returned"
                        break
                    try:
                        if message["operation"] == "completion":
                            if not (output / "initial-context.json").exists():
                                (output / "initial-context.json").write_text(
                                    json.dumps(message["arguments"], indent=2) + "\n"
                                )
                            kwargs = {
                                k: v
                                for k, v in message["arguments"].items()
                                if k
                                in (
                                    "messages",
                                    "tools",
                                    "tool_choice",
                                    "response_format",
                                    "stop",
                                    "parallel_tool_calls",
                                )
                            }
                            response = litellm.completion(
                                **kwargs,
                                model=args.model,
                                max_completion_tokens=8192,
                                timeout=min(180, study.allowance.remaining_s()),
                                num_retries=0,
                            ).model_dump(mode="json")
                        elif message["operation"] == "evaluate":
                            response = study.evaluate(
                                message["source"], message["steps"]
                            )
                        else:
                            raise ValueError("Unknown agent request")
                    except litellm.exceptions.APIError as error:
                        detail = str(error)
                        for key in ("OPENAI_API_KEY", "OPENROUTER_API_KEY"):
                            secret = os.environ.get(key)
                            if secret:
                                detail = detail.replace(secret, "[redacted]")
                        log.write(
                            json.dumps(
                                {
                                    "error_type": type(error).__name__,
                                    "detail": detail,
                                    "status_code": getattr(error, "status_code", None),
                                }
                            )
                            + "\n"
                        )
                        log.flush()
                        response = {"error": type(error).__name__}
                    history.write(json.dumps({"response": response}) + "\n")
                    history.flush()
                    parent.send_bytes(json.dumps(response).encode())
            finally:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGKILL)
                process.wait()
    except (EOFError, AllowanceExhausted) as error:
        status = type(error).__name__
    finally:
        parent.close()
        child.close()
        selected = select(study.database, EPISODE_CAPS[args.task])
        (output / "selection.json").write_text(
            json.dumps(
                {
                    "status": "selected" if selected else "incomplete_search",
                    "agent_status": status,
                    "source_hash": selected,
                    "allowance": study.allowance.usage(),
                },
                indent=2,
            )
            + "\n"
        )


if __name__ == "__main__":
    main()

"""Freeze completed study selections, then evaluate paired held-out cases."""

import argparse
import hashlib
import json
import shutil
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from program_budget import Allowance
from run_program_search import EPISODE_CAPS, HELD_OUT_CASES, run_case


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", choices=EPISODE_CAPS, required=True)
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--improvement", type=Path, required=True)
    parser.add_argument("--synthesis", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    code = output / "code"
    shutil.copytree(
        Path(__file__).resolve().parent,
        code,
        ignore=shutil.ignore_patterns("__pycache__"),
    )
    sources = {"reference": code / "reference_program.py"}
    selections = {}
    for condition in ("improvement", "synthesis"):
        study = getattr(args, condition).resolve()
        config = json.loads((study / "config.json").read_text())
        if config["task"] != args.task or config["condition"] != condition:
            raise ValueError("Study does not match held-out comparison")
        selection = json.loads((study / "selection.json").read_text())
        selections[condition] = {"study": str(study), "selection": selection}
        if selection["source_hash"] is not None:
            source = study / "programs" / selection["source_hash"] / "program.py"
            if (
                hashlib.sha256(source.read_bytes()).hexdigest()
                != selection["source_hash"]
            ):
                raise ValueError("Selected program hash differs")
            destination = output / f"{condition}.py"
            shutil.copy2(source, destination)
            sources[condition] = destination
    # This immutable manifest is written before opening any held-out case.
    (output / "frozen-selections.json").write_text(
        json.dumps(
            {
                "task": args.task,
                "studies": selections,
                "source_hashes": {
                    name: hashlib.sha256(path.read_bytes()).hexdigest()
                    for name, path in sources.items()
                },
                "held_out": HELD_OUT_CASES,
            },
            indent=2,
        )
        + "\n"
    )
    allowance = Allowance.create(output / "allowance.sqlite", 1600000, 4 * 3600)
    jobs = [
        (name, source, reset, sampling)
        for name, source in sources.items()
        for reset, sampling in HELD_OUT_CASES
    ]

    def evaluate(job: tuple[str, Path, int, int]) -> dict:
        name, source, reset, sampling = job
        result = run_case(
            source,
            output / f"{name}-{reset}-{sampling}",
            args.task,
            reset,
            sampling,
            EPISODE_CAPS[args.task],
            allowance,
            code / "run_guided_mpc_rlbench.py",
            args.cases.resolve() / f"{reset}-{sampling}.json",
        )
        return {
            "condition": name,
            "reset": reset,
            "sampling": sampling,
            "result": result,
        }

    with ThreadPoolExecutor(2) as pool:
        outcomes = list(pool.map(evaluate, jobs))
    (output / "outcomes.json").write_text(
        json.dumps({"outcomes": outcomes, "allowance": allowance.usage()}, indent=2)
        + "\n"
    )


if __name__ == "__main__":
    main()

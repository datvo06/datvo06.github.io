#!/usr/bin/env bash
set -euo pipefail
root="${VOXPOSER_ROOT:?Set VOXPOSER_ROOT to the external runtime directory}"
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export COPPELIASIM_ROOT="$root/CoppeliaSim"
export LD_LIBRARY_PATH="$COPPELIASIM_ROOT${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export QT_QPA_PLATFORM_PLUGIN_PATH="$COPPELIASIM_ROOT"
export DISPLAY="${DISPLAY:-:97}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-8}"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-8}"
export PYTHONUNBUFFERED=1
export PYTHONPATH="$root/VoxPoser/src${PYTHONPATH:+:$PYTHONPATH}"
if [[ "$DISPLAY" == :97 && ! -S /tmp/.X11-unix/X97 ]]; then
    nohup "$root/display/bin/Xvfb" :97 -screen 0 1280x1024x24 -nolisten tcp \
        > "$root/logs/xvfb.log" 2>&1 < /dev/null &
    echo $! > "$root/xvfb.pid"
    for attempt in {1..50}; do
        [[ -S /tmp/.X11-unix/X97 ]] && break
        sleep 0.1
    done
    if [[ ! -S /tmp/.X11-unix/X97 ]]; then
        echo "Xvfb did not start; see $root/logs/xvfb.log" >&2
        exit 1
    fi
fi
cd "$root/VoxPoser/src"
exec "$root/env312/bin/python" "$script_dir/$1" "${@:2}"

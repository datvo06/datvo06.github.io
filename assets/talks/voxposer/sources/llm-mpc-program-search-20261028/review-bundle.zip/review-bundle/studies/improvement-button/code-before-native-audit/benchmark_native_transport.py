"""Paired native JSON-file, binary-pipe and process-reuse measurements."""

import argparse
import gzip
import json
import pickle
import shutil
import statistics
import subprocess
import time
from multiprocessing import Pipe
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", required=True)
    parser.add_argument("--requests", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=False)
    code = args.output / "code"
    code.mkdir()
    for name in (
        "rlbench_mpc.py",
        "mpc_program.py",
        "run_voxposer.sh",
        "benchmark_native_transport.py",
    ):
        shutil.copy2(Path(__file__).with_name(name), code / name)
    command = [
        "bash",
        str(code / "run_voxposer.sh"),
        "rlbench_mpc.py",
        "--task",
        args.task,
        "--seed",
        "0",
    ]
    requests = [json.loads(p.read_text()) for p in args.requests]
    # A/B/A ordering checks reuse after an intervening alternative.
    requests = [requests[0], requests[-1], requests[0]] * 2
    records = []
    reference = []
    for mode in ("json-fresh", "binary-fresh", "binary-reuse"):
        process = None
        parent = None
        log = (args.output / (mode + ".log")).open("w")
        try:
            for index, request in enumerate(requests):
                start = time.perf_counter()
                if mode == "json-fresh":
                    request_path = args.output / f"{mode}-{index}.request.json"
                    response_path = args.output / f"{mode}-{index}.response.json"
                    encoding_start = time.perf_counter()
                    payload = json.dumps(request)
                    encode_s = time.perf_counter() - encoding_start
                    request_path.write_text(payload)
                    subprocess.run(
                        command
                        + [
                            "--request",
                            str(request_path),
                            "--response",
                            str(response_path),
                        ],
                        stdout=log,
                        stderr=log,
                        timeout=180,
                        check=True,
                    )
                    raw = response_path.read_bytes()
                    decoding_start = time.perf_counter()
                    response = json.loads(raw)
                    decode_s = time.perf_counter() - decoding_start
                    response_path.unlink()
                    transferred = len(payload.encode()) + len(raw)
                else:
                    if process is None:
                        parent, child = Pipe()
                        process = subprocess.Popen(
                            command + ["--pipe-fd", str(child.fileno())],
                            pass_fds=(child.fileno(),),
                            stdout=log,
                            stderr=log,
                        )
                        child.close()
                    encoding_start = time.perf_counter()
                    payload = pickle.dumps(request, protocol=5)
                    encode_s = time.perf_counter() - encoding_start
                    parent.send_bytes(payload)
                    if not parent.poll(180):
                        raise TimeoutError("Native binary worker did not respond")
                    raw = parent.recv_bytes()
                    decoding_start = time.perf_counter()
                    response = pickle.loads(raw)
                    decode_s = time.perf_counter() - decoding_start
                    transferred = len(payload) + len(raw)
                if mode == "binary-fresh":
                    parent.send(None)
                    process.wait(timeout=30)
                    parent.close()
                    process = None
                elapsed = time.perf_counter() - start
                comparable = {
                    k: v for k, v in response.items() if k not in ("timing", "pid")
                }
                comparable = json.loads(json.dumps(comparable))
                if mode == "json-fresh":
                    reference.append(comparable)
                with gzip.open(
                    args.output / f"{mode}-{index}.response.json.gz", "wt"
                ) as f:
                    json.dump(response, f)
                if mode != "json-fresh" and comparable != reference[index]:
                    (args.output / "failure.json").write_text(
                        json.dumps(
                            {
                                "mode": mode,
                                "index": index,
                                "reason": "Native results differ",
                                "reference": reference[index],
                                "actual": comparable,
                            }
                        )
                        + "\n"
                    )
                    raise ValueError("Transport or worker reuse changed native results")
                records.append(
                    {
                        "mode": mode,
                        "index": index,
                        "wall_s": elapsed,
                        "bytes": transferred,
                        "encode_s": encode_s,
                        "decode_s": decode_s,
                        **response["timing"],
                        "physics_steps": response["physics_steps"],
                        "replay_error": response["replay_error"],
                    }
                )
                (args.output / "measurements.json").write_text(
                    json.dumps(records, indent=2) + "\n"
                )
        finally:
            if process is not None:
                process.terminate()
                try:
                    process.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
            if parent is not None:
                parent.close()
            log.close()
    summaries = []
    for mode in ("json-fresh", "binary-fresh", "binary-reuse"):
        values = sorted(r["wall_s"] for r in records if r["mode"] == mode)
        summaries.append(
            {
                "mode": mode,
                "median_s": statistics.median(values),
                "tail_max_s": max(values),
                "total_s": sum(values),
                "identical_native_results": True,
            }
        )
    (args.output / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")
    print(json.dumps(summaries))


if __name__ == "__main__":
    main()

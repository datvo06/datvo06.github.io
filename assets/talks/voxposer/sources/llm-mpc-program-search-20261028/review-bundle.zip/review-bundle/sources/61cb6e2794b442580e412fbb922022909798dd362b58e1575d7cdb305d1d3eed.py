
from dataclasses import dataclass
from math import sqrt
from mpc_program import Action, CartesianProposal, JointProposal, ProgramObservation, Proposals


def dist(a, b):
    return sqrt(sum((x-y)*(x-y) for x, y in zip(a, b)))


@dataclass(frozen=True)
class State:
    mode: str
    start_z: float


class LidProgram:
    def init(self, observation: ProgramObservation, instruction: str) -> State:
        return State('go_above', observation.object_pose[2])

    def advance(self, state: State, action: Action, observation: ProgramObservation) -> State:
        ox, oy, oz = observation.object_pose[:3]
        tx, ty, tz = observation.tip[:3]
        xy = dist((ox, oy), (tx, ty))
        mode = state.mode
        if observation.grasped:
            mode = 'lift'
        elif mode == 'go_above' and xy < 0.06 and tz < oz + 0.18:
            mode = 'go_down'
        elif mode == 'go_down' and xy < 0.03 and tz < oz + 0.08:
            mode = 'close'
        elif mode == 'close':
            mode = 'wait_closed'
        elif mode == 'wait_closed':
            mode = 'lift'
        return State(mode, state.start_z)

    def proposals(self, state: State, observation: ProgramObservation) -> Proposals:
        ox, oy, oz = observation.object_pose[:3]
        quat = observation.tip[3:]
        if state.mode == 'go_above':
            target = (ox, oy, oz + 0.12)
            grip = 1
        elif state.mode == 'go_down':
            target = (ox, oy, oz + 0.03)
            grip = 1
        elif state.mode == 'close':
            target = (ox, oy, oz + 0.03)
            grip = 0
        elif state.mode == 'wait_closed':
            target = (ox, oy, oz + 0.03)
            grip = 0
        else:
            target = (ox, oy, oz + 0.20)
            grip = 0 if observation.grasped else 1
        return (
            CartesianProposal(target=target, quaternion=quat, gripper=grip),
            JointProposal(actions=((*observation.joint_targets, grip),)),
        )

    def trajectory_cost(self, initial: State, states: tuple[State, ...], observations: tuple[ProgramObservation, ...]) -> float:
        o = observations[-1]
        obj = o.object_pose[:3]
        tip = o.tip[:3]
        xy = dist(obj[:2], tip[:2])
        dz = obj[2] - initial.start_z
        if o.grasped:
            return -1.0 - 5.0 * dz + 0.1 * xy
        mode = states[-1].mode if states else initial.mode
        if mode == 'go_above':
            return xy + abs(tip[2] - (obj[2] + 0.12))
        elif mode == 'go_down':
            return 2*xy + abs(tip[2] - (obj[2] + 0.03))
        else:
            return 3*xy + abs(tip[2] - (obj[2] + 0.03))

program = LidProgram()


from dataclasses import dataclass
from math import sqrt
from mpc_program import CartesianProposal, ProgramObservation, Proposals, Action


def dist2(a, b):
    return sqrt(sum((x-y)*(x-y) for x, y in zip(a, b)))


@dataclass(frozen=True)
class State:
    phase: str
    start_z: float


class LidOffProgram:
    def init(self, observation: ProgramObservation, instruction: str) -> State:
        return State('approach', observation.object_pose[2])

    def advance(self, state: State, action: Action, observation: ProgramObservation) -> State:
        ox, oy, oz = observation.object_pose[:3]
        tx, ty, tz = observation.tip[:3]
        xy = dist2((ox, oy), (tx, ty))
        if observation.grasped:
            phase = 'lift'
        elif state.phase == 'approach':
            phase = 'descend' if (xy < 0.03 and tz < oz + 0.16) else 'approach'
        elif state.phase == 'descend':
            phase = 'close' if (xy < 0.02 and tz < oz + 0.06) else 'descend'
        elif state.phase == 'close':
            phase = 'hold_closed'
        elif state.phase == 'hold_closed':
            phase = 'lift'
        else:
            phase = state.phase
        return State(phase, state.start_z)

    def proposals(self, state: State, observation: ProgramObservation) -> Proposals:
        ox, oy, oz, qx, qy, qz, qw = observation.object_pose
        quat = (qx, qy, qz, qw)
        if state.phase == 'approach':
            target = (ox, oy, oz + 0.18)
            grip = 1
        elif state.phase == 'descend':
            target = (ox, oy, oz + 0.035)
            grip = 1
        elif state.phase == 'close':
            target = (ox, oy, oz + 0.03)
            grip = 0
        elif state.phase == 'hold_closed':
            target = (ox, oy, oz + 0.03)
            grip = 0
        else:
            target = (ox, oy, oz + 0.25)
            grip = 0
        return (CartesianProposal(target=target, quaternion=quat, gripper=grip),)

    def trajectory_cost(self, initial: State, states: tuple[State, ...], observations: tuple[ProgramObservation, ...]) -> float:
        o = observations[-1]
        ox, oy, oz = o.object_pose[:3]
        tx, ty, tz = o.tip[:3]
        xy = dist2((ox, oy), (tx, ty))
        if o.grasped:
            return -(oz - initial.start_z) + 0.05 * xy
        phase = states[-1].phase if states else initial.phase
        if phase == 'approach':
            return xy + abs(tz - (oz + 0.18))
        elif phase == 'descend':
            return 2.0 * xy + abs(tz - (oz + 0.035))
        elif phase in ('close', 'hold_closed'):
            return 3.0 * xy + abs(tz - (oz + 0.03))
        else:
            return xy - 0.2 * (oz - initial.start_z)


program = LidOffProgram()

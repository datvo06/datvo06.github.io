
from dataclasses import dataclass
import numpy as np
from mpc_program import CartesianProposal, ProgramObservation, Proposals

@dataclass(frozen=True)
class State:
    initial: ProgramObservation
    current: ProgramObservation
    instruction: str
    button_mode: bool
    radial_dist: float


def guidance(state: State) -> tuple[str, CartesianProposal]:
    observation = state.current
    tip = np.asarray(observation.tip[:3], dtype=float)
    target = np.array(observation.object_pose[:3], dtype=float)
    quat = state.initial.tip[3:]
    if state.instruction == "take lid off the saucepan":
        if observation.grasped:
            stage, gripper = "lift", 0
            target = tip + np.array([0.0, 0.0, max(0.0, state.initial.object_pose[2] + 0.15 - target[2])])
        elif np.linalg.norm(tip - target) < 0.02:
            stage, gripper = "grasp", 0
        else:
            stage, gripper = "approach", observation.gripper_command
        return stage, CartesianProposal(target=tuple(target), quaternion=quat, gripper=gripper)

    # button task
    radial = state.radial_dist
    if radial > 0.34:
        # far buttons: first descend less and press from above at edge-reachable xy
        base_xy = np.asarray(state.initial.tip[:2], dtype=float)
        delta = target[:2] - base_xy
        dist = float(np.linalg.norm(delta))
        if dist > 1e-9:
            target[:2] = base_xy + delta * (0.30 / dist)
        aligned = np.linalg.norm(tip[:2] - target[:2]) < 0.018
        target[2] += (0.03 if aligned else 0.08)
        stage, gripper = ("press" if aligned else "approach"), 0
    else:
        aligned = np.linalg.norm(tip[:2] - target[:2]) < 0.02
        target[2] += (-0.01 if aligned else 0.10)
        stage, gripper = ("press" if aligned else "approach"), 0
    return stage, CartesianProposal(target=tuple(target), quaternion=quat, gripper=gripper)


class ImprovedProgram:
    def init(self, observation: ProgramObservation, instruction: str) -> State:
        radial = float(np.linalg.norm(np.asarray(observation.object_pose[:2]) - np.asarray(observation.tip[:2])))
        return State(observation, observation, instruction, observation.button_displacement is not None, radial)

    def advance(self, state: State, action, observation: ProgramObservation) -> State:
        return State(state.initial, observation, state.instruction, state.button_mode, state.radial_dist)

    def proposals(self, state: State, observation: ProgramObservation) -> Proposals:
        return (guidance(state)[1],)

    def trajectory_cost(self, initial: State, states, observations) -> float:
        stage, proposal = guidance(initial)
        target = np.asarray(proposal.target, dtype=float)
        costs = []
        for observation in observations:
            tip = np.asarray(observation.tip[:3], dtype=float)
            guide = np.sum((tip - target) ** 2)
            if initial.instruction == "take lid off the saucepan":
                task = max(0.0, initial.initial.object_pose[2] + 0.15 - observation.object_pose[2]) ** 2
                grasp = float(stage in ("grasp", "lift") and not observation.grasped)
                costs.append(100.0 * guide + 200.0 * task + 2.0 * grasp)
            else:
                disp = float(abs(observation.button_displacement or 0.0))
                task = max(0.0, 0.003 - disp) ** 2
                xy_err = np.sum((tip[:2] - target[:2]) ** 2)
                z_err = (tip[2] - target[2]) ** 2
                costs.append(120.0 * guide + 120.0 * xy_err + 80.0 * z_err + 500.0 * task)
        return float(np.mean(costs) + costs[-1])

program = ImprovedProgram()

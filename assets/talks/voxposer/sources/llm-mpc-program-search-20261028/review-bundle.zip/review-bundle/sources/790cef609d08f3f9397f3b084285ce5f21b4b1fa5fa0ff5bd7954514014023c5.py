
from dataclasses import dataclass
import math
import numpy as np
from mpc_program import Action, CartesianProposal, ProgramObservation, Proposals


APPROACH_Z = 0.10
GRASP_XY_THRESH = 0.02
GRASP_Z_THRESH = 0.035
LIFT_HEIGHT = 0.22
SIDE_BIAS = 0.015


@dataclass(frozen=True)
class State:
    initial: ProgramObservation
    current: ProgramObservation
    instruction: str


def _xy_dist(a, b) -> float:
    return float(math.hypot(a[0] - b[0], a[1] - b[1]))


def guidance(state: State) -> tuple[str, CartesianProposal]:
    observation = state.current
    tip = np.asarray(observation.tip[:3], dtype=float)
    obj = np.asarray(observation.object_pose[:3], dtype=float)
    target = obj.copy()
    quat = state.initial.tip[3:]

    if state.instruction == "take lid off the saucepan":
        init_obj = np.asarray(state.initial.object_pose[:3], dtype=float)
        xyd = _xy_dist(tip, obj)
        zd = float(abs(tip[2] - obj[2]))

        if observation.grasped:
            stage = "lift"
            target = tip.copy()
            target[2] = max(float(tip[2]), float(init_obj[2] + LIFT_HEIGHT))
            gripper = 0
        elif xyd < GRASP_XY_THRESH and zd < GRASP_Z_THRESH:
            stage = "grasp"
            target = obj.copy()
            gripper = 0
        else:
            stage = "approach"
            if obj[1] < tip[1]:
                target[1] += SIDE_BIAS
            else:
                target[1] -= SIDE_BIAS
            target[2] += APPROACH_Z
            gripper = 1
    else:
        aligned = _xy_dist(tip, obj) < 0.02
        stage, gripper = ("press", 0) if aligned else ("approach", 0)
        target[2] += -0.01 if aligned else 0.10

    return stage, CartesianProposal(
        target=tuple(float(x) for x in target), quaternion=quat, gripper=gripper
    )


class Program:
    def init(self, observation: ProgramObservation, instruction: str) -> State:
        return State(observation, observation, instruction)

    def advance(self, state: State, action: Action, observation: ProgramObservation) -> State:
        return State(state.initial, observation, state.instruction)

    def proposals(self, state: State, observation: ProgramObservation) -> Proposals:
        return (guidance(state)[1],)

    def trajectory_cost(self, initial: State, states: tuple[State, ...], observations: tuple[ProgramObservation, ...]) -> float:
        stage, proposal = guidance(initial)
        costs = []
        init_obj_z = float(initial.initial.object_pose[2])
        for observation in observations:
            tip = np.asarray(observation.tip[:3], dtype=float)
            target = np.asarray(proposal.target, dtype=float)
            guide = np.sum((tip - target) ** 2)
            if initial.instruction == "take lid off the saucepan":
                obj = np.asarray(observation.object_pose[:3], dtype=float)
                lift_shortfall = max(0.0, init_obj_z + 0.18 - float(obj[2]))
                xyd = _xy_dist(tip, obj)
                if stage == 'approach':
                    phase = 4.0 * max(0.0, xyd - 0.015) ** 2 + 2.0 * max(0.0, float(tip[2] - obj[2]) - 0.05) ** 2
                elif stage == 'grasp':
                    phase = 20.0 * float(not observation.grasped)
                else:
                    phase = 8.0 * lift_shortfall * lift_shortfall + 2.0 * float(not observation.grasped)
                task = 200.0 * lift_shortfall * lift_shortfall
                grasp = 5.0 * float(stage in ('grasp', 'lift') and not observation.grasped)
                costs.append(80.0 * guide + phase + task + grasp)
            else:
                assert observation.button_displacement is not None
                task = max(0.0, 0.003 - abs(observation.button_displacement)) ** 2
                costs.append(100.0 * guide + 200.0 * task)
        return float(np.mean(costs) + 2.0 * costs[-1])


program = Program()


from dataclasses import dataclass
from mpc_program import CartesianProposal, ProgramObservation, Proposals


@dataclass(frozen=True)
class State:
    phase: int
    obj: tuple[float, float, float]
    press_xy: tuple[float, float]
    quat: tuple[float, float, float, float]


class ButtonProgram:
    def init(self, observation: ProgramObservation, instruction: str) -> State:
        obj = observation.object_pose
        return State(
            phase=0,
            obj=(obj[0], obj[1], obj[2]),
            press_xy=(obj[0], obj[1]),
            quat=(0.0, 1.0, 0.0, 0.0),
        )

    def advance(self, state: State, action, observation: ProgramObservation) -> State:
        obj = observation.object_pose
        bd = observation.button_displacement or 0.0
        phase = state.phase
        if bd > 0.02:
            phase = 3
        elif observation.time > 2.0:
            phase = 2
        elif observation.time > 1.0:
            phase = 1
        return State(phase=phase, obj=(obj[0], obj[1], obj[2]), press_xy=state.press_xy, quat=state.quat)

    def proposals(self, state: State, observation: ProgramObservation) -> Proposals:
        x, y, z = state.obj
        px, py = state.press_xy
        if state.phase == 0:
            target = (px, py, z + 0.10)
        elif state.phase == 1:
            target = (px, py, z + 0.03)
        elif state.phase == 2:
            target = (px, py, z - 0.03)
        else:
            target = (px, py, z + 0.08)
        return (CartesianProposal(target=target, quaternion=state.quat, gripper=1),)

    def trajectory_cost(self, initial: State, states, observations) -> float:
        if not observations:
            return 0.0
        obs = observations[-1]
        bd = obs.button_displacement or 0.0
        obj = obs.object_pose
        tip = obs.tip
        px, py = initial.press_xy
        dx = tip[0] - px
        dy = tip[1] - py
        dz = tip[2] - (obj[2] - 0.03)
        return dx*dx + dy*dy + 0.3*dz*dz - 20.0*bd


program = ButtonProgram()

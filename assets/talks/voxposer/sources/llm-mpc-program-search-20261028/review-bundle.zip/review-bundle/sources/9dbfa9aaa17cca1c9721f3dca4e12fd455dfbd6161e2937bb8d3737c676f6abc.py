"""Fixed privileged-state guidance used for the paired reference condition."""

from dataclasses import dataclass

import numpy as np
from mpc_program import Action, CartesianProposal, ProgramObservation, Proposals


@dataclass(frozen=True)
class State:
    initial: ProgramObservation
    current: ProgramObservation
    instruction: str


def guidance(state: State) -> tuple[str, CartesianProposal]:
    observation = state.current
    tip = np.asarray(observation.tip[:3])
    target = np.array(observation.object_pose[:3])
    if state.instruction == "take lid off the saucepan":
        if observation.grasped:
            stage, gripper = "lift", 0
            target = tip + np.array(
                [0, 0, max(0, state.initial.object_pose[2] + 0.18 - target[2])]
            )
        elif np.linalg.norm(tip - target) < 0.02:
            stage, gripper = "grasp", 0
        else:
            stage, gripper = "approach", observation.gripper_command
    else:
        aligned = np.linalg.norm(tip[:2] - target[:2]) < 0.02
        stage, gripper = ("press" if aligned else "approach"), 0
        target[2] += -0.01 if aligned else 0.10
    return stage, CartesianProposal(
        target=tuple(target), quaternion=state.initial.tip[3:], gripper=gripper
    )


class ReferenceProgram:
    """Reference mean-plus-terminal objective with guidance fixed per solve."""

    def init(self, observation: ProgramObservation, instruction: str) -> State:
        return State(observation, observation, instruction)

    def advance(
        self, state: State, action: Action, observation: ProgramObservation
    ) -> State:
        return State(state.initial, observation, state.instruction)

    def proposals(self, state: State, observation: ProgramObservation) -> Proposals:
        return (guidance(state)[1],)

    def trajectory_cost(
        self,
        initial: State,
        states: tuple[State, ...],
        observations: tuple[ProgramObservation, ...],
    ) -> float:
        stage, proposal = guidance(initial)
        costs = []
        for observation in observations:
            guide = np.sum((np.asarray(observation.tip[:3]) - proposal.target) ** 2)
            if initial.instruction == "take lid off the saucepan":
                task = (
                    max(
                        0,
                        initial.initial.object_pose[2]
                        + 0.18
                        - observation.object_pose[2],
                    )
                    ** 2
                )
                grasp = float(stage in ("grasp", "lift") and not observation.grasped)
            else:
                assert observation.button_displacement is not None
                task = max(0, 0.003 - abs(observation.button_displacement)) ** 2
                grasp = 0.0
            costs.append(100 * guide + 200 * task + 2 * grasp)
        return float(np.mean(costs) + costs[-1])


program = ReferenceProgram()

"""Run an upstream VoxPoser instruction and save its RLBench outcome and video."""

import argparse
import json
import os
import sys
import time
from collections.abc import Iterator
from contextlib import ExitStack, closing, contextmanager
from dataclasses import asdict, dataclass
from pathlib import Path
from unittest.mock import patch

import imageio.v2 as imageio
import numpy as np
import openai
from arguments import get_config
from envs import rlbench_env
from interfaces import setup_LMP
from numpy.typing import NDArray
from pyrep.objects.vision_sensor import VisionSensor
from rlbench.action_modes.action_mode import MoveArmThenGripper
from rlbench.backend.observation import Observation
from rlbench.environment import Environment
from utils import set_lmp_objects


@contextmanager
def environment() -> Iterator[rlbench_env.VoxPoserRLBench]:
    """Own the simulator before VoxPoser's constructor launches it."""
    with ExitStack() as resources:

        def create(action_mode: MoveArmThenGripper) -> Environment:
            instance = Environment(action_mode, headless=True, shaped_rewards=False)
            resources.callback(instance.shutdown)
            return instance

        with patch.object(rlbench_env, "Environment", create):
            yield rlbench_env.VoxPoserRLBench()


@dataclass
class Outcome:
    """Record a completed instruction using RLBench's own success condition."""

    task: str
    seed: int
    model: str
    instruction: str
    task_success: bool
    physics_steps: int = 0
    simulation_dt_s: float = 0.0
    wall_s: float = 0.0


@contextmanager
def recording(
    env: rlbench_env.VoxPoserRLBench, outcome: Outcome, output: Path
) -> Iterator[None]:
    """Record native steps and the sparse rewards returned by the executed task."""
    # RLBench exposes the physics-step callback only through its internal scene.
    scene = env.rlbench_env._scene
    outcome.simulation_dt_s = env.rlbench_env._pyrep.get_simulation_timestep()
    camera = VisionSensor("cam_front")
    task_step = env.task.step

    def observed_step(action: NDArray[np.float64]) -> tuple[Observation, float, bool]:
        obs, reward, terminate = task_step(action)
        outcome.task_success |= reward > 0
        return obs, reward, terminate

    with closing(
        imageio.get_writer(
            str(output / "episode.mp4"), fps=1.0 / outcome.simulation_dt_s
        )
    ) as writer:

        def capture() -> None:
            outcome.physics_steps += 1
            rgb = (np.clip(camera.capture_rgb(), 0, 1) * 255).astype(np.uint8)
            writer.append_data(rgb)

        with patch.object(env.task, "step", observed_step):
            scene.register_step_callback(capture)
            try:
                yield
            finally:
                scene.register_step_callback(None)


def main() -> None:
    """Execute the released language-to-value-map pipeline without policy changes."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", default="PushButton")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--model", default="gpt-4.1")
    parser.add_argument("--key-stdin", action="store_true")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    openai.api_key = (
        sys.stdin.readline().strip() if args.key_stdin else os.environ["OPENAI_API_KEY"]
    )
    np.random.seed(args.seed)
    config = get_config("rlbench")
    config["lmp_config"]["env"]["visualize"] = False
    for cfg in config["lmp_config"]["lmps"].values():
        cfg["model"] = args.model
    (output / "config.json").write_text(json.dumps(config, indent=2) + "\n")
    start = time.perf_counter()
    with environment() as env:
        env.load_task(args.task)
        descriptions, obs = env.reset()
        outcome = Outcome(
            args.task,
            args.seed,
            args.model,
            descriptions[0],
            False,
        )
        imageio.imwrite(output / "initial.png", obs.front_rgb)
        lmps, _ = setup_LMP(env, config, debug=False)
        set_lmp_objects(lmps, env.get_object_names())
        with recording(env, outcome, output):
            lmps["plan_ui"](descriptions[0])
        imageio.imwrite(output / "final.png", env.latest_obs.front_rgb)
    outcome.wall_s = time.perf_counter() - start
    serialized = json.dumps(asdict(outcome), indent=2)
    (output / "result.json").write_text(serialized + "\n")
    print(serialized)


if __name__ == "__main__":
    main()

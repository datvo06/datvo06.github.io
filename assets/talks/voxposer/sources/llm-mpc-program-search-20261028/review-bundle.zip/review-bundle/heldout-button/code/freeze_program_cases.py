"""Freeze numeric paired RLBench cases before training or held-out execution."""

import argparse
import json
from contextlib import ExitStack
from pathlib import Path

from run_guided_mpc_rlbench import NativeProcess
from run_program_search import HELD_OUT_CASES, TRAINING_CASES


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    total_steps = 0
    for reset, sampling in (*TRAINING_CASES, *HELD_OUT_CASES):
        artifact = output / f"reset-{reset}"
        artifact.mkdir()
        command = [
            "bash",
            str(Path(__file__).with_name("run_voxposer.sh")),
            "rlbench_mpc.py",
            "--task",
            args.task,
            "--seed",
            str(reset),
            "--max-physics",
            "64",
        ]
        with ExitStack() as resources:
            native = NativeProcess(command, artifact, resources)
            (output / f"{reset}-{sampling}.json").write_text(
                json.dumps(native.initial, indent=2) + "\n"
            )
            total_steps += native.initial["metadata"]["initialization_steps"]
    (output / "cost.json").write_text(
        json.dumps(
            {
                "initialization_steps": total_steps,
                "purpose": "paired case freezing; outside search allowance",
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
set -euo pipefail
repo="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
root="${VOXPOSER_ROOT:?Set VOXPOSER_ROOT to the external runtime directory}"
mkdir -p "$root/downloads" "$root/logs" "$root/artifacts"
if [[ ! -d "$root/VoxPoser/.git" ]]; then
    git clone --no-checkout --filter=blob:none https://github.com/huangwl18/VoxPoser.git "$root/VoxPoser"
fi
git -C "$root/VoxPoser" fetch --depth 1 origin e3a4c9e57b6ecb45f91e19c80510091c8cbbcbce
git -C "$root/VoxPoser" checkout --detach e3a4c9e57b6ecb45f91e19c80510091c8cbbcbce
archive="$root/downloads/CoppeliaSim_Edu_V4_1_0_Ubuntu20_04.tar.xz"
if [[ ! -f "$archive" ]]; then
    curl -fL --retry 2 \
        https://downloads.coppeliarobotics.com/V4_1_0/CoppeliaSim_Edu_V4_1_0_Ubuntu20_04.tar.xz \
        -o "$archive"
fi
echo "512de3a7347387fcc1b12fa675195a912265753f7901808382865bbf51a2a7f8  $archive" | sha256sum -c -
if [[ ! -d "$root/CoppeliaSim" ]]; then
    mkdir "$root/CoppeliaSim"
    tar -xf "$archive" -C "$root/CoppeliaSim" --strip-components=1
fi
if [[ ! -d "$root/display" ]]; then
    conda create -y -p "$root/display" -c conda-forge \
        xorg-xvfb-server=21.1.25 mesalib=26.2.5
fi
export COPPELIASIM_ROOT="$root/CoppeliaSim"
export LD_LIBRARY_PATH="$COPPELIASIM_ROOT${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
UV_PROJECT_ENVIRONMENT="$root/env312" uv sync --managed-python --python 3.12 \
    --project "$repo/environments/voxposer"

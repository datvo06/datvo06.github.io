"""Evaluate the fixed reference on frozen training cases with a reserved allowance."""

import argparse
import json
import shutil
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from program_budget import Allowance
from run_program_search import EPISODE_CAPS, TRAINING_CASES, run_case


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", choices=EPISODE_CAPS, required=True)
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    code = output / "code"
    shutil.copytree(
        Path(__file__).resolve().parent,
        code,
        ignore=shutil.ignore_patterns("__pycache__"),
    )
    allowance = Allowance.create(output / "allowance.sqlite", 1600000, 4 * 3600)

    def evaluate(case: tuple[int, int]) -> dict:
        reset, sampling = case
        return run_case(
            code / "reference_program.py",
            output / f"case-{reset}-{sampling}",
            args.task,
            reset,
            sampling,
            EPISODE_CAPS[args.task],
            allowance,
            code / "run_guided_mpc_rlbench.py",
            args.cases.resolve() / f"{reset}-{sampling}.json",
        )

    with ThreadPoolExecutor(2) as pool:
        outcomes = list(pool.map(evaluate, TRAINING_CASES))
    (output / "outcomes.json").write_text(
        json.dumps({"outcomes": outcomes, "allowance": allowance.usage()}, indent=2)
        + "\n"
    )


if __name__ == "__main__":
    main()

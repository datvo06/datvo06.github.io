"""Allow generated VoxPoser programs to set each LEAP joint target."""

import hashlib
from pathlib import Path

import numpy as np
from LMP import LMP
from run_voxposer_robotl import main
from run_voxposer_robotl_api import ObservedHandEnv

FINGER_CONTEXT = """
You additionally have set_hand_joint_targets(targets), where targets is a
dictionary from any of the 16 names in get_hand_state()['joints'] to absolute
joint angles in radians. All 16 joints can be selected independently.
Unspecified joints keep their current commanded target. Targets must lie
inside the reported lower_rad and upper_rad; invalid requests raise an error.
The command interpolates the selected targets while holding the current arm
pose. It also remembers the resulting hand posture as the closed posture for
subsequent Cartesian moves and gripper-map close commands. Open commands
restore the original open posture; close commands reuse the latest specified
posture. You may query current joint and fingertip states and revise targets
throughout the program. This API supplies no grasp planner or posture examples.
""".strip()


class IndividualHandEnv(ObservedHandEnv):
    """Expose independently commanded joint positions through the same servos."""

    def configure_lmps(self, lmps: dict[str, LMP]) -> None:
        super().configure_lmps(lmps)
        (self.output / "finger-source.txt").write_text(Path(__file__).read_text())
        with (self.output / "hand-interface-prompt.txt").open("a") as stream:
            stream.write("\n" + FINGER_CONTEXT + "\n")
        for lmp in lmps.values():
            lmp._variable_vars["set_hand_joint_targets"] = self.set_hand_joint_targets
            lmp._base_prompt += "\n\n" + FINGER_CONTEXT

    def set_hand_joint_targets(self, targets: dict[str, float]) -> None:
        state = self.hand_state()
        target = self.data.ctrl.copy()
        for name, angle in targets.items():
            joint = state["joints"][name]
            if (
                not np.isfinite(angle)
                or not joint["lower_rad"] <= angle <= joint["upper_rad"]
            ):
                raise ValueError(
                    f"{name}: {angle} outside [{joint['lower_rad']}, {joint['upper_rad']}]"
                )
            actuator = self.joint_ids[name]
            target[actuator] = angle * self.episode.gear[actuator]
        self.record_hand_call(
            {
                "api": "set_hand_joint_targets",
                "targets_rad": targets,
                "previous_targets_rad": {
                    name: state["joints"][name]["target_rad"] for name in targets
                },
                "changed_actuators": np.flatnonzero(target != self.data.ctrl).tolist(),
            }
        )
        previous_closed = self.closed_control.copy()
        simulation_time = self.data.time
        self.closed_control[7:] = target[7:]
        try:
            self.close_gripper()
        except ValueError:
            if self.data.time == simulation_time:
                self.closed_control[:] = previous_closed
            raise

    def metadata(self) -> dict:
        return super().metadata() | {
            "variant": "individual-finger-targets",
            "finger_context": FINGER_CONTEXT,
            "adaptations": [
                "Native MuJoCo Panda+LEAP fixture, not RLBench Panda gripper",
                "Privileged collision vertices with radial approximate normals",
                "Bounded arm IK; independently generated LEAP joint targets retained as the current closed posture",
                "IK convergence and pose checks; no collision or dynamic feasibility screening",
                "No grasp proposals, Guided MPC or rollout ranking",
                "Native final-pose acceptance measured from episode start; five seconds hold after program",
            ],
            "finger_source_sha256": hashlib.sha256(
                Path(__file__).read_bytes()
            ).hexdigest(),
        }


if __name__ == "__main__":
    main(IndividualHandEnv)

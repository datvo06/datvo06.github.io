"""Focused behavioral checks for constrained MPC and isolated native prediction."""

import argparse
import json
import subprocess
from contextlib import ExitStack
from pathlib import Path

import numpy as np
from program_evaluation import program_observation
from pydantic import ValidationError
from reference_program import program
from run_guided_mpc_rlbench import Config, NativeProcess, predict, project


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    config = Config()
    rng = np.random.default_rng(7)
    intervals = np.tile([-1.0, 2.0], (7, 1))
    previous = np.zeros(7)
    velocity = np.zeros(7)
    for _ in range(100):
        proposal = rng.normal(0, 20, (32, 8))
        proposal[:, 7] = 1
        controls = project(proposal, previous, velocity, intervals, 0.05, config)
        speeds = np.diff(np.vstack([previous, controls[:, :7]]), axis=0) / 0.05
        accelerations = np.diff(np.vstack([velocity, speeds]), axis=0) / 0.05
        assert np.max(np.abs(controls[:, :7])) <= 1 + 1e-8
        assert np.max(np.abs(speeds)) <= config.max_velocity + 1e-8
        assert np.max(np.abs(accelerations)) <= config.max_acceleration + 1e-8
        previous, velocity = controls[7, :7], speeds[7]
    for bad in (
        {"rounds": 0},
        {"execute_steps": 0},
        {"replay_tolerance": float("inf")},
        {"max_velocty": 0.2},
    ):
        try:
            Config.model_validate(bad)
        except ValidationError:
            continue
        raise AssertionError(f"Invalid configuration accepted: {bad}")
    script_dir = Path(__file__).resolve().parent
    command = [
        "bash",
        str(script_dir / "run_voxposer.sh"),
        "rlbench_mpc.py",
        "--task",
        "PushButton",
    ]
    with ExitStack() as resources:
        live = NativeProcess(command, output, resources)
        initial = live.initial
        (output / "initial-state.json").write_text(json.dumps(initial, indent=2) + "\n")
        state = initial["state"]
        dt = initial["metadata"]["dt"]
        prefix = {"prefix": [], "expected": state, "tolerance": config.replay_tolerance}
        observation = program_observation(state, initial["metadata"])
        controller = program.init(observation, initial["metadata"]["instruction"])
        guide = program.proposals(controller, observation)[0]
        proposal = predict(
            command,
            output,
            "proposal",
            {
                **prefix,
                "operation": "propose",
                "target": guide.target,
                "quaternion": guide.quaternion,
            },
        )
        controls = project(
            np.tile([*proposal["joint_goal"], guide.gripper], (8, 1)),
            np.asarray(state["targets"]),
            np.zeros(7),
            np.asarray(initial["metadata"]["joint_intervals"]),
            dt,
            config,
        ).tolist()
        controls[0][7] = controls[1][7] = 1
        request = {
            **prefix,
            "operation": "rollout",
            "candidate": controls,
        }
        prediction = predict(command, output, "prediction", request)
        assert live.request({"operation": "state"}) == state
        frames = [
            live.request({"operation": "step", "action": control})
            for control in controls
        ]
        assert frames == prediction["trajectory"]
        replay = predict(
            command,
            output,
            "after-closure",
            {
                **request,
                "prefix": controls,
                "expected": frames[-1]["state"],
                "candidate": [controls[-1]],
            },
        )
        for name, changes in (
            ("incomplete-state", {"expected": {"steps": 0}}),
            ("infinite-tolerance", {"tolerance": float("inf")}),
            ("wrong-state", {"expected": {**state, "q": [100.0] * 7}}),
            ("partial-gripper", {"candidate": [[*controls[0][:7], 0.9]]}),
            ("empty-candidate", {"candidate": []}),
        ):
            request_path = output / (name + ".json")
            request_path.write_text(json.dumps({**request, **changes}))
            with (output / (name + ".log")).open("w") as log:
                invalid = subprocess.run(
                    command
                    + [
                        "--request",
                        str(request_path),
                        "--response",
                        str(output / (name + ".response")),
                    ],
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    timeout=60,
                )
            assert invalid.returncode != 0, name
            error_log = (output / (name + ".log")).read_text()
            expected_error = (
                "Replay mismatch" if name == "wrong-state" else "ValidationError"
            )
            assert expected_error in error_log, (name, error_log)
            assert not (output / (name + ".response")).exists(), name
        result = {
            "projection_horizons": 100,
            "executed_steps": len(frames),
            "prediction_matches_execution_exactly": True,
            "live_unchanged_by_planning": True,
            "replay_error": replay["replay_error"],
            "invalid_requests_rejected": 5,
        }
        (output / "checks.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()

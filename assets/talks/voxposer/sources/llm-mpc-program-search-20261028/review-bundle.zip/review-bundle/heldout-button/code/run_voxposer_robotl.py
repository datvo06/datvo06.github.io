"""Run upstream VoxPoser programs against a saved RoboTL Panda and LEAP scene.

The deployment imports VoxPoser e3a4c9e from deps/VoxPoser/src (LMP.py and
interfaces.py), and RoboTL ff60eaad from
../RoboTL/.claude/worktrees/leap-codesign-v2/scripts. LMP.exec_safe re-raises
execution exceptions, so TrialEnded unwinds to this runner's finalization.
"""

import argparse
import hashlib
import json
import os
import time
from functools import partial
from itertools import product
from pathlib import Path
from unittest.mock import patch

import mujoco
import numpy as np
import openai
from arguments import get_config
from interfaces import setup_LMP
from LMP import LMP
from robotl.examples.panda_leap_teleop import RunInfo
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
from scripts.hammer_grasp_mpc import GRIP_SELECTIONS, HAMMER_HEAD_UP, HammerGrasp
from scripts.pickup_palm_mpc import (
    ARM_SPEED,
    NativeEpisode,
    RolloutBudget,
    fixture_start,
    load_scene,
    mesh_points,
    pad_points,
    resolve_ids,
)
from scripts.pinch_lift_mpc import PINCH_LIFT, PinchLift
from scripts.screwdriver_grasp_mpc import SCREWDRIVER_TIP_DOWN, ScrewdriverGrasp
from scripts.upright_pinch_lift_mpc import UPRIGHT_LIFT, UprightPinchLift
from utils import set_lmp_objects

# Operational IK tolerances, separate from the pickup acceptance predicate.
# Position matches VoxPoser's 1 cm waypoint tolerance; rotation leaves margin
# inside the native task's 20 degree orientation acceptance.
IK_POSITION_TOLERANCE_M = 0.01
IK_ROTATION_TOLERANCE_RAD = np.deg2rad(5)

TASKS = {
    "hammer": (
        partial(HammerGrasp, grips=GRIP_SELECTIONS["neck"]),
        HAMMER_HEAD_UP[-1],
        210.0,
        "Pick up the hammer, turn it so the head is above the handle, "
        "and hold it upright at least 6cm above the table. Keep holding it.",
    ),
    "screwdriver": (
        ScrewdriverGrasp,
        SCREWDRIVER_TIP_DOWN[-1],
        150.0,
        "Pick up the screwdriver, turn it so the shaft tip points down, "
        "and hold the whole screwdriver at least 6cm above the table. Keep holding it.",
    ),
    "apple": (
        PinchLift,
        PINCH_LIFT[-1],
        40.0,
        "Pick up the apple and hold it at least 6cm above the table. Keep holding it.",
    ),
    "mustard": (
        UprightPinchLift,
        UPRIGHT_LIFT[-1],
        40.0,
        "Pick up the mustard bottle and hold it upright at least 6cm above the table. "
        "Keep holding it.",
    ),
}


class TrialEnded(Exception):
    """The native hold succeeded or the simulation budget was exhausted."""


class MapRecorder:
    """Store the arrays the upstream interface sends to its visualizer."""

    def __init__(self, output: Path):
        self.output = output
        self.count = 0

    def visualize(self, info: dict) -> None:
        self.count += 1
        arrays = {k: v for k, v in info.items() if isinstance(v, np.ndarray)}
        arrays["trajectory_xyz"] = np.asarray([p[0] for p in info["traj_world"]])
        np.savez_compressed(self.output / f"maps-{self.count:03d}.npz", **arrays)


class RoboTLEnv:
    """Translate VoxPoser's Cartesian pose and binary gripper API to native servos.

    Object geometry is privileged collision-mesh geometry. A fixed scalar closure
    bends each digit's proximal, middle and distal joints, preserving lateral
    joints as RoboTL's LEAP teleoperation does. No task-specific grasp IK is used.
    """

    def __init__(self, fixture: Path, task: str, output: Path, seed: int):
        self.model = load_scene(fixture)
        self.data = fixture_start(self.model, fixture)
        self.ids = resolve_ids(
            self.model,
            RunInfo.model_validate_json((fixture / "scene.json").read_text()),
        )
        factory, stage, self.duration, self.instruction = TASKS[task]
        self.task = task
        self.objective = factory(self.model, self.data, self.ids, stage)
        self.episode = NativeEpisode(
            self.model,
            self.data,
            self.ids,
            RolloutBudget(batch=1, threads=1, horizon_s=1, replan_s=0.25, hold_s=5),
            seed=seed,
        )
        self.episode.objective = self.objective
        self.status = "program_finished_without_hold"
        self.workspace_bounds_min = np.array([-0.15, -0.6, 0.0])
        self.workspace_bounds_max = np.array([0.9, 0.6, 1.0])
        self.visualizer = MapRecorder(output)
        self.open_control = self.data.ctrl.copy()
        self.closed_control = self.open_control.copy()
        for digit in self.ids.digits:
            for actuator in (
                digit.servos.proximal,
                digit.servos.middle,
                digit.servos.distal,
            ):
                self.closed_control[actuator] = np.clip(
                    1.2 * self.episode.gear[actuator],
                    *self.model.actuator_ctrlrange[actuator],
                )
        self.scratch = mujoco.MjData(self.model)
        mujoco.mj_copyData(self.scratch, self.model, self.data)
        self.scratch.qpos[self.episode.qadr[7:]] = (
            self.closed_control[7:] / self.episode.gear[7:]
        )
        mujoco.mj_forward(self.model, self.scratch)
        palm_rotation = self.scratch.site_xmat[self.ids.palm].reshape(3, 3)
        self.tcp_offset = palm_rotation.T @ (
            pad_points(self.ids.digits, self.scratch).mean(axis=0)
            - self.scratch.site_xpos[self.ids.palm]
        )
        self.gripper = 1.0
        self.initial_pose = np.r_[self.get_ee_pos(), self.get_ee_quat()]
        self.actions = []
        self.episode._record(self.objective)

    def get_ee_pos(self) -> np.ndarray:
        rotation = self.data.site_xmat[self.ids.palm].reshape(3, 3)
        return self.data.site_xpos[self.ids.palm] + rotation @ self.tcp_offset

    def get_ee_quat(self) -> np.ndarray:
        return Rotation.from_matrix(
            self.data.site_xmat[self.ids.palm].reshape(3, 3)
        ).as_quat(scalar_first=True)

    def get_last_gripper_action(self) -> float:
        return self.gripper

    def get_object_names(self) -> list[str]:
        if self.task in ("hammer", "screwdriver"):
            end = "head" if self.task == "hammer" else "shaft"
            return [self.task, f"{self.task} handle", f"{self.task} {end}"]
        return ["mustard bottle" if self.task == "mustard" else "apple"]

    def get_3d_obs_by_name(self, name: str) -> tuple[np.ndarray, np.ndarray]:
        normalized = name.lower().replace("_", " ")
        if normalized not in self.get_object_names():
            raise ValueError(
                f"Unknown object {name!r}; available objects: {self.get_object_names()}"
            )
        geoms = self.ids.objects
        if normalized.endswith(" handle"):
            geoms = [g for g in geoms if self.model.geom_bodyid[g] == self.ids.obj]
        elif normalized.endswith((" head", " shaft")):
            geoms = [g for g in geoms if self.model.geom_bodyid[g] != self.ids.obj]
        points = mesh_points(self.model, self.data, geoms)
        normals = points - points.mean(axis=0)
        normals /= np.maximum(np.linalg.norm(normals, axis=1, keepdims=True), 1e-9)
        return points, normals

    def robot_points(self) -> np.ndarray:
        """Sample the robot's collidable geometry in world coordinates."""
        model, data = self.model, self.data
        actuated = set(model.jnt_bodyid[self.episode.joints])
        bodies = set(actuated)
        for body in actuated:
            while body:
                bodies.add(body)
                body = int(model.body_parentid[body])
        for body in range(1, model.nbody):
            ancestor = body
            while ancestor and ancestor not in actuated:
                ancestor = int(model.body_parentid[ancestor])
            if ancestor in actuated:
                bodies.add(body)
        clouds = []
        for geom in range(model.ngeom):
            if (
                model.geom_bodyid[geom] not in bodies
                or not (model.geom_contype[geom] or model.geom_conaffinity[geom])
                or geom in self.ids.objects
                or model.geom_type[geom] == mujoco.mjtGeom.mjGEOM_PLANE
            ):
                continue
            kind = mujoco.mjtGeom(int(model.geom_type[geom]))
            size = model.geom_size[geom]
            if kind == mujoco.mjtGeom.mjGEOM_MESH:
                clouds.append(mesh_points(model, data, [geom]))
                continue
            if kind == mujoco.mjtGeom.mjGEOM_BOX:
                local = np.array(list(product(*[(-s, 0, s) for s in size])))
                local = local[np.any(local != 0, axis=1)]
            elif kind in (mujoco.mjtGeom.mjGEOM_CAPSULE, mujoco.mjtGeom.mjGEOM_SPHERE):
                theta, phi = np.meshgrid(
                    np.linspace(0, 2 * np.pi, 16, endpoint=False),
                    np.linspace(-np.pi / 2, np.pi / 2, 9),
                )
                local = (
                    size[0]
                    * np.c_[
                        (np.cos(phi) * np.cos(theta)).ravel(),
                        (np.cos(phi) * np.sin(theta)).ravel(),
                        np.sin(phi).ravel(),
                    ]
                )
                if kind == mujoco.mjtGeom.mjGEOM_CAPSULE:
                    local[:, 2] += np.sign(local[:, 2]) * size[1]
            else:
                raise ValueError(f"Robot point cloud does not support geom type {kind}")
            clouds.append(
                local @ data.geom_xmat[geom].reshape(3, 3).T + data.geom_xpos[geom]
            )
        return np.concatenate(clouds)

    def get_scene_3d_obs(self, ignore_robot=False, ignore_grasped_obj=False):
        """Exclude a grasped object only when native contact retention passes.

        Merely commanding a closed hand does not establish a grasp. The native
        observer recomputes contact forces on a copy without stepping the scene.
        """
        grasped = False
        if ignore_grasped_obj:
            self.episode._refresh_observation()
            observed = self.episode.observation_data
            observation = self.episode.observer.observe(
                observed, self.objective.whole_clearance(observed)
            )
            grasped = self.objective.contained(observed, observation)
        clouds = []
        if not grasped:
            clouds.append(mesh_points(self.model, self.data, self.ids.objects))
        x, y = np.meshgrid(np.linspace(-0.15, 0.9, 60), np.linspace(-0.6, 0.6, 60))
        floor = np.c_[x.ravel(), y.ravel(), np.zeros(x.size)]
        clouds.append(floor)
        if not ignore_robot:
            clouds.append(self.robot_points())
        points = np.concatenate(clouds)
        return points, np.tile([0.0, 0.0, 1.0], (len(points), 1))

    def advance(self, control: np.ndarray) -> None:
        self.data.ctrl[:] = control
        mujoco.mj_step(self.model, self.data)
        self.episode._record(self.objective)
        if self.episode.lifted_clock.held_for(self.data.time) >= 5:
            self.status = "success"
            raise TrialEnded
        if self.data.time - self.episode.start_time >= self.duration:
            self.status = "timeout"
            raise TrialEnded

    def apply_action(self, action: np.ndarray):
        action = np.asarray(action, dtype=float)
        if action.shape != (8,) or not np.isfinite(action).all():
            raise ValueError("Expected eight finite action values: position, quaternion, gripper")
        rotation = Rotation.from_quat(action[3:7], scalar_first=True).as_matrix()
        position = action[:3] - rotation @ self.tcp_offset
        model, data, scratch = self.model, self.data, self.scratch
        mujoco.mj_copyData(scratch, model, data)
        qadr = self.episode.qadr[:7]
        lower, upper = model.jnt_range[self.episode.joints[:7]].T

        def residual(q):
            scratch.qpos[qadr] = q
            mujoco.mj_kinematics(model, scratch)
            turn = Rotation.from_matrix(
                rotation @ scratch.site_xmat[self.ids.palm].reshape(3, 3).T
            ).as_rotvec()
            return np.r_[scratch.site_xpos[self.ids.palm] - position, 0.08 * turn]

        solved = least_squares(
            residual,
            np.clip(data.qpos[qadr], lower + 1e-8, upper - 1e-8),
            bounds=(lower, upper),
            max_nfev=100,
        )
        if not solved.success:
            raise ValueError(f"Arm IK did not converge: {solved.message}")
        pose_error = residual(solved.x)
        position_error = float(np.linalg.norm(pose_error[:3]))
        rotation_error = float(np.linalg.norm(pose_error[3:]) / 0.08)
        if (
            position_error > IK_POSITION_TOLERANCE_M
            or rotation_error > IK_ROTATION_TOLERANCE_RAD
        ):
            raise ValueError(
                f"Arm IK pose error: {position_error:.6f} m, {rotation_error:.6f} rad "
                f"(limits {IK_POSITION_TOLERANCE_M} m, {IK_ROTATION_TOLERANCE_RAD} rad)"
            )
        self.gripper = float(np.clip(action[7], 0, 1))
        target = (
            self.gripper * self.open_control + (1 - self.gripper) * self.closed_control
        )
        target[:7] = solved.x * self.episode.gear[:7]
        start = data.ctrl.copy()
        duration = max(
            0.3,
            float(np.max(np.abs(target[:7] - start[:7]) / (ARM_SPEED * 0.25))) * 1.875,
            float(np.max(np.abs(target[7:] - start[7:]))) / 0.6,
        )
        steps = max(1, round(duration / model.opt.timestep))
        self.actions.append(
            dict(
                time_s=float(data.time),
                target=action.tolist(),
                ik_residual=float(np.linalg.norm(solved.fun)),
                duration_s=duration,
            )
        )
        for fraction in np.arange(1, steps + 1) / steps:
            blend = fraction**3 * (10 - 15 * fraction + 6 * fraction**2)
            self.advance(start + blend * (target - start))
        return None, 0.0, False

    def move_to_pose(self, pose, speed=None):
        return self.apply_action(np.r_[pose, self.gripper])

    def reset_to_default_pose(self):
        return self.move_to_pose(self.initial_pose)

    def open_gripper(self):
        return self.apply_action(np.r_[self.get_ee_pos(), self.get_ee_quat(), 1.0])

    def close_gripper(self):
        return self.apply_action(np.r_[self.get_ee_pos(), self.get_ee_quat(), 0.0])

    def configure_lmps(self, lmps: dict[str, LMP]) -> None:
        """The baseline exposes only the upstream VoxPoser interfaces."""

    def metadata(self) -> dict:
        """Additional experiment metadata supplied by an interface extension."""
        return {}


def main(environment_class: type[RoboTLEnv] = RoboTLEnv) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", choices=TASKS, required=True)
    parser.add_argument("--fixture", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    np.random.seed(args.seed)
    openai.api_key = os.environ["OPENAI_API_KEY"]
    config = get_config("rlbench")
    config["lmp_config"]["env"]["visualize"] = True
    for cfg in config["lmp_config"]["lmps"].values():
        cfg["model"] = "gpt-4.1"
    env = environment_class(args.fixture, args.task, args.output, args.seed)
    (args.output / "config.json").write_text(
        json.dumps(
            {
                "voxposer": config,
                "task": args.task,
                "instruction": env.instruction,
                "source_revision": "ff60eaad16a044591e2a3119f6f499449869b8e7",
                "seed": args.seed,
                "scene_sha256": hashlib.sha256(
                    (args.fixture / "scene.mjb").read_bytes()
                ).hexdigest(),
                "adapter_sha256": hashlib.sha256(
                    Path(__file__).read_bytes()
                ).hexdigest(),
                "mujoco": mujoco.__version__,
                "numpy": np.__version__,
                "workspace_min": env.workspace_bounds_min.tolist(),
                "workspace_max": env.workspace_bounds_max.tolist(),
                "tcp_offset_palm": env.tcp_offset.tolist(),
                "open_control": env.open_control.tolist(),
                "closed_control": env.closed_control.tolist(),
                "adaptations": [
                    "Native MuJoCo Panda+LEAP fixture, not RLBench Panda gripper",
                    "Privileged collision vertices with radial approximate normals",
                    "Bounded arm IK and fixed scalar hand closure; no grasp proposals or Guided MPC",
                    "Native final-pose acceptance measured from episode start; five seconds hold after program",
                ],
                **env.metadata(),
            },
            indent=2,
        )
    )
    generated = []
    original = LMP._cached_api_call

    def record_reply(lmp, **kwargs):
        prompt = kwargs["prompt"]
        code = original(lmp, **kwargs)
        generated.append(dict(generator=lmp._name, prompt=prompt, code=code))
        (args.output / "generated-code.json").write_text(
            json.dumps(generated, indent=2)
        )
        return code

    began = time.monotonic()
    try:
        with patch.object(LMP, "_cached_api_call", record_reply):
            lmps, _ = setup_LMP(env, config, debug=False)
            set_lmp_objects(lmps, env.get_object_names())
            env.configure_lmps(lmps)
            lmps["plan_ui"](env.instruction)
            for _ in range(round(5.1 / env.model.opt.timestep)):
                env.advance(env.data.ctrl.copy())
    except TrialEnded:
        pass
    except Exception as error:
        env.status = "program_error"
        (args.output / "error.json").write_text(
            json.dumps({"type": type(error).__name__, "message": str(error)})
        )
        raise
    finally:
        env.episode.wall_s = time.monotonic() - began
        (args.output / "actions.json").write_text(json.dumps(env.actions, indent=2))
        env.episode.save(args.output, env.status)


if __name__ == "__main__":
    main()

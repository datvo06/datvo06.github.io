"""Trusted filtering of native replay state into program observations."""

import hashlib
import math
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from tempfile import TemporaryFile

from mpc_program import ProgramObservation, ProgramRequest, ProgramResponse


class ProgramRuntime:
    """Reconstruct typed state in a fresh networkless, read-only Linux sandbox."""

    def __init__(self, source: Path):
        self.source = source.resolve()
        self.source_hash = hashlib.sha256(self.source.read_bytes()).hexdigest()
        script = Path(__file__).resolve().parent
        self.command = [
            "bwrap",
            "--die-with-parent",
            "--unshare-all",
            "--new-session",
            "--clearenv",
            "--proc",
            "/proc",
            "--dev",
            "/dev",
            "--tmpfs",
            "/tmp",
        ]
        for directory in dict.fromkeys(
            [
                "/usr",
                "/lib",
                "/lib64",
                sys.base_prefix,
                sys.prefix,
                str(Path(sys.executable).resolve().parent.parent),
            ]
        ):
            self.command += ["--ro-bind", directory, directory]
        for name in ("mpc_program.py", "program_worker.py"):
            self.command += ["--ro-bind", str(script / name), "/app/" + name]
        self.command += [
            "--ro-bind",
            str(self.source),
            "/program.py",
            "--chdir",
            "/app",
            "--setenv",
            "PYTHONHASHSEED",
            "0",
            "--setenv",
            "OPENBLAS_NUM_THREADS",
            "1",
            "--setenv",
            "PYTHONPATH",
            str(
                Path(sys.prefix)
                / "lib"
                / f"python{sys.version_info.major}.{sys.version_info.minor}"
                / "site-packages"
            ),
            str(Path(sys.executable).resolve()),
            "/app/program_worker.py",
        ]

    def evaluate(
        self, request: ProgramRequest, timeout_s: float = 20
    ) -> ProgramResponse:
        """Require identical outputs from two independent reconstructed branches."""
        responses = []
        deadline = time.monotonic() + timeout_s
        for _ in range(2):
            with TemporaryFile() as output, TemporaryFile() as errors:
                with subprocess.Popen(
                    self.command,
                    stdin=subprocess.PIPE,
                    stdout=output,
                    stderr=errors,
                    start_new_session=True,
                ) as process:
                    try:
                        process.communicate(
                            request.model_dump_json().encode(),
                            timeout=max(0, deadline - time.monotonic()),
                        )
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.communicate()
                        raise
                if process.returncode:
                    errors.seek(0)
                    raise RuntimeError(
                        "Program worker failed: "
                        + errors.read(4096).decode(errors="replace")
                    )
                output.seek(0)
                responses.append(
                    ProgramResponse.model_validate_json(output.read(1024**2))
                )
        if responses[0] != responses[1]:
            raise ValueError("Program is not repeatable from explicit inputs")
        if responses[0].source_hash != self.source_hash:
            raise ValueError("Frozen program source changed")
        return responses[0]


def program_observation(state: dict, metadata: dict) -> ProgramObservation:
    """Copy only the declared policy inputs from private native state."""
    name = {
        "TakeLidOffSaucepan": "saucepan_lid_grasp_point",
        "PushButton": "target_button_topPlate",
    }[metadata["task"]]
    obj = state["objects"][name]
    return ProgramObservation(
        tip=tuple(state["tip"]),
        joints=tuple(state["q"]),
        joint_targets=tuple(state["targets"]),
        object_pose=tuple(obj["pose"]),
        object_velocity=tuple(obj["velocity"]),
        grasped=bool(state["grasped"]),
        button_displacement=None
        if state["button_joint"] is None
        else state["button_joint"] - metadata["initial_joint"],
        time=state["steps"] * metadata["dt"],
        gripper_command=state["gripper_command"],
        gripper_ready=not (state["actuating"] or state["settle"]),
    )


type JSON = dict[str, JSON] | list[JSON] | str | float | int | bool | None


def compare_state(
    actual: JSON, expected: JSON, tolerance: float, path: str = ""
) -> float:
    """Reject mismatched replay before using a candidate prediction."""
    if isinstance(expected, dict) and isinstance(actual, dict):
        if actual.keys() != expected.keys():
            raise ValueError(f"Replay keys mismatch at {path}")
        return max(
            compare_state(actual[k], v, tolerance, path + "." + k)
            for k, v in expected.items()
        )
    if isinstance(expected, list) and isinstance(actual, list):
        if len(actual) != len(expected):
            raise ValueError(f"Replay length mismatch at {path}")
        return max(
            (
                compare_state(a, b, tolerance, f"{path}[{i}]")
                for i, (a, b) in enumerate(zip(actual, expected))
            ),
            default=0.0,
        )
    if (
        isinstance(expected, (float, int))
        and isinstance(actual, (float, int))
        and not isinstance(expected, bool)
    ):
        error = abs(float(actual) - expected)
        if not math.isfinite(error) or error > tolerance:
            raise ValueError(f"Replay mismatch at {path}: {actual} vs {expected}")
        return error
    if actual != expected:
        raise ValueError(f"Replay mismatch at {path}: {actual} vs {expected}")
    return 0.0

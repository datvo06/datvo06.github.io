"""Disposable program execution. Invoke only inside the evaluator's sandbox."""

import hashlib
import importlib.util
import pickle
import resource
import sys
from pathlib import Path

from mpc_program import ProgramRequest, ProgramResponse, Proposals
from pydantic import TypeAdapter


def main() -> None:
    resource.setrlimit(resource.RLIMIT_CPU, (10, 10))
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE, (1024**2, 1024**2))
    resource.setrlimit(resource.RLIMIT_NOFILE, (32, 32))
    resource.setrlimit(resource.RLIMIT_NPROC, (0, 0))
    request = ProgramRequest.model_validate_json(sys.stdin.read())
    path = Path("/program.py")
    source_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    spec = importlib.util.spec_from_file_location("candidate", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules["candidate"] = module
    spec.loader.exec_module(module)
    program = module.program
    state = program.init(request.initial, request.instruction)
    states = [state]
    snapshots = [pickle.dumps(state, protocol=5)]
    for step in request.prefix:
        state = program.advance(state, step.action, step.observation)
        states.append(state)
        snapshots.append(pickle.dumps(state, protocol=5))
    initial = state
    observation = request.prefix[-1].observation if request.prefix else request.initial
    proposals = TypeAdapter(Proposals).validate_python(
        program.proposals(state, observation)
    )
    predicted = []
    for step in request.trajectory:
        state = program.advance(state, step.action, step.observation)
        states.append(state)
        snapshots.append(pickle.dumps(state, protocol=5))
        predicted.append(state)
    cost = (
        program.trajectory_cost(
            initial, tuple(predicted), tuple(s.observation for s in request.trajectory)
        )
        if predicted
        else None
    )
    for state, snapshot in zip(states, snapshots, strict=True):
        if pickle.dumps(state, protocol=5) != snapshot:
            raise ValueError("Program mutated an earlier state")
    response = ProgramResponse(
        proposals=proposals,
        cost=cost,
        state_hashes=tuple(hashlib.sha256(s).hexdigest() for s in snapshots),
        source_hash=source_hash,
    )
    print(response.model_dump_json())


if __name__ == "__main__":
    main()

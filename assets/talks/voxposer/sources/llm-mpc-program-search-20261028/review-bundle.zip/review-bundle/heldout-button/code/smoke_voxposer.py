"""Check perception, pushing optimization, and a reachable motion without an LLM."""

import json
import time

import numpy as np
from arguments import get_config
from controllers import Controller
from interfaces import setup_LMP

from run_voxposer import environment


def main() -> None:
    """Exercise the upstream planner and controller in a live RLBench simulation."""
    np.random.seed(0)
    config = get_config("rlbench")
    config["lmp_config"]["env"]["visualize"] = False
    with environment() as env:
        env.load_task("PushButton")
        env.reset()
        _, interface = setup_LMP(env, config, debug=False)
        points, _ = env.get_3d_obs_by_name(env.get_object_names()[0])
        if not len(points) or not np.isfinite(points).all():
            raise RuntimeError("Object perception returned empty or nonfinite points")
        sampled = points[
            np.linspace(0, len(points) - 1, min(64, len(points))).astype(int)
        ]
        start = time.perf_counter()
        control, _ = Controller(env, config["controller"]).random_shooting_MPC(
            {"_point_cloud_world": sampled},
            sampled.mean(axis=0) + np.array([0.03, 0, 0]),
        )
        elapsed = time.perf_counter() - start
        if not np.isfinite(control).all():
            raise RuntimeError("Pushing optimizer returned nonfinite controls")
        # The initial arm pose is near its upper reach limit.
        target = env.get_ee_pos().copy() + np.array([0, 0, -0.03])
        target_voxel = interface.get_ee_pos().copy()
        target_voxel[2] -= interface.cm2index(3, "z")
        affordance = interface.get_empty_affordance_map()
        affordance[tuple(target_voxel)] = 1
        interface.execute(
            lambda: interface.detect("gripper"), affordance_map=lambda: affordance
        )
        error = float(np.linalg.norm(env.get_ee_pos() - target))
        if not np.isfinite(error) or error >= 0.02:
            raise RuntimeError(f"Motion did not reach target: {error} m")
        print(
            json.dumps(
                {
                    "object_points": len(points),
                    "mpc_optimizer_s": elapsed,
                    "mpc_candidates": config["controller"]["num_samples"],
                    "motion_target_error_m": error,
                    "smoke_passed": True,
                }
            )
        )


if __name__ == "__main__":
    main()

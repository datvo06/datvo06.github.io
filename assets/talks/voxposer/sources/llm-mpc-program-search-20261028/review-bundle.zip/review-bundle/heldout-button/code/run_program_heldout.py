"""Freeze completed study selections, then evaluate paired held-out cases."""

import argparse
import hashlib
import json
import shutil
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack
from pathlib import Path

from program_budget import Allowance
from run_program_search import EPISODE_CAPS, HELD_OUT_CASES, run_case, study_lock

EVALUATOR_FILES = (
    "mpc_program.py",
    "program_evaluation.py",
    "program_worker.py",
    "rlbench_mpc.py",
    "run_guided_mpc_rlbench.py",
    "run_voxposer.sh",
    "program_budget.py",
    "reference_program.py",
)


def evaluator_identity(study: Path) -> dict[str, str]:
    """Verify the implementation actually used by a frozen training study."""
    config = json.loads((study / "config.json").read_text())
    identity = {
        name: hashlib.sha256((study / "code" / name).read_bytes()).hexdigest()
        for name in EVALUATOR_FILES
    }
    if any(
        config["source_hashes"][name] != digest for name, digest in identity.items()
    ):
        raise ValueError("Frozen study evaluator changed")
    return identity


def evaluate_heldout(args: argparse.Namespace) -> None:
    """Freeze and evaluate while both study lifecycle locks are held."""
    identity = evaluator_identity(args.improvement)
    if evaluator_identity(args.synthesis) != identity:
        raise ValueError("Study evaluator implementations differ")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    code = output / "code"
    shutil.copytree(
        args.improvement / "code",
        code,
        ignore=shutil.ignore_patterns("__pycache__"),
    )
    sources = {"reference": code / "reference_program.py"}
    selections = {}
    cases = output / "cases"
    cases.mkdir()
    case_hashes = {}
    for reset, sampling in HELD_OUT_CASES:
        name = f"{reset}-{sampling}.json"
        shutil.copy2(args.cases / name, cases / name)
        case_hashes[name] = hashlib.sha256((cases / name).read_bytes()).hexdigest()
    for condition in ("improvement", "synthesis"):
        study = getattr(args, condition).resolve()
        config = json.loads((study / "config.json").read_text())
        if config["task"] != args.task or config["condition"] != condition:
            raise ValueError("Study does not match held-out comparison")
        if any(
            config["case_hashes"][name] != digest
            for name, digest in case_hashes.items()
        ):
            raise ValueError("Held-out cases differ from frozen study cases")
        selection = json.loads((study / "selection.json").read_text())
        selections[condition] = {"study": str(study), "selection": selection}
        if selection["source_hash"] is not None:
            source = study / "programs" / selection["source_hash"] / "program.py"
            if (
                hashlib.sha256(source.read_bytes()).hexdigest()
                != selection["source_hash"]
            ):
                raise ValueError("Selected program hash differs")
            destination = output / f"{condition}.py"
            shutil.copy2(source, destination)
            sources[condition] = destination
    # This manifest freezes selections and inputs before held-out evaluation.
    (output / "frozen-selections.json").write_text(
        json.dumps(
            {
                "task": args.task,
                "studies": selections,
                "source_hashes": {
                    name: hashlib.sha256(path.read_bytes()).hexdigest()
                    for name, path in sources.items()
                },
                "held_out": HELD_OUT_CASES,
                "case_hashes": case_hashes,
                "parallel_cases": args.parallel_cases,
                "evaluator_hashes": identity,
            },
            indent=2,
        )
        + "\n"
    )
    for study in (args.improvement, args.synthesis):
        with (study / "frozen-for-heldout.json").open("x") as marker:
            marker.write(
                json.dumps(
                    {
                        "heldout_output": str(output),
                        "selection": json.loads((study / "selection.json").read_text()),
                        "evaluator_hashes": identity,
                    }
                )
                + "\n"
            )
    allowance = Allowance.create(output / "allowance.sqlite", 1600000, 4 * 3600)
    jobs = [
        (name, source, reset, sampling)
        for name, source in sources.items()
        for reset, sampling in HELD_OUT_CASES
    ]

    def evaluate(job: tuple[str, Path, int, int]) -> dict:
        name, source, reset, sampling = job
        result = run_case(
            source,
            output / f"{name}-{reset}-{sampling}",
            args.task,
            reset,
            sampling,
            EPISODE_CAPS[args.task],
            allowance,
            code / "run_guided_mpc_rlbench.py",
            cases / f"{reset}-{sampling}.json",
        )
        return {
            "condition": name,
            "reset": reset,
            "sampling": sampling,
            "result": result,
        }

    with ThreadPoolExecutor(args.parallel_cases) as pool:
        outcomes = list(pool.map(evaluate, jobs))
    (output / "outcomes.json").write_text(
        json.dumps({"outcomes": outcomes, "allowance": allowance.usage()}, indent=2)
        + "\n"
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", choices=EPISODE_CAPS, required=True)
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--improvement", type=Path, required=True)
    parser.add_argument("--synthesis", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--parallel-cases", type=int, choices=(1, 2, 4), default=2)
    args = parser.parse_args()
    with ExitStack() as resources:
        for study in sorted((args.improvement.resolve(), args.synthesis.resolve())):
            resources.enter_context(study_lock(study))
        evaluate_heldout(args)


if __name__ == "__main__":
    main()

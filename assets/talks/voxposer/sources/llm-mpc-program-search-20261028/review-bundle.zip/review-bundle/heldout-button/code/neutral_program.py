"""Neutral synthesis scaffold: hold the current joint targets."""

from mpc_program import Action, JointProposal, ProgramObservation, Proposals


class HoldProgram:
    def init(self, observation: ProgramObservation, instruction: str) -> None:
        return None

    def advance(
        self, state: None, action: Action, observation: ProgramObservation
    ) -> None:
        return None

    def proposals(self, state: None, observation: ProgramObservation) -> Proposals:
        return (
            JointProposal(
                actions=((*observation.joint_targets, observation.gripper_command),)
            ),
        )

    def trajectory_cost(
        self,
        initial: None,
        states: tuple[None, ...],
        observations: tuple[ProgramObservation, ...],
    ) -> float:
        return 0.0


program = HoldProgram()

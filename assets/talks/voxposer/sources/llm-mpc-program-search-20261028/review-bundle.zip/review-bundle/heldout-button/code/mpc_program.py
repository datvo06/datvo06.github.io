"""Permitted controller inputs and outputs, in metres, radians and seconds."""

from typing import Annotated, Literal, Protocol

from pydantic import BaseModel, ConfigDict, Field

type FiniteFloat = Annotated[float, Field(allow_inf_nan=False)]
type Vec3 = tuple[FiniteFloat, FiniteFloat, FiniteFloat]
type Quaternion = tuple[FiniteFloat, FiniteFloat, FiniteFloat, FiniteFloat]
type Pose = tuple[
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
]
type Action = tuple[
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    FiniteFloat,
    Literal[0, 1],
]


class ProgramObservation(BaseModel):
    """Physical observations in metres, radians and seconds.

    ``tip`` and ``object_pose`` are world-frame xyz + xyzw quaternion poses.
    The object is the lid grasp marker for the saucepan task and the target
    button top plate for the button task. ``object_velocity`` contains world
    linear xyz (m/s), then angular xyz (rad/s). ``joints`` and ``joint_targets``
    are the seven arm joint positions and commands. ``grasped`` reports native
    attachment to the gripper. ``button_displacement`` is joint displacement
    relative to reset (None for the saucepan). ``time`` is elapsed simulation
    time. Gripper commands are 0 closed / 1 open; ``gripper_ready`` means no
    actuation or settling is pending, so changing the command is permitted.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")
    tip: Pose
    joints: tuple[FiniteFloat, ...]
    joint_targets: tuple[FiniteFloat, ...]
    object_pose: Pose
    object_velocity: tuple[FiniteFloat, ...]
    grasped: bool
    button_displacement: FiniteFloat | None
    time: FiniteFloat
    gripper_command: Literal[0, 1]
    gripper_ready: bool


class CartesianProposal(BaseModel):
    """A world-frame IK target, advanced by at most 10 cm by the adapter."""

    model_config = ConfigDict(extra="forbid")
    target: Vec3
    quaternion: Quaternion
    gripper: Literal[0, 1]


class JointProposal(BaseModel):
    """Joint targets projected by the sampler onto its fixed command bounds."""

    model_config = ConfigDict(extra="forbid")
    actions: Annotated[tuple[Action, ...], Field(min_length=1, max_length=32)]


type Proposals = Annotated[
    tuple[CartesianProposal | JointProposal, ...], Field(min_length=1, max_length=7)
]


class Program[T](Protocol):
    """Deterministic Python controller with explicit, unrestricted typed state.

    Export an instance as ``program``. Return new state without mutating previous
    values. Sampling belongs to MPC. Costs cannot redefine native acceptance.
    """

    def init(self, observation: ProgramObservation, instruction: str) -> T: ...
    def advance(
        self, state: T, action: Action, observation: ProgramObservation
    ) -> T: ...
    def proposals(self, state: T, observation: ProgramObservation) -> Proposals: ...
    def trajectory_cost(
        self,
        initial: T,
        states: tuple[T, ...],
        observations: tuple[ProgramObservation, ...],
    ) -> float: ...


class ProgramStep(BaseModel):
    """The actual action and resulting permitted observation."""

    action: Action
    observation: ProgramObservation


class ProgramRequest(BaseModel):
    """Inputs for reconstruction in a fresh isolated Python runtime."""

    initial: ProgramObservation
    instruction: str
    prefix: tuple[ProgramStep, ...]
    trajectory: tuple[ProgramStep, ...] = ()


class ProgramResponse(BaseModel):
    """Only bounded guidance, finite cost and opaque audit hashes leave a worker."""

    proposals: Proposals
    cost: FiniteFloat | None
    state_hashes: tuple[str, ...]
    source_hash: str

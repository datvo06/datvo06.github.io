"""Check scene exclusions and IK rejection on native hammer states.

The recording must belong to the supplied fixture and end with a retained
grasp. No language-model calls or new pickup trials are made.
"""

import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import mujoco
import numpy as np
from arguments import get_config
from interfaces import setup_LMP
from run_voxposer_robotl import RoboTLEnv
from scripts.pickup_palm_mpc import mesh_points


def check(fixture: Path, recording: Path, output: Path) -> dict[str, bool | float]:
    env = RoboTLEnv(fixture, "hammer", output, seed=0)
    model, data = env.model, env.data
    initial = mujoco.MjData(model)
    mujoco.mj_copyData(initial, model, data)
    objects = mesh_points(model, data, env.ids.objects)
    x, y = np.meshgrid(np.linspace(-0.15, 0.9, 60), np.linspace(-0.6, 0.6, 60))
    floor = np.c_[x.ravel(), y.ravel(), np.zeros(x.size)]
    background, _ = env.get_scene_3d_obs(ignore_robot=True)
    np.testing.assert_array_equal(background, np.concatenate([objects, floor]))
    ungrasped, _ = env.get_scene_3d_obs(ignore_robot=True, ignore_grasped_obj=True)
    np.testing.assert_array_equal(ungrasped, background)
    full, _ = env.get_scene_3d_obs(ignore_robot=False)
    assert len(full) > len(background)
    robot = env.robot_points()

    _, interface = setup_LMP(env, get_config("rlbench"), debug=False)
    collisions = interface._get_scene_collision_voxel_map()
    object_voxels = interface._points_to_voxel_map(objects).astype(bool)
    robot_only = interface._points_to_voxel_map(robot).astype(bool)
    robot_only &= ~interface._points_to_voxel_map(background).astype(bool)
    assert robot_only.any()
    assert np.all(collisions[object_voxels] > 0)
    assert np.all(collisions[robot_only] == 0)

    with np.load(recording) as recorded:
        data.qpos[:], data.qvel[:], data.ctrl[:] = (
            recorded["qpos"][-1],
            recorded["qvel"][-1],
            recorded["ctrl"][-1],
        )
        data.time = float(recorded["time_s"][-1])
    data.qacc_warmstart[:] = 0
    mujoco.mj_forward(model, data)
    held_all, _ = env.get_scene_3d_obs(ignore_robot=True)
    held_excluded, _ = env.get_scene_3d_obs(ignore_robot=True, ignore_grasped_obj=True)
    assert len(held_all) > len(held_excluded)
    np.testing.assert_array_equal(held_excluded, floor)
    assert len(env.get_scene_3d_obs(ignore_grasped_obj=True)[0]) > len(floor)
    mujoco.mj_copyData(data, model, initial)
    np.testing.assert_array_equal(
        env.get_scene_3d_obs(ignore_robot=True, ignore_grasped_obj=True)[0], background
    )

    start = env.get_ee_pos().copy()
    env.move_to_pose(np.r_[start + [0.015, 0, 0], env.get_ee_quat()])
    displacement = float(np.linalg.norm(env.get_ee_pos() - start))
    assert displacement > 0.003
    before_time, before_gripper = data.time, env.get_last_gripper_action()
    before_qpos, before_qvel, before_ctrl = (
        data.qpos.copy(),
        data.qvel.copy(),
        data.ctrl.copy(),
    )
    try:
        env.apply_action(np.r_[[3.0, 0, 0.5], env.get_ee_quat(), 1 - before_gripper])
    except ValueError as error:
        assert "Arm IK" in str(error)
    else:
        raise AssertionError("Unreachable Cartesian pose was executed")
    assert data.time == before_time
    assert env.get_last_gripper_action() == before_gripper
    np.testing.assert_array_equal(data.qpos, before_qpos)
    np.testing.assert_array_equal(data.qvel, before_qvel)
    np.testing.assert_array_equal(data.ctrl, before_ctrl)
    invalid_actions = (
        np.r_[env.get_ee_pos(), env.get_ee_quat(), np.nan],
        np.r_[env.get_ee_pos(), env.get_ee_quat()],
    )
    for action in invalid_actions:
        try:
            env.apply_action(action)
        except ValueError:
            pass
        else:
            raise AssertionError("Invalid Cartesian action was executed")
        assert data.time == before_time
        assert env.get_last_gripper_action() == before_gripper
        np.testing.assert_array_equal(data.qpos, before_qpos)
        np.testing.assert_array_equal(data.qvel, before_qvel)
        np.testing.assert_array_equal(data.ctrl, before_ctrl)
    return dict(
        original_planner_cloud_preserved=True,
        robot_geometry_included_on_request=True,
        upstream_collision_map_excludes_robot=True,
        grasped_object_excluded_from_real_contact_state=True,
        ungrasped_object_restored_without_stale_state=True,
        reachable_pose_moves_arm_m=displacement,
        unreachable_pose_rejected_before_gripper_or_motion=True,
        invalid_actions_rejected_without_state_change=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixture", type=Path, required=True)
    parser.add_argument("--grasp-recording", type=Path, required=True)
    args = parser.parse_args()
    with TemporaryDirectory(
        prefix="backend-check-", dir=args.fixture.resolve().parent
    ) as tmp:
        result = check(args.fixture, args.grasp_recording, Path(tmp))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

"""Durable, shared simulator reservations for one bounded program study."""

import sqlite3
import time
from contextlib import closing
from pathlib import Path


class AllowanceExhausted(RuntimeError):
    """A study reached its predeclared wall or simulator allowance."""


class Allowance:
    """Reserve work transactionally before dispatch; interrupted work stays charged."""

    def __init__(self, path: Path):
        self.path = path

    @classmethod
    def create(cls, path: Path, steps: int, wall_s: float) -> "Allowance":
        with closing(sqlite3.connect(path)) as db, db:
            db.execute("CREATE TABLE limits (steps INTEGER, deadline REAL)")
            db.execute(
                "INSERT INTO limits VALUES (?, ?)", (steps, time.time() + wall_s)
            )
            db.execute(
                "CREATE TABLE work (id INTEGER PRIMARY KEY, reserved INTEGER CHECK(reserved >= 0), actual INTEGER)"
            )
        return cls(path)

    def reserve(self, steps: int) -> int:
        with closing(sqlite3.connect(self.path, timeout=30)) as db, db:
            db.execute("BEGIN IMMEDIATE")
            limit, deadline = db.execute(
                "SELECT steps, deadline FROM limits"
            ).fetchone()
            used = db.execute(
                "SELECT COALESCE(SUM(COALESCE(actual, reserved)), 0) FROM work"
            ).fetchone()[0]
            if time.time() >= deadline or used + steps > limit:
                raise AllowanceExhausted("Wall or simulator-step allowance exhausted")
            return db.execute(
                "INSERT INTO work (reserved) VALUES (?) RETURNING id", (steps,)
            ).fetchone()[0]

    def settle(self, reservation: int, actual: int) -> None:
        with closing(sqlite3.connect(self.path, timeout=30)) as db, db:
            db.execute("BEGIN IMMEDIATE")
            reserved, previous = db.execute(
                "SELECT reserved, actual FROM work WHERE id=?", (reservation,)
            ).fetchone()
            if previous is not None or not 0 <= actual <= reserved:
                raise ValueError(
                    "Invalid or duplicate simulator reservation settlement"
                )
            db.execute("UPDATE work SET actual=? WHERE id=?", (actual, reservation))

    def remaining_s(self) -> float:
        with closing(sqlite3.connect(self.path)) as db:
            deadline = db.execute("SELECT deadline FROM limits").fetchone()[0]
        remaining = deadline - time.time()
        if remaining <= 0:
            raise AllowanceExhausted("Wall allowance exhausted")
        return remaining

    def usage(self) -> dict:
        with closing(sqlite3.connect(self.path)) as db:
            charged, actual, outstanding = db.execute(
                "SELECT COALESCE(SUM(COALESCE(actual,reserved)),0), COALESCE(SUM(actual),0), COUNT(*) FILTER (WHERE actual IS NULL) FROM work"
            ).fetchone()
        return {
            "charged_steps": charged,
            "confirmed_steps": actual,
            "unsettled_reservations": outstanding,
        }

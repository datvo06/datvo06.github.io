"""Compare extracted reference guidance and costs with frozen native artifacts."""

import argparse
import gzip
import json
from pathlib import Path

import numpy as np
from program_evaluation import program_observation
from reference_program import guidance, program


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reference", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    results = []
    for task in ("saucepan-v1", "button-v1"):
        directory = args.reference / task
        initial = json.loads((directory / "initial-state.json").read_text())
        metadata = initial["metadata"]
        state = program.init(
            program_observation(initial["state"], metadata), metadata["instruction"]
        )
        execution = [
            json.loads(line)
            for line in (directory / "execution.jsonl").read_text().splitlines()
        ]
        maximum = 0.0
        checked = 0
        advanced = 0
        for record in map(
            json.loads, (directory / "optimization.jsonl").read_text().splitlines()
        ):
            step = record["step"]
            for frame in execution[advanced:step]:
                state = program.advance(
                    state,
                    tuple(frame["action"]),
                    program_observation(frame["state"], metadata),
                )
            advanced = step
            stage, proposal = guidance(state)
            assert stage == record["guidance"]["stage"]
            np.testing.assert_array_equal(proposal.target, record["guidance"]["target"])
            assert proposal.gripper == record["guidance"]["gripper"]
            for round_record in record["rounds"]:
                for name, expected_cost in zip(
                    round_record["candidate_artifacts"],
                    round_record["costs"],
                    strict=True,
                ):
                    with gzip.open(
                        directory / "rollouts" / (name + ".response.json.gz"), "rt"
                    ) as f:
                        trajectory = json.load(f)["trajectory"]
                    observations = tuple(
                        program_observation(frame["state"], metadata)
                        for frame in trajectory
                    )
                    branch = state
                    states = []
                    for frame, observation in zip(
                        trajectory, observations, strict=True
                    ):
                        branch = program.advance(
                            branch, tuple(frame["action"]), observation
                        )
                        states.append(branch)
                    cost = program.trajectory_cost(state, tuple(states), observations)
                    maximum = max(maximum, abs(cost - expected_cost))
                    np.testing.assert_allclose(
                        cost, expected_cost, atol=1e-12, rtol=1e-12
                    )
                    checked += 1
        results.append(
            {
                "task": task,
                "candidate_costs_checked": checked,
                "max_cost_difference": maximum,
                "guidance_matches": True,
            }
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results))


if __name__ == "__main__":
    main()

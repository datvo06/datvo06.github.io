"""Check the LEAP hand API with native physics and an existing hammer fixture.

Run in the same external dependency environment as the VoxPoser adapters.
No language-model calls or pickup trials are made. Temporary API logs live
beside the fixture and are removed after the check.
"""

import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

import numpy as np
from run_voxposer_robotl_api import ObservedHandEnv, vec2quat
from run_voxposer_robotl_fingers import IndividualHandEnv
from scipy.spatial.transform import Rotation


def targets(env: ObservedHandEnv) -> dict[str, float]:
    """Read commanded angles through the public observation API."""
    return {
        name: joint["target_rad"]
        for name, joint in env.get_hand_state()["joints"].items()
    }


def assert_targets(env: ObservedHandEnv, expected: dict[str, float]) -> None:
    actual = targets(env)
    assert actual.keys() == expected.keys()
    np.testing.assert_allclose(
        [actual[name] for name in expected],
        list(expected.values()),
        atol=1e-10,
        rtol=0,
    )


def check(fixture: Path, output: Path) -> dict[str, bool | int | float]:
    fixed_output, finger_output = output / "fixed", output / "fingers"
    fixed_output.mkdir()
    finger_output.mkdir()
    fixed = ObservedHandEnv(fixture, "hammer", fixed_output, seed=0)
    fingers = IndividualHandEnv(fixture, "hammer", finger_output, seed=0)
    initial = fingers.get_hand_state()
    assert fixed.get_hand_state() == initial
    assert len(initial["joints"]) == 16

    for direction in ([0, 0, 1], [0, 0, -1], [1, 0, 0], [1, 2, 3]):
        rotation = Rotation.from_quat(vec2quat(direction), scalar_first=True)
        np.testing.assert_allclose(
            rotation.as_matrix()[:, 2],
            np.asarray(direction) / np.linalg.norm(direction),
            atol=1e-6,
        )

    before = targets(fingers)
    selected = "finger_0.middle"
    angle = before[selected] + 0.15
    fingers.set_hand_joint_targets({selected: angle})
    expected = before | {selected: angle}
    assert_targets(fingers, expected)
    achieved = fingers.get_hand_state()["joints"][selected]["angle_rad"]
    assert abs(achieved - initial["joints"][selected]["angle_rad"]) > 0.01

    start = fingers.get_ee_pos().copy()
    pose = np.r_[start + [0.015, 0, 0], fingers.get_ee_quat()]
    fingers.move_to_pose(pose)
    assert_targets(fingers, expected)
    arm_displacement = float(np.linalg.norm(fingers.get_ee_pos() - start))
    assert arm_displacement > 0.003

    fingers.open_gripper()
    assert_targets(fingers, before)
    fingers.close_gripper()
    assert_targets(fingers, expected)

    simulation_time = fingers.data.time
    positions = fingers.data.qpos.copy()
    with patch.object(
        fingers, "close_gripper", side_effect=ValueError("Arm IK did not converge")
    ):
        try:
            fingers.set_hand_joint_targets({selected: angle + 0.01})
        except ValueError as error:
            assert "Arm IK" in str(error)
        else:
            raise AssertionError("Rejected IK was accepted")
    assert fingers.data.time == simulation_time
    np.testing.assert_array_equal(fingers.data.qpos, positions)
    assert_targets(fingers, expected)
    fingers.open_gripper()
    fingers.close_gripper()
    assert_targets(fingers, expected)

    # A valid entry before an invalid one must not cause a partial command.
    limit = initial["joints"]["thumb.distal"]["upper_rad"]
    invalid_requests = (
        {selected: angle + 0.01, "thumb.distal": limit + 1},
        {selected: float("nan")},
        {"unknown_joint": 0.1},
    )
    for request in invalid_requests:
        simulation_time = fingers.data.time
        positions = fingers.data.qpos.copy()
        velocities = fingers.data.qvel.copy()
        controls = fingers.data.ctrl.copy()
        try:
            fingers.set_hand_joint_targets(request)
        except (ValueError, KeyError):
            pass
        else:
            raise AssertionError(f"Invalid joint command was accepted: {request}")
        assert fingers.data.time == simulation_time
        np.testing.assert_array_equal(fingers.data.qpos, positions)
        np.testing.assert_array_equal(fingers.data.qvel, velocities)
        np.testing.assert_array_equal(fingers.data.ctrl, controls)
        assert_targets(fingers, expected)

    # Rejected requests must not alter the posture restored by a later close.
    fingers.open_gripper()
    fingers.close_gripper()
    assert_targets(fingers, expected)
    return {
        "shared_initial_observation": True,
        "joint_count": len(initial["joints"]),
        "quaternion_axes_verified": 4,
        "partial_command_preserves_other_targets": True,
        "selected_joint_moves_in_physics": True,
        "cartesian_motion_preserves_custom_posture": True,
        "arm_displacement_m": arm_displacement,
        "open_close_restores_custom_posture": True,
        "invalid_requests_rejected_without_motion": len(invalid_requests),
        "invalid_requests_preserve_saved_posture": True,
        "ik_rejection_preserves_current_and_saved_posture": True,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixture", type=Path, required=True)
    args = parser.parse_args()
    fixture = args.fixture.resolve()
    with TemporaryDirectory(prefix="hand-interface-check-", dir=fixture.parent) as tmp:
        result = check(fixture, Path(tmp))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

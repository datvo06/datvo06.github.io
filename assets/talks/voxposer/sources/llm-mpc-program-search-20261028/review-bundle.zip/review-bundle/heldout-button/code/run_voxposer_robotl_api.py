"""Fixed-closure control with measured hand state and a quaternion helper."""

import hashlib
import json
from pathlib import Path

import numpy as np
import run_voxposer_robotl
from LMP import LMP
from run_voxposer_robotl import RoboTLEnv, main
from utils import pointat2quat

HAND_CONTEXT = """
This robot has a Panda arm and a LEAP hand, not a two-finger parallel gripper.
get_hand_state() returns a dictionary with 'joints', 'digits', and 'palm'.
Each joints[name] entry contains angle_rad, target_rad, lower_rad, upper_rad,
and actuator. The 16 names are finger_0, finger_1, finger_2 and thumb, each
followed by .proximal, .lateral, .middle or .distal. Finger numbers follow
their geometric order on the palm. Proximal bends at the palm, middle and
distal bend farther along the digit. Finger lateral joints spread sideways;
the thumb lateral joint twists. Positive bending closes toward the palm.
digits[name]['pad_position_world_m'] is the current fingertip position in metres.
palm contains position_world_m and quaternion_wxyz. All these are measured
states; queries do not move the robot. They are dictionaries, not attributes
of detect() observations. Do not assume other object attributes are present.
vec2quat(direction) is an alias of the existing pointat2quat(direction).
It returns a wxyz quaternion whose local +z axis points along the given
nonzero world direction. Roll follows the existing pointat2quat construction;
it is not an object-axis transform or a command to turn an object.
The ordinary VoxPoser execute() and gripper-map interfaces remain available.
Use only the listed APIs and the functions shown in the original examples.
""".strip()


def vec2quat(direction) -> np.ndarray:
    """Use upstream's local-z pointing convention, accepting a Python list."""
    direction = np.asarray(direction, dtype=float)
    if (
        direction.shape != (3,)
        or not np.isfinite(direction).all()
        or np.linalg.norm(direction) == 0
    ):
        raise ValueError(
            "vec2quat requires a finite, nonzero world direction of length 3"
        )
    return pointat2quat(direction)


class ObservedHandEnv(RoboTLEnv):
    """Keep scalar closure while exposing the same measured hand data as B."""

    def __init__(self, fixture: Path, task: str, output: Path, seed: int):
        super().__init__(fixture, task, output, seed)
        self.output = output
        self.hand_api_calls: list[dict] = []
        self.joint_ids = {
            f"{name}.{role}": getattr(digit.servos, role)
            for name, digit in zip(
                ["finger_0", "finger_1", "finger_2", "thumb"],
                self.ids.digits,
                strict=True,
            )
            for role in ("proximal", "lateral", "middle", "distal")
        }

    def hand_state(self) -> dict:
        """Current kinematic state and actuator-supported angle bounds."""
        joints = {}
        for name, actuator in self.joint_ids.items():
            joint = self.episode.joints[actuator]
            gear = self.episode.gear[actuator]
            ctrl_lower, ctrl_upper = sorted(
                self.model.actuator_ctrlrange[actuator] / gear
            )
            lower, upper = self.model.jnt_range[joint]
            joints[name] = dict(
                actuator=self.model.actuator(actuator).name,
                angle_rad=float(self.data.qpos[self.episode.qadr[actuator]]),
                target_rad=float(self.data.ctrl[actuator] / gear),
                lower_rad=float(max(lower, ctrl_lower)),
                upper_rad=float(min(upper, ctrl_upper)),
            )
        return dict(
            joints=joints,
            digits={
                name: {"pad_position_world_m": digit.point.position(self.data).tolist()}
                for name, digit in zip(
                    ["finger_0", "finger_1", "finger_2", "thumb"],
                    self.ids.digits,
                    strict=True,
                )
            },
            palm=dict(
                position_world_m=self.data.site_xpos[self.ids.palm].tolist(),
                quaternion_wxyz=self.get_ee_quat().tolist(),
            ),
        )

    def record_hand_call(self, record: dict) -> None:
        self.hand_api_calls.append({"time_s": float(self.data.time), **record})
        (self.output / "hand-api-calls.json").write_text(
            json.dumps(self.hand_api_calls, indent=2)
        )

    def get_hand_state(self) -> dict:
        state = self.hand_state()
        self.record_hand_call({"api": "get_hand_state", "state": state})
        return state

    def configure_lmps(self, lmps: dict[str, LMP]) -> None:
        (self.output / "adapter-source.txt").write_text(
            Path(run_voxposer_robotl.__file__).read_text()
        )
        (self.output / "api-source.txt").write_text(Path(__file__).read_text())
        context = (
            HAND_CONTEXT
            + "\nInitial measured hand state:\n"
            + json.dumps(self.hand_state())
        )
        (self.output / "hand-interface-prompt.txt").write_text(context + "\n")
        for lmp in lmps.values():
            lmp._variable_vars.update(
                get_hand_state=self.get_hand_state, vec2quat=vec2quat
            )
            lmp._base_prompt += "\n\n" + context

    def metadata(self) -> dict:
        return dict(
            variant="api-repair-fixed-closure",
            api_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            hand_context=HAND_CONTEXT,
            hand_initial_state=self.hand_state(),
            vec2quat_semantics="Upstream pointat2quat: local +z along world direction, wxyz",
            shared_backend_limits=[
                "IK convergence and pose checks; no collision or dynamic feasibility screening",
                "No MPC rollouts or proposal ranking",
                "Native validator measures physical violations but does not filter actions",
                "Final pose must hold 5 seconds with >=3cm clearance; task prompt requests 6cm",
                "Program completion adds 5.1 seconds at last servo targets; errors stop immediately",
            ],
        )


if __name__ == "__main__":
    main(ObservedHandEnv)

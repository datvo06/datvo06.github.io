# Focused scientific review

Three reviewers examined the implementation and retained pilot evidence: the parent reviewer, the native/runtime reviewer, and the program-boundary/selection reviewer. Their implementation reviews covered native acceptance ownership, typed request parsing, isolated state reconstruction, budgets and failure accounting, training-only feedback, resume behavior, and frozen held-out lifecycle ownership. Blocking findings were corrected before the corresponding commits were presented.

For the private report draft, the parent approved the static scientific claims. The boundary reviewer checked all 11 submitted source hashes, all report links, the four selected video/program pairs, the 32 case attempts, the 3/4 versus 2/4 button comparison, and probe exclusions. The native reviewer compared all 32 case summaries with retained native-any, raw-final, executed-step and simulator-count evidence, and checked the frozen transport measurements.

The report now includes the native reviewer's requested proximity-attachment limitation and exact partial-step accounting reconciliation. It also includes a verbatim generated cost branch and labels the component timing as a double evaluation. The native reviewer approved the corrected training/runtime/transport/provenance claims.

After held-out completion, all three reviewers independently verified the eight case rows, exact source hashes, native-any/raw-final/primary distinctions, and 634,306 fully confirmed simulator steps. The parent also independently verified all 12 videos at 640 by 640 pixels with frame counts matching executed steps. All three approved the final scientific report; identical reference/improvement aliases represent eight physical episodes, not sixteen.

"""Sensor definitions for RoboTL components.

This module defines various sensor types that can observe component states.
"""

import abc
import dataclasses
from enum import Enum
from typing import TYPE_CHECKING, Any, cast, get_args

import jax
from effectful.ops.syntax import defdata, defop
from effectful.ops.types import NotHandled, Term

if TYPE_CHECKING:
    from robotl.ops import actuators, joints
    from robotl.ops.syntax import Component
from robotl.ops.coords import (
    Coordinate,
    CoordinateTangent,
    Displacement,
    DisplacementTangent,
    RawCoordinate,
    Rotation,
    RotationTangent,
    ScalarDisplacement,
    ScalarForce,
    ScalarTorque,
)
from robotl.ops.id import Id, make_id

type SensorValue = Coordinate | CoordinateTangent | ScalarTorque | ScalarForce


def _refine[T](value, ty: type[T]) -> T:
    """Narrow *value* to *ty*: assert concrete values, retype symbolic terms."""
    if isinstance(value, Term):
        return defdata.dispatch(ty)(ty, value.op, *value.args, **value.kwargs)
    assert isinstance(value, ty), (value, ty)
    return value


class Sensor[V: SensorValue](abc.ABC):
    id: Id

    @property
    @abc.abstractmethod
    def quantity(self) -> type[V]:
        """Sensor value type."""

    # effectful cannot type terms by a union like SensorValue, so the op is
    # typed `object` and `get` narrows it via `quantity`
    @defop
    def _get(self) -> object:
        raise NotHandled

    def get(self) -> V:
        return _refine(self._get(), self.quantity)


@dataclasses.dataclass
class Position[Q: Coordinate](Sensor[Q]):
    joint: "joints.DofJoint[Q, Any]"
    id: Id = dataclasses.field(default_factory=make_id)

    @property
    def quantity(self) -> type[Q]:
        return self.joint.q_type


@dataclasses.dataclass
class Velocity[DQ: CoordinateTangent](Sensor[DQ]):
    joint: "joints.DofJoint[Any, DQ]"
    id: Id = dataclasses.field(default_factory=make_id)

    @property
    def quantity(self) -> type[DQ]:
        return self.joint.dq_type


@dataclasses.dataclass
class ActuatorFrc[F: ScalarTorque | ScalarForce](Sensor[F]):
    actuator: "actuators.Actuator[Any, Any, F]"
    id: Id = dataclasses.field(default_factory=make_id)

    @property
    def quantity(self) -> type[F]:
        return self.actuator.target.frc_type


@dataclasses.dataclass
class ActuatorVel[DQ: CoordinateTangent](Sensor[DQ]):
    actuator: "actuators.Actuator[Any, DQ, Any]"
    id: Id = dataclasses.field(default_factory=make_id)

    @property
    def quantity(self) -> type[DQ]:
        return self.actuator.target.dq_type


@dataclasses.dataclass
class MinimumContactDistance(Sensor[ScalarDisplacement]):
    """Smallest signed contact distance across the native scene, in metres.

    Returns zero when no contacts exist. Negative distance is penetration.
    Native reduction examines all contacts, with no fixed-capacity truncation.
    """

    id: Id = dataclasses.field(default_factory=make_id)

    @property
    def quantity(self) -> type[ScalarDisplacement]:
        return ScalarDisplacement


class ContactField(Enum):
    """Native contact payload fields in their packed order."""

    FOUND = 1
    FORCE = 2
    DISTANCE = 8
    POSITION = 16
    NORMAL = 32

    @property
    def width(self) -> int:
        return 3 if self in (self.FORCE, self.POSITION, self.NORMAL) else 1


DEFAULT_CONTACT_FIELDS = frozenset(
    {ContactField.FOUND, ContactField.FORCE, ContactField.DISTANCE}
)


class Contact(Sensor[RawCoordinate]):
    """Fixed-capacity native contacts between two component bodies.

    By default each slot contains ``[found, normal_force, tangent_force_1,
    tangent_force_2, distance]``. ``found`` is zero for empty slots and
    otherwise the total number of matching contacts, repeated in each
    occupied slot. Consumers must check that this total does not exceed
    ``capacity`` before reducing the per-contact readings.

    :param first: First body participating in the contact.
    :param second: Second body participating in the contact.
    :param capacity: Number of contact slots; native compilation requires
        a positive value.
    :param fields: Native payload fields, packed in ContactField order.

    Readings are a flat :class:`~robotl.ops.coords.RawCoordinate` of length
    ``slot_width * capacity`` (five values per slot by default).
    Position and normal are world-frame vectors; reversing the body pair
    reverses the normal. Verified with native MuJoCo 3.8.1; MJX body-body
    matching is not supported.
    """

    first_id: Id
    second_id: Id
    capacity: int
    fields: frozenset[ContactField]

    def __init__(
        self,
        first: "Component",
        second: "Component",
        capacity: int,
        *,
        fields: frozenset[ContactField] = DEFAULT_CONTACT_FIELDS,
    ) -> None:
        # A sensor can target its owner. Keep body IDs, not recursive component
        # graphs, opaque to symbolic expression and shape analysis.
        self.first_id = first.id
        self.second_id = second.id
        self.capacity = capacity
        self.fields = fields
        self.id = make_id()

    @property
    def mask(self) -> int:
        return sum(field.value for field in ContactField if field in self.fields)

    @property
    def slot_width(self) -> int:
        return sum(field.width for field in ContactField if field in self.fields)

    def field(self, field: ContactField) -> jax.Array:
        """Read one selected field across all contact slots."""
        offset = 0
        for selected in ContactField:
            if selected in self.fields:
                if selected is field:
                    return self.get().x.reshape(self.capacity, self.slot_width)[
                        :, offset : offset + selected.width
                    ]
                offset += selected.width
        raise ValueError(f"Contact field {field.name} was not selected")

    @property
    def quantity(self) -> type[RawCoordinate]:
        return RawCoordinate


def subtree_contact_sensors(
    component1: "Component",
    component2: "Component",
    *,
    capacity: int = 8,
    fields: frozenset[ContactField] = DEFAULT_CONTACT_FIELDS,
) -> list[Contact]:
    """Create body-pair sensors across two RoboTL component graphs.

    Each component and its logical children are included once, excluding
    ports. Mechanical joint connections do not extend either selection.
    The returned sensors must be stored on a component to be compiled.

    :param component1: Root of the first logical component graph.
    :param component2: Root of the second logical component graph.
    :param capacity: Contact slots per body pair.
    :param fields: Native fields selected for each pair.
    :returns: One native body-body sensor per distinct unordered body pair.
    """
    pairs: dict[frozenset[Id], Contact] = {}
    second_bodies = list(component2.components())
    for first in component1.components():
        for second in second_bodies:
            key = frozenset((first.id, second.id))
            if first.id != second.id and key not in pairs:
                pairs[key] = Contact(first, second, capacity, fields=fields)
    return list(pairs.values())


@dataclasses.dataclass
class FrameSensor[V: SensorValue](Sensor[V]):
    id: Id = dataclasses.field(default_factory=make_id)


class FrameLinPos(FrameSensor[Displacement]):
    @property
    def quantity(self) -> type[Displacement]:
        return Displacement


class FrameAngPos(FrameSensor[Rotation]):
    @property
    def quantity(self) -> type[Rotation]:
        return Rotation


class FrameLinVel(FrameSensor[DisplacementTangent]):
    @property
    def quantity(self) -> type[DisplacementTangent]:
        return DisplacementTangent


class FrameAngVel(FrameSensor[RotationTangent]):
    @property
    def quantity(self) -> type[RotationTangent]:
        return RotationTangent


_SENSOR_VALUE_TYPES = get_args(SensorValue.__value__)


# eq=False: ``expr`` holds a graph, so instances hash by identity
@dataclasses.dataclass(eq=False)
class Virtual[V: SensorValue](Sensor[V]):
    """A typed expression recomputed from sensor reads in the current state."""

    expr: V
    id: Id = dataclasses.field(default_factory=make_id)

    def __post_init__(self):
        ty = self.quantity
        if not issubclass(ty, _SENSOR_VALUE_TYPES):
            raise TypeError(
                f"Virtual expression must be a typed quantity, got {ty!r}: wrap "
                "it in a Coordinate, CoordinateTangent or scalar box; read sensors "
                "outside an interpretation rather than passing a closure, "
                "e.g. Virtual(Angle(2.0 * self.angle.get().theta)) or "
                "Virtual(RawCoordinate(latent))"
            )

    @property
    def quantity(self) -> type[V]:
        cls = type(self.expr)
        if isinstance(self.expr, Term):
            # a typed term is an ``_XTerm(Term, X)``: recover ``X`` from the
            # bases (``typeof`` would report the op's declared ``object``)
            for base in cls.__mro__:
                if not issubclass(base, Term) and issubclass(base, _SENSOR_VALUE_TYPES):
                    return cast(type[V], base)
        return cast(type[V], cls)  # untyped terms are rejected by __post_init__


class FrameLinAcc(FrameSensor[DisplacementTangent]):
    @property
    def quantity(self) -> type[DisplacementTangent]:
        return DisplacementTangent


class FrameAngAcc(FrameSensor[RotationTangent]):
    @property
    def quantity(self) -> type[RotationTangent]:
        return RotationTangent

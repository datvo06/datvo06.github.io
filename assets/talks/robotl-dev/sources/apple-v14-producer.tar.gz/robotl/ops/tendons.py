"""Tendon definitions for RoboTL components."""

import dataclasses
from collections.abc import Sequence

import jax

from robotl.ops import shapes
from robotl.ops.actuators import Actuatable
from robotl.ops.coords import (
    ScalarDisplacement,
    ScalarDisplacementTangent,
    ScalarForce,
)
from robotl.ops.id import NULL_ID, Id, make_id
from robotl.ops.joints import Joint
from robotl.ops.syntax import LegacyComponent, Port, Pose


class TendonPulley(LegacyComponent):
    """Simple wrap geometry (cylinder) with a stable geom identity."""

    def __init__(self, radius: float = 0.03, thickness: float = 0.01):
        super().__init__(name="TendonPulley")
        self.shape = shapes.cylinder(r=radius, h=thickness)
        # disable collision for MJX as it doesn't support cylinder collisions
        self.disable_collision = True
        self.base = self.place(Port())
        self.side = self.place(Port(), Pose(pos=[radius, 0, thickness / 2]))


def _require_port(p, label: str):
    if not isinstance(p, Port):
        raise TypeError(f"tendon path must use ports; got {label}={p!r}")


@dataclasses.dataclass(kw_only=True)
class Tendon:
    """Base class for all tendons."""

    stiffness: jax.typing.ArrayLike = 0
    limit_stiffness: jax.typing.ArrayLike = 0
    damping: jax.typing.ArrayLike = 0
    rest_length: (
        jax.typing.ArrayLike | tuple[jax.typing.ArrayLike, jax.typing.ArrayLike]
    ) = 0
    """A scalar spring rest length, or two endpoints of a force-free deadband."""
    offset: jax.typing.ArrayLike = 0
    range: None | tuple[jax.typing.ArrayLike, jax.typing.ArrayLike] = None
    id: Id = NULL_ID

    def __post_init__(self):
        if self.id == NULL_ID:
            self.id = make_id()


@dataclasses.dataclass
class SpatialTendon(
    Tendon, Actuatable[ScalarDisplacement, ScalarDisplacementTangent, ScalarForce]
):
    """Spatial tendon routed over sites and wrap geoms.

    An actuator on a spatial tendon drives its length: the cable's length is a
    :class:`~robotl.ops.coords.ScalarDisplacement`, its rate a
    :class:`~robotl.ops.coords.ScalarDisplacementTangent` and the pull a
    :class:`~robotl.ops.coords.ScalarForce`.

    Args:
        path: Routing entries; first/last must be Port sites. Use TendonPulley
            for wrap segments.
        stiffness: Spring stiffness driving the tendon toward rest_length.
    """

    q_type, dq_type, frc_type = (
        ScalarDisplacement,
        ScalarDisplacementTangent,
        ScalarForce,
    )

    path: Sequence[Port | TendonPulley]
    width: jax.typing.ArrayLike | None = None
    color: Sequence[float] | None = None

    def __post_init__(self):
        needs_init = self.id == NULL_ID
        super().__post_init__()
        if needs_init:
            if len(self.path) < 2:
                raise ValueError("tendon path must contain at least two entries")
            _require_port(self.path[0], "path[0]")
            _require_port(self.path[-1], "path[-1]")
            for entry in self.path:
                if not isinstance(entry, (Port, TendonPulley)):
                    raise TypeError("tendon path entries must be Port or TendonPulley")


@dataclasses.dataclass
class FixedTendon(Tendon):
    """Fixed tendon that couples joint positions directly (no spatial routing).

    Args:
        joints: Ordered joints to couple.
        gear_ratios: Per-joint coefficients (defaults to 1.0).
        stiffness: Spring stiffness driving the tendon toward rest_length.
    """

    joints: Sequence[Joint]
    gear_ratios: Sequence[jax.typing.ArrayLike] | None = None

    def __post_init__(self):
        needs_init = self.id == NULL_ID
        super().__post_init__()
        if needs_init:
            if len(self.joints) == 0:
                raise ValueError("fixed tendon must reference at least one joint")
            if self.gear_ratios is None:
                self.gear_ratios = [1.0 for _ in self.joints]
            if len(self.gear_ratios) != len(self.joints):
                raise ValueError("gear_ratios must match joints length")

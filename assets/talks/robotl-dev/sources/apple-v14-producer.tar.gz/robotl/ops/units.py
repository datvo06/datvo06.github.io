"""Unit-carrying parameter annotations.

Explicit units everywhere: the ``Annotated`` aliases accept quantities only
— a bare float fails validation; :func:`mm` and :func:`deg` are how authors
make quantities. Each alias checks dimension (any convertible unit is
accepted and stored as written) and range/shape; consumption converts once
at the geometry boundary via ``.to("m")`` / ``.to("rad")``.
"""

from collections.abc import Callable
from typing import Annotated

import effectful.handlers.jax.numpy as jnp
import unxt
from pydantic import AfterValidator


def mm(v) -> unxt.AbstractQuantity:
    """Millimetre quantity; floats and arrays are taken as millimetres."""
    return (
        v.to("mm") if isinstance(v, unxt.AbstractQuantity) else unxt.Quantity(v, "mm")
    )


def deg(v) -> unxt.AbstractQuantity:
    """Degree quantity; floats and arrays are taken as degrees."""
    return (
        v.to("deg") if isinstance(v, unxt.AbstractQuantity) else unxt.Quantity(v, "deg")
    )


def newton(v) -> unxt.AbstractQuantity:
    """Newton quantity; floats and arrays are taken as newtons."""
    return v.to("N") if isinstance(v, unxt.AbstractQuantity) else unxt.Quantity(v, "N")


def kg(v) -> unxt.AbstractQuantity:
    """Kilogram quantity; floats and arrays are taken as kilograms."""
    return (
        v.to("kg") if isinstance(v, unxt.AbstractQuantity) else unxt.Quantity(v, "kg")
    )


def newton_meter(v) -> unxt.AbstractQuantity:
    """Torque quantity; floats and arrays are taken as newton metres."""
    return (
        v.to("N m") if isinstance(v, unxt.AbstractQuantity) else unxt.Quantity(v, "N m")
    )


def volt(v) -> unxt.AbstractQuantity:
    """Voltage quantity; floats and arrays are taken as volts."""
    return v.to("V") if isinstance(v, unxt.AbstractQuantity) else unxt.Quantity(v, "V")


def rpm(v) -> unxt.AbstractQuantity:
    """Angular speed quantity; floats and arrays are taken as revolutions per minute."""
    return (
        v.to("cycle/min")
        if isinstance(v, unxt.AbstractQuantity)
        else unxt.Quantity(v, "cycle/min")
    )


def _length_dim(q: unxt.AbstractQuantity) -> unxt.AbstractQuantity:
    q.to("mm")  # raises UnitConversionError on wrong dimension
    return q  # not canonicalized: the original unit survives


def _angle_dim(q: unxt.AbstractQuantity) -> unxt.AbstractQuantity:
    q.to("deg")
    return q


def _force_dim(q: unxt.AbstractQuantity) -> unxt.AbstractQuantity:
    q.to("N")
    return q


def _positive(q: unxt.AbstractQuantity) -> unxt.AbstractQuantity:
    if not bool(jnp.all(q.value > 0)):
        raise ValueError(f"must be positive, got {q}")
    return q


def _nonnegative(q: unxt.AbstractQuantity) -> unxt.AbstractQuantity:
    if not bool(jnp.all(q.value >= 0)):
        raise ValueError(f"must be nonnegative, got {q}")
    return q


def _n_by_3(q: unxt.AbstractQuantity) -> unxt.AbstractQuantity:
    if (
        q.value.ndim != 2
        or q.value.shape[1] != 3
        or not bool(jnp.isfinite(jnp.asarray(q.value)).all())
    ):
        raise ValueError(f"expected a finite (n, 3) array, got shape {q.value.shape}")
    return q


def _unit_interval(v: float) -> float:
    if not 0 < v <= 1:
        raise ValueError(f"must be in (0, 1], got {v}")
    return v


def _torque_dim(q: unxt.AbstractQuantity) -> unxt.AbstractQuantity:
    q.to("N m")
    return q


def _voltage_dim(q: unxt.AbstractQuantity) -> unxt.AbstractQuantity:
    q.to("V")
    return q


def _finite_scalar(q: unxt.AbstractQuantity) -> unxt.AbstractQuantity:
    value = jnp.asarray(q.value)
    if value.ndim != 0 or not bool(jnp.isfinite(value)):
        raise ValueError(f"expected a finite scalar, got {q}")
    return q


def _angular_speed_dim(q: unxt.AbstractQuantity) -> unxt.AbstractQuantity:
    q.to("rad/s")
    return q


def within(
    lo: unxt.AbstractQuantity, hi: unxt.AbstractQuantity, why: str
) -> Callable[[unxt.AbstractQuantity], unxt.AbstractQuantity]:
    """A range check for ``AfterValidator``: the quantity, converted to
    ``lo``'s unit, must lie in ``[lo, hi]``; ``why`` is the reason the bound
    exists and goes into the error."""

    def check(q: unxt.AbstractQuantity) -> unxt.AbstractQuantity:
        v = float(q.to(lo.unit).value)
        if not float(lo.value) <= v <= float(hi.to(lo.unit).value):
            raise ValueError(f"{q} is outside [{lo}, {hi}]: {why}")
        return q

    return check


Mm = Annotated[
    unxt.AbstractQuantity, AfterValidator(_length_dim), AfterValidator(_positive)
]
MmOrOff = Annotated[
    unxt.AbstractQuantity, AfterValidator(_length_dim), AfterValidator(_nonnegative)
]
Unit = Annotated[float, AfterValidator(_unit_interval)]
Deg = Annotated[
    unxt.AbstractQuantity, AfterValidator(_angle_dim), AfterValidator(_positive)
]
N = Annotated[
    unxt.AbstractQuantity, AfterValidator(_force_dim), AfterValidator(_positive)
]
PlacementMm = Annotated[
    unxt.AbstractQuantity, AfterValidator(_length_dim), AfterValidator(_n_by_3)
]
PlacementDeg = Annotated[
    unxt.AbstractQuantity, AfterValidator(_angle_dim), AfterValidator(_n_by_3)
]
NewtonMeter = Annotated[
    unxt.AbstractQuantity,
    AfterValidator(_torque_dim),
    AfterValidator(_finite_scalar),
    AfterValidator(_positive),
]
Volt = Annotated[
    unxt.AbstractQuantity, AfterValidator(_voltage_dim), AfterValidator(_positive)
]
RadPerS = Annotated[
    unxt.AbstractQuantity,
    AfterValidator(_angular_speed_dim),
    AfterValidator(_finite_scalar),
    AfterValidator(_positive),
]

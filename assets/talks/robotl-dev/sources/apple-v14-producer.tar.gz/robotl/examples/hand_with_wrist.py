from effectful.handlers.jax import numpy as jnp

from robotl.ops import actuators, joints, shapes
from robotl.ops.coords import Pose
from robotl.ops.syntax import Component, Port, defcomponent

X, Y, Z = jnp.eye(3)


@defcomponent
def Wrist(self, size=0.03):
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, size]))
    self.shape = shapes.transform(
        shapes.cylinder(r=size / 2, h=size),
        Pose(pos=[0, size / 2, size / 4], rv=jnp.pi / 2 * X),
    )


@defcomponent
def HandWithWrist(self, hand: Component, size=0.03):
    self.base = self.place(Port())
    self.wrist = Wrist(size)
    self.hand = hand
    self.joints = [
        joints.Hinge(
            self.base,
            self.wrist.base,
            axis=X,
            range=(-jnp.pi / 4, jnp.pi / 4),
            damping=0.5,
            armature=0.0002,
        ),
        joints.Hinge(
            self.wrist.tip,
            self.hand.base,
            axis=Y,
            range=(-jnp.pi / 4, jnp.pi / 4),
            damping=0.5,
            armature=0.0002,
        ),
    ]
    self.actuators = [
        actuators.Position(j, forcerange=(-10, 10), kp=10, ctrlrange=j.range)
        for j in self.joints
    ]
    self.fingertips = self.hand.fingertips
    self.tip = self.hand.tip

"""Install the pinned Panda arm meshes used by robotl.examples.panda.

The CLI and Panda test fixture share one checksum-verified installer.
"""

import json
import shutil
from hashlib import sha256
from pathlib import Path
from tempfile import NamedTemporaryFile
from urllib.request import urlopen

from robotl.examples.panda import MESH_FILES, meshes

REVISION = "14ceccf557cc47240202f2354d684eca58ff8de4"
BASE_URL = (
    "https://raw.githubusercontent.com/google-deepmind/mujoco_menagerie/"
    f"{REVISION}/franka_emika_panda/assets"
)
MESH_DIRECTORY = Path(meshes["link0_c"]).parent


def install_panda_meshes(
    output: Path,
    source: Path | None = None,
    force: bool = False,
) -> None:
    """Install and verify assets, preserving verified cached files for offline use."""
    hashes: dict[str, str] = json.loads(
        (MESH_DIRECTORY.parent / "mesh_checksums.json").read_text()
    )
    output.mkdir(parents=True, exist_ok=True)

    def verify(path: Path, file: str) -> None:
        if sha256(path.read_bytes()).hexdigest() != hashes[file]:
            raise ValueError(f"Panda mesh checksum mismatch: {path}")

    for file in MESH_FILES:
        destination = output / file
        if destination.exists() and not force:
            verify(destination, file)
            continue
        # Concurrent callers publish only complete, verified meshes.
        with NamedTemporaryFile(dir=output, delete=False) as temporary_stream:
            temporary = Path(temporary_stream.name)
        try:
            if source:
                shutil.copyfile(source / file, temporary)
            else:
                with urlopen(f"{BASE_URL}/{file}", timeout=60) as response:
                    with temporary.open("wb") as stream:
                        shutil.copyfileobj(response, stream)
            verify(temporary, file)
            temporary.replace(destination)
        finally:
            temporary.unlink(missing_ok=True)

"""Panda arm with a centered, downward-facing LEAP hand.

Run ``python -m robotl.examples.panda_leap`` to open the MuJoCo viewer.
The mount aligns the palm visual bounding box's proximal face center with the
flange, with a 5 mm gap. Adapter geometry and inertia are not modeled.
"""

from dataclasses import dataclass
from math import pi
from pathlib import Path
from typing import Self

import jax
import jax.numpy as jnp
import mujoco
import mujoco.viewer

from robotl.examples.based import Based
from robotl.examples.leap_hand_menagerie import LeapHandConfig, ParameterizedLeapHand
from robotl.examples.panda import PandaArm
from robotl.handlers.mujoco import compile_model
from robotl.handlers.mujoco.config import MujocoSettings
from robotl.handlers.mujoco.mappings import Layout
from robotl.ops import joints
from robotl.ops.coords import Angle
from robotl.ops.syntax import (
    Component,
    LegacyComponent,
    Port,
    Pose,
    assert_transform,
    frame,
)


@dataclass(eq=False, kw_only=True)
class PandaLeapHand(Component):
    """Rigid assembly with the LEAP finger direction along the flange's +Z axis."""

    arm: PandaArm
    hand: LegacyComponent
    base: Port
    mount: joints.Weld
    arm_anchor: joints.Weld

    @classmethod
    def make(cls, hand_config: LeapHandConfig | None = None) -> Self:
        """Build the stock arm and hand with a centered visual mounting pose."""
        with frame() as pose:
            arm = PandaArm.make()
            hand = ParameterizedLeapHand(config=hand_config)
            base = Port()
            assembly = cls(
                pose=pose,
                arm=arm,
                hand=hand,
                base=base,
                mount=joints.Weld(arm.tip, hand.palm.mount, Pose(pos=[0, 0, 0.005])),
                arm_anchor=joints.Weld(base, arm.base),
            )
            assert_transform(assembly, base)
        return assembly


def main() -> None:
    """Open the assembly at the Panda home pose, with fingers pointing down."""
    with jax.enable_x64():
        settings = MujocoSettings.standard()
        assembly, context, physics = compile_model(
            lambda: Based.make(PandaLeapHand.make()),
            build_path=Path("build/panda_leap"),
            settings=settings,
        )
        settings.apply(physics)
        data = mujoco.MjData(physics)
        layout = Layout.make(physics, context)
        set_home(assembly.c.arm, layout, data)
        mujoco.mj_forward(physics, data)
        mujoco.viewer.launch(physics, data)


def set_home(arm: PandaArm, layout: Layout, data: mujoco.MjData) -> None:
    """Set the arm's home joint angles and servo targets through the layout."""
    q = layout.qv.q.unpack(jnp.asarray(data.qpos))
    u = layout.u.unpack(jnp.asarray(data.ctrl))
    home = (0, -pi / 4, 0, -3 * pi / 4, 0, pi / 2, pi / 4)
    for hinge, actuator, angle in zip(
        arm.hinges, arm.hinge_actuators, home, strict=True
    ):
        q.parts[hinge.id] = Angle(jnp.asarray(angle))
        u[actuator.id] = Angle(jnp.asarray(angle))
    data.qpos[:] = layout.qv.q.pack(q)
    data.ctrl[:] = layout.u.pack(u)


if __name__ == "__main__":
    main()

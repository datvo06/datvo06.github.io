import math
from typing import Annotated, Literal, Self

import effectful.handlers.jax.numpy as jnp
import numpy as np
import pydantic.dataclasses
from pydantic import ConfigDict, Field, validate_call

from robotl.examples.simple_cad import Cylinder
from robotl.handlers.cad.face import face
from robotl.ops import actuators, joints, sensors, shapes
from robotl.ops.coords import Rotation
from robotl.ops.shapes import cube, transform, translate
from robotl.ops.syntax import (
    Component,
    LegacyComponent,
    Material,
    Port,
    Pose,
    assert_transform,
    defcomponent,
    frame,
)
from robotl.ops.units import (
    Mm,
    NewtonMeter,
    RadPerS,
    Volt,
    mm,
    newton_meter,
    rpm,
    volt,
    within,
)

MM_SCALE = 1e-3  # measurements in millimeters, scaled to meters

POS_Z = Rotation.from_euler("x", 0, degrees=True)
NEG_Z = Rotation.from_euler("x", 180, degrees=True)
POS_X = Rotation.from_euler("y", 90, degrees=True)
NEG_X = Rotation.from_euler("y", -90, degrees=True)
POS_Y = Rotation.from_euler("x", 90, degrees=True)
NEG_Y = Rotation.from_euler("x", -90, degrees=True)

# Source: Claude / google
POLYCARBONATE = Material(
    density=1200, friction=0.4, color=jnp.array([0.4, 0.4, 0.4, 1.0])
)

# Source: Website for density / friction from POLYCARBONATE
X330_MATERIAL = Material(
    density=1300, friction=0.4, color=jnp.array([0.4, 0.4, 0.4, 1.0])
)


type X430Model = Literal["XL430-W250", "XM430-W210", "XM430-W350"]

# ROBOTIS e-Manual: voltage (V), momentary stall torque (N m), no-load speed (rpm).
_OPERATING_POINTS: dict[X430Model, tuple[tuple[float, float, float], ...]] = {
    "XL430-W250": ((9, 1.0, 47), (11.1, 1.4, 57), (12, 1.5, 61)),
    "XM430-W210": ((11.1, 2.7, 70), (12, 3.0, 77), (14.8, 3.7, 95)),
    "XM430-W350": ((11.1, 3.8, 43), (12, 4.1, 46), (14.8, 4.8, 57)),
}

# ROBOTIS e-Manual servo masses, in kg.
_MASSES: dict[X430Model, float] = {
    "XL430-W250": 0.0572,
    "XM430-W210": 0.082,
    "XM430-W350": 0.082,
}


@pydantic.dataclasses.dataclass(
    frozen=True, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class DynamixelDrive:
    """Geometry-independent, voltage-limited DC servo approximation.

    The output torque is ``clip(kp * error, +/- PWM * stall) - b * speed``,
    with ``b = stall / free_speed``. Back-EMF is joint damping outside the
    command clamp. Internal servo gearing is already represented by the ROBOTIS
    output-shaft operating points.

    Sources: https://emanual.robotis.com/docs/en/dxl/x/xl430-w250/,
    https://emanual.robotis.com/docs/en/dxl/x/xm430-w210/,
    https://emanual.robotis.com/docs/en/dxl/x/xm430-w350/.

    Stall is not a continuous rating. Gains are assumed SI gains, not firmware
    register values. Current-limited modes, profiles, thermal limits, backlash
    and rotor inertia are not identified.
    """

    stall_torque: NewtonMeter
    free_speed: RadPerS

    @classmethod
    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def at_voltage(cls, model: X430Model, supply: Volt) -> Self:
        """Interpolate within published operating points, without extrapolation."""
        points = np.array(_OPERATING_POINTS[model])
        supply = within(
            volt(points[0, 0]), volt(points[-1, 0]), "datasheet operating points"
        )(supply)
        voltage = float(supply.to("V").value)
        return cls(
            stall_torque=newton_meter(
                float(np.interp(voltage, points[:, 0], points[:, 1]))
            ),
            free_speed=rpm(float(np.interp(voltage, points[:, 0], points[:, 2]))),
        )

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def hinge(
        self,
        fixed: Port,
        moving: Port,
        *,
        rot_range: tuple[float, float],
        pwm_limit: Annotated[float, Field(gt=0, le=1, allow_inf_nan=False)] = 1.0,
        kp: Annotated[float, Field(gt=0, allow_inf_nan=False)] = 3.0,
    ) -> tuple[joints.Hinge, actuators.Position]:
        """Construct an output joint and servo without adding another motor body.

        :param kp: Output-coordinate proportional gain, in N m/rad.
        :param pwm_limit: Available supply-voltage fraction, not a current limit.
        """
        stall = float(self.stall_torque.to("N m").value)
        speed = float(self.free_speed.to("rad/s").value)
        hinge = joints.Hinge(fixed, moving, damping=stall / speed, range=rot_range)
        limit = pwm_limit * stall
        return hinge, actuators.Position(
            hinge, kp=kp, ctrlrange=rot_range, forcerange=(-limit, limit)
        )


@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class X430(Component):
    """XL430-W250 or XM430-W210/W350 with a printed mixer spool.

    The three models share the 28.5 x 46.5 x 34 mm housing envelope; the XL430
    weighs 57.2 g and the XM430s 82 g, with different output-shaft torque/speed
    curves (see :class:`DynamixelDrive`).

    Servo mass is lumped into the housing, whose inertia is a uniform-box
    approximation; spool inertia uses its geometry and an assumed printed-plastic
    density of 1240 kg/m3. The shared envelope does not certify horn,
    bolt-pattern or printed-spool compatibility.
    """

    shape: shapes.Shape
    material: Material
    base: Port
    output_mount: Port
    spool: LegacyComponent
    hinge: joints.Hinge
    actuator: actuators.Position

    @classmethod
    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def make(
        cls,
        *,
        model: X430Model = "XL430-W250",
        supply: Volt = volt(11.1),
        pwm_limit: float = 1.0,
        kp: float = 3.0,
        spool_radius: Mm = mm(21),
        spool_thickness: Mm = mm(6),
        rot_range: tuple[float, float] = (-math.pi, math.pi),
    ) -> Self:
        """Build a housing and one driven spool joint.

        :param model: Published motor model.
        :param supply: Supply voltage; operating points are linearly interpolated.
        :param pwm_limit: Fraction of supply voltage available to the motor.
        :param kp: Assumed proportional position gain, in N m/rad.
        :param spool_radius: Printed spool outer radius.
        :param spool_thickness: Printed spool thickness.
        :param rot_range: Mechanical spool travel, in radians.
        """
        drive = DynamixelDrive.at_voltage(model, supply)
        radius = float(spool_radius.to("m").value)
        thickness = float(spool_thickness.to("m").value)
        dimensions = np.array([28.5, 34.0, 46.5]) * MM_SCALE
        with frame() as pose:
            base, output_mount = Port(), Port()
            spool = Cylinder(d=2 * radius, h=thickness)
            spool.material = Material(density=1240, color=jnp.array([0.2, 0.3, 0.5, 1]))
            spool.disable_collision = True
            hinge, actuator = drive.hinge(
                output_mount,
                spool.base,
                rot_range=rot_range,
                pwm_limit=pwm_limit,
                kp=kp,
            )
            motor = cls(
                pose=pose,
                shape=shapes.centered_cube(*dimensions.tolist()),
                material=Material(
                    density=_MASSES[model] / float(np.prod(dimensions)),
                    color=jnp.array([0.2, 0.2, 0.2, 1]),
                ),
                base=base,
                output_mount=output_mount,
                spool=spool,
                hinge=hinge,
                actuator=actuator,
                disable_collision=True,
            )
            assert_transform(motor, base)
            assert_transform(motor, output_mount, Pose(pos=[0, 0, dimensions[2] / 2]))
        return motor


@defcomponent
def _X330RotAxis(self, axis_width):
    self.base = self.place(Port())
    self.front = self.place(Port(), Pose(pos=[0, -axis_width / 2, 0], rot=NEG_Y))
    self.back = self.place(Port(), Pose(pos=[0, axis_width / 2, 0], rot=POS_Y))


@defcomponent
def X330(
    self,
    damping=0.03,
    frictionloss=0.001,
    kp=3,
    kv=0.11,
    torque_limit: float = 0.28,
    rot_range: tuple[float, float] | None = None,
    initial_rotation: float = 0.0,
):
    """A Dynamixel XC330-M288-T/XL330-M288-T motor.

    :param damping: Joint damping coefficient.
    :param frictionloss: Joint friction loss.
    :param kp: Proportional gain for the position actuator.
    :param kv: Derivative gain for the position actuator. The default is the
        motor's own torque-speed line, stall torque over no-load speed:
        0.93 N m over 8.48 rad/s at 5.0 V, so the servo has nothing left to
        give at free speed.
    :param torque_limit: Bound on the servo torque in both directions, N m.
        The LEAP hand drives its servos in current-based position mode and
        caps the current, 550 mA for the XC330 build in the LEAP Hand API
        (350 mA for the lite build); at the datasheet's 0.517 N m/A that is
        0.28 N m (0.18 for lite). The stall torque, 0.93 N m at 5.0 V, is
        the physical ceiling if the cap is raised. Without a bound, ``kp``
        times the hinge range lets the position loop pull several times
        what the servo can.
    :param rot_range: Tuple of (min, max) rotation limits in radians. Defaults
        to (-2*pi, 2*pi).
    :param initial_rotation: Initial rotation angle in radians. Defaults to 0.
    """
    motor_x_dim = 20
    motor_y_dim = 23
    motor_z_dim = 34
    motor_y_rot_axis_width = 29
    motor_rot_x_offset = motor_x_dim / 2
    motor_rot_z_offset = motor_z_dim - 9.5
    screw_x_dist = 16  # center to center distance
    screw_x_inset = (motor_x_dim - screw_x_dist) / 2  # inset from motor edge
    screw_z_dist = 30  # center to center distance
    screw_z_inset = (motor_z_dim - screw_z_dist) / 2  # inset from motor edge

    self.material = X330_MATERIAL
    self.shape = shapes.scale(
        cube(motor_x_dim, motor_y_dim, motor_z_dim), jnp.full([3], MM_SCALE)
    )

    self.base = self.place(Port())

    self.left = self.place(
        Port(),
        Pose(
            pos=face(self.shape, "-x").center
            + jnp.array([screw_x_inset, 0, 0]) * MM_SCALE,
            rot=NEG_X,
        ),
    )
    self.right = self.place(
        Port(),
        Pose(
            pos=face(self.shape, "+x").center
            - jnp.array([screw_x_inset, 0, 0]) * MM_SCALE,
            rot=POS_X,
        ),
    )
    self.top = self.place(
        Port(),
        Pose(
            pos=face(self.shape, "+z").center
            - jnp.array([0, 0, screw_z_inset]) * MM_SCALE,
            rot=POS_Z,
        ),
    )
    self.bottom = self.place(
        Port(),
        Pose(
            pos=face(self.shape, "-z").center
            + jnp.array([0, 0, screw_z_inset]) * MM_SCALE,
            rot=NEG_Z,
        ),
    )
    self._rot_fixed = self.place(
        Port(),
        Pose(
            pos=jnp.array([motor_rot_x_offset, motor_y_dim / 2, motor_rot_z_offset])
            * MM_SCALE,
            rot=POS_Z,
        ),
    )
    self._rot_moving = _X330RotAxis(motor_y_rot_axis_width * MM_SCALE)
    self.rot_center = self._rot_moving.base
    self.rot_front = self._rot_moving.front
    self.rot_back = self._rot_moving.back

    rot_range = rot_range if rot_range is not None else (-2 * math.pi, 2 * math.pi)
    rot_range = (rot_range[0] - initial_rotation, rot_range[1] - initial_rotation)
    rot_axis = jnp.array([0, -1, 0])
    self.hinge = joints.Hinge2(
        self._rot_fixed,
        self._rot_moving.base,
        axis=rot_axis,
        damping=damping,
        frictionloss=frictionloss,
        range=rot_range,
    )
    assert_transform(
        self._rot_fixed, self._rot_moving.base, Pose(rv=initial_rotation * rot_axis)
    )
    self.actuator = actuators.Position(
        self.hinge,
        kp=kp,
        kv=kv,
        ctrlrange=rot_range,
        forcerange=(-torque_limit, torque_limit),
    )
    self.sensor = sensors.Position(self.hinge)

    self.base = self.place(Port())


@defcomponent
def FPX330_S101(self) -> None:
    """A Dynamixel FPX330-S101 side mounting plate.

    A flat rectangular plate that attaches to the side of a Dynamixel
    XC330/XL330 motor.

    The base is centered on the motor-side face, and there are two mounting
    ports (lower and upper) on the outer face of the plate.

    """
    x_dim = 28.6
    y_dim = 34
    z_dim = 2  # not specified in diagram, tabs not modeled
    screw_z_offset = -5
    face_mount_center_distance = 15
    face_mount_lower_offset = (y_dim - face_mount_center_distance) / 2

    self.shape = shapes.scale(cube(x_dim, y_dim, z_dim), jnp.full([3], MM_SCALE))
    self.material = POLYCARBONATE

    self.base = self.place(
        Port(),
        Pose(
            pos=face(self.shape, "+z").center
            + jnp.array([0, 0, screw_z_offset]) * MM_SCALE,
        ),
    )
    self.lower = self.place(
        Port(),
        Pose(
            pos=face(self.shape, "+z").lower_left
            + jnp.array([x_dim / 2, face_mount_lower_offset, 0]) * MM_SCALE,
        ),
    )
    self.upper = self.place(
        Port(),
        Pose(
            pos=face(self.shape, "+z").lower_left
            + jnp.array(
                [x_dim / 2, face_mount_lower_offset + face_mount_center_distance, 0]
            )
            * MM_SCALE
        ),
    )


@defcomponent
def FPX330_S102(self) -> None:
    """A Dynamixel FPX330-S102 top mounting plate.

    A flat rectangular plate that attaches to the top or bottom of a Dynamixel
    XC330/XL330 motor.

    The base is centered on the motor-side face, and the tip is on the outer
    face of the plate.

    """
    x_dim = 28.6
    y_dim = 20
    z_dim = 3  # not specified in diagram, tabs not modeled
    screw_z = z_dim - 5

    self.shape = shapes.scale(cube(x_dim, y_dim, z_dim), jnp.full([3], MM_SCALE))
    self.material = POLYCARBONATE

    self.base = self.place(
        Port(),
        Pose(pos=face(self.shape, "-z").center + jnp.array([0, 0, screw_z]) * MM_SCALE),
    )
    self.tip = self.place(Port(), Pose(pos=face(self.shape, "+z").center))


@defcomponent
def FPX330_H101(self):
    """A Dynamixel FPX330-H101 attachment plate.

    The base of the plate is at the center of the axis of rotation and the tip
    is a the center of the top face.

    """
    plate_top_thickness = 3
    plate_x_dim = 34.6
    plate_internal_x_dim = 29
    plate_y_dim = 20
    plate_z_dim = 25
    plate_side_thickness = (plate_x_dim - plate_internal_x_dim) / 2
    plate_hinge_hole_offset = plate_y_dim / 3  # from bottom, unclear from drawing

    plate_top = cube(plate_x_dim, plate_y_dim, plate_top_thickness)
    plate_side_height = plate_z_dim - plate_top_thickness
    plate_side = cube(plate_side_thickness, plate_y_dim, plate_side_height)

    # the plate is placed so that the y-axis is the axis of rotation
    self.shape = shapes.scale(
        transform(
            translate(
                shapes.union(
                    plate_top,
                    translate(plate_side, [0, 0, -plate_side_height]),
                    translate(
                        plate_side,
                        [
                            plate_side_thickness + plate_internal_x_dim,
                            0,
                            -plate_side_height,
                        ],
                    ),
                ),
                [-plate_x_dim / 2, -plate_y_dim / 2, 0],
            ),
            Pose(rot=Rotation.from_euler("z", 90, degrees=True)),
        ),
        jnp.full([3], MM_SCALE),
    )
    self.material = POLYCARBONATE

    self.base = self.place(
        Port(),
        Pose(pos=[0, 0, MM_SCALE * (-plate_side_height + plate_hinge_hole_offset)]),
    )
    self.tip = self.place(Port(), Pose(pos=[0, 0, MM_SCALE * plate_top_thickness]))


_rot_z_90 = Pose(rot=Rotation.from_euler("z", 90, degrees=True))


@defcomponent
def Motor(
    self, left=False, right=False, upper=False, lower=False, hinge=False, **motor_kwargs
):
    if (left or right) and (lower or upper):
        raise ValueError(
            "Side attachment plates are incompatible with lower and upper attachment plates"
        )

    if hinge:
        hinge_rot = 1.95
        rot_range = motor_kwargs.get("rot_range", (-hinge_rot, hinge_rot))
        rot_range = (max(-hinge_rot, rot_range[0]), min(hinge_rot, rot_range[1]))
        motor_kwargs["rot_range"] = rot_range

    self.motor = X330(**motor_kwargs)

    self.joints = []
    if left:
        self.left = FPX330_S101()
        self.joints.append(joints.Weld(self.left.base, self.motor.left, pose=_rot_z_90))
    if right:
        self.right = FPX330_S101()
        self.joints.append(
            joints.Weld(self.right.base, self.motor.right, pose=_rot_z_90)
        )
    if lower:
        self.lower = FPX330_S102()
        self.joints.append(
            joints.Weld(self.lower.base, self.motor.bottom, pose=_rot_z_90)
        )
    if upper:
        self.upper = FPX330_S102()
        self.joints.append(joints.Weld(self.upper.base, self.motor.top, pose=_rot_z_90))
    if hinge:
        self.hinge = FPX330_H101()
        self.joints.append(joints.Weld(self.hinge.base, self.motor.rot_center))
    self.base = self.place(Port())
    self.joints.append(joints.Weld(self.base, self.motor.base))

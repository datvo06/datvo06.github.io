"""Franka Emika Panda arm.

Design pattern
--------------
:class:`PandaLink` and :class:`PandaArm` are pure-data ``@dataclass``
components with ``make`` classmethod constructors, following the
``DHChain`` conventions: construction runs under ``with frame() as pose:``
and registers port edges with ``assert_transform``. Both expose
``base``/``tip`` ports (:class:`~robotl.examples.based.HasBaseAndTip`),
so they compose with any base/tip linkage. Per-link measurements live in :data:`_LINK_SPECS`;
the eight links are one class over that data.
"""

from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Any, Self

import effectful.handlers.jax.numpy as jnp
import unxt

from robotl.examples.based import Based
from robotl.handlers.mujoco import view_model
from robotl.ops import actuators, joints, shapes
from robotl.ops.syntax import (
    Component,
    Inertia,
    Material,
    Port,
    Pose,
    VisualShape,
    assert_transform,
    frame,
)

JOINT_VELOCITY_LIMITS_RAD_S = (2.175, 2.175, 2.175, 2.175, 2.61, 2.61, 2.61)
JOINT_ACCELERATION_LIMITS_RAD_S2 = (15.0, 7.5, 10.0, 12.5, 15.0, 20.0, 20.0)


def _q(values, unit: str) -> unxt.AbstractQuantity:
    """A quantity from a plain scalar/sequence and a unit string."""
    return unxt.Quantity(jnp.asarray(values), unit)


_mesh_dir = resources.files("robotl").parent.joinpath(  # type: ignore
    "assets", "franka_emika_panda", "meshes"
)
meshes = {
    k: str(_mesh_dir.joinpath(v))
    for k, v in dict(
        link0_c="link0.stl",
        link1_c="link1.stl",
        link2_c="link2.stl",
        link3_c="link3.stl",
        link4_c="link4.stl",
        link5_c0="link5_collision_0.obj",
        link5_c1="link5_collision_1.obj",
        link5_c2="link5_collision_2.obj",
        link6_c="link6.stl",
        link7_c="link7.stl",
    ).items()
}
# Colors and per-link mesh assignments mirror panda.xml at the asset revision
# pinned in robotl.examples.panda_assets.
_VISUAL_COLORS = {
    "white": (1.0, 1.0, 1.0, 1.0),
    "off_white": (0.901961, 0.921569, 0.929412, 1.0),
    "black": (0.25, 0.25, 0.25, 1.0),
    "green": (0.0, 1.0, 0.0, 1.0),
    "light_blue": (0.039216, 0.541176, 0.780392, 1.0),
}


@dataclass(frozen=True, kw_only=True)
class _LinkSpec:
    """Per-link geometry: mesh keys, measured inertia and tip-port pose.

    Dimensioned measurements are unxt quantities -- ``com`` (length), ``mass``
    (mass), ``diag``/``offdiag`` (mass * length**2), ``tip_pos`` (length),
    :meth:`PandaLink.make` converts them at the geometry boundary. ``tip_pos`` /
    ``tip_quat`` are omitted where the tip port carries no offset / rotation.
    """

    meshes: tuple[str, ...]
    visual_meshes: tuple[tuple[str, str], ...]
    com: unxt.AbstractQuantity
    mass: unxt.AbstractQuantity
    diag: unxt.AbstractQuantity
    offdiag: unxt.AbstractQuantity
    tip_pos: unxt.AbstractQuantity | None = None
    tip_quat: tuple[float, ...] | None = None


@dataclass(frozen=True, kw_only=True)
class _JointLinkSpec(_LinkSpec):
    """Link geometry and the required hinge range, gains and torque limit."""

    joint_range: unxt.AbstractQuantity
    gains: tuple[float, float]
    torque_limit: unxt.AbstractQuantity


_BASE_LINK_SPEC = _LinkSpec(
    meshes=("link0_c",),
    visual_meshes=(
        ("link0_0", "off_white"),
        ("link0_1", "black"),
        ("link0_2", "off_white"),
        ("link0_3", "black"),
        ("link0_4", "off_white"),
        ("link0_5", "black"),
        ("link0_7", "white"),
        ("link0_8", "white"),
        ("link0_9", "black"),
        ("link0_10", "off_white"),
        ("link0_11", "white"),
    ),
    com=_q([-0.041018, -0.00014, 0.049974], "m"),
    mass=_q(0.629769, "kg"),
    diag=_q([0.00315, 0.00388, 0.004285], "kg m2"),
    offdiag=_q([8.2904e-7, 0.00015, 8.2299e-6], "kg m2"),
    tip_pos=_q([0, 0, 0.333], "m"),
)

_JOINT_LINK_SPECS: tuple[_JointLinkSpec, ...] = (
    _JointLinkSpec(
        meshes=("link1_c",),
        visual_meshes=(("link1", "white"),),
        com=_q([0.003875, 0.002081, -0.04762], "m"),
        mass=_q(4.970684, "kg"),
        diag=_q([0.70337, 0.70661, 0.0091170], "kg m2"),
        offdiag=_q([-0.00013900, 0.0067720, 0.019169], "kg m2"),
        tip_quat=(1, -1, 0, 0),
        joint_range=_q([-2.8973, 2.8973], "rad"),
        gains=(4500, 450),
        torque_limit=_q(87, "N m"),
    ),
    _JointLinkSpec(
        meshes=("link2_c",),
        visual_meshes=(("link2", "white"),),
        com=_q([-0.003141, -0.02872, 0.003495], "m"),
        mass=_q(0.646926, "kg"),
        diag=_q([0.0079620, 2.8110e-2, 2.5995e-2], "kg m2"),
        offdiag=_q([-3.925e-3, 1.0254e-2, 7.04e-4], "kg m2"),
        tip_pos=_q([0, -0.316, 0], "m"),
        tip_quat=(1, 1, 0, 0),
        joint_range=_q([-1.7628, 1.7628], "rad"),
        gains=(4500, 450),
        torque_limit=_q(87, "N m"),
    ),
    _JointLinkSpec(
        meshes=("link3_c",),
        visual_meshes=(
            ("link3_0", "white"),
            ("link3_1", "white"),
            ("link3_2", "white"),
            ("link3_3", "black"),
        ),
        com=_q([2.7518e-2, 3.9252e-2, -6.6502e-2], "m"),
        mass=_q(3.228604, "kg"),
        diag=_q([3.7242e-2, 3.6155e-2, 1.083e-2], "kg m2"),
        offdiag=_q([-4.761e-3, -1.1396e-2, -1.2805e-2], "kg m2"),
        tip_pos=_q([0.0825, 0, 0], "m"),
        tip_quat=(1, 1, 0, 0),
        joint_range=_q([-2.8973, 2.8973], "rad"),
        gains=(3500, 350),
        torque_limit=_q(87, "N m"),
    ),
    _JointLinkSpec(
        meshes=("link4_c",),
        visual_meshes=(
            ("link4_0", "white"),
            ("link4_1", "white"),
            ("link4_2", "black"),
            ("link4_3", "white"),
        ),
        com=_q([-5.317e-2, 1.04419e-1, 2.7454e-2], "m"),
        mass=_q(3.587895, "kg"),
        diag=_q([2.5853e-2, 1.9552e-2, 2.8323e-2], "kg m2"),
        offdiag=_q([7.796e-3, -1.332e-3, 8.641e-3], "kg m2"),
        tip_pos=_q([-0.0825, 0.384, 0], "m"),
        tip_quat=(1, -1, 0, 0),
        joint_range=_q([-3.0718, -0.0698], "rad"),
        gains=(3500, 350),
        torque_limit=_q(87, "N m"),
    ),
    _JointLinkSpec(
        meshes=("link5_c0", "link5_c1", "link5_c2"),
        visual_meshes=(
            ("link5_0", "black"),
            ("link5_1", "white"),
            ("link5_2", "white"),
        ),
        com=_q([-1.1953e-2, 4.1065e-2, -3.8437e-2], "m"),
        mass=_q(1.225946, "kg"),
        diag=_q([3.5549e-2, 2.9474e-2, 8.627e-3], "kg m2"),
        offdiag=_q([-2.117e-3, -4.037e-3, 2.29e-4], "kg m2"),
        tip_quat=(1, 1, 0, 0),
        joint_range=_q([-2.8973, 2.8973], "rad"),
        gains=(2000, 200),
        torque_limit=_q(12, "N m"),
    ),
    _JointLinkSpec(
        meshes=("link6_c",),
        visual_meshes=(
            ("link6_0", "off_white"),
            ("link6_1", "white"),
            ("link6_2", "black"),
            ("link6_3", "white"),
            ("link6_4", "white"),
            ("link6_5", "white"),
            ("link6_6", "white"),
            ("link6_7", "light_blue"),
            ("link6_8", "light_blue"),
            ("link6_9", "black"),
            ("link6_10", "black"),
            ("link6_11", "white"),
            ("link6_12", "green"),
            ("link6_13", "white"),
            ("link6_14", "black"),
            ("link6_15", "black"),
            ("link6_16", "white"),
        ),
        com=_q([6.0149e-2, -1.4117e-2, -1.0517e-2], "m"),
        mass=_q(1.666555, "kg"),
        diag=_q([1.964e-3, 4.354e-3, 5.433e-3], "kg m2"),
        offdiag=_q([1.09e-4, -1.158e-3, 3.41e-4], "kg m2"),
        tip_pos=_q([0.088, 0, 0], "m"),
        tip_quat=(1, 1, 0, 0),
        joint_range=_q([-0.0175, 3.7525], "rad"),
        gains=(2000, 200),
        torque_limit=_q(12, "N m"),
    ),
    _JointLinkSpec(
        meshes=("link7_c",),
        visual_meshes=(
            ("link7_0", "white"),
            ("link7_1", "black"),
            ("link7_2", "black"),
            ("link7_3", "black"),
            ("link7_4", "black"),
            ("link7_5", "black"),
            ("link7_6", "black"),
            ("link7_7", "white"),
        ),
        com=_q([1.0517e-2, -4.252e-3, 6.1597e-2], "m"),
        mass=_q(7.35522e-01, "kg"),
        diag=_q([1.2516e-2, 1.0027e-2, 4.815e-3], "kg m2"),
        offdiag=_q([-4.28e-4, -1.196e-3, -7.41e-4], "kg m2"),
        tip_pos=_q([0, 0, 0.107], "m"),
        tip_quat=(0.3826834, 0, 0, 0.9238795),
        joint_range=_q([-2.8973, 2.8973], "rad"),
        gains=(2000, 200),
        torque_limit=_q(12, "N m"),
    ),
)

_LINK_SPECS = (_BASE_LINK_SPEC, *_JOINT_LINK_SPECS)

MESH_FILES = tuple(
    sorted(
        {Path(path).name for path in meshes.values()}
        | {f"{mesh}.obj" for spec in _LINK_SPECS for mesh, _ in spec.visual_meshes}
    )
)


@dataclass(eq=False, kw_only=True)
class PandaLink(Component):
    """One Panda link: collision meshes, colored visual shells and measured inertia.

    Pure-data dataclass: every field is populated by :meth:`make`.

    :param shape: Collision mesh, or union of meshes for the split link.
    :param vshape: Full-resolution Menagerie meshes with per-part colors.
    :param inertia: Measured inertia in the link frame.
    :param base: Port at the link's joint frame.
    :param tip: Port where the next link's joint frame sits.
    """

    shape: shapes.Shape
    inertia: Inertia
    base: Port
    tip: Port

    @classmethod
    def make(cls, spec: _LinkSpec) -> Self:
        """Build a :class:`PandaLink` from its per-link measurements."""
        with frame() as pose:
            parts = [shapes.external_mesh(meshes[m]) for m in spec.meshes]
            shape = shapes.union(*parts) if len(parts) > 1 else parts[0]
            visuals = tuple(
                VisualShape(
                    shape=shapes.external_mesh(str(_mesh_dir.joinpath(f"{mesh}.obj"))),
                    material=Material(color=_VISUAL_COLORS[material]),
                )
                for mesh, material in spec.visual_meshes
            )
            inertia = Inertia(
                pose=Pose(pos=spec.com.to("m").value),
                mass=float(spec.mass.to("kg").value),
                diag=spec.diag.to("kg m2").value,
                offdiag=spec.offdiag.to("kg m2").value,
            )
            tip_kwargs: dict[str, Any] = {}
            if spec.tip_pos is not None:
                tip_kwargs["pos"] = spec.tip_pos.to("m").value
            if spec.tip_quat is not None:
                tip_kwargs["quat"] = spec.tip_quat
            base = Port()
            tip = Port()
            link = cls(
                pose=pose,
                shape=shape,
                vshape=visuals,
                inertia=inertia,
                base=base,
                tip=tip,
            )
            assert_transform(link, base)
            assert_transform(link, tip, Pose(**tip_kwargs))
        return link


@dataclass(eq=False, kw_only=True)
class PandaArm(Component):
    """Franka Emika Panda: seven hinge DOFs over eight measured links.

    Pure-data dataclass: every field is populated by :meth:`make`.

    :param links: The eight links, base plate to flange.
    :param hinges: Z-axis hinges between consecutive links, with the
        per-joint ranges from the Panda datasheet.
    :param hinge_actuators: Position actuator per hinge, with per-joint
        gains.
    :param base: Port at the arm's local frame origin, welded to the
        first link.
    :param tip: Alias to the flange link's tip.
    :param weld_base: Weld holding ``base`` -> ``links[0].base``.
    """

    links: tuple[PandaLink, ...]
    base: Port
    tip: Port
    hinges: tuple[joints.Hinge, ...]
    hinge_actuators: tuple[actuators.Position, ...]
    weld_base: joints.Weld

    @classmethod
    def make(cls) -> Self:
        """Build the stock Panda arm."""
        with frame() as pose:
            links = tuple(PandaLink.make(spec) for spec in _LINK_SPECS)
            hinges: list[joints.Hinge] = []
            acts: list[actuators.Position] = []
            # Each non-base link carries the hinge that drives it from its parent.
            for a, b, spec in zip(
                links[:-1], links[1:], _JOINT_LINK_SPECS, strict=True
            ):
                limit = float(spec.torque_limit.to("N m").value)
                lo, hi = spec.joint_range.to("rad").value
                hinge = joints.Hinge(
                    a.tip,
                    b.base,
                    range=(float(lo), float(hi)),
                    armature=0.1,
                    damping=1,
                    axis=jnp.array([0, 0, 1]),
                )
                kp, kv = spec.gains
                hinges.append(hinge)
                acts.append(
                    actuators.Position(
                        hinge,
                        kp=kp,
                        kv=kv,
                        forcerange=(-limit, limit),
                        ctrlrange=hinge.range,
                    )
                )
            base = Port()
            arm = cls(
                pose=pose,
                links=links,
                hinges=tuple(hinges),
                hinge_actuators=tuple(acts),
                base=base,
                tip=links[-1].tip,
                weld_base=joints.Weld(base, links[0].base),
            )
            assert_transform(arm, base)
        return arm


if __name__ == "__main__":
    view_model(lambda: Based.make(PandaArm.make()))

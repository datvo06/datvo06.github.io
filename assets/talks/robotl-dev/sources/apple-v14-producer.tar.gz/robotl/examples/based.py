import typing
from collections.abc import Callable
from dataclasses import dataclass
from typing import Self, runtime_checkable

from robotl.ops import joints
from robotl.ops.coords import Pose
from robotl.ops.syntax import (
    Component,
    ComponentProtocol,
    Origin,
    Port,
    assert_transform,
    frame,
)


@runtime_checkable
class HasBase(ComponentProtocol, typing.Protocol):
    """A component exposing a ``base`` port."""

    base: Port


@runtime_checkable
class HasTip(ComponentProtocol, typing.Protocol):
    """A component exposing a ``tip`` port."""

    tip: Port


@runtime_checkable
class HasBaseAndTip(HasBase, HasTip, typing.Protocol):
    """A component exposing both ``base`` and ``tip`` ports."""


@dataclass(eq=False, kw_only=True)
class Based(Component):
    """Anchors a component to the world by welding its base to ``Origin``.

    :param c: The anchored component.
    :param base: Own port carrying the ``Origin`` weld; without it this
        component would form an isolated island and be freejointed.
    :param welds: ``Origin.base`` -> ``base`` -> ``c.base``.
    """

    c: HasBase
    base: Port
    welds: tuple[joints.Weld, joints.Weld]

    @staticmethod
    def anchor[Scene: Component](
        c: HasBase,
        factory: Callable[[Pose, Port, tuple[joints.Weld, joints.Weld]], Scene],
    ) -> Scene:
        """Construct a complete component with one anchored base attachment."""
        with frame() as pose:
            base = Port()
            scene = factory(
                pose,
                base,
                (joints.Weld(Origin.base, base), joints.Weld(base, c.base)),
            )
            assert_transform(scene, base)
        return scene

    @classmethod
    def make(cls, c: HasBase) -> Self:
        return cls.anchor(
            c, lambda pose, base, welds: cls(pose=pose, c=c, base=base, welds=welds)
        )

"""DH-parameterized manipulator components (Figure 4 of arXiv:2509.13077).

Each link is parameterized by three Denavit-Hartenberg parameters:
- d: length along the previous joint axis (Z)
- a: offset perpendicular to the joint axis (X)
- alpha: twist angle between consecutive joint axes (rotation about X)

Three design modes:
- Free: continuous d, a, alpha
- Economic: alpha constrained to {0, +/-pi/2}
- Modular: select from a discrete catalog of link modules

Design pattern
--------------
:class:`DHLink`, :class:`DHRotorLink`, and :class:`DHChain` are pure-data
``@dataclass`` subclasses of :class:`Component` — they have **no**
``__post_init__`` setup logic. All construction work (geometry, joint
placement, kinematic-edge registration) lives in ``make`` classmethod
constructors (:meth:`DHLink.make`, :meth:`DHRotorLink.make`,
:meth:`DHChain.make`), following the ``EnvProcess.make`` convention.
Each ``make`` opens the component's pose variable with
``with frame() as pose:``, mirroring ``defcomponent``, so any
context-relative coordinate queries during construction resolve in the
component's own frame. The top-level convenience :func:`dh_chain`
assembles a full chain from DH specs.

Subclass-declared fields (``links``, ``alpha_joints``, etc.) are discovered
by the MuJoCo compiler alongside the legacy ``attributes`` dict that
``@defcomponent`` populates — see ``syntax.component_state``.

Benefits over a ``__post_init__``-with-sentinel-gate pattern:
- No ``default=None`` + ``# type: ignore[assignment]`` lies on output fields;
  every field has its real type and is populated by the builder.
- No re-entrancy gate needed, because ``dataclasses.replace`` driven by
  effectful's ``_evaluate_object`` doesn't re-run any user setup logic.
- Construction order is free — builders run once, top-to-bottom.

Cross-component joints (``joints.Hinge``, ``joints.Weld``) still register
their kinematic edges via their own ``__post_init__``s; that's fine because
the joint never passes itself to ``assert_transform`` (it passes the two
ports), so the recursive-evaluate-of-self issue doesn't arise.
"""

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Self

import effectful.handlers.jax.numpy as jnp
import numpy as np

from robotl.examples.based import Based, HasBaseAndTip
from robotl.handlers.mujoco import view_model
from robotl.internals.utils import Colors
from robotl.ops import actuators, joints, sensors, shapes
from robotl.ops.syntax import Component, Port, Pose, assert_transform, frame

Z = jnp.array([0.0, 0.0, 1.0])
X = jnp.array([1.0, 0.0, 0.0])
Y = jnp.array([0.0, 1.0, 0.0])


# ---------------------------------------------------------------------------
# DHLink — link body geometry
# ---------------------------------------------------------------------------


@dataclass(eq=False, kw_only=True)
class DHLink(Component):
    """A single DH-parameterized link body (Figure 4).

    Pure-data dataclass: every field is populated by :meth:`make`.
    Direct construction (e.g. ``DHLink(shape=..., base=..., tip=...)``) is
    supported for advanced cases but most callers should use :meth:`make`.

    ``kw_only=True`` is required because ``Component`` provides
    defaulted base fields and dataclass's ordering rule forbids
    non-defaulted fields after defaulted ones; making the new fields
    keyword-only sidesteps the rule.

    :param shape: Union of housing cylinder + d-segment capsule + optional
        a-segment elbow + a-tube.
    :param color: RGBA color for visualization.
    :param base: Port at the link's base (origin of its local frame).
    :param tip: Port at the link's tip, with the DH alpha twist baked in.
    """

    shape: shapes.Shape
    color: tuple[float, float, float, float]
    base: Port
    tip: Port

    @classmethod
    def make(
        cls,
        d: float = 0.15,
        a: float = 0.0,
        alpha: float = 0.0,
        radius: float = 0.02,
    ) -> Self:
        """Build a :class:`DHLink` from DH parameters.

        :param d: Length along Z axis [m].
        :param a: Offset along X axis [m].
        :param alpha: Twist angle about X axis [rad], in ``[-pi, pi]``.
        :param radius: Tube radius [m].
        :raises ValueError: If ``alpha`` is outside ``[-pi, pi]``.
        """
        if not (-np.pi <= alpha <= np.pi):
            raise ValueError(f"DHLink: alpha must be in [-pi, pi], got {alpha}")

        with frame() as pose:
            # Motor housing: wide cylinder at base (Figure 4 joint
            # aesthetic). The housing visually overlaps with the previous
            # link's tip at each alpha-hinge — that's a decorative choice
            # (the housing represents the motor sitting at the joint), and
            # the overlap is silenced by ``DHLink.disable_collision=True``
            # rather than by physical separation.
            housing_r = radius * 4.0
            housing_h = housing_r * 1.5
            parts = [shapes.cylinder(r=housing_r, h=housing_h)]

            # d-segment: thin tube along Z from top of housing
            d_len = max(abs(d), 0.02)
            parts.append(
                shapes.translate(
                    shapes.capsule(r=radius, h=d_len),
                    [0, 0, housing_h],
                )
            )

            tip_z = housing_h + d_len

            # a-segment: tube along X at end of d-segment (L-shape)
            if abs(a) > 0.02:
                a_len = abs(a)
                a_sign = 1.0 if a >= 0 else -1.0
                # Elbow ball at the bend
                parts.append(
                    shapes.translate(
                        shapes.capsule(r=radius * 2.0, h=radius),
                        [0, 0, tip_z],
                    )
                )
                # Tube along X
                parts.append(
                    shapes.transform(
                        shapes.capsule(r=radius, h=a_len),
                        Pose(
                            pos=[0, 0, tip_z],
                            rv=a_sign * jnp.pi / 2 * Y,
                        ),
                    )
                )

            shape = shapes.union(*parts) if len(parts) > 1 else parts[0]
            base = Port()
            tip = Port()

            link = cls(pose=pose, shape=shape, color=Colors.red, base=base, tip=tip)

            # Register the base/tip edges now that ``link`` exists.
            assert_transform(link, base)
            # Tip includes alpha rotation about X — next link's Z axis is
            # tilted
            assert_transform(link, tip, Pose(pos=[a, 0, tip_z], rv=alpha * X))

        return link


# ---------------------------------------------------------------------------
# DHRotorLink — link body + Z-hinge + actuator/sensor
# ---------------------------------------------------------------------------


@dataclass(eq=False, kw_only=True)
class DHRotorLink(Component):
    """Wraps one :class:`DHLink` with a Z-axis revolute joint at the tip.

    Pure-data dataclass: every field is populated by :meth:`make`. The
    link body encodes ``(d, a, alpha)`` geometry; the Z-hinge between
    ``link.tip`` and ``tip`` provides the theta DOF, with the position
    actuator + velocity sensor on that joint.

    :param link: The link body being mounted.
    :param base: Alias to ``link.base`` (the rotor's outer base port).
    :param tip: New port at the rotor's local frame origin; the Z-hinge
        connects ``link.tip`` to this.
    :param joint: The Z-axis hinge providing the theta DOF.
    :param actuator: (Position, Velocity) actuator pair on ``joint``.
    :param sensor: Joint-position sensor on ``joint``.
    """

    link: DHLink
    base: Port
    tip: Port
    joint: joints.Hinge
    actuator: tuple[actuators.Position, actuators.Velocity]
    sensor: sensors.Position

    @classmethod
    def make(cls, link: DHLink) -> Self:
        """Build a :class:`DHRotorLink` wrapping ``link`` with a Z-hinge tip.

        :param link: The link body to mount.
        """
        with frame() as pose:
            tip = Port()
            # ``joints.Hinge.__post_init__`` registers ``link.tip`` ->
            # ``tip`` via ``assert_transform``; its parent isn't ``self`` so
            # it doesn't trigger the recursive-evaluate-of-self issue.
            joint = joints.Hinge(link.tip, tip, axis=Z, damping=1)
            actuator = (actuators.Position(joint, kp=10), actuators.Velocity(joint))
            sensor = sensors.Position(joint)

            rotor = cls(
                pose=pose,
                link=link,
                base=link.base,
                tip=tip,
                joint=joint,
                actuator=actuator,
                sensor=sensor,
            )
            # Register the rotor-frame -> tip-port edge now that ``rotor``
            # exists.
            assert_transform(rotor, tip)
        return rotor


# ---------------------------------------------------------------------------
# DHChain — composition of base/tip segments via inter-link X-hinges
# ---------------------------------------------------------------------------


_DEFAULT_SPECS: tuple[tuple[float, float, float], ...] = (
    (0.30, 0.0, np.pi / 2),
    (0.25, 0.0, -np.pi / 2),
    (0.20, 0.0, np.pi / 2),
    (0.15, 0.0, -np.pi / 2),
    (0.10, 0.0, 0.0),
)


@dataclass(eq=False, kw_only=True)
class DHChain(Component):
    """A kinematic chain composed of pre-built base/tip segments.

    Pure-data dataclass: every field is populated by :meth:`make`.
    Connects consecutive ``links`` via X-axis hinges (the alpha-rotation
    axis) and welds the first link to the chain's base port. Adds n-1
    inter-link X-hinge DOFs on top of whatever DOFs the segments carry
    (:class:`DHRotorLink` s bring one Z-hinge each, giving 2n-1 total).

    :param links: Tuple of base/tip components (:class:`HasBaseAndTip`). At least one.
    :param alpha_joints: Inter-link X-axis hinges (length n-1).
    :param alpha_actuators: Per-hinge (Position, Velocity) actuator pairs.
    :param alpha_sensors: Per-hinge position sensors.
    :param base: New port at the chain's local frame origin; welded to
        ``links[0].base``.
    :param tip: Alias to ``links[-1].tip``.
    :param weld_base: The Weld holding the kinematic edge ``base`` ->
        ``links[0].base``; held as a field so the compiler discovers it.
    """

    links: tuple[HasBaseAndTip, ...]
    base: Port
    tip: Port
    alpha_joints: tuple[joints.Hinge, ...]
    alpha_actuators: tuple[tuple[actuators.Position, actuators.Velocity], ...]
    alpha_sensors: tuple[sensors.Position, ...]
    weld_base: joints.Weld

    @classmethod
    def make(cls, links: Sequence[HasBaseAndTip]) -> Self:
        """Compose pre-built base/tip segments into a :class:`DHChain`.

        :param links: Base/tip components (:class:`HasBaseAndTip`). At least one.
        :raises ValueError: If ``links`` is empty.
        """
        if not links:
            raise ValueError("DHChain needs at least one link")

        with frame() as pose:
            # Inter-link X-hinges. The alpha twist is already in the tip
            # geometry, so these hinges provide extra DOFs in the
            # alpha-rotated frame.
            alpha_joints = tuple(
                joints.Hinge(a.tip, b.base, axis=X, damping=1)
                for a, b in zip(links[:-1], links[1:])
            )
            alpha_actuators = tuple(
                (actuators.Position(j, kp=10), actuators.Velocity(j))
                for j in alpha_joints
            )
            alpha_sensors = tuple(sensors.Position(j) for j in alpha_joints)

            base = Port()
            weld = joints.Weld(base, links[0].base)

            chain = cls(
                pose=pose,
                links=tuple(links),
                alpha_joints=alpha_joints,
                alpha_actuators=alpha_actuators,
                alpha_sensors=alpha_sensors,
                base=base,
                tip=links[-1].tip,
                weld_base=weld,
            )
            # Register the chain-frame -> base-port edge now that ``chain``
            # exists.
            assert_transform(chain, base)
        return chain


def dh_chain(
    specs: tuple[tuple[float, float, float], ...] = _DEFAULT_SPECS,
    radius: float = 0.02,
) -> DHChain:
    """Build a uniform-radius DH chain from a list of ``(d, a, alpha)`` specs.

    Convenience top-level factory for the common case where every link in
    the chain has the same tube radius and the user just wants to list the
    DH parameters. For per-link variation (different radius, custom
    geometry, mixing link types), call :meth:`DHLink.make` /
    :meth:`DHRotorLink.make` / :meth:`DHChain.make` directly.

    :param specs: Tuple of ``(d, a, alpha)`` tuples, one per link.
    :param radius: Tube radius shared by every link [m].
    :returns: A :class:`DHChain` composed of one :class:`DHRotorLink` per spec.

    >>> chain = dh_chain()  # default 5-link chain
    >>> chain = dh_chain(specs=((0.3, 0, 0), (0.2, 0, np.pi/2)), radius=0.03)
    """
    links = tuple(
        DHRotorLink.make(DHLink.make(d=d, a=a, alpha=alpha, radius=radius))
        for d, a, alpha in specs
    )
    # Suppress collision on each link's body. At every alpha-hinge the
    # next link's wide motor housing visually overlaps the previous link's
    # tip — that's design-time decoration (the housing represents the
    # motor *at* the joint), not a physical contact. The chain factory
    # makes this decision because it's the layer that knows the
    # composition topology; the DHLink itself doesn't carry an opinion.
    for rotor in links:
        rotor.link.disable_collision = True
    return DHChain.make(links)


# ---------------------------------------------------------------------------
# Module catalogs for the three design modes (Section 3.4 / Figure 4)
# ---------------------------------------------------------------------------

# Modular catalog: discrete set of link modules
MODULE_CATALOG: dict[str, tuple[float, float, float]] = {
    "I-short": (0.15, 0.0, 0.0),  # straight, no twist
    "I-long": (0.30, 0.0, 0.0),  # long straight
    "L-ortho": (0.15, 0.0, np.pi / 2),  # 90-degree twist
    "L-ortho-neg": (0.15, 0.0, -np.pi / 2),  # -90-degree twist
    "L-offset": (0.0, 0.15, np.pi / 2),  # lateral offset + twist
}

# Economic constraints: alpha must be one of these values
ECONOMIC_ALPHAS: list[float] = [0.0, np.pi / 2, -np.pi / 2]


def snap_to_economic(alpha: float) -> float:
    """Snap alpha to nearest economic constraint value."""
    return min(ECONOMIC_ALPHAS, key=lambda x: abs(x - alpha))


if __name__ == "__main__":
    view_model(lambda: Based.make(dh_chain()))

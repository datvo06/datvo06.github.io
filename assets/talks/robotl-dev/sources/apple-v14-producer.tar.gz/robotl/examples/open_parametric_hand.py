"""Motor-driven Open Parametric Hand approximation.

Based on the `100_fingers` project by Gilday et al. (2025):
  https://github.com/kg398/100_fingers
  Gilday, K., Sirithunge, C., Iida, F., & Hughes, J. (2025).
  Embodied manipulation with past and future morphologies through an open
  parametric hand design. Science Robotics, 10(102), eads6437.

Design pattern
--------------
:class:`Bone`, :class:`Digit`, :class:`Palm`, and
:class:`OpenParametricHand` are pure-data ``@dataclass`` components with
``make`` classmethod constructors, following the ``DHChain`` conventions:
construction runs under ``with frame() as pose:`` and registers port edges
with ``assert_transform``. :class:`Bone`, :class:`Digit`, and the hand
expose ``base``/``tip`` ports (:class:`~robotl.examples.based.HasBaseAndTip`),
so they compose with any base/tip linkage (e.g. ``DHChain``).

Two XL430-W250-T motors drive compliant tendon mixers by default; XM430-W210
and W350 are selectable same-envelope alternatives. The motor reference
is the music-playing parametric hand (doi:10.3389/frobt.2024.1463744,
section 2.4); routing follows the grasp-oriented double pulley in the OPH
paper (arxiv:2410.18633, section 4.6), not the music-playing synergies.
Hinges and constant tendon moment arms approximate rolling joints and
nonlinear routing. Spring stiffnesses are paper-derived; passive damping,
pretension (zero), mixer packaging, and servo gains are not calibrated.
The constant-moment-arm distal flexor and extensor are parallel constraints:
together with the intermediate flexor they leave one three-hinge flexion
mode without spring restoring stiffness. Passive joint mechanics are not a
validated model of the printed rolling-flexure hand.
"""

import math
from enum import IntEnum, unique
from typing import NamedTuple, Self

import effectful.handlers.jax.numpy as jnp
import pydantic.dataclasses
import unxt
from effectful.ops.types import Term
from flax import struct
from pydantic import ConfigDict, TypeAdapter, validate_call

from robotl.examples.based import Based
from robotl.examples.dynamixel import X430, X430Model
from robotl.handlers.mujoco import view_model
from robotl.ops import joints, shapes, tendons
from robotl.ops.syntax import (
    Component,
    Port,
    Pose,
    assert_transform,
    disable_pair_collisions,
    frame,
)
from robotl.ops.units import (
    Mm,
    MmOrOff,
    PlacementDeg,
    PlacementMm,
    Unit,
    Volt,
    deg,
    mm,
    volt,
)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------
@unique
class FingerType(IntEnum):
    """Finger-type enum (matching 100_fingers/OpenSCAD/parameters.scad)."""

    FOUR_DOF = 0
    FOUR_DOF_THUMB = 1
    THREE_DOF = 2
    THREE_DOF_THUMB = 3
    TWO_DOF = 4
    TWO_DOF_THUMB = 5


@unique
class JointType(IntEnum):
    """Joint-type enum for bone configuration."""

    BASE = 0  # flat base
    HINGE = 1  # 1-DOF cylindrical
    BALL = 2  # 2-DOF spherical
    TIP = 3  # fingertip (with nail)


# ---------------------------------------------------------------------------
# Parameter dataclasses
# ---------------------------------------------------------------------------
@struct.dataclass
class LigParams:
    """Ligament dimensions (mm)."""

    width: MmOrOff = mm(0.0)
    thickness: MmOrOff = mm(0.0)


@struct.dataclass
class PulleyParams:
    """Flexor-pulley dimensions (mm)."""

    length: MmOrOff = mm(0.0)
    thickness: MmOrOff = mm(0.0)
    radius: MmOrOff = mm(0.0)


class BoneLengths(NamedTuple):
    """Bone lengths for one digit (mm), matching the phalanx order."""

    metacarpal: Mm
    proximal: Mm
    intermediate: Mm
    distal: Mm


class JointTaper(NamedTuple):
    """Taper factors at each of the 5 joint boundaries (base -> tip)."""

    base: Unit
    mcp: Unit
    pip: Unit
    dip: Unit
    tip: Unit


class FingerScalars(NamedTuple):
    """One scalar per finger, in anatomical order."""

    index: Mm  # type: ignore[assignment]  # pyright: ignore[reportIncompatibleVariableOverride] - shadows tuple.index
    middle: Mm
    ring: Mm
    pinky: Mm


class ThumbScalars(NamedTuple):
    """One scalar per thumb."""

    inner: Mm
    outer: Mm


@struct.dataclass
class JointEnd:
    """Geometry of one end (proximal or distal) of a bone, in mm quantities."""

    diameter: Mm
    width: Mm
    joint_type: JointType = struct.field(pytree_node=False, default=JointType.BASE)


@struct.dataclass
class DigitParams:
    """Parameters for a single digit (finger or thumb), in mm."""

    bone_lengths: BoneLengths
    joint_diameters: list[Mm]  # n+1 values (one per joint boundary)
    joint_widths: list[Mm]  # n+1 values
    joint_configs: list[tuple[JointType, JointType]] = struct.field(pytree_node=False)
    lig: LigParams
    pulley: PulleyParams


@struct.dataclass
class HandParams:
    """Default parameters from ``100_fingers/OpenSCAD/parameters.scad``.

    Raw dimensions are in **millimetres** and **degrees**.  Derived per-digit
    arrays (joint diameters and widths after taper) are exposed as
    ``@property`` methods so they stay in sync when any base value changes.
    """

    # -- Digit types -------------------------------------------------------
    type_finger: list[FingerType] = struct.field(
        pytree_node=False,
        default_factory=lambda: [FingerType.FOUR_DOF] * 4,
    )
    type_thumb: list[FingerType] = struct.field(
        pytree_node=False,
        default_factory=lambda: [FingerType.FOUR_DOF_THUMB] * 2,
    )

    # -- Bone lengths (mm), one per digit ------------------------------------
    bone_lengths_finger: list[BoneLengths] = struct.field(
        default_factory=lambda: [
            BoneLengths(mm(80), mm(38), mm(20), mm(20)),
            BoneLengths(mm(82), mm(41), mm(20.5), mm(20.5)),
            BoneLengths(mm(79), mm(38), mm(19), mm(19)),
            BoneLengths(mm(74), mm(35), mm(17), mm(17)),
        ],
    )
    bone_lengths_thumb: list[BoneLengths] = struct.field(
        default_factory=lambda: [
            BoneLengths(mm(25), mm(35), mm(25), mm(25)),
            BoneLengths(mm(25), mm(35), mm(25), mm(25)),
        ],
    )

    # -- Joint diameters: base value per digit + taper factors (n+1) -------
    base_jd_finger: FingerScalars = FingerScalars(
        index=mm(12.5),
        middle=mm(14),
        ring=mm(12.5),
        pinky=mm(11),
    )
    base_jd_thumb: ThumbScalars = ThumbScalars(inner=mm(16.0), outer=mm(16.0))
    jd_factors: JointTaper = JointTaper(
        base=0.7,
        mcp=1.0,
        pip=0.6,
        dip=0.5,
        tip=0.4,
    )

    # -- Joint widths: base value per digit + taper factors (n+1) ----------
    base_w_finger: FingerScalars = FingerScalars(
        index=mm(15.0),
        middle=mm(16.0),
        ring=mm(15.0),
        pinky=mm(13.0),
    )
    base_w_thumb: ThumbScalars = ThumbScalars(inner=mm(20.0), outer=mm(20.0))
    w_factors: JointTaper = JointTaper(
        base=0.7,
        mcp=1.0,
        pip=0.8,
        dip=0.7,
        tip=0.7,
    )

    # -- Ligament params -----------------------------------------------------
    lig_finger: LigParams = LigParams(mm(2.5), mm(0.6))
    lig_thumb: LigParams = LigParams(mm(2.5), mm(0.6))

    # -- Pulley params -------------------------------------------------------
    pulley_finger: PulleyParams = PulleyParams(mm(5.0), mm(1.5), mm(1.0))
    pulley_thumb: PulleyParams = PulleyParams(mm(5.0), mm(2.2), mm(1.0))

    # -- Digit placement: origins in mm, angles in degrees -------------------
    origins_finger: PlacementMm = struct.field(
        default_factory=lambda: mm(
            jnp.array(
                [
                    [0.0, 1.5, 0.0],
                    [0.0, 0.0, -12.0],
                    [0.0, 1.0, -24.0],
                    [0.0, 3.5, -34.0],
                ]
            )
        ),
    )
    angles_finger: PlacementDeg = struct.field(
        default_factory=lambda: deg(
            jnp.array(
                [
                    [0.0, -10.0, 0.0],
                    [0.0, 3.0, 0.0],
                    [0.0, 16.0, 0.0],
                    [0.0, 30.0, 0.0],
                ]
            )
        ),
    )
    origins_thumb: PlacementMm = struct.field(
        default_factory=lambda: mm(
            jnp.array(
                [
                    [-3.0, 5.5, 15.0],
                    [-3.0, 5.5, -45.0],
                ]
            )
        ),
    )
    angles_thumb: PlacementDeg = struct.field(
        default_factory=lambda: deg(
            jnp.array(
                [
                    [0.0, -100.0, 0.0],
                    [0.0, 100.0, 0.0],
                ]
            )
        ),
    )

    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    @classmethod
    def validated(cls, **kwargs) -> Self:
        """Authoring seam: construct with every constraint checked."""
        return TypeAdapter(cls).validate_python(kwargs)

    def finger(self, index: int) -> DigitParams:
        """Return :class:`DigitParams` for finger *index*."""
        ft = self.type_finger[index]
        base_jd = self.base_jd_finger[index]
        base_w = self.base_w_finger[index]
        return DigitParams(
            bone_lengths=self.bone_lengths_finger[index],
            joint_diameters=[base_jd * f for f in self.jd_factors],
            joint_widths=[base_w * f for f in self.w_factors],
            joint_configs=DOF4_JOINTS[: N_BONES[ft]],
            lig=self.lig_finger,
            pulley=self.pulley_finger,
        )

    def thumb(self, index: int) -> DigitParams:
        """Return :class:`DigitParams` for thumb *index*."""
        ft = self.type_thumb[index]
        base_jd = self.base_jd_thumb[index]
        base_w = self.base_w_thumb[index]
        return DigitParams(
            bone_lengths=self.bone_lengths_thumb[index],
            joint_diameters=[base_jd * f for f in self.jd_factors],
            joint_widths=[base_w * f for f in self.w_factors],
            joint_configs=DOF4_JOINTS[: N_BONES[ft]],
            lig=self.lig_thumb,
            pulley=self.pulley_thumb,
        )


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
DOF4_JOINTS: list[tuple[JointType, JointType]] = [
    (JointType.BASE, JointType.BALL),  # metacarpal
    (JointType.BALL, JointType.HINGE),  # proximal phalanx
    (JointType.HINGE, JointType.HINGE),  # intermediate phalanx
    (JointType.HINGE, JointType.TIP),  # distal phalanx
]

N_BONES: dict[FingerType, int] = {
    FingerType.FOUR_DOF: 4,
    FingerType.FOUR_DOF_THUMB: 4,
    FingerType.THREE_DOF: 3,
    FingerType.THREE_DOF_THUMB: 3,
    FingerType.TWO_DOF: 2,
    FingerType.TWO_DOF_THUMB: 2,
}

# Ry(pi/2): maps local +Z (bone direction) to +X (outward from palm).
# The OpenSCAD "print angle" only affects living-hinge offsets and is
# not needed for joint-based simulation.
_BASE_ROT = Pose(rv=[0.0, jnp.pi / 2.0, 0.0])

_MOUNT_CLEARANCE = 0.05
"""Distance from the base port to the palm plate along the outward axis, in
metres. The base port is the hand's mounting face: a wrist that mounts at
the base sits this far behind the palm, clear of the plate and of the
metacarpal roots, the same convention as ``ParameterizedLeapHand``'s
``leap_offset``."""


# ---------------------------------------------------------------------------
# Bone: single anatomical bone segment
# ---------------------------------------------------------------------------
@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class Bone(Component):
    """Anatomical bone with tapered body, joint knobs, ligaments, and pulleys.

    Pure-data dataclass: every field is populated by :meth:`make`.

    :param shape: Union of tapered body, joint knobs, and optional
        ligament strips and flexor-pulley channel.
    :param base: Port at the bone's proximal end.
    :param tip: Port at the bone's distal end.
    """

    shape: shapes.Shape
    base: Port
    tip: Port

    @classmethod
    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def make(
        cls,
        length: unxt.AbstractQuantity,
        prox: JointEnd,
        dist: JointEnd,
        lig: LigParams | None = None,
        pulley: PulleyParams | None = None,
    ) -> Self:
        """Build a :class:`Bone` from its end geometries.

        Dimensions arrive as quantities and are converted to metres here,
        at the geometry boundary.

        The body is a tapered shape (wider at proximal, narrower at distal).
        Joint knobs are spheres (2-DOF) or cylinders (1-DOF) at each end.
        Distal tip type gets a flat nail cap.

        Ligaments are thin flexible strips on each side of the bone bridging
        from the proximal joint outward; they provide passive joint stability.

        Pulleys are small guide channels on the palmar (flexor) side of the
        bone that keep tendons close to the bone surface through joint
        articulation.

        :param length: Bone length along local Z.
        :param prox: Geometry of the proximal end.
        :param dist: Geometry of the distal end.
        :param lig: Ligament dimensions; omitted when ``None``.
        :param pulley: Flexor-pulley dimensions; omitted when ``None``.
        """
        length_m = float(length.to("m").value)
        pd, dd = float(prox.diameter.to("m").value), float(dist.diameter.to("m").value)
        pwf, dwf = float(prox.width.to("m").value), float(dist.width.to("m").value)
        with frame() as pose:
            pr, dr = pd / 2.0, dd / 2.0
            pw, dw = pwf / 2.0, dwf / 2.0

            # --- Tapered body (approximate with two overlapping cuboids) ---
            body_prox = shapes.centered_cube(pd, pwf, length_m * 0.6)
            body_dist = shapes.translate(
                shapes.centered_cube(dd, dwf, length_m * 0.6),
                [0, 0, length_m * 0.4],
            )
            body = shapes.union(body_prox, body_dist)

            # --- Proximal joint knob ---
            if prox.joint_type == JointType.BALL:
                knob_prox = shapes.sphere(pr)
            elif prox.joint_type == JointType.HINGE:
                knob_prox = shapes.translate(
                    shapes.cylinder(r=pr, h=pwf),
                    [0, -pw, 0],
                )
            else:  # JointType.BASE — flat, no extra geometry
                knob_prox = shapes.cube(pd, pwf, 0.01)
                knob_prox = shapes.translate(knob_prox, [-pr, -pw, 0])

            # --- Distal joint knob ---
            if dist.joint_type == JointType.TIP:
                nail = shapes.centered_cube(dd * 1.2, dwf, dd * 0.3)
                nail = shapes.translate(nail, [0, 0, length_m])
                knob_dist = shapes.union(
                    shapes.translate(shapes.sphere(dr), [0, 0, length_m]),
                    nail,
                )
            elif dist.joint_type == JointType.BALL:
                knob_dist = shapes.translate(shapes.sphere(dr), [0, 0, length_m])
            elif dist.joint_type == JointType.HINGE:
                knob_dist = shapes.translate(
                    shapes.cylinder(r=dr, h=dwf),
                    [0, -dw, length_m],
                )
            else:
                knob_dist = shapes.translate(
                    shapes.sphere(dr * 0.5),
                    [0, 0, length_m],
                )

            parts = [body, knob_prox, knob_dist]

            # --- Ligaments: thin strips on ±Y sides of the proximal joint ---
            lig_w = float(lig.width.to("m").value) if lig else 0.0
            lig_t = float(lig.thickness.to("m").value) if lig else 0.0
            if lig_w > 0 and lig_t > 0 and prox.joint_type != JointType.BASE:
                lig_length = pd * 2.0
                for side in (+1.0, -1.0):
                    strip = shapes.centered_cube(lig_t, lig_w, lig_length)
                    strip = shapes.translate(
                        strip,
                        [
                            pd / 2.0,
                            side * (pw - lig_w / 2.0),
                            -lig_length / 4.0,
                        ],
                    )
                    parts.append(strip)

            # --- Flexor pulley: guide channel on the palmar (+X) side ---
            pu_l = float(pulley.length.to("m").value) if pulley else 0.0
            pu_t = float(pulley.thickness.to("m").value) if pulley else 0.0
            pu_r = float(pulley.radius.to("m").value) if pulley else 0.0
            if pu_l > 0 and pu_t > 0 and pu_r > 0:
                p_outer_r = pu_r + pu_t
                channel = shapes.cylinder(r=p_outer_r, h=pu_l)
                mid_z = length_m / 2.0 - pu_l / 2.0
                channel = shapes.translate(
                    channel,
                    [pd / 2.0, -pu_l / 2.0, mid_z],
                )
                parts.append(channel)

            base = Port()
            tip = Port()
            bone = cls(pose=pose, shape=shapes.union(*parts), base=base, tip=tip)
            assert_transform(bone, base)
            assert_transform(bone, tip, Pose(pos=[0, 0, length_m]))
        return bone


# ---------------------------------------------------------------------------
# Digit: passive chain of Bones
# ---------------------------------------------------------------------------
@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class Digit(Component):
    """Anatomical digit: chain of :class:`Bone` s connected by hinges.

    Pure-data dataclass: every field is populated by :meth:`make`.

    :param bones: Bones from metacarpal to distal phalanx.
    :param base: Port at the digit's base, welded to the first bone.
    :param tip: Alias to the last bone's tip port.
    :param hinges: Inter-bone hinge joints (length ``len(bones) - 1``).
    :param weld_base: Weld holding ``base`` -> ``bones[0].base``.
    :param excludes: Unhandled ``disable_pair_collisions`` terms (the op is
        typed ``None``); the compiler walks these to emit exclusions.
    """

    bones: tuple[Bone, ...]
    base: Port
    tip: Port
    hinges: tuple[joints.Hinge, ...]
    weld_base: joints.Weld
    excludes: tuple[Term | None, ...]

    @classmethod
    def make(cls, dp: DigitParams) -> Self:
        """Build a :class:`Digit` from a single-digit parameter bundle.

        :param dp: Digit parameters, in mm quantities.
        """
        with frame() as pose:
            bones = tuple(
                Bone.make(
                    length=dp.bone_lengths[i],
                    prox=JointEnd(
                        dp.joint_diameters[i],
                        dp.joint_widths[i],
                        dp.joint_configs[i][0],
                    ),
                    dist=JointEnd(
                        dp.joint_diameters[i + 1],
                        dp.joint_widths[i + 1],
                        dp.joint_configs[i][1],
                    ),
                    lig=dp.lig,
                    pulley=dp.pulley,
                )
                for i in range(len(dp.joint_configs))
            )

            # Distal phalanx overlaps the proximal phalanx's joint sphere at
            # qpos=0.
            excludes = (
                (disable_pair_collisions(bones[-1], bones[1]),)
                if len(bones) >= 4
                else ()
            )

            base = Port()
            weld_base = joints.Weld(base, bones[0].base)

            hinges = tuple(
                joints.Hinge(
                    parent.tip,
                    child.base,
                    axis=jnp.array([1.0, 0.0, 0.0]),
                    range=(-1.2, 1.2),
                    damping=0.01,
                )
                for parent, child in zip(bones[:-1], bones[1:])
            )
            digit = cls(
                pose=pose,
                bones=bones,
                base=base,
                tip=bones[-1].tip,
                hinges=hinges,
                weld_base=weld_base,
                excludes=excludes,
            )
            assert_transform(digit, base)
        return digit


def _cable(
    hinges: tuple[joints.Hinge, ...],
    moment_arms: tuple[float, ...],
    stiffness: float,
) -> tendons.FixedTendon:
    """A tension-only spring with constant moment arms, in metres.

    All OPH hinges and mixer joints travel less than one revolution. The
    lower deadband endpoint covers that travel with room for limit overshoot.
    """
    return tendons.FixedTendon(
        joints=hinges,
        gear_ratios=moment_arms,
        stiffness=stiffness,
        rest_length=(-math.tau * sum(abs(arm) for arm in moment_arms), 0.0),
    )


# ---------------------------------------------------------------------------
# Palm — computes its own geometry from HandParams
# ---------------------------------------------------------------------------
@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class Palm(Component):
    """Palm plate that derives size, digit poses, and ports from params.

    Pure-data dataclass: every field is populated by :meth:`make`.

    :param shape: Palm plate cuboid sized to cover the digit origins.
    :param base: Port at the palm's local frame origin.
    :param finger_ports: One port per finger, splayed per the params.
    :param thumb_ports: One port per thumb.
    """

    shape: shapes.Shape
    base: Port
    finger_ports: tuple[Port, ...]
    thumb_ports: tuple[Port, ...]

    @classmethod
    def make(
        cls,
        params: HandParams,
        n_fingers: int,
        n_thumbs: int,
    ) -> Self:
        """Build a :class:`Palm` from hand parameters.

        :param params: Hand parameters, in mm and degree quantities.
        :param n_fingers: Number of finger ports (capped by the params).
        :param n_thumbs: Number of thumb ports (capped by the params).
        """
        origins_f = jnp.asarray(params.origins_finger.to("m").value)
        origins_t = jnp.asarray(params.origins_thumb.to("m").value)
        angles_f = jnp.asarray(params.angles_finger.to("rad").value)
        angles_t = jnp.asarray(params.angles_thumb.to("rad").value)
        n_f = min(n_fingers, origins_f.shape[0])
        n_t = min(n_thumbs, origins_t.shape[0])

        with frame() as pose:
            # Compute digit poses (splay + base rotation + unit scaling)
            finger_poses = [
                Pose(pos=origins_f[i], rv=angles_f[i]) @ _BASE_ROT for i in range(n_f)
            ]
            thumb_poses = [
                Pose(pos=origins_t[i], rv=angles_t[i]) @ _BASE_ROT for i in range(n_t)
            ]

            # Derive palm dimensions from the digit origin positions (metres)
            if n_f + n_t > 0:
                xyz = jnp.concatenate([origins_f[:n_f], origins_t[:n_t]])
                pad = 0.020
                dxyz = jnp.maximum(
                    xyz.max(axis=0) - xyz.min(axis=0) + pad,
                    jnp.array([0.020, 0.020, 0.040]),
                )
                center = (xyz.min(axis=0) + xyz.max(axis=0)) / 2
            else:
                dxyz = jnp.array([0.020, 0.060, 0.080])
                center = jnp.zeros(3)

            shape = shapes.translate(
                shapes.centered_cube(*dxyz.tolist()),
                center.tolist(),
            )

            base = Port()
            fports = tuple(Port() for _ in finger_poses)
            tports = tuple(Port() for _ in thumb_poses)
            palm = cls(
                pose=pose,
                shape=shape,
                base=base,
                finger_ports=fports,
                thumb_ports=tports,
            )
            assert_transform(palm, base)
            for port, digit_pose in zip(fports, finger_poses):
                assert_transform(palm, port, digit_pose)
            for port, digit_pose in zip(tports, thumb_poses):
                assert_transform(palm, port, digit_pose)
        return palm


# ---------------------------------------------------------------------------
# OpenParametricHand — full assembly
# ---------------------------------------------------------------------------
@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class OpenParametricHand(Component):
    """Open parametric hand assembled from a palm and hinge-mounted digits.

    Pure-data dataclass: every field is populated by :meth:`make`; pass a
    :class:`HandParams` to override the stock ``parameters.scad`` anatomy.

    :param base: Port at the hand's local frame origin.
    :param tip: Alias to the first digit's tip (the hand's reference
        fingertip).
    :param fingertips: One tip port per digit, fingers then thumbs. This is
        the grip-point interface the grasp losses and the cube placement
        walk; :class:`~robotl.examples.hand_with_wrist.HandWithWrist`
        forwards it when the hand is mounted on a wrist.
    :param palm: Palm plate carrying the digit mount ports.
    :param weld_palm: Weld holding ``base`` -> ``palm.base``.
    :param fingers: Finger digits, one per palm finger port.
    :param thumbs: Thumb digits, one per palm thumb port.
    :param base_joints: Metacarpal hinge per digit, at its palm port.
    :param motors: Intermediate/opposition mixer, then distal-flexor mixer.
    :param motor_welds: Mixer housings attached behind the palm.
    :param tendons: Active series-elastic cables and passive antagonist cables.
    :param excludes: Unhandled ``disable_pair_collisions`` terms (the op is
        typed ``None``); the compiler walks these to emit exclusions.
    """

    base: Port
    tip: Port
    fingertips: tuple[Port, ...]
    palm: Palm
    weld_palm: joints.Weld
    fingers: tuple[Digit, ...]
    thumbs: tuple[Digit, ...]
    base_joints: tuple[joints.Hinge, ...]
    motors: tuple[X430, X430]
    motor_welds: tuple[joints.Weld, joints.Weld]
    tendons: tuple[tendons.FixedTendon, ...]
    excludes: tuple[Term | None, ...]

    @classmethod
    def make(
        cls,
        params: HandParams | None = None,
        n_fingers: int = 4,
        n_thumbs: int = 1,
        *,
        motor_model: X430Model = "XL430-W250",
        motor_supply: Volt = volt(11.1),
    ) -> Self:
        """Build an :class:`OpenParametricHand`.

        :param params: Hand anatomy; stock ``parameters.scad`` values when
            ``None``.
        :param n_fingers: Number of fingers.
        :param n_thumbs: Number of thumbs.
        :param motor_model: Model of both mixer motors.
        :param motor_supply: Both motor supplies; defaults to the ROBOTIS
            recommended 11.1 V, not a reported voltage from the OPH paper.
        """
        p = params or HandParams()
        joint_axis = jnp.array([0.0, 1.0, 0.0])
        joint_range = (-1.2, 1.2)

        with frame() as pose:
            base = Port()
            palm = Palm.make(params=p, n_fingers=n_fingers, n_thumbs=n_thumbs)
            weld_palm = joints.Weld(
                base, palm.base, Pose(pos=[_MOUNT_CLEARANCE, 0.0, 0.0])
            )

            fingers = []
            thumbs = []
            base_joints = []
            excludes: list[Term | None] = []

            # --- Fingers ---
            for i, fport in enumerate(palm.finger_ports):
                digit = Digit.make(dp=p.finger(i))
                # Metacarpal overlaps the palm at the base joint.
                excludes.append(disable_pair_collisions(palm, digit.bones[0]))
                base_joints.append(
                    joints.Hinge(
                        fport,
                        digit.base,
                        axis=joint_axis,
                        range=joint_range,
                        damping=0.01,
                    )
                )
                fingers.append(digit)

            # --- Thumbs ---
            for i, tport in enumerate(palm.thumb_ports):
                digit = Digit.make(dp=p.thumb(i))
                # Metacarpal sits inside the palm; on top of that the thumb's
                # large splay drives the proximal phalanx through the palm
                # geometry.
                excludes.append(disable_pair_collisions(palm, digit.bones[0]))
                if len(digit.bones) >= 2:
                    excludes.append(disable_pair_collisions(palm, digit.bones[1]))
                base_joints.append(
                    joints.Hinge(
                        tport,
                        digit.base,
                        axis=joint_axis,
                        range=joint_range,
                        damping=0.01,
                    )
                )
                thumbs.append(digit)

            # Adjacent fingers' metacarpals and proximal phalanges sit close
            # enough at rest that their tapered cuboid bodies overlap; exclude
            # the pairs.
            for a, b in zip(fingers[:-1], fingers[1:]):
                excludes.extend(
                    disable_pair_collisions(a.bones[k], b.bones[k])
                    for k in (0, 1)
                    if k < len(a.bones) and k < len(b.bones)
                )

            digits = (*fingers, *thumbs)
            if not digits:
                raise ValueError("OpenParametricHand needs at least one digit")
            digit_params = [
                *(p.finger(i) for i in range(len(fingers))),
                *(p.thumb(i) for i in range(len(thumbs))),
            ]
            mixer_radii = [
                float(dp.joint_diameters[1].to("m").value)
                * (
                    (18.3, 19.4, 18.3, 16.0)[i] / (12.5, 14, 12.5, 11)[i]
                    if i < len(fingers)
                    else 21 / 16
                )
                for i, dp in enumerate(digit_params)
            ]
            spool_radius = max(mixer_radii)
            motors = (
                X430.make(
                    model=motor_model,
                    supply=motor_supply,
                    spool_radius=mm(spool_radius * 1000),
                    rot_range=(0.0, math.pi / 2),
                ),
                X430.make(
                    model=motor_model,
                    supply=motor_supply,
                    spool_radius=mm(spool_radius * 1000),
                    rot_range=(0.0, math.pi / 2),
                ),
            )
            first_motor_weld, second_motor_weld = (
                joints.Weld(
                    base,
                    motor.base,
                    Pose(
                        pos=[
                            _MOUNT_CLEARANCE - spool_radius - 0.01,
                            0.02,
                            -0.025 - i * 0.06,
                        ]
                    ),
                )
                for i, motor in enumerate(motors)
            )

            cables = []
            for i, (digit, base_joint, dp, mixer_radius) in enumerate(
                zip((*fingers, *thumbs), base_joints, digit_params, mixer_radii)
            ):
                is_thumb = i >= len(fingers)
                arms = tuple(
                    float(d.to("m").value) / 2
                    for d in dp.joint_diameters[1 : len(digit.bones)]
                )
                base_arm = float(dp.joint_diameters[0].to("m").value) / 2
                cables.append(
                    _cable(
                        (motors[1].hinge, *digit.hinges),
                        (mixer_radius, *(-arm for arm in arms)),
                        870.0,
                    )
                )
                cables.append(_cable(digit.hinges, arms, 320.0))
                if digit.hinges[:-1]:
                    intermediate = digit.hinges[:-1]
                    flexion_arms = tuple(-arm for arm in arms[:-1])
                    if is_thumb or i == 0:
                        cables.append(
                            _cable(
                                (motors[0].hinge, *intermediate),
                                (mixer_radius, *flexion_arms),
                                870.0,
                            )
                        )
                    else:
                        cables.append(_cable(intermediate, flexion_arms, 320.0))
                for sign in (-1, 1):
                    if is_thumb:
                        cables.append(
                            _cable(
                                (motors[0].hinge, base_joint),
                                (mixer_radius, sign * base_arm),
                                870.0,
                            )
                        )
                    else:
                        cables.append(_cable((base_joint,), (sign * base_arm,), 110.0))
                if is_thumb:
                    cables.append(
                        _cable(
                            (base_joint,),
                            (-base_arm,),
                            320.0,
                        )
                    )

            hand = cls(
                pose=pose,
                base=base,
                tip=digits[0].tip,
                fingertips=tuple(d.tip for d in digits),
                palm=palm,
                weld_palm=weld_palm,
                fingers=tuple(fingers),
                thumbs=tuple(thumbs),
                base_joints=tuple(base_joints),
                motors=motors,
                motor_welds=(first_motor_weld, second_motor_weld),
                tendons=tuple(cables),
                excludes=tuple(excludes),
            )
            assert_transform(hand, base)
        return hand


if __name__ == "__main__":
    view_model(lambda: Based.make(OpenParametricHand.make()))

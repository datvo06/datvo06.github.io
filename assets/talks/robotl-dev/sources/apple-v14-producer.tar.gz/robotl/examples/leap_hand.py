import logging
import math
import sys

import effectful.handlers.jax.numpy as jnp
import effectful.handlers.numpyro as dist

from robotl.examples.based import Based
from robotl.examples.dynamixel import POLYCARBONATE, Motor
from robotl.handlers.cad.face import face
from robotl.handlers.cad.support import non_overlap
from robotl.handlers.mujoco import view_model
from robotl.ops import joints, shapes
from robotl.ops.coords import Rotation
from robotl.ops.shapes import cube, sphere, transform, translate
from robotl.ops.syntax import Component, Port, Pose, choose, constrain, defcomponent

MM_SCALE = 1e-3  # measurements in millimeters, scaled to meters

NEG_Z = Rotation.from_euler("x", 180, degrees=True)
POS_X = Rotation.from_euler("y", 90, degrees=True)
NEG_X = Rotation.from_euler("y", -90, degrees=True)
POS_Y = Rotation.from_euler("x", 90, degrees=True)
NEG_Y = Rotation.from_euler("x", -90, degrees=True)
ROT_Z_90 = Pose(rot=Rotation.from_euler("z", 90, degrees=True))
ROT_Z_NEG_90 = Pose(rot=Rotation.from_euler("z", -90, degrees=True))


@defcomponent
def LeapHand(
    self,
    palm: Component | None = None,
    finger_tips: list[Component] | None = None,
    thumb_tip: Component | None = None,
    middle_length_mm: float = 6.0,
    lateral_lower_mm: float = 22.0,
    lateral_upper_mm: float = 28.6,
):
    """LEAP hand with pluggable palm shape and configurable finger spacers.

    :param palm: optional palm component. Must expose ``base``,
        ``finger_mounts`` (a list) and ``thumb_mount`` ports. Defaults to
        :func:`RectangularPalm`.
    :param finger_tips: optional per-finger tip components. Defaults to
        :class:`CapsuleTip` for every mount.
    :param thumb_tip: optional thumb tip component.
    :param middle_length_mm: see :func:`Finger`.
    :param lateral_lower_mm: see :func:`Finger`.
    :param lateral_upper_mm: see :func:`Finger`.

    ``non_overlap`` between adjacent proximal motors is only applied when
    finger positions are stochastic (e.g. the Dirichlet-sampled rail on
    :func:`RectangularPalm`). Palms that fix finger positions analytically
    (circular, triangular) opt out via ``stochastic_finger_positions=False``.
    """
    self.palm = palm if palm is not None else RectangularPalm()
    self.base = self.place(Port(), Pose(rv=-jnp.pi / 2 * jnp.array([0, 0, 1])))
    self.origin = self.place(Port())
    self._palm_weld = joints.Weld(self.origin, self.palm.base)

    finger_tips_or_none = (
        [None] * len(self.palm.finger_mounts) if finger_tips is None else finger_tips
    )
    assert len(finger_tips_or_none) == len(self.palm.finger_mounts)

    self.fingers = [
        Finger(
            tip=t,
            middle_length_mm=middle_length_mm,
            lateral_lower_mm=lateral_lower_mm,
            lateral_upper_mm=lateral_upper_mm,
        )
        for t in finger_tips_or_none
    ]
    if self.palm.stochastic_finger_positions:
        for i in range(len(self.fingers) - 1):
            constrain(
                non_overlap(
                    self.fingers[i].proximal_motor.hinge,
                    self.fingers[i + 1].proximal_motor.hinge,
                )
            )

    self._finger_welds = [
        joints.Weld(mount, finger.base, pose=ROT_Z_90)
        for mount, finger in zip(self.palm.finger_mounts, self.fingers)
    ]

    self.thumb = Thumb(tip=thumb_tip)
    self._thumb_weld = joints.Weld(self.palm.thumb_mount, self.thumb.base)
    self.fingertips = [finger.tip for finger in [*self.fingers, self.thumb]]
    self.tip = self.fingertips[0]


@defcomponent
def RectangularPalm(self, n_fingers=3, palm_width=0.08):
    """Stock LEAP palm with fingers along one rail.

    Finger Y positions are stochastic — sampled from a Dirichlet over
    ``n_fingers + 1`` gaps along the rail. ``LeapHand`` adds
    ``non_overlap`` constraints between adjacent proximal motors which,
    combined with the Dirichlet, give a unique non-overlapping layout per
    sample.
    """
    self.stochastic_finger_positions = True
    # Reference edges shared by multiple boxes
    near_x = -0.02  # finger-side edge (rail, body)
    top_y = 0.025  # wrist-side edge (rail, body, ledge)
    top_z = 0.012  # front face (rail, ledge)
    far_x = near_x - palm_width  # thumb-side edge

    # Main body half-depth (z), shared by body and lower sections
    body_hz = 0.023
    body_z = -body_hz / 2

    # Lower palm and top ledge: scale with palm_width.
    # Inner edge stays fixed where lower palm meets the body.
    lower_inner_x = -0.056
    lower_hx = (lower_inner_x - far_x) / 2 + 0.01
    lower_x = (lower_inner_x + far_x) / 2
    lower_hy = 0.026
    lower_y = -0.053

    bridge_hx, bridge_hy, bridge_hz = 0.002, 0.018, 0.017
    bridge_z = -0.006

    rail_hx, rail_hy, rail_hz = 0.01, 0.06, 0.015
    ledge_hy, ledge_hz = 0.028, 0.002

    # All dims below are full extents (twice the half-extents above).
    rail = translate(
        shapes.centered_cube(2 * rail_hx, 2 * rail_hy, 2 * rail_hz),
        [near_x - rail_hx, top_y - rail_hy, top_z - rail_hz],
    )

    lower_palm = translate(
        shapes.centered_cube(2 * lower_hx, 2 * lower_hy, 2 * body_hz),
        [lower_x + 0.01, lower_y, body_z],
    )

    self.shape = shapes.union(
        rail,  # Finger-side rail: right edge at near_x, top at top_y, front at top_z
        lower_palm,  # Lower palm
        # Thumb bridge: sits on top of lower palm, at far edge
        translate(
            shapes.centered_cube(2 * bridge_hx, 2 * bridge_hy, 2 * bridge_hz),
            [far_x + bridge_hx, lower_y + lower_hy + bridge_hy, bridge_z],
        ),
        # Top ledge: top at top_y, front at top_z
        translate(
            shapes.centered_cube(2 * lower_hx, 2 * ledge_hy, 2 * ledge_hz),
            [lower_x + 0.01, top_y - ledge_hy, top_z - ledge_hz],
        ),
        transform(
            shapes.centered_cube(0.058, 0.02, 2 * body_hz),
            Pose(pos=[-0.066 + 0.01, -0.078, body_z], quat=[0.989016, 0, 0, -0.147806]),
        ),
        transform(
            shapes.centered_cube(0.01, 0.12, 0.02),
            Pose(pos=[-0.032, -0.035, -0.024], quat=[0.923956, 0, 0.382499, 0]),
        ),
    )
    self.material = POLYCARBONATE

    back_face = face(lower_palm, "-x")
    back_face_left_center = (back_face.lower_right + back_face.upper_right) / 2
    self.base = self.place(Port(), Pose(pos=back_face_left_center, rot=POS_X))

    # Place finger mounts evenly along the max-x face of the finger rail.
    x = near_x + 1e-4
    z = top_z - rail_hz

    y_lo = top_y - 2 * rail_hy + 0.01
    y_hi = top_y - 0.01
    gaps = choose(dist.Dirichlet(jnp.ones(n_fingers + 1)))
    cumulative = jnp.cumsum(gaps[:-1])  # n values in (0, 1), sorted
    finger_y_positions = y_lo + (y_hi - y_lo) * cumulative
    finger_positions = [
        jnp.array([x, finger_y_positions[i], z]) for i in range(n_fingers)
    ]

    self.thumb_mount = self.place(
        Port(), Pose(pos=[-0.0693 + 0.015, -0.0012 - 0.015, -0.0216], rot=POS_Y)
    )
    self.finger_mounts = [
        self.place(Port(), Pose(pos=pos, rot=NEG_X)) for pos in finger_positions
    ]


@defcomponent
def CubeTip(self):
    dim = [20, 23, 34]  # Eyeball measurements
    self.shape = shapes.scale(cube(*dim), jnp.full([3], MM_SCALE))
    self.material = POLYCARBONATE
    self.base = self.place(Port(), Pose(pos=face(self.shape, "-z").center))


@defcomponent
def BallTip(self, radius_ratio: float = 1.0):
    """A square base with a ball tip. Radius of the tip is relative to the base size."""
    base_xy_dim = 20
    base_z_dim = 10
    base_dim = [base_xy_dim, base_xy_dim, base_z_dim]

    radius = radius_ratio * base_xy_dim / 2

    base = shapes.scale(
        translate(cube(*base_dim), [-base_xy_dim / 2, -base_xy_dim / 2, -base_z_dim]),
        jnp.full([3], MM_SCALE),
    )
    ball = shapes.scale(
        translate(sphere(radius), [0, 0, radius - base_z_dim]), jnp.full([3], MM_SCALE)
    )
    self.shape = shapes.union(base, ball)
    self.material = POLYCARBONATE
    self.base = self.place(Port(), Pose(pos=face(base, "-z").center))


@defcomponent
def CapsuleTip(self, radius_ratio: float = 1.0, height_ratio: float = 1.0):
    """A square base with a capsule tip. Radius and height of the tip are relative to the base size."""
    base_xy_dim = 20
    base_z_dim = 10
    base_dim = [base_xy_dim, base_xy_dim, base_z_dim]

    radius = radius_ratio * base_xy_dim / 2
    height = height_ratio * base_xy_dim / 2

    base = shapes.scale(
        translate(cube(*base_dim), [-base_xy_dim / 2, -base_xy_dim / 2, -base_z_dim]),
        jnp.full([3], MM_SCALE),
    )
    tip = shapes.scale(
        translate(shapes.capsule(r=radius, h=height), [0, 0, radius - base_z_dim]),
        jnp.full([3], MM_SCALE),
    )
    self.shape = shapes.union(base, tip)
    self.material = POLYCARBONATE
    self.base = self.place(Port(), Pose(pos=face(base, "-z").center))


@defcomponent
def CylinderTip(
    self,
    lower_radius_ratio: float = 1.0,
    upper_radius_ratio: float = 0.5,
    height_ratio: float = 3.0,
):
    """A square base with a capsule tip. Radius and height of the tip are relative to the base size."""
    base_xy_dim = 20
    base_z_dim = 10
    base_dim = [base_xy_dim, base_xy_dim, base_z_dim]

    lower_radius = lower_radius_ratio * base_xy_dim / 2
    upper_radius = upper_radius_ratio * base_xy_dim / 2
    height = height_ratio * base_xy_dim / 2

    base = shapes.scale(
        translate(cube(*base_dim), [-base_xy_dim / 2, -base_xy_dim / 2, -base_z_dim]),
        jnp.full([3], MM_SCALE),
    )
    tip = shapes.scale(
        shapes.cylinder(r=lower_radius, r2=upper_radius, h=height),
        jnp.full([3], MM_SCALE),
    )
    self.shape = shapes.union(base, tip)
    self.material = POLYCARBONATE
    self.base = self.place(Port(), Pose(pos=face(base, "-z").center))


@defcomponent
def HookTip(
    self,
    radius_ratio: float = 1.0,
    height_ratio: float = 1.0,
    void_radius_ratio: float = 0.75,
    void_inset_ratio: float = 1.0,
):
    """A square base with a capsule tip with a hook. Radius and height of the
    tip and inner radius of the hook are relative to the base size. Inset of the
    hook is relative to the hook inner radius.

    """
    base_xy_dim = 20
    base_z_dim = 10
    base_dim = [base_xy_dim, base_xy_dim, base_z_dim]

    radius = radius_ratio * base_xy_dim / 2
    height = height_ratio * base_xy_dim / 2
    void_height = base_xy_dim * 2
    void_radius = void_radius_ratio * base_xy_dim / 2
    void_y_inset = void_radius * void_inset_ratio

    base = shapes.scale(
        translate(cube(*base_dim), [-base_xy_dim / 2, -base_xy_dim / 2, -base_z_dim]),
        jnp.full([3], MM_SCALE),
    )
    tip = shapes.scale(
        translate(shapes.capsule(r=radius, h=height), [0, 0, radius - base_z_dim]),
        jnp.full([3], MM_SCALE),
    )
    void = shapes.scale(
        translate(
            transform(
                shapes.cylinder(r=void_radius, h=base_xy_dim * 2),
                Pose(rot=Rotation.from_euler("y", 90, degrees=True)),
            ),
            [-void_height / 2, radius + void_radius - void_y_inset, height],
        ),
        jnp.full([3], MM_SCALE),
    )
    self.shape = shapes.union(base, shapes.difference(tip, void))
    self.material = POLYCARBONATE
    self.base = self.place(Port(), Pose(pos=face(base, "-z").center))


@defcomponent
def MiddleSpacer(self, length_mm: float = 6.0):
    """Z-axis spacer plate between the middle and distal motors.

    :param length_mm: cube extent along the base→tip (Z) axis.
        Default 6 mm matches the stock LEAP plate.
    """
    self.shape = shapes.scale(cube(28.6, 17, length_mm), jnp.full([3], MM_SCALE))
    self.material = POLYCARBONATE
    self.base = self.place(Port(), Pose(pos=face(self.shape, "-z").center))
    self.tip = self.place(Port(), Pose(pos=face(self.shape, "+z").center, rot=NEG_Z))


@defcomponent
def LateralSpacer(self, lower_height_mm: float = 22.0, upper_height_mm: float = 28.6):
    """L-shaped spacer linking the lateral motor to the proximal motor.

    :param lower_height_mm: proximal-leg height.
    :param upper_height_mm: distal-leg height.
    """
    upper_thickness = 9
    upper_width = 20
    lower_thickness = upper_thickness / 3
    lower_width = 34.6
    lower = shapes.scale(
        cube(lower_width, lower_thickness, lower_height_mm), jnp.full([3], MM_SCALE)
    )
    upper = shapes.scale(
        shapes.translate(
            cube(upper_width, upper_thickness, upper_height_mm),
            jnp.array([lower_width / 2 - upper_width / 2, 0, lower_height_mm]),
        ),
        jnp.full([3], MM_SCALE),
    )
    self.shape = shapes.union(lower, upper)
    self.material = POLYCARBONATE
    self.base = self.place(Port(), Pose(pos=face(lower, "-y").center, rot=NEG_Y))
    self.tip = self.place(Port(), Pose(pos=face(upper, "+y").center, rot=POS_Y))


@defcomponent
def Finger(
    self,
    tip: Component | None = None,
    middle_length_mm: float = 6.0,
    lateral_lower_mm: float = 22.0,
    lateral_upper_mm: float = 28.6,
):
    """4-motor LEAP-style finger.

    :param tip: fingertip component, defaults to :class:`CapsuleTip`.
    :param middle_length_mm: see :func:`MiddleSpacer`.
    :param lateral_lower_mm: see :func:`LateralSpacer`.
    :param lateral_upper_mm: see :func:`LateralSpacer`.
    """
    self.tip = CapsuleTip() if tip is None else tip
    self.distal_motor = Motor(hinge=True, left=True, initial_rotation=-math.pi / 2)
    self.middle_spacer = MiddleSpacer(length_mm=middle_length_mm)
    self.middle_motor = Motor(hinge=True, right=True)
    self.lateral_motor = Motor(upper=True, initial_rotation=-math.pi)
    self.lateral_spacer = LateralSpacer(
        lower_height_mm=lateral_lower_mm, upper_height_mm=lateral_upper_mm
    )
    self.proximal_motor = Motor(hinge=True, left=True, initial_rotation=-math.pi / 2)
    self.base = self.place(Port())

    self.joints = [
        joints.Weld(self.base, self.proximal_motor.left.lower),
        joints.Weld(self.tip.base, self.distal_motor.hinge.tip),
        joints.Weld(self.distal_motor.left.upper, self.middle_spacer.tip),
        joints.Weld(
            self.middle_spacer.base, self.middle_motor.hinge.tip, pose=ROT_Z_90
        ),
        joints.Weld(self.middle_motor.right.upper, self.lateral_motor.motor.rot_front),
        joints.Weld(
            self.lateral_motor.upper.tip, self.lateral_spacer.tip, pose=ROT_Z_90
        ),
        joints.Weld(
            self.lateral_spacer.base, self.proximal_motor.hinge.tip, pose=ROT_Z_NEG_90
        ),
    ]


@defcomponent
def Thumb(self, tip: Component | None = None):
    self.tip = CapsuleTip() if tip is None else tip
    self.distal_motor = Motor(hinge=True, lower=True)
    self.middle_motor = Motor(hinge=True, lower=True)
    self.lateral_motor = Motor(right=True)
    self.proximal_motor = Motor(lower=True, initial_rotation=math.pi / 2)
    self.base = self.place(Port())

    # TODO nasty hack resulting from port semantics
    port_flip_hack = Pose(
        pos=[0, 0, 0.005],
        rot=Rotation.from_euler("y", 180, degrees=True),
    ) @ Pose(rot=Rotation.from_euler("z", 90, degrees=True))

    self.joints = [
        joints.Weld(self.base, self.proximal_motor.lower.base),
        joints.Weld(self.tip.base, self.distal_motor.lower.tip, pose=ROT_Z_90),
        joints.Weld(
            self.distal_motor.hinge.tip,
            self.middle_motor.lower.base,
            pose=port_flip_hack,
        ),
        joints.Weld(self.middle_motor.hinge.tip, self.lateral_motor.motor.rot_front),
        joints.Weld(
            self.lateral_motor.right.lower, self.proximal_motor.motor.rot_front
        ),
    ]


if __name__ == "__main__":
    log = logging.getLogger("robotl")
    log.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s %(name)s %(levelname)s: %(message)s", datefmt="%H:%M:%S"
        )
    )
    log.addHandler(handler)
    view_model(lambda: Based.make(LeapHand()), debug_ports=True)

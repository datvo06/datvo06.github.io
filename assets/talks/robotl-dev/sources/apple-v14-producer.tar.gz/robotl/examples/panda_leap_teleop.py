"""Keyboard control of Panda and LEAP in a YCB scene, with pose recording and replay.

W/S, D/A, R/F move the wrist along world X/Y/Z. Arrows rotate yaw/pitch;
Z/X rotate roll. Space curls finger bases and distal joints, O opens them.
Brackets select a hand joint, comma/period change its target. J toggles arm
joint control: left/right select a joint, up/down change its target. H returns home.

Run with ``--object 013_apple --mesh-path PATH --output RUN_DIRECTORY``.
On macOS use ``mjpython -m robotl.examples.panda_leap_teleop``. The passive
viewer reports key presses, so each press changes a target by a fixed step.
Recordings contain world poses in metres and wxyz quaternions, joint states,
servo targets, and the compiled model. Replay with ``--replay RUN/recording.npz``.
For headless actuation, ``--key-script FILE --headless --duration SECONDS`` reads
``{"events": [{"time_s": 0, "key": "W"}, {"time_s": 0.2, "key": "SPACE"}]}``.
"""

import argparse
import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field, replace
from datetime import datetime
from enum import StrEnum
from itertools import combinations
from pathlib import Path
from queue import SimpleQueue
from typing import Literal, NamedTuple, Self

import glfw  # type: ignore[import-untyped]
import jax
import jax.numpy as jnp
import mediapy
import mujoco
import mujoco.viewer
import numpy as np
from effectful.ops.types import Term
from numpy.typing import NDArray
from pydantic import BaseModel, ConfigDict, Field
from scipy.spatial.transform import Rotation

from robotl.examples.based import Based
from robotl.examples.leap_hand_menagerie import (
    DigitDims,
    LeapHandConfig,
)
from robotl.examples.panda_leap import PandaLeapHand, set_home
from robotl.examples.ycb_artifacts import OBJECT_CONFIGS, YCBObject
from robotl.handlers.cad.bbox import bbox_from_shape
from robotl.handlers.cad.decomposition import as_trimesh
from robotl.handlers.mujoco import compile_model
from robotl.handlers.mujoco.compiler import MujocoContext, make_context
from robotl.handlers.mujoco.config import MujocoSettings
from robotl.handlers.mujoco.control.ik_solver import site_pose_ik_step
from robotl.handlers.mujoco.mappings import Layout
from robotl.ops import actuators, joints, shapes
from robotl.ops.coords import Angle, AngleTangent, ScalarTorque
from robotl.ops.id import Id
from robotl.ops.syntax import (
    Component,
    Origin,
    Port,
    Pose,
    assert_transform,
    disable_pair_collisions,
    frame,
)
from robotl.ops.units import kg

type FloatArray = NDArray[np.float64]


class HandDesign(BaseModel):
    """Distal spacer scales with stock motors, palm and joint count."""

    model_config = ConfigDict(extra="forbid")

    finger_distal_scale: float = Field(default=1.0, ge=0.8, le=1.2)
    thumb_distal_scale: float = Field(default=1.0, ge=0.8, le=1.2)

    def leap_config(self, friction: float | None = None) -> LeapHandConfig:
        """Resolve physical spacer geometry and accurate visual representation."""
        fingers, thumb = DigitDims.default(4), DigitDims.default(4)
        fingers.lengths[-1] = self.finger_distal_scale
        thumb.lengths[-1] = self.thumb_distal_scale
        return LeapHandConfig(
            friction=friction,
            finger_dims=fingers,
            thumb_dims=thumb,
            use_meshes=self.finger_distal_scale == self.thumb_distal_scale == 1.0,
        )


class SceneConfig(BaseModel):
    """YCB placement and collision decomposition settings."""

    object_name: str
    mesh_path: Path
    object_xy_m: tuple[float, float] = (0.4, 0.0)
    object_yaw_rad: float = 0.0
    object_tilt_rad: tuple[float, float] = (0.0, 0.0)
    object_mass_kg: float | None = Field(default=None, gt=0)
    grasp_friction: float | None = Field(default=None, gt=0)
    grasp_point_m: tuple[float, float, float] | None = None
    max_parts: int | None = Field(default=6, ge=1)
    hand_design: HandDesign = Field(default_factory=HandDesign)
    timestep_s: float = Field(default=MujocoSettings.standard().dt, gt=0)


class SitePoseReference(BaseModel):
    """A named site frame in the compiled model."""

    name: str
    site_name: str


class BodyPoseReference(BaseModel):
    """A named body frame in the compiled model."""

    name: str
    body_name: str


type PoseReference = SitePoseReference | BodyPoseReference


class RunInfo(BaseModel):
    """Scene provenance and the coordinate convention of a recording."""

    scene: SceneConfig
    pose_frame: Literal["world"] = "world"
    quaternion_order: Literal["wxyz"] = "wxyz"
    poses: list[PoseReference]
    actuator_names: list[str]


class ArtifactPose(BaseModel):
    """Position in metres and quaternion in the recorded frame."""

    position_m: tuple[float, float, float]
    orientation_wxyz: tuple[float, float, float, float]


class FinalState(BaseModel):
    """Artifact placements and servo targets for a completed recording."""

    time_s: float
    frame: Literal["world"]
    quaternion_order: Literal["wxyz"]
    poses: dict[str, ArtifactPose]
    qpos: list[float]
    qvel: list[float]
    actuator_targets_rad: dict[str, float]


class Key(StrEnum):
    """Commands supported by the keyboard controller and key-script format."""

    W = "W"
    S = "S"
    D = "D"
    A = "A"
    R = "R"
    F = "F"
    LEFT = "LEFT"
    RIGHT = "RIGHT"
    UP = "UP"
    DOWN = "DOWN"
    Z = "Z"
    X = "X"
    SPACE = "SPACE"
    O = "O"
    LEFT_BRACKET = "LEFT_BRACKET"
    RIGHT_BRACKET = "RIGHT_BRACKET"
    COMMA = "COMMA"
    PERIOD = "PERIOD"
    J = "J"
    H = "H"


class KeyEvent(BaseModel):
    """One keyboard command at a simulation timestamp."""

    time_s: float = Field(ge=0)
    key: Key


class KeyScript(BaseModel):
    """Timed keyboard commands for headless actuation."""

    events: list[KeyEvent] = Field(default_factory=list)


def world_poses(data: mujoco.MjData, references: list[PoseReference]) -> FloatArray:
    """Return position and wxyz orientation for each referenced frame."""
    poses = []
    for reference in references:
        if isinstance(reference, SitePoseReference):
            site = data.site(reference.site_name)
            quat = np.empty(4)
            mujoco.mju_mat2Quat(quat, site.xmat)
            poses.append(np.r_[site.xpos, quat])
        else:
            body = data.body(reference.body_name)
            poses.append(np.r_[body.xpos, body.xquat])
    return np.stack(poses)


class Sample(NamedTuple):
    """Aligned state, applied control and poses at one physics timestamp."""

    time_s: float
    qpos: FloatArray
    qvel: FloatArray
    controls: FloatArray
    poses: FloatArray


@dataclass
class Recording:
    """One sample per physics step, including the initial state."""

    info: RunInfo
    initial_warmstart: FloatArray
    samples: list[Sample] = field(default_factory=list)
    keys: list[KeyEvent] = field(default_factory=list)

    def append(self, data: mujoco.MjData) -> None:
        """Capture the state and the controls that produced it."""
        self.samples.append(
            Sample(
                float(data.time),
                data.qpos.copy(),
                data.qvel.copy(),
                data.ctrl.copy(),
                world_poses(data, self.info.poses),
            )
        )

    def save(self, output: Path) -> None:
        """Save trace for --replay, keys for --key-script, and final poses for users."""
        np.savez_compressed(
            output / "recording.npz",
            time_s=np.asarray([sample.time_s for sample in self.samples]),
            qpos=np.stack([sample.qpos for sample in self.samples]),
            qvel=np.stack([sample.qvel for sample in self.samples]),
            ctrl=np.stack([sample.controls for sample in self.samples]),
            poses=np.stack([sample.poses for sample in self.samples]),
            initial_warmstart=self.initial_warmstart,
        )
        (output / "scene.json").write_text(self.info.model_dump_json(indent=2) + "\n")
        (output / "keys.json").write_text(
            KeyScript(events=self.keys).model_dump_json(indent=2) + "\n"
        )
        final = self.samples[-1]
        payload = FinalState(
            time_s=final.time_s,
            frame=self.info.pose_frame,
            quaternion_order=self.info.quaternion_order,
            poses={
                reference.name: ArtifactPose(
                    position_m=pose[:3].tolist(),
                    orientation_wxyz=pose[3:].tolist(),
                )
                for reference, pose in zip(self.info.poses, final.poses, strict=True)
            },
            qpos=final.qpos.tolist(),
            qvel=final.qvel.tolist(),
            actuator_targets_rad=dict(
                zip(self.info.actuator_names, final.controls.tolist(), strict=True)
            ),
        )
        (output / "final.json").write_text(payload.model_dump_json(indent=2) + "\n")


@dataclass(eq=False, kw_only=True)
class PandaLeapYcbAssembly(Component):
    """Physical arm, hand and free object attached through the base port."""

    robot: PandaLeapHand
    obj: YCBObject
    shape: shapes.Shape
    base: Port
    welds: tuple[joints.Weld]
    digit_exclusions: tuple[Term | None, ...]
    object_frame: Port
    grasp_point: FloatArray

    @classmethod
    def make(cls, config: SceneConfig) -> Self:
        """Construct the robot base attachment and free object's initial frame."""
        with frame() as pose:
            robot = PandaLeapHand.make(
                hand_config=config.hand_design.leap_config(
                    friction=config.grasp_friction
                )
            )
            obj = YCBObject.make(
                name=config.object_name,
                mesh_path=config.mesh_path,
                max_parts=config.max_parts,
                mass=kg(config.object_mass_kg)
                if config.object_mass_kg is not None
                else None,
                friction=config.grasp_friction,
            )
            base, object_frame = Port(), Port()
            welds = (joints.Weld(base, robot.base),)
            # The compiler consumes the unhandled exclusion terms.
            digit_exclusions = tuple(
                disable_pair_collisions(a.object, b.object)
                for digit in [*robot.hand.fingers, robot.hand.thumb]
                for a, b in combinations(
                    [
                        c
                        for id, c in make_context(digit).components.items()
                        if id != Origin.id
                    ],
                    2,
                )
            )
            rotation = Rotation.from_euler(
                "xyz", [*config.object_tilt_rad, config.object_yaw_rad]
            )
            bounds = bbox_from_shape(
                shapes.transform(
                    shapes.external_mesh(str(config.mesh_path)),
                    Pose(rv=rotation.as_rotvec()),
                )
            )
            object_pose = Pose(
                pos=jnp.array([*config.object_xy_m, -bounds.lo[2] + 0.002]),
                rv=rotation.as_rotvec(),
            )
            grasp_point = np.asarray(
                config.grasp_point_m
                if config.grasp_point_m is not None
                else (obj.whole_vertices.min(axis=0) + obj.whole_vertices.max(axis=0))
                / 2
            )
            assembly = cls(
                pose=pose,
                name="PandaLeapYcbAssembly",
                robot=robot,
                obj=obj,
                shape=shapes.plane(),
                base=base,
                welds=welds,
                digit_exclusions=digit_exclusions,
                object_frame=object_frame,
                grasp_point=grasp_point,
            )
            assert_transform(assembly, base)
            assert_transform(assembly, object_frame, object_pose)
            assert_transform(object_frame, obj)
        return assembly


@dataclass(eq=False, kw_only=True)
class PandaLeapYcbScene(Component):
    """World anchor for one physical Panda, LEAP and free-object assembly."""

    assembly: PandaLeapYcbAssembly
    base: Port
    welds: tuple[joints.Weld, joints.Weld]

    @classmethod
    def make(cls, config: SceneConfig) -> Self:
        """Anchor one physical assembly to the world."""
        assembly = PandaLeapYcbAssembly.make(config)
        return Based.anchor(
            assembly,
            lambda pose, base, welds: cls(
                pose=pose, assembly=assembly, base=base, welds=welds
            ),
        )


class KeyboardControl[Scene: PandaLeapYcbScene]:
    """Cartesian wrist targets and bounded joint targets for this assembly.

    The shared site-pose IK step changes only the seven arm joints, preserving
    independently teleoperated finger targets and reusing one kinematic state.
    """

    def __init__(
        self,
        robot: PandaLeapHand,
        context: MujocoContext,
        physics: mujoco.MjModel,
        data: mujoco.MjData,
        layout: Layout,
        *,
        scene: Scene,
    ) -> None:
        self.robot, self.context, self.physics, self.data, self.layout = (
            robot,
            context,
            physics,
            data,
            layout,
        )
        self.scene = scene
        self.flange = context.ports[robot.arm.tip.id].idx
        self.goal_position = data.site_xpos[self.flange].copy()
        self.goal_rotation = data.site_xmat[self.flange].reshape(3, 3).copy()
        self.home_position = self.goal_position.copy()
        self.home_rotation = self.goal_rotation.copy()
        self.arm_mode = False
        self.arm_joint = 0
        self.hand_joint = 0
        hand = robot.hand
        self.hand_actuators = [
            a
            for base, digit in zip(
                hand.actuators, [*hand.fingers, hand.thumb], strict=True
            )
            for a in [base, *digit.actuators]
        ]
        # Palm-to-digit joints belong to the hand; digit joint 0 stays independent.
        self.closing_actuators = [
            *hand.actuators,
            *[a for digit in [*hand.fingers, hand.thumb] for a in digit.actuators[1:]],
        ]
        self.actuators = [*robot.arm.hinge_actuators, *self.hand_actuators]
        self.targets: dict[Id, float] = {
            id: float(value.theta)
            for id, value in layout.u.unpack(jnp.asarray(data.ctrl)).items()
            if isinstance(value, Angle)
        }
        self.home_targets = self.targets.copy()
        self.dofs = np.array(
            [
                physics.jnt_dofadr[context.joints[hinge.id].idx]
                for hinge in robot.arm.hinges
            ]
        )
        self.kinematics = mujoco.MjData(physics)

    def change_joint(
        self,
        actuator: actuators.Position[Angle, AngleTangent, ScalarTorque],
        delta: float,
    ) -> None:
        """Change one servo target within its declared control range."""
        self.set_target(actuator, self.targets[actuator.id] + delta)

    def set_target(
        self,
        actuator: actuators.Position[Angle, AngleTangent, ScalarTorque],
        angle: float,
    ) -> None:
        """Clamp a joint target to the compiled actuator's limits."""
        lo, hi = self.physics.actuator_ctrlrange[
            self.context.actuators[actuator.id].idx
        ]
        self.targets[actuator.id] = float(np.clip(angle, lo, hi))

    def press(self, key: Key) -> None:
        """Apply one keyboard target increment."""
        translations = {
            Key.W: (0, 1),
            Key.S: (0, -1),
            Key.D: (1, 1),
            Key.A: (1, -1),
            Key.R: (2, 1),
            Key.F: (2, -1),
        }
        rotations = {
            Key.LEFT: (2, 1),
            Key.RIGHT: (2, -1),
            Key.UP: (1, 1),
            Key.DOWN: (1, -1),
            Key.Z: (0, 1),
            Key.X: (0, -1),
        }
        if key == Key.J:
            self.arm_mode = not self.arm_mode
            self.goal_position[:] = self.data.site_xpos[self.flange]
            self.goal_rotation[:] = self.data.site_xmat[self.flange].reshape(3, 3)
            print("Arm joint mode" if self.arm_mode else "Cartesian wrist mode")
        elif key == Key.H:
            self.targets = self.home_targets.copy()
            self.goal_position[:] = self.home_position
            self.goal_rotation[:] = self.home_rotation
        elif self.arm_mode and key in (Key.LEFT, Key.RIGHT):
            self.arm_joint = (self.arm_joint + (1 if key == Key.RIGHT else -1)) % 7
            print(f"Selected arm joint {self.arm_joint + 1}")
        elif self.arm_mode and key in (Key.UP, Key.DOWN):
            self.change_joint(
                self.robot.arm.hinge_actuators[self.arm_joint],
                0.05 if key == Key.UP else -0.05,
            )
        elif not self.arm_mode and key in translations:
            axis, sign = translations[key]
            self.goal_position[axis] += sign * 0.005
        elif not self.arm_mode and key in rotations:
            axis, sign = rotations[key]
            increment = np.zeros(3)
            increment[axis] = sign * np.deg2rad(2)
            self.goal_rotation[:] = (
                Rotation.from_rotvec(increment).as_matrix() @ self.goal_rotation
            )
        elif key in (Key.LEFT_BRACKET, Key.RIGHT_BRACKET):
            delta = 1 if key == Key.RIGHT_BRACKET else -1
            self.hand_joint = (self.hand_joint + delta) % len(self.hand_actuators)
            print(self.context.actuators[self.hand_actuators[self.hand_joint].id].name)
        elif key in (Key.COMMA, Key.PERIOD):
            self.change_joint(
                self.hand_actuators[self.hand_joint],
                0.05 if key == Key.PERIOD else -0.05,
            )
        elif key == Key.SPACE:
            for actuator in self.closing_actuators:
                self.change_joint(actuator, 0.1)
        elif key == Key.O:
            for actuator in self.hand_actuators:
                self.targets[actuator.id] = self.home_targets[actuator.id]

    def update(self) -> None:
        """Solve bounded servo setpoints toward the Cartesian target."""
        if not self.arm_mode:
            q = self.layout.qv.q.unpack(jnp.asarray(self.data.qpos))
            for hinge, actuator in zip(
                self.robot.arm.hinges, self.robot.arm.hinge_actuators, strict=True
            ):
                q.parts[hinge.id] = Angle(jnp.asarray(self.targets[actuator.id]))
            self.kinematics.qpos[:] = self.layout.qv.q.pack(q)
            delta = site_pose_ik_step(
                self.physics,
                self.kinematics,
                self.flange,
                self.dofs,
                self.goal_position,
                self.goal_rotation,
            )
            for actuator, increment in zip(
                self.robot.arm.hinge_actuators,
                delta,
                strict=True,
            ):
                self.set_target(
                    actuator,
                    self.targets[actuator.id]
                    + float(np.clip(increment, -0.015, 0.015)),
                )
        self.data.ctrl[:] = self.layout.u.pack(
            {id: Angle(jnp.asarray(value)) for id, value in self.targets.items()}
        )


def create_session[Scene: PandaLeapYcbScene](
    config: SceneConfig,
    output: Path,
    *,
    scene_factory: Callable[[SceneConfig], Scene],
) -> tuple[mujoco.MjModel, mujoco.MjData, KeyboardControl[Scene], Recording]:
    """Compile once, initialize the arm, and save the compiled scene for replay."""
    output.mkdir(parents=True, exist_ok=False)
    mesh_path = output.resolve() / "ycb_scan.stl"
    as_trimesh(config.mesh_path).export(mesh_path)
    compiled_config = config.model_copy(update={"mesh_path": mesh_path})
    settings = replace(MujocoSettings.standard(), dt=config.timestep_s)
    scene, context, physics = compile_model(
        lambda: scene_factory(compiled_config),
        build_path=output / "scene",
        settings=settings,
    )
    settings.apply(physics)
    layout = Layout.make(physics, context)
    data = mujoco.MjData(physics)
    set_home(scene.assembly.robot.arm, layout, data)
    mujoco.mj_forward(physics, data)
    control = KeyboardControl(
        scene.assembly.robot, context, physics, data, layout, scene=scene
    )
    control.update()
    info = RunInfo(
        scene=config,
        poses=[
            SitePoseReference(
                name="panda_flange",
                site_name=context.ports[scene.assembly.robot.arm.tip.id].name,
            ),
            SitePoseReference(
                name="leap_palm",
                site_name=context.ports[scene.assembly.robot.hand.origin.id].name,
            ),
            BodyPoseReference(
                name=config.object_name,
                body_name=context.components[scene.assembly.obj.id].name,
            ),
        ],
        actuator_names=[physics.actuator(i).name for i in range(physics.nu)],
    )
    recording = Recording(info, data.qacc_warmstart.copy())
    recording.append(data)
    mujoco.mj_saveModel(physics, str(output / "scene.mjb"))
    return physics, data, control, recording


def run_session(
    config: SceneConfig,
    output: Path,
    headless: bool,
    duration: float,
    key_events: tuple[KeyEvent, ...] = (),
) -> None:
    """Run keyboard-driven native physics and save all states on exit."""
    physics, data, control, recording = create_session(
        config, output, scene_factory=PandaLeapYcbScene.make
    )
    events: SimpleQueue[Key] = SimpleQueue()
    scheduled = deque(sorted(key_events, key=lambda event: event.time_s))
    key_names = {int(getattr(glfw, f"KEY_{key.value}")): key for key in Key}

    def press(key: Key) -> None:
        control.press(key)
        recording.keys.append(KeyEvent(time_s=data.time, key=key))

    def receive_key(key: int) -> None:
        # Viewer-only keys do not change robot targets or enter the command log.
        if key in key_names:
            events.put(key_names[key])

    def advance() -> None:
        while not events.empty():
            press(events.get())
        for _ in range(max(1, round(1 / (60 * physics.opt.timestep)))):
            while scheduled and scheduled[0].time_s <= data.time + 1e-12:
                event = scheduled.popleft()
                press(event.key)
            control.update()
            mujoco.mj_step(physics, data)
            mujoco.mj_kinematics(physics, data)
            recording.append(data)

    try:
        if headless:
            while data.time < duration:
                advance()
        else:
            print(__doc__)
            with mujoco.viewer.launch_passive(
                physics, data, key_callback=receive_key
            ) as viewer:
                while viewer.is_running() and (duration == 0 or data.time < duration):
                    started = time.perf_counter()
                    before = data.time
                    advance()
                    viewer.sync()
                    time.sleep(
                        max(0, data.time - before - (time.perf_counter() - started))
                    )
    finally:
        recording.save(output)
    print(output / "final.json")


def replay(path: Path, headless: bool) -> float:
    """Actuate the saved scene using recorded controls and report state error."""
    physics = mujoco.MjModel.from_binary_path(str(path.parent / "scene.mjb"))
    with np.load(path, allow_pickle=False) as trace:
        qpos, qvel, controls, times = (
            trace[key] for key in ("qpos", "qvel", "ctrl", "time_s")
        )
        data = mujoco.MjData(physics)
        data.qpos[:], data.qvel[:], data.ctrl[:] = qpos[0], qvel[0], controls[0]
        data.time = float(times[0])
        mujoco.mj_forward(physics, data)
        data.qacc_warmstart[:] = trace["initial_warmstart"]
        errors = []

        def step(index: int) -> None:
            data.ctrl[:] = controls[index]
            mujoco.mj_step(physics, data)
            mujoco.mj_kinematics(physics, data)
            errors.append(float(np.max(np.abs(data.qpos - qpos[index]))))

        if headless:
            for index in range(1, len(times)):
                step(index)
        else:
            with mujoco.viewer.launch_passive(physics, data) as viewer:
                for index in range(1, len(times)):
                    if not viewer.is_running():
                        break
                    started = time.perf_counter()
                    step(index)
                    viewer.sync()
                    time.sleep(
                        max(0, physics.opt.timestep - (time.perf_counter() - started))
                    )
    error = max(errors, default=0.0)
    print(
        f"Replayed {len(errors)}/{len(times) - 1} steps; maximum qpos error: {error:.6g}"
    )
    return error


def render_recording(path: Path, output: Path) -> None:
    """Render saved native states at 30 fps using their compiled scene."""
    physics = mujoco.MjModel.from_binary_path(str(path.parent / "scene.mjb"))
    data = mujoco.MjData(physics)
    camera = mujoco.MjvCamera()
    camera.lookat[:] = [0.3, 0, 0.3]
    camera.distance = 1.25
    camera.azimuth = 135
    camera.elevation = -25
    physics.vis.global_.offwidth = 960
    physics.vis.global_.offheight = 720
    fps = 30
    with np.load(path, allow_pickle=False) as trace:
        times = trace["time_s"]
        frame_times = np.arange(times[0], times[-1] + 0.5 / fps, 1 / fps)
        indices = np.minimum(np.searchsorted(times, frame_times), len(times) - 1)
        with (
            mujoco.Renderer(physics, height=720, width=960) as renderer,
            mediapy.VideoWriter(str(output), shape=(720, 960), fps=fps) as writer,
        ):
            for index in indices:
                data.qpos[:] = trace["qpos"][index]
                mujoco.mj_kinematics(physics, data)
                renderer.update_scene(data, camera=camera)
                writer.add_image(renderer.render())


def main() -> None:
    """Parse the scene, recording, and replay options."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--object", choices=OBJECT_CONFIGS, default="013_apple")
    parser.add_argument("--mesh-path", type=Path)
    parser.add_argument("--object-xy", type=float, nargs=2, default=(0.4, 0.0))
    parser.add_argument("--object-yaw", type=float, default=0.0, help="yaw in radians")
    parser.add_argument(
        "--object-tilt",
        type=float,
        nargs=2,
        default=(0.0, 0.0),
        help="roll and pitch in radians",
    )
    parser.add_argument(
        "--object-mass",
        type=float,
        help="total object mass in kg; retain YCB mass when omitted",
    )
    parser.add_argument(
        "--grasp-friction", type=float, help="object/hand sliding friction"
    )
    parser.add_argument("--hand-design", type=Path, help="distal spacer scales as JSON")
    parser.add_argument(
        "--timestep",
        type=float,
        default=MujocoSettings.standard().dt,
        help="physics step in seconds",
    )
    parser.add_argument(
        "--max-parts",
        type=int,
        default=6,
        help="use --single-hull for a closed scan without decomposition",
    )
    parser.add_argument("--single-hull", action="store_true")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("runs/panda-leap-teleop")
        / datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    parser.add_argument("--replay", type=Path)
    parser.add_argument("--video", type=Path, help="render --replay to MP4")
    parser.add_argument(
        "--key-script", type=Path, help="timed keyboard commands as JSON"
    )
    parser.add_argument("--headless", action="store_true")
    parser.add_argument(
        "--duration",
        type=float,
        default=0.0,
        help="seconds; 0 runs until the viewer closes",
    )
    args = parser.parse_args()
    if args.video and not args.replay:
        parser.error("--video requires --replay")
    with jax.enable_x64():
        if args.replay:
            if args.video:
                render_recording(args.replay, args.video)
            else:
                replay(args.replay, args.headless)
        else:
            if args.mesh_path is None:
                parser.error("--mesh-path is required for a YCB scene")
            if args.headless and args.duration <= 0:
                parser.error("headless recording requires --duration > 0")
            config = SceneConfig(
                object_name=args.object,
                mesh_path=args.mesh_path.resolve(),
                object_xy_m=tuple(args.object_xy),
                object_yaw_rad=args.object_yaw,
                object_tilt_rad=tuple(args.object_tilt),
                object_mass_kg=args.object_mass,
                grasp_friction=args.grasp_friction,
                timestep_s=args.timestep,
                hand_design=(
                    HandDesign.model_validate_json(args.hand_design.read_text())
                    if args.hand_design is not None
                    else HandDesign()
                ),
                max_parts=None if args.single_hull else args.max_parts,
            )
            script = (
                KeyScript.model_validate_json(args.key_script.read_text())
                if args.key_script
                else KeyScript()
            )
            run_session(
                config, args.output, args.headless, args.duration, tuple(script.events)
            )


if __name__ == "__main__":
    main()

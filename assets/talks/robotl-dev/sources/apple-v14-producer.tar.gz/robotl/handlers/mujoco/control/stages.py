"""Observed-state gates for native MuJoCo controllers."""

from collections.abc import Callable
from dataclasses import dataclass, replace
from enum import Enum

import jax
import jax.random as rax

from robotl.handlers.mujoco.control.planners import NoFeasiblePlan
from robotl.handlers.mujoco.process import Controller, EnvProcess


class StageStatus(Enum):
    """Observed execution outcome."""

    ACTIVE = "active"
    COMPLETE = "complete"
    TIMEOUT = "timeout"
    INVARIANT_FAILED = "invariant_failed"
    PLANNING_FAILED = "planning_failed"


@dataclass(frozen=True)
class Stage[T]:
    """Controller and observed goal with continuous dwell and a deadline.

    ``recoverable`` may be false for less than ``recovery_s`` continuous
    seconds; ``invariant`` fails on its first false tick. ``achieved`` may be
    false for less than ``lapse_s`` continuous seconds without restarting the
    dwell, and the stage never advances on a tick where it is false.
    """

    controller: Controller[T]
    achieved: Callable[[EnvProcess], bool]
    invariant: Callable[[EnvProcess], bool]
    dwell_s: float
    timeout_s: float
    recoverable: Callable[[EnvProcess], bool] = lambda env: True
    recovery_s: float = 0.0
    lapse_s: float = 0.0

    def __post_init__(self) -> None:
        if not 0 <= self.dwell_s <= self.timeout_s or self.timeout_s <= 0:
            raise ValueError("Require 0 <= dwell_s <= timeout_s and timeout_s > 0")
        if not 0 <= self.lapse_s <= self.dwell_s:
            raise ValueError("Require 0 <= lapse_s <= dwell_s")


@dataclass(frozen=True)
class StageState[T]:
    """Active controller state and observed goal timing in seconds."""

    index: int
    inner: T
    rng: jax.Array
    entered_at: float
    satisfied_since: float | None = None
    lapsed_since: float | None = None
    violated_since: float | None = None
    status: StageStatus = StageStatus.ACTIVE


@dataclass(eq=False)
class StagedController[T]:
    """Advance after a sustained observed goal; fail on timeout or invariant loss.

    Each call can advance at most one stage.
    Terminal calls emit no new action, retaining the last actuator targets.
    This controller uses the native episode loop, not MJX's compiled scan.
    """

    stages: tuple[Stage[T], ...]

    def __post_init__(self) -> None:
        if not self.stages:
            raise ValueError("A staged controller needs at least one stage")

    def init(self, rng: jax.Array, env0: EnvProcess) -> StageState[T]:
        if env0.spec.is_mjx:
            raise ValueError("StagedController requires native MuJoCo")
        return StageState(
            index=0,
            inner=self.stages[0].controller.init(rax.fold_in(rng, 0), env0),
            rng=rng,
            entered_at=float(env0.state.t),
        )

    def recover(
        self, stage: Stage[T], state: StageState[T], env: EnvProcess
    ) -> StageState[T]:
        """Track continuous ``recoverable`` loss; fail once it reaches ``recovery_s``."""
        if stage.recoverable(env):
            return replace(state, violated_since=None)
        now = float(env.state.t)
        violated = now if state.violated_since is None else state.violated_since
        if now - violated >= stage.recovery_s:
            return replace(
                state, violated_since=violated, status=StageStatus.INVARIANT_FAILED
            )
        return replace(state, violated_since=violated)

    def __call__(self, state: StageState[T], env: EnvProcess) -> StageState[T]:
        if state.status != StageStatus.ACTIVE:
            return state
        stage = self.stages[state.index]
        now = float(env.state.t)
        if not stage.invariant(env):
            return replace(state, status=StageStatus.INVARIANT_FAILED)
        state = self.recover(stage, state, env)
        if state.status != StageStatus.ACTIVE:
            return state

        achieved = stage.achieved(env)
        since, lapsed = state.satisfied_since, state.lapsed_since
        if achieved:
            lapsed = None
            if since is None:
                since = now
        elif since is not None:
            lapsed = now if lapsed is None else lapsed
            if now - lapsed >= stage.lapse_s:
                since, lapsed = None, None
        state = replace(state, satisfied_since=since, lapsed_since=lapsed)
        final = state.index + 1 == len(self.stages)
        # A stage advances on a satisfied tick only, and the last stage cannot
        # complete while a recovery window is open.
        if (
            achieved
            and since is not None
            and now - since >= stage.dwell_s
            and not (final and state.violated_since is not None)
        ):
            if final:
                return replace(state, status=StageStatus.COMPLETE)
            index = state.index + 1
            stage = self.stages[index]
            state = StageState(
                index=index,
                inner=stage.controller.init(rax.fold_in(state.rng, index), env),
                rng=state.rng,
                entered_at=now,
                violated_since=state.violated_since,
            )
            # Check the new stage's invariants before it can actuate.
            if not stage.invariant(env):
                return replace(state, status=StageStatus.INVARIANT_FAILED)
            state = self.recover(stage, state, env)
            if state.status != StageStatus.ACTIVE:
                return state
            if stage.achieved(env):
                state = replace(state, satisfied_since=now)
        elif now - state.entered_at >= stage.timeout_s:
            return replace(state, status=StageStatus.TIMEOUT)

        try:
            inner = stage.controller(state.inner, env)
        except NoFeasiblePlan:
            return replace(state, status=StageStatus.PLANNING_FAILED)
        return replace(state, inner=inner)

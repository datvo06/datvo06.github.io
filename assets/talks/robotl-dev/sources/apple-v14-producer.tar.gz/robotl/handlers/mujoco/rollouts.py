"""Runners — simulators for planning.

A :class:`Runner` advances :class:`EnvState`s under given controls, either
open-loop over a control sequence (:meth:`~Runner.rollout`) or one step at a
time (:meth:`~Runner.step`, for closed-loop use). It runs raw ``mj_step`` /
``mujoco.rollout`` (bypassing :class:`ControlProcess`) and sits deliberately
outside the :class:`Episode` taxonomy, returning bare :class:`EnvState` stacks.

The backends — :class:`SequentialRunner`, :class:`ThreadedRunner`,
:class:`JaxableThreadedRunner` and :class:`MjxRunner` — share one batching rule.
:func:`openloop_rollouts` defaults to the spec's own; planners take any runner's
:meth:`~Runner.rollout` as their ``rollout`` executor. Only the
:class:`MjxRunner` and :class:`JaxableThreadedRunner` are
usable inside a jax trace.
"""

import abc
import dataclasses
import threading
from collections.abc import Callable
from functools import partial, wraps
from multiprocessing import cpu_count
from typing import ClassVar, cast, final

import effectful.handlers.jax.numpy as jnp
import jax
import mujoco
import mujoco.rollout
import numpy as np
from flax import struct
from mujoco import mjx

from robotl.handlers.mujoco.compiler import FIDELITY_PARAMS
from robotl.handlers.mujoco.mappings import Layout
from robotl.internals.utils import deepstack, jit_for, maybe_enable_x64
from robotl.ops.syntax import fidelity

from .process import (
    Action,
    EnvSpec,
    EnvState,
    set_ctrl,
)


def _pack_u(layout: Layout, action: Action, length: int | None) -> jax.Array:
    if jax.tree.leaves(action):
        u = layout.u.pack(action)
        assert length is None or u.shape[-2] == length, (u.shape, length)
    else:  # no actuators, so nothing to infer the horizon from
        assert length is not None, "rollout without actuators needs a length"
        u = jnp.zeros([length, 0])
    assert u.ndim in (2, 3), u.shape
    assert u.shape[-1] == layout.mj_model.nu
    return u


def _pack(
    layout: Layout, state: EnvState, u: jax.Array
) -> tuple[jax.Array, jax.Array, jax.Array, jax.Array]:
    B, T, _ = u.shape
    M = layout.mj_model.nmocap

    # vectorize state according to mjSTATE_FULLPHYSICS
    def pack_state(state: EnvState) -> tuple[jax.Array, jax.Array, jax.Array]:
        qpos, qvel = layout.qv.pack(state.qv)
        fp = jnp.concatenate([jnp.asarray(state.t)[None], qpos, qvel])
        return fp, *layout.fixed_q.pack(state.fixed_q)

    fp0, mocap_pos, mocap_quat = jax.vmap(pack_state)(state)
    # fixed poses are not part of FULLPHYSICS; feed them to the rollout
    # through the control vector, held constant over the episode
    control = jnp.concatenate(
        [
            u,
            jnp.broadcast_to(mocap_pos.reshape([B, 1, M * 3]), [B, T, M * 3]),
            jnp.broadcast_to(mocap_quat.reshape([B, 1, M * 4]), [B, T, M * 4]),
        ],
        axis=-1,
    )
    return fp0, control, mocap_pos, mocap_quat


def _unpack(
    layout: Layout,
    fp: jax.Array,
    sensordata: jax.Array,
    u: jax.Array,
    rng: jax.Array,
    mocap_pos: jax.Array,
    mocap_quat: jax.Array,
) -> EnvState:
    def unpack_state(
        fp: jax.Array,
        sensordata: jax.Array,
        u: jax.Array,
        rng: jax.Array,
        mocap_pos: jax.Array,
        mocap_quat: jax.Array,
    ) -> EnvState:
        nq = layout.mj_model.nq
        return EnvState(
            t=fp[0],
            qv=layout.qv.unpack(fp[1:][:nq], fp[1 + nq :]),
            fixed_q=layout.fixed_q.unpack(mocap_pos, mocap_quat),
            y=layout.y.unpack(sensordata),
            u=layout.u.unpack(u),
            rng=rng,
        )

    # rng and fixed poses are constant over the episode
    in_axes = [0, 0, 0, None, None, None]
    return jax.vmap(jax.vmap(unpack_state, in_axes=in_axes))(
        fp, sensordata, u, rng, mocap_pos, mocap_quat
    )


@jax.jit
def _broadcast_batch(state: EnvState, u: jax.Array) -> tuple[EnvState, jax.Array]:
    if state.t.ndim == 0:
        state = jax.tree.map(lambda x: x[None], state)
    if u.ndim == 2:
        u = u[None]
    [B] = np.broadcast_shapes(state.t.shape[:1], u.shape[:1])
    _, T, U = u.shape
    u = jnp.broadcast_to(u, [B, T, U])
    state = jax.tree.map(lambda x: jnp.broadcast_to(x, [B, *x.shape[1:]]), state)
    return state, u


@partial(jax.jit, static_argnames=["axis"])
def _squeeze[T](tree: T, axis: int) -> T:
    return jax.tree.map(lambda x: jnp.squeeze(x, axis=axis), tree)


def _canonicalize_batch[F: Callable](rollout: F) -> F:
    # pack u, broadcast state/u to a common batch size, check the wrapped
    # rollout returned the promised [B, T], and drop B again if neither was batched
    @wraps(rollout)
    def wrapper(
        self, spec: EnvSpec, state: EnvState, action: Action, length: int | None = None
    ) -> EnvState:
        u = jit_for(spec.layout, _pack_u, static_argnames=("length",))(action, length)
        batched = state.t.ndim == 1 or u.ndim == 3
        state, u = _broadcast_batch(state, u)
        B, T, _ = u.shape
        rollouts = rollout(self, spec, state, u)
        assert rollouts.t.shape[:2] == (B, T), rollouts.t.shape
        assert all(x.shape[:2] == (B, T) for x in jax.tree.leaves(rollouts.y))
        if not batched:
            rollouts = _squeeze(rollouts, axis=0)
        return rollouts

    return cast(F, wrapper)


@dataclasses.dataclass(eq=False)
class Runner(abc.ABC):
    """Simulator advancing :class:`EnvState`s under given controls."""

    jaxable: ClassVar[bool] = False

    @abc.abstractmethod
    def rollout(
        self, spec: EnvSpec, state: EnvState, u: Action, length: int | None = None
    ) -> EnvState:
        """Roll out open-loop control ``u`` (leaves ``[B?, T]``) starting from
        given state. ``length`` is required only if ``u`` is empty (no
        actuators), and otherwise checked against ``T``.

        Either ``state`` or ``u`` can have a leading batch axis, or both or
        neither. Batched inputs are broadcast to a single common batch axis;
        if neither is batched, neither is the result."""
        ...

    def step(self, spec: EnvSpec, state: EnvState, u: Action) -> EnvState:
        # control values are scalar per actuator, so leaves are [B?]
        u_batched = any(jnp.ndim(x) for x in jax.tree.leaves(u))
        rollouts = self.rollout(
            spec, state, jax.tree.map(lambda x: x[..., None], u), length=1
        )
        # rollout returns [B?, T]; the time axis follows the batch axis if any
        axis = 1 if state.t.ndim == 1 or u_batched else 0
        return _squeeze(rollouts, axis=axis)

    def forward(self, spec: EnvSpec, state: EnvState) -> EnvState:
        # recompute sensordata using rollouts, exploiting the fact that sensordata lags behind
        next_state = self.step(spec, state, state.u)
        return state.replace(y=next_state.y)

    def rollout_with_jacobians(
        self, spec: EnvSpec, state: EnvState, u: jax.Array, fd_eps: float = 1e-6
    ) -> tuple[EnvState, jax.Array, jax.Array, jax.Array, jax.Array]:
        """Nominal open-loop rollout of unbatched ``state`` under ``u`` ``[T, nu]``
        with per-step transition Jacobians from ``mujoco.mjd_transitionFD``.
        With ``x_{t+1} = f(x_t, u_t)``: ``A[t] = ∂x_{t+1}/∂x_t`` ``[2nv, 2nv]``,
        ``B[t] = ∂x_{t+1}/∂u_t`` ``[2nv, nu]``, ``C[t] = ∂s_t/∂x_t``
        ``[nsensordata, 2nv]`` and ``D[t] = ∂s_t/∂u_t``, where ``s_t`` is the
        sensordata carried by the post-step ``states[t]`` — ``mj_step``
        evaluates sensors during the *pre-step* forward, so ``s_t`` is a
        function of ``(x_t, u_t)``. Returns ``(states, A, B, C, D)``. CPU
        MuJoCo only; stateless actuators (``na == 0``).

        The state tangent is ``[dq; dv]``, both halves in the layout's flat
        tangent basis (:meth:`VLayout.pack`, MuJoCo dof order): ``dq`` is the
        right perturbation ``q ⊕ Exp(dq)`` per ``mj_integratePos`` — matching
        :meth:`Coordinate.__add__` — and ``dv`` is a plain velocity offset.
        Sensor rows follow the :meth:`YLayout.pack` layout."""
        m = spec.mj_model
        assert not spec.is_mjx and m.na == 0
        T, nu = u.shape
        nq, nx, ns = m.nq, 2 * m.nv, m.nsensordata
        dtype = jax.dtypes.canonicalize_dtype(np.float64)
        qpos, qvel = spec.layout.qv.pack(state.qv)
        mocap_pos, mocap_quat = spec.layout.fixed_q.pack(state.fixed_q)

        def call_host(t, qpos, qvel, mocap_pos, mocap_quat, u):
            d = mujoco.MjData(m)
            d.time, d.qpos, d.qvel = t, qpos, qvel
            d.mocap_pos, d.mocap_quat = mocap_pos, mocap_quat
            mujoco.mj_forward(m, d)
            fp, y = np.empty((T, 1 + nq + m.nv)), np.empty((T, ns))
            A, B = np.empty((T, nx, nx)), np.empty((T, nx, nu))
            C, D = np.empty((T, ns, nx)), np.empty((T, ns, nu))
            for i in range(T):
                d.ctrl = u[i]
                mujoco.mjd_transitionFD(m, d, fd_eps, 1, A[i], B[i], C[i], D[i])
                mujoco.mj_step(m, d)
                fp[i] = np.concatenate([[d.time], d.qpos, d.qvel])
                y[i] = d.sensordata
            return tuple(x.astype(dtype) for x in [fp, y, A, B, C, D])

        shapes = [[T, 1 + nq + m.nv], [T, ns], [T, nx, nx], [T, nx, nu]]
        shapes += [[T, ns, nx], [T, ns, nu]]
        fp, y, A, B, C, D = jax.pure_callback(
            call_host,
            tuple(jax.ShapeDtypeStruct(shape, dtype) for shape in shapes),
            state.t,
            qpos,
            qvel,
            mocap_pos,
            mocap_quat,
            u,
            vmap_method="sequential",
        )
        states = jax.vmap(
            lambda fp, y, u: EnvState(
                t=fp[0],
                qv=spec.layout.qv.unpack(fp[1 : 1 + nq], fp[1 + nq :]),
                fixed_q=state.fixed_q,
                y=spec.layout.y.unpack(y),
                u=spec.layout.u.unpack(u),
                rng=state.rng,
            )
        )(fp, y, u)
        return states, A, B, C, D


@final
class SequentialRunner(Runner):
    @_canonicalize_batch
    def rollout(self, spec, state, u):
        u = np.asarray(u)
        B, T, _ = u.shape

        def do_rollout(state, u):
            m, d = spec.mj_model, spec.layout.state_to_data(state)
            rollout = []
            for t in range(T):
                d.ctrl = u[t]
                mujoco.mj_step(m, d)
                rollout.append(spec.layout.state_from_data(d, rng=state.rng))
            return deepstack(rollout)

        return deepstack(
            [do_rollout(jax.tree.map(lambda x: x[b], state), u[b]) for b in range(B)]
        )


@final
class MjxRunner(Runner):
    jaxable = True

    @_canonicalize_batch
    def rollout(self, spec, state, u):
        def one_rollout(state, u):
            def fn(md, u_t):
                md = mjx.step(spec.mj_model, md.replace(ctrl=u_t.astype(md.ctrl.dtype)))
                return md, spec.layout.state_from_data(md, rng=state.rng)

            _, states = jax.lax.scan(fn, spec.layout.state_to_data(state), u)
            return states

        with maybe_enable_x64(FIDELITY_PARAMS[fidelity()]["x64"]):
            return jax.vmap(one_rollout)(state, u)


@final
@dataclasses.dataclass(eq=False)
class _MjRollout:
    manager: mujoco.rollout.Rollout
    scratch: mujoco.MjData | list[mujoco.MjData]
    # XLA runs independent host calls concurrently, and they share the scratch
    lock: threading.Lock = dataclasses.field(default_factory=threading.Lock)

    @classmethod
    def make(cls, spec: EnvSpec, nthread: int) -> "_MjRollout":
        assert not spec.is_mjx
        manager = mujoco.rollout.Rollout(nthread=nthread)  # nthread=0 runs inline
        if manager.nthread == 0:
            scratch = mujoco.MjData(spec.mj_model)
        else:
            scratch = [mujoco.MjData(spec.mj_model) for _ in range(nthread)]
        return cls(manager, scratch)

    def rollout(
        self,
        spec: EnvSpec,
        state: EnvState,
        u: jax.Array,
        jaxable: bool,
    ) -> EnvState:
        assert spec.mj_model.na == 0  # stateful actuators require tracking mj_data.act
        B, T, _ = u.shape
        dtype = jax.dtypes.canonicalize_dtype(np.float64)
        fp0, control, mocap_pos, mocap_quat = jit_for(spec.layout, _pack)(state, u)
        control_spec = (
            mujoco.mjtState.mjSTATE_CTRL
            | mujoco.mjtState.mjSTATE_MOCAP_POS
            | mujoco.mjtState.mjSTATE_MOCAP_QUAT
        )

        def call_host(fp0, control):
            """Call out to mujoco.rollout to do the work"""
            fp0, control = np.asarray(fp0), np.asarray(control)
            assert np.all(np.isfinite(fp0))
            # an outer vmap adds leading axes; flatten them into the rollout batch
            batch_shape = fp0.shape[:-1]
            assert control.shape[:-2] == batch_shape, (fp0.shape, control.shape)
            B = int(np.prod(batch_shape))
            with self.lock:
                fp, sensordata = self.manager.rollout(
                    model=spec.mj_model,
                    data=self.scratch,
                    initial_state=fp0.reshape([B, fp0.shape[-1]]),
                    control=control.reshape([B, *control.shape[-2:]]),
                    control_spec=control_spec,
                )
            fp = fp.reshape([*batch_shape, *fp.shape[1:]])
            sensordata = sensordata.reshape([*batch_shape, *sensordata.shape[1:]])
            # mujoco allocates its outputs float64; jax runs float32 unless x64.
            # Sensor readings only feed losses and are the bulk of a rollout, so
            # they stay float32 even under x64.
            return fp.astype(dtype), sensordata.astype(jnp.float32)

        # Eagerly dispatched, pure_callback is cached by JAX for the process,
        # keyed on call_host, which would keep this pool and the spec alive.
        traced = isinstance(fp0, jax.core.Tracer) or isinstance(
            control, jax.core.Tracer
        )
        if jaxable and traced:
            fp, sensordata = jax.pure_callback(
                call_host,
                (
                    jax.ShapeDtypeStruct([B, T, fp0.shape[-1]], dtype),
                    jax.ShapeDtypeStruct(
                        [B, T, spec.mj_model.nsensordata], jnp.float32
                    ),
                ),
                fp0,
                control,
                # an outer vmap becomes a single host call over the whole batch
                vmap_method="broadcast_all",
            )
        else:
            fp, sensordata = call_host(fp0, control)
        assert fp.shape == (B, T, fp0.shape[-1])
        assert sensordata.shape == (B, T, spec.mj_model.nsensordata)

        return jit_for(spec.layout, _unpack)(
            fp, sensordata, u, state.rng, mocap_pos, mocap_quat
        )


@final
@dataclasses.dataclass(eq=False)
class ThreadedRunner(Runner):
    pool: _MjRollout

    @classmethod
    def make(cls, spec: EnvSpec, nthread: int = cpu_count()):
        return cls(_MjRollout.make(spec, nthread))

    @_canonicalize_batch
    def rollout(self, spec, state, u):
        return self.pool.rollout(spec, state, u, jaxable=False)


@final
@dataclasses.dataclass(eq=False)
class JaxableThreadedRunner(Runner):
    pool: _MjRollout
    jaxable = True

    @classmethod
    def make(cls, spec: EnvSpec, nthread: int = cpu_count()):
        return cls(_MjRollout.make(spec, nthread))

    @_canonicalize_batch
    def rollout(self, spec, state, u):
        return self.pool.rollout(spec, state, u, jaxable=True)


Threadpool = JaxableThreadedRunner
"""Alias kept so existing ``Threadpool`` call sites keep working. Jaxable,
since planners trace their rollouts under ``lax.cond``."""


def openloop_rollouts(
    spec: EnvSpec,
    state: EnvState,
    u: Action,
    threadpool: Runner | None = None,
    length: int | None = None,
) -> EnvState:
    """Roll out ``u`` from ``state`` with ``threadpool``, defaulting to
    ``spec.runner``. See :meth:`Runner.rollout` for the batching contract.
    """
    runner = spec.runner if threadpool is None else threadpool
    return runner.rollout(spec, state, u, length=length)


class OpenLoopController(struct.PyTreeNode):
    u: jax.Array

    def init(self, rng, env):
        return 0

    def __call__(self, t, env):
        set_ctrl(self.u[t])
        return t + 1


@jax.jit
def default_batched_loss_fn(spec: EnvSpec, rollouts: EnvState):
    @jax.vmap
    @jax.vmap
    def fn(state):
        return spec.get_loss(state)

    return fn(rollouts).mean(axis=1)  # average over time


@jax.jit
def batched_stage_loss_fn(spec: EnvSpec, rollouts: EnvState) -> jax.Array:
    """Per-``(batch, timestep)`` total task loss, shape ``[B, T]``. Jitted so
    the effectful loss evaluation is traced once, not per call."""
    return jax.vmap(jax.vmap(spec.get_loss))(rollouts)

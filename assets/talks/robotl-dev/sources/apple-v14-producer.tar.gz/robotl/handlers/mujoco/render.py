"""Trajectory rendering: offscreen frames, mp4 writing, GL backend selection."""

import dataclasses
import os
import sys
from copy import deepcopy
from pathlib import Path

import effectful.handlers.jax.numpy as jnp
import jax
import mediapy
import mujoco
import numpy as np

from robotl.internals.utils import deepunstack

from .process import EnvSpec, EnvState


@dataclasses.dataclass
class Camera:
    lookat: jax.Array | None = None
    distance: float | None = None
    elevation: float | None = None  # in radians
    azimuth: float | None = None  # in radians

    def to_mujoco(self, mj_model):
        cam = mujoco.MjvCamera()
        cam.type = mujoco.mjtCamera.mjCAMERA_FREE
        mujoco.mjv_defaultFreeCamera(mj_model, cam)
        if self.lookat is not None:
            cam.lookat = self.lookat
        if self.distance is not None:
            cam.distance = self.distance
        if self.elevation is not None:
            cam.elevation = self.elevation * 180 / jnp.pi
        if self.azimuth is not None:
            cam.azimuth = self.azimuth * 180 / jnp.pi
        return cam


def render_trajectory(
    spec: EnvSpec,
    rollout: EnvState,
    *,
    save_to: str | Path | None = None,
    max_frames: int | None = None,
    height: int = 480,
    width: int = 640,
    camera: Camera = Camera(),
    scene_option: mujoco.MjvOption | None = None,
) -> jax.Array:
    """Render a trajectory to an array of images, optionally writing an mp4.

    :param save_to: If given, also write the rendered frames to this path as
        an mp4 (parent directories are created). Off by default — pass a path
        to enable it.
    :param max_frames: If given, subsample to at most this many evenly-spaced
        frames before rendering; ``None`` renders every frame. The video frame
        rate is the sim rate ``1/timestep`` adjusted for the subsample stride.
    """

    [T] = rollout.t.shape

    stride = 1
    if max_frames is not None and T > max_frames:
        stride = T // max_frames
        rollout = jax.tree.map(lambda x: x[::stride], rollout)

    m = deepcopy(spec.mj_model)
    m.vis.global_.offheight = max(height, m.vis.global_.offheight)
    m.vis.global_.offwidth = max(width, m.vis.global_.offwidth)

    mj_camera = camera.to_mujoco(m)

    scratch = mujoco.MjData(m)
    with mujoco.Renderer(m, height=height, width=width) as renderer:

        def get_image(state) -> jax.Array:
            nonlocal scratch
            scratch = spec.layout.state_to_data(state, scratch)
            renderer.update_scene(scratch, camera=mj_camera, scene_option=scene_option)
            return renderer.render()

        frames = jnp.stack(list(map(get_image, deepunstack(rollout))))

    if save_to is not None:
        save_to = Path(save_to)
        save_to.parent.mkdir(parents=True, exist_ok=True)
        fps = 1.0 / (float(m.opt.timestep) * stride)
        mediapy.write_video(str(save_to), np.asarray(frames), fps=fps)

    return frames


def ensure_mujoco_gl(preferred: str | None = None) -> str:
    """Pick a working MuJoCo GL backend for this platform and process.
    Returns the selected backend string.
    """
    _VALID = {"glfw", "egl", "osmesa"}

    def _try_backend(backend: str) -> bool:
        os.environ["MUJOCO_GL"] = backend
        try:
            ctx = mujoco.GLContext(1, 1)
            ctx.make_current()
            return True
        except Exception:
            return False

    # Respect a valid, pre-set value
    cur = os.environ.get("MUJOCO_GL", "").lower()
    if cur in _VALID:
        # Quick smoke test: if it doesn't work, we'll fall through and try others
        if _try_backend(cur):
            return cur

    # Build candidates by platform
    candidates: list[str] = []
    if preferred:
        candidates.append(preferred)

    if sys.platform == "darwin":
        # macOS builds use GLFW (Cocoa)
        candidates += ["glfw"]
    else:
        # Linux: try GPU EGL first, then pure CPU OSMesa, then GLFW (requires X)
        candidates += ["egl", "osmesa", "glfw"]

    # Try in order until one works
    for b in candidates:
        if b in _VALID and _try_backend(b):
            return b

    raise RuntimeError(
        f"No working MuJoCo GL backend found. Tried: {', '.join(candidates)}. "
        "On Linux CI, install libosmesa6/libosmesa6-dev or run with an EGL-capable GPU. "
        "As a last resort, run under an X server (e.g., xvfb) for GLFW."
    )

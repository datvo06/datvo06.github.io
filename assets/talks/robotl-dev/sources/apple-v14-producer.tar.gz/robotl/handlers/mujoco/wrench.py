"""How much of a required wrench a robot's contacts can apply to an object.

The margin is a linear program over MuJoCo's pyramidal friction cones: each
robot contact on the object pushes along the edges ``n +/- mu_1 t1`` and
``n +/- mu_2 t2`` of its contact frame, and the program finds the largest
multiple of a required wrench those edge forces can apply about the object's
centre of mass. A margin of at least 1 means the contacts can apply it.
"""

from collections.abc import Collection

import mujoco
import numpy as np
from numpy.typing import NDArray
from pydantic import BaseModel
from scipy.optimize import linprog


class WrenchMargin(BaseModel):
    """Multiples of a required wrench a robot's contacts can apply.

    :param held: margin with each robot body's normal load capped at its load
        in the evaluated state
    :param servo: margin with the robot in static balance, its own gravity and
        bias included, against actuator forces bounded by their force ranges
        instead; infinite when the robot's structure, such as a world-welded
        link, carries the wrench, and 0 when the actuators cannot hold the
        robot itself
    """

    held: float
    servo: float


def wrench_margin(
    model: mujoco.MjModel,
    data: mujoco.MjData,
    object_geoms: Collection[int],
    robot_geoms: Collection[int],
    support_geoms: Collection[int],
    wrench: NDArray[np.float64],
) -> WrenchMargin:
    """Largest multiple of ``wrench`` the robot's contacts apply to the object.

    Every active contact between an object geom and a robot geom carries load
    and is owned by the robot geom's body. Contacts with ``support_geoms``,
    such as a table, are left out, and so are contacts MuJoCo excludes from
    its constraint solve. With no robot contact the margin is 0.

    :param model: compiled model with pyramidal friction cones
    :param data: forwarded state whose contacts, loads and actuator moments
        are evaluated
    :param object_geoms: geoms of the object
    :param robot_geoms: geoms that may carry load on the object
    :param support_geoms: geoms whose contacts with the object are excluded
    :param wrench: required world-frame force and torque about the object's
        centre of mass, ``(fx, fy, fz, tx, ty, tz)``; lifting against gravity
        is ``(-mass * model.opt.gravity, 0, 0, 0)``
    :returns: the ``held`` and ``servo`` margins
    :raises ValueError: on elliptic cones, a zero wrench, a massless object,
        an actuator without a force range that moves a balanced degree of
        freedom, an object contact with a geom outside ``robot_geoms`` and
        ``support_geoms``, or a robot contact whose condim is not 3
    :raises RuntimeError: if the linear program hits its iteration limit or
        a numerical failure
    """
    # The edges must match the cone the simulator enforces, not bound it.
    if model.opt.cone != mujoco.mjtCone.mjCONE_PYRAMIDAL:
        raise ValueError("wrench_margin models pyramidal friction cones")
    # A zero wrench leaves the multiple unbounded.
    if not np.any(wrench):
        raise ValueError("wrench_margin needs a nonzero required wrench")
    object_geoms, robot_geoms = set(object_geoms), set(robot_geoms)
    support_geoms = set(support_geoms)
    bodies = sorted({int(model.geom_bodyid[g]) for g in object_geoms})
    mass = float(model.body_mass[bodies].sum())
    if mass <= 0:
        raise ValueError(f"object bodies {bodies} have no mass")
    com = model.body_mass[bodies] @ data.xipos[bodies] / mass

    # One entry per pyramid edge: owning body, contact point, unit edge force on the object.
    edges: list[tuple[int, NDArray[np.float64], NDArray[np.float64]]] = []
    loads: dict[int, float] = {}
    force = np.zeros(6)
    for i in range(data.ncon):
        contact = data.contact[i]
        first, second = int(contact.geom1), int(contact.geom2)
        if (first in object_geoms) == (second in object_geoms):
            continue
        other = second if first in object_geoms else first
        # Excluded contacts carry no constraint force.
        if other in support_geoms or contact.exclude:
            continue
        body = int(model.geom_bodyid[other])
        if other not in robot_geoms:
            raise ValueError(
                f"object touches geom {other} of {model.body(body).name!r}"
            )
        if contact.dim != 3:
            raise ValueError(f"robot contact {i} has condim {contact.dim}, not 3")
        mujoco.mj_contactForce(model, data, i, force)
        loads[body] = loads.get(body, 0.0) + float(force[0])
        # The frame normal points from geom1 to geom2; flip it onto the object.
        sign = 1.0 if second in object_geoms else -1.0
        normal, first_tangent, second_tangent = sign * contact.frame.reshape(3, 3)
        edges.extend(
            (body, contact.pos.copy(), normal + mu * direction)
            for tangent, mu in (
                (first_tangent, contact.friction[0]),
                (second_tangent, contact.friction[1]),
            )
            for direction in (tangent, -tangent)
        )

    if not edges:
        return WrenchMargin(held=0.0, servo=0.0)
    count = len(edges)
    wrench_rows = np.array(
        [
            np.concatenate([edge, np.cross(position - com, edge)])
            for _, position, edge in edges
        ]
    ).T

    owners = [body for body, _, _ in edges]
    held_caps = np.array([[float(owner == body) for owner in owners] for body in loads])
    held = _largest_multiple(
        np.hstack([wrench_rows, -wrench[:, None]]),
        np.zeros(6),
        np.hstack([held_caps, np.zeros((len(loads), 1))]),
        np.array(list(loads.values())),
        [(0, None)] * (count + 1),
        multiple=count,
    )

    # Static balance of the robot: the actuators' generalized forces cancel the
    # contact reactions on every degree of freedom either one reaches.
    jacobian = np.zeros((3, model.nv))
    reactions = []
    for body, position, edge in edges:
        mujoco.mj_jac(model, data, jacobian, None, position, body)
        reactions.append(-jacobian.T @ edge)
    reaction_rows = np.array(reactions).T
    # Dense (nu, nv) map from actuator force to generalized force, gear included.
    moment = np.zeros((model.nu, model.nv))
    mujoco.mju_sparse2dense(
        moment,
        data.actuator_moment,
        data.moment_rownnz,
        data.moment_rowadr,
        data.moment_colind,
    )
    # Balance every dof a contact loads, and every dof the actuators involved reach.
    balanced = np.any(reaction_rows != 0, axis=1)
    while True:
        moving = np.any(moment[:, balanced] != 0, axis=1)
        reached = balanced | np.any(moment[moving] != 0, axis=0)
        if np.array_equal(reached, balanced):
            break
        balanced = reached
    unlimited = np.flatnonzero(moving & (model.actuator_forcelimited == 0))
    if len(unlimited):
        names = [model.actuator(int(a)).name for a in unlimited]
        raise ValueError(f"actuators without a force range move loaded dofs: {names}")
    actuated = np.flatnonzero(moving)
    balance_rows = np.hstack(
        [
            reaction_rows[balanced],
            np.zeros((int(balanced.sum()), 1)),
            moment[np.ix_(actuated, np.flatnonzero(balanced))].T,
        ]
    )
    wrench_balance = np.hstack(
        [wrench_rows, -wrench[:, None], np.zeros((6, len(actuated)))]
    )
    # Statics: actuator forces plus contact reactions carry the robot's own
    # gravity and bias, net of passive forces such as gravity compensation.
    own_load = (data.qfrc_bias - data.qfrc_passive)[balanced]
    servo = _largest_multiple(
        np.vstack([wrench_balance, balance_rows]),
        np.concatenate([np.zeros(6), own_load]),
        None,
        None,
        [(0, None)] * (count + 1)
        + [tuple(model.actuator_forcerange[a]) for a in actuated],
        multiple=count,
    )
    return WrenchMargin(held=held, servo=servo)


def _largest_multiple(
    equality: NDArray[np.float64],
    equality_rhs: NDArray[np.float64],
    caps: NDArray[np.float64] | None,
    limits: NDArray[np.float64] | None,
    bounds: list[tuple[float | None, float | None]],
    multiple: int,
) -> float:
    """Maximize variable ``multiple`` subject to the equalities, caps and bounds.

    Unbounded means nothing caps the multiple, so it is infinite. Infeasible
    means not even a zero multiple balances, as when the actuators cannot
    carry the robot's own load, so it is 0.
    """
    cost = np.zeros(len(bounds))
    cost[multiple] = -1.0
    result = linprog(
        cost,
        A_ub=caps,
        b_ub=limits,
        A_eq=equality,
        b_eq=equality_rhs,
        bounds=bounds,
    )
    if result.status == 3:
        return float("inf")
    if result.status == 2:
        return 0.0
    if not result.success:
        raise RuntimeError(
            f"wrench margin program failed with status {result.status}: {result.message}"
        )
    return float(-result.fun)

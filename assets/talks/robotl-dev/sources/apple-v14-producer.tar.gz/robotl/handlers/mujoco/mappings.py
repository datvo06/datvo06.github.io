import dataclasses
from collections.abc import Callable, Iterable, Mapping
from typing import TYPE_CHECKING, Any, cast

import effectful.handlers.jax.numpy as jnp
import jax
import mujoco
import numpy as np
from mujoco import mjx

from robotl.handlers.mujoco.compiler import JointInfo
from robotl.handlers.mujoco.types import QV, FixedQ, Q, QVTangent, V
from robotl.internals.utils import deepstack, deepunstack, jit_method
from robotl.ops import joints, sensors
from robotl.ops.actuators import ControlValue
from robotl.ops.coords import (
    Angle,
    AngleTangent,
    Coordinate,
    CoordinateTangent,
    Displacement,
    DisplacementTangent,
    Pose,
    PoseTangent,
    ProductCoordinate,
    ProductCoordinateTangent,
    RawCoordinate,
    Rotation,
    RotationTangent,
    ScalarDisplacement,
    ScalarDisplacementTangent,
    ScalarForce,
    ScalarTorque,
    TangentBundle,
    TangentBundleTangent,
)
from robotl.ops.id import Id
from robotl.ops.sensors import SensorValue

if TYPE_CHECKING:
    from robotl.handlers.mujoco.compiler import (
        ComponentInfo,
        MujocoContext,
    )
    from robotl.handlers.mujoco.process import EnvState

type Quantity = Coordinate | CoordinateTangent | ControlValue | SensorValue


@dataclasses.dataclass(eq=False, repr=False)
class Codec[T: Quantity]:
    quantity: type[T]
    dim: int
    wrap: Callable[[jax.Array], T]
    unwrap: Callable[[T], jax.Array]


def scalar_codec[T: Quantity](
    quantity: type[T], unwrap: Callable[[T], jax.Array]
) -> Codec[T]:
    wrap = cast(Callable[[jax.Array], T], quantity)  # mypy rejects calling type[T]
    return Codec(quantity, 1, lambda x: wrap(x[..., 0]), lambda v: unwrap(v)[..., None])


_CODECS: dict[type, Codec[Any]] = {
    c.quantity: c
    for c in (
        scalar_codec(Angle, lambda v: v.theta),
        scalar_codec(AngleTangent, lambda v: v.omega),
        scalar_codec(ScalarDisplacement, lambda v: v.x),
        scalar_codec(ScalarDisplacementTangent, lambda v: v.dx),
        scalar_codec(ScalarTorque, lambda v: v.tau),
        scalar_codec(ScalarForce, lambda v: v.f),
        Codec(Displacement, 3, Displacement, lambda v: v.x),
        Codec(DisplacementTangent, 3, DisplacementTangent, lambda v: v.dx),
        Codec(Rotation, 4, lambda x: Rotation(quat=x), lambda v: v.unit_quat),
        Codec(RotationTangent, 3, RotationTangent, lambda v: v.rv),
        Codec(
            Pose,
            7,
            lambda x: Pose(pos=x[..., :3], quat=x[..., 3:]),
            lambda v: jnp.concatenate([v.pos, v.unit_quat], axis=-1),
        ),
        Codec(
            PoseTangent,
            6,
            lambda x: PoseTangent(x[..., :3], x[..., 3:]),
            lambda v: jnp.concatenate([v.linear.dx, v.angular.rv], axis=-1),
        ),
    )
}


def get_codec[T: Quantity](quantity: type[T]) -> Codec[T]:
    try:
        c = _CODECS[quantity]
    except KeyError:
        raise KeyError(f"no codec for {quantity.__name__}") from None
    assert c.quantity is quantity
    return cast(Codec[T], c)


def unpack_quantity[T: Quantity](x: jax.Array, quantity: type[T]) -> T:
    c = get_codec(quantity)
    assert x.shape[-1] == c.dim
    return c.wrap(x)


def pack_quantity[T: Quantity](quantity: type[T], value: T) -> jax.Array:
    return get_codec(quantity).unwrap(value)


def unpack_quantities[K, T: Quantity](
    x: jax.Array, quantities: Mapping[K, Codec[T]]
) -> dict[K, T]:
    codecs = list(quantities.values())
    dims = [codec.dim for codec in codecs]
    assert sum(dims) == x.shape[-1]
    parts = jnp.split(x, np.cumsum(dims)[:-1], axis=-1)
    return {
        key: codec.wrap(part) for key, codec, part in zip(quantities, codecs, parts)
    }


def pack_quantities[K, T: Quantity](
    quantities: Mapping[K, Codec[T]], values: Mapping[K, T]
) -> jax.Array:
    parts = [codec.unwrap(values[k]) for k, codec in quantities.items()]
    return jnp.concatenate(parts, axis=-1) if parts else jnp.zeros([0])


def _check_dims_match(
    quantities: Iterable[Codec[Any]],
    offsets: np.typing.ArrayLike,
    length: int,
) -> None:
    dims = [codec.dim for codec in quantities]
    assert np.all(np.cumsum(dims) - dims == np.asarray(offsets))
    assert sum(dims) == length


def maybe_reverse[T](
    value: T, info: "JointInfo | ComponentInfo", downward: bool = False
) -> T:
    """Map ball-joint value between mujoco and robotl.

    Rotations are relative to the joint's reference rotation and flipped when
    the joint is reversed; tangents are negated when reversed. Other values pass
    through unchanged.

    ``downward=True`` maps from robotl to mujoco,
    ``downward=False`` maps from mujoco to robotl."""
    result: Any = value
    match value, info:
        case Rotation(), JointInfo(object=joints.Ball() as ball):
            flip = lambda r: ~r if info.reversed else r
            ref = flip(ball.pose0.rot)
            result = ~ref @ flip(value) if downward else flip(ref @ value)
        case RotationTangent(), JointInfo(object=joints.Ball()):
            result = -value if info.reversed else value
    return cast(T, result)


@dataclasses.dataclass(eq=False, repr=False)
class QLayout:
    """Maps between MuJoCo's flat ``[nq]`` position vector and a product of
    per-joint :class:`Coordinate` objects keyed by :class:`Id`."""

    template: dict[Id, Codec[Coordinate]]
    context: "MujocoContext"

    @jit_method
    def unpack(self, qpos: jax.Array) -> Q:
        things = self.context.joints | self.context.components
        values = unpack_quantities(qpos, self.template)
        return ProductCoordinate(
            {id: maybe_reverse(v, things[id]) for id, v in values.items()}
        )

    @jit_method
    def pack(self, q: Q) -> jax.Array:
        things = self.context.joints | self.context.components
        return pack_quantities(
            self.template,
            {
                id: maybe_reverse(v, things[id], downward=True)
                for id, v in q.parts.items()
            },
        )


@dataclasses.dataclass(eq=False, repr=False)
class VLayout:
    """Maps between a flat ``[nv]`` tangent vector (MuJoCo dof order, e.g.
    ``qvel`` or an ``mj_integratePos``-style position perturbation) and a
    product of per-joint order-1 :class:`CoordinateTangent` objects keyed by
    :class:`Id`."""

    template: dict[Id, Codec[CoordinateTangent]]
    context: "MujocoContext"

    @jit_method
    def unpack(self, x: jax.Array) -> V:
        things = self.context.joints | self.context.components
        values = unpack_quantities(x, self.template)
        return ProductCoordinateTangent(
            {id: maybe_reverse(v, things[id]) for id, v in values.items()}
        )

    @jit_method
    def pack(self, v: V) -> jax.Array:
        things = self.context.joints | self.context.components
        return pack_quantities(
            self.template,
            {
                id: maybe_reverse(dx, things[id], downward=True)
                for id, dx in v.parts.items()
            },
        )


@dataclasses.dataclass(eq=False, repr=False)
class QVLayout:
    """Maps between MuJoCo's ``(qpos, qvel)`` vectors and a
    :class:`TangentBundle` of the position and velocity products."""

    q: QLayout
    v: VLayout

    @jit_method
    def unpack(self, qpos: jax.Array, qvel: jax.Array) -> QV:
        return TangentBundle(self.q.unpack(qpos), self.v.unpack(qvel))

    @jit_method
    def pack(self, qv: QV) -> tuple[jax.Array, jax.Array]:
        return self.q.pack(qv.x), self.v.pack(qv.dx)


@dataclasses.dataclass(eq=False, repr=False)
class QVTangentLayout:
    """Maps a flat ``[2 nv]`` state tangent ``[dq; dv]`` (MuJoCo dof order,
    the ``mjd_transitionFD`` basis) to a :class:`TangentBundleTangent`
    suitable for shifting a ``qv`` bundle."""

    v: VLayout
    nv: int

    @jit_method
    def unpack(self, x: jax.Array) -> QVTangent:
        return TangentBundleTangent(
            self.v.unpack(x[..., : self.nv]),
            self.v.unpack(x[..., self.nv :]).log(),  # second-order tangent
        )


@dataclasses.dataclass(eq=False, repr=False)
class FixedQLayout:
    """Maps between MuJoCo's mocap arrays and a product of per-body fixed
    :class:`Pose` objects keyed by :class:`Id`."""

    ids: tuple[Id, ...]

    @jit_method
    def unpack(self, mocap_pos: jax.Array, mocap_quat: jax.Array) -> FixedQ:
        poses = deepunstack(Pose(pos=mocap_pos, quat=mocap_quat))
        return ProductCoordinate(dict(zip(self.ids, poses)))

    @jit_method
    def pack(self, fixed_q: FixedQ) -> tuple[jax.Array, jax.Array]:
        poses = [fixed_q.parts[id] for id in self.ids]
        if not poses:
            return jnp.zeros([0, 3]), jnp.zeros([0, 4])
        pose = deepstack(poses)
        return pose.pos, pose.unit_quat


@dataclasses.dataclass(eq=False, repr=False)
class ULayout:
    """Maps between MuJoCo's flat ``ctrl`` vector and per-actuator
    :class:`ControlValue` objects keyed by :class:`Id`."""

    template: dict[Id, Codec[ControlValue]]
    context: "MujocoContext"

    def check(self, id: Id, value: ControlValue) -> None:
        ai = self.context.actuators[id]
        quantity = ai.object.quantity
        if not isinstance(value, quantity):
            raise TypeError(
                f"actuator {ai.name!r} expects {quantity.__name__}, "
                f"got {type(value).__name__}"
            )

    @jit_method
    def unpack(self, ctrl: jax.Array) -> dict[Id, ControlValue]:
        return unpack_quantities(ctrl, self.template)

    @jit_method
    def pack(self, values: dict[Id, ControlValue]) -> jax.Array:
        for id, ai in self.context.actuators.items():
            if id not in values:
                raise KeyError(f"missing control for actuator {ai.name!r}")
            self.check(id, values[id])
        return pack_quantities(self.template, values)


@dataclasses.dataclass(eq=False, repr=False)
class YLayout:
    """Maps between MuJoCo's flat ``sensordata`` vector and per-sensor
    :class:`SensorValue` objects keyed by :class:`Id`."""

    template: dict[Id, Codec[Any]]
    context: "MujocoContext"

    @jit_method
    def unpack(self, sensordata: jax.Array) -> dict[Id, SensorValue]:
        values = unpack_quantities(sensordata, self.template)
        for id, value in values.items():
            match self.context.sensors[id].object:
                case sensors.Position(joint=j) | sensors.Velocity(joint=j):
                    values[id] = maybe_reverse(value, self.context.joints[j.id])
        return values

    @jit_method
    def pack(self, values: dict[Id, SensorValue]) -> jax.Array:
        values = dict(values)
        for id, value in values.items():
            match self.context.sensors[id].object:
                case sensors.Position(joint=j) | sensors.Velocity(joint=j):
                    values[id] = maybe_reverse(
                        value, self.context.joints[j.id], downward=True
                    )
        return pack_quantities(self.template, values)


@dataclasses.dataclass(eq=False, repr=False)
class Layout:
    """Maps between MuJoCo's flat state vectors and products of typed
    quantities keyed by :class:`Id`."""

    mj_model: mujoco.MjModel | mjx.Model
    context: "MujocoContext"
    qv: QVLayout
    qv_tangent: QVTangentLayout
    fixed_q: FixedQLayout
    u: ULayout
    y: YLayout

    @classmethod
    def make(
        cls, mj_model: mujoco.MjModel | mjx.Model, context: "MujocoContext"
    ) -> "Layout":
        """Build all templates in MuJoCo address order; free joints are keyed
        by their component's id, all others by their joint's id."""
        m = mj_model

        ci_by_idx = {ci.idx: ci for ci in context.components.values()}
        ji_by_idx = {
            ji.idx: ji
            for ji in context.joints.values()
            if not isinstance(ji.object, joints.Weld)
        }

        def _get_dof(jidx):
            if m.jnt_type[jidx] == mujoco.mjtJoint.mjJNT_FREE:
                id = ci_by_idx[int(m.jnt_bodyid[jidx])].object.id
                return id, Pose, PoseTangent
            j = ji_by_idx[jidx].object
            assert isinstance(j, joints.DofJoint)
            return j.id, j.q_type, j.dq_type

        dofs = list(map(_get_dof, range(m.njnt)))
        q = QLayout({id: get_codec(typ) for id, typ, _ in dofs}, context)
        v = VLayout({id: get_codec(typ) for id, _, typ in dofs}, context)
        qv = QVLayout(q, v)
        qv_tangent = QVTangentLayout(v, m.nv)

        fixed_indices = dict(
            sorted(
                (
                    (id, m.body_mocapid[ci.idx])
                    for id, ci in context.components.items()
                    if ci.is_fixed
                ),
                key=lambda kv: kv[1],
            )
        )
        assert list(fixed_indices.values()) == list(range(m.nmocap))
        fixed_q = FixedQLayout(tuple(fixed_indices.keys()))

        ais = sorted(context.actuators.items(), key=lambda kv: kv[1].idx)
        u = ULayout({id: get_codec(ai.object.quantity) for id, ai in ais}, context)

        sis = sorted(
            ((id, si) for id, si in context.sensors.items() if si.idx >= 0),
            key=lambda kv: m.sensor_adr[kv[1].idx],
        )
        codecs = {
            id: Codec(
                RawCoordinate,
                int(m.sensor_dim[si.idx]),
                RawCoordinate,
                lambda value: value.x,
            )
            if isinstance(si.object, sensors.Contact)
            else get_codec(si.object.quantity)
            for id, si in sis
        }
        y = YLayout(codecs, context)

        _check_dims_match(q.template.values(), m.jnt_qposadr, m.nq)
        _check_dims_match(v.template.values(), m.jnt_dofadr, m.nv)
        _check_dims_match(u.template.values(), np.arange(m.nu), m.nu)
        _check_dims_match(y.template.values(), m.sensor_adr, m.nsensordata)

        return cls(mj_model, context, qv, qv_tangent, fixed_q, u, y)

    def state_from_data(
        self, md: mujoco.MjData | mjx.Data, rng: jax.Array
    ) -> "EnvState":
        from robotl.handlers.mujoco.process import EnvState

        return EnvState(
            t=jnp.asarray(md.time),
            qv=self.qv.unpack(jnp.asarray(md.qpos), jnp.asarray(md.qvel)),
            fixed_q=self.fixed_q.unpack(
                jnp.asarray(md.mocap_pos), jnp.asarray(md.mocap_quat)
            ),
            y=self.y.unpack(jnp.asarray(md.sensordata)),
            u=self.u.unpack(jnp.asarray(md.ctrl)),
            rng=rng,
        )

    def state_to_data(self, state: "EnvState", md: mujoco.MjData | None = None):
        qpos, qvel = self.qv.pack(state.qv)
        mocap_pos, mocap_quat = self.fixed_q.pack(state.fixed_q)
        sensordata = self.y.pack(state.y)
        ctrl = self.u.pack(state.u)
        if isinstance(self.mj_model, mjx.Model):
            md = mjx.make_data(self.mj_model)
            md = md.replace(
                time=state.t,
                qpos=qpos,
                qvel=qvel,
                mocap_pos=mocap_pos,
                mocap_quat=mocap_quat,
                sensordata=sensordata,
                ctrl=ctrl,
            )
            md = mjx.forward(self.mj_model, md)
        else:
            if md is None:
                md = mujoco.MjData(self.mj_model)
            md.time = state.t
            md.qpos = qpos
            md.qvel = qvel
            md.mocap_pos = mocap_pos
            md.mocap_quat = mocap_quat
            md.sensordata = sensordata
            md.ctrl = ctrl
            mujoco.mj_forward(self.mj_model, md)
        return md

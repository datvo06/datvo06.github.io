"""MuJoCo export handler for RoboTL components.

This module provides functionality to convert RoboTL component trees
into MuJoCo XML format for physics simulation.
"""

import dataclasses
import logging
from collections.abc import Iterator
from importlib import resources
from itertools import combinations
from pathlib import Path
from typing import Any

import effectful.handlers.jax.numpy as jnp
import jax
import jax.random as rax
import mujoco
import networkx as nx
from effectful.ops.semantics import evaluate, handler
from effectful.ops.types import Interpretation, Term
from jax.scipy.spatial.transform import Rotation
from solid2.core.object_base import OpenSCADObject

from robotl.handlers.cad.inertia import inertia_from_shape
from robotl.handlers.cad.openscad import (
    DecomposeToMeshes,
    ShapeToOpenSCAD,
    solid2_to_mesh,
)
from robotl.handlers.cad.simplification import (
    FlattenLogicalOps,
    LogicalsOutward,
    NormalizeTransforms,
)
from robotl.handlers.mujoco.config import MujocoSettings
from robotl.internals import utils
from robotl.internals.utils import treepath_to_str
from robotl.ops import actuators, joints, sensors, shapes, tendons
from robotl.ops.id import Id
from robotl.ops.syntax import (
    Component,
    Fidelity,
    Inertia,
    Material,
    Origin,
    Port,
    Pose,
    collect_children,
    component_state,
    disable_pair_collisions,
    enable_pair_collisions,
    fidelity,
)

logger = logging.getLogger(__name__)


# NOTE x64=1 is currently broken
FIDELITY_PARAMS = {
    Fidelity.DEFAULT: dict(frac_collision=1.0, x64=0, frac_triangles=1.0),
    Fidelity.HIGH: dict(frac_collision=1.0, x64=0, frac_triangles=1.0),
    Fidelity.MEDIUM: dict(frac_collision=0.5, x64=0, frac_triangles=0.5),
    Fidelity.LOW: dict(frac_collision=0.0, x64=0, frac_triangles=0.25),
}


def _get_open3d():
    try:
        import open3d as o3d
    except ImportError as exc:
        raise ImportError(
            "open3d is required for mesh simplification. "
            "Install with `pip install .[fidelity]` or `uv sync --extra fidelity`."
        ) from exc
    return o3d


def is_port(c: Component) -> bool:
    return isinstance(c, Port)


@dataclasses.dataclass
class ComponentInfo:
    object: Component
    name: str
    is_fixed: bool
    idx: int = -1


@dataclasses.dataclass
class PortInfo:
    object: Port
    name: str
    owner: ComponentInfo
    idx: int = -1


@dataclasses.dataclass
class ActuatorInfo:
    object: actuators.Actuator
    name: str
    owner: ComponentInfo | PortInfo
    idx: int = -1


@dataclasses.dataclass
class SensorInfo:
    object: sensors.Sensor
    name: str
    owner: ComponentInfo | PortInfo
    idx: int = -1


@dataclasses.dataclass
class TendonInfo:
    object: tendons.Tendon
    name: str
    owner: ComponentInfo
    idx: int = -1


@dataclasses.dataclass
class JointInfo:
    object: joints.Joint
    name: str
    owner: ComponentInfo
    comp_a: Id
    comp_b: Id
    idx: int = -1
    reversed: bool | None = None


@dataclasses.dataclass
class MujocoContext:
    components: dict[Id, ComponentInfo] = dataclasses.field(default_factory=dict)
    ports: dict[Id, PortInfo] = dataclasses.field(default_factory=dict)
    sensors: dict[Id, SensorInfo] = dataclasses.field(default_factory=dict)
    actuators: dict[Id, ActuatorInfo] = dataclasses.field(default_factory=dict)
    joints: dict[Id, JointInfo] = dataclasses.field(default_factory=dict)
    tendons: dict[Id, TendonInfo] = dataclasses.field(default_factory=dict)
    pair_collision_excludes: set[frozenset[Id]] = dataclasses.field(default_factory=set)
    pair_collision_includes: set[frozenset[Id]] = dataclasses.field(default_factory=set)

    joints_by_component: dict[Id, list[tuple[JointInfo, Id]]] = dataclasses.field(
        default_factory=dict
    )


def make_context(root: Component) -> MujocoContext:
    ctx = MujocoContext()

    def _collect_components(node: Component, name: str):
        if is_port(node):
            return
        for k, v in collect_children(node).items():
            if v.id not in ctx.components:
                _collect_components(v, name=treepath_to_str((name, *k)))
        is_fixed = getattr(node, "_is_fixed", False)
        ctx.components.setdefault(node.id, ComponentInfo(node, name, is_fixed=is_fixed))

    _collect_components(Origin, "origin")
    _collect_components(root, "root")

    # we want to associate ports, sensors, actuators etc with their proper
    # owners -- not with abstract containers that inherited ports from their
    # children. traverse depth first so we encounter deeper occurrences first.
    def _collect_ports(parent: ComponentInfo):
        # descend first
        for k, v in collect_children(parent.object).items():
            if not is_port(v):
                _collect_ports(ctx.components[v.id])
        # then collect ports on current node
        for k, v in collect_children(parent.object).items():
            if is_port(v) and v.id not in ctx.ports:
                assert isinstance(v, Port)
                child_name = treepath_to_str((parent.name, *k))
                ctx.ports[v.id] = PortInfo(v, child_name, parent)

    _collect_ports(ctx.components[Origin.id])
    _collect_ports(ctx.components[root.id])

    def _collect_leaves(parent: ComponentInfo | PortInfo):
        # descend first
        for k, v in collect_children(parent.object).items():
            info = ctx.ports[v.id] if is_port(v) else ctx.components[v.id]
            _collect_leaves(info)
        # then collect leaves on current node
        for k, v in jax.tree.leaves_with_path(component_state(parent.object)):
            child_name = treepath_to_str((parent.name, *k))
            if isinstance(v, sensors.Sensor) and v.id not in ctx.sensors:
                ctx.sensors[v.id] = SensorInfo(v, child_name, parent)
            if isinstance(v, actuators.Actuator) and v.id not in ctx.actuators:
                ctx.actuators[v.id] = ActuatorInfo(v, child_name, parent)
                # auto create sensors used to compute actuation energy loss
                actfrc, actvel = sensors.ActuatorFrc(v), sensors.ActuatorVel(v)
                ctx.sensors[actfrc.id] = SensorInfo(
                    actfrc, f"{child_name}__actfrc", parent
                )
                ctx.sensors[actvel.id] = SensorInfo(
                    actvel, f"{child_name}__actvel", parent
                )
            if isinstance(v, joints.Joint) and v.id not in ctx.joints:
                if not is_port(v.a) or not is_port(v.b):
                    raise TypeError(
                        "Joints must connect Ports, not general Components", child_name
                    )
                try:
                    comp_a = ctx.ports[v.a.id].owner.object.id
                    comp_b = ctx.ports[v.b.id].owner.object.id
                except KeyError:
                    raise ValueError("Joint references unknown component", child_name)
                assert isinstance(parent, ComponentInfo)
                ctx.joints[v.id] = JointInfo(
                    v, child_name, parent, comp_a=comp_a, comp_b=comp_b
                )
            if isinstance(v, tendons.Tendon) and v.id not in ctx.tendons:
                assert isinstance(parent, ComponentInfo)
                ctx.tendons[v.id] = TendonInfo(v, child_name, parent)
            if isinstance(v, Term) and v.op is disable_pair_collisions:
                c1, c2 = v.args
                assert isinstance(c1, Component) and isinstance(c2, Component)
                ctx.pair_collision_excludes.add(frozenset((c1.id, c2.id)))
            if isinstance(v, Term) and v.op is enable_pair_collisions:
                c1, c2 = v.args
                assert isinstance(c1, Component) and isinstance(c2, Component)
                ctx.pair_collision_includes.add(frozenset((c1.id, c2.id)))

    _collect_leaves(ctx.components[Origin.id])
    _collect_leaves(ctx.components[root.id])

    # index joints for O(1) lookup
    ctx.joints_by_component.update((id, []) for id in ctx.components.keys())
    for ji in ctx.joints.values():
        ctx.joints_by_component[ji.comp_a].append((ji, ji.comp_b))
        ctx.joints_by_component[ji.comp_b].append((ji, ji.comp_a))

    return ctx


def update_context(ctx: MujocoContext, mj_model: mujoco.MjModel):
    for ci in ctx.components.values():
        ci.idx = mj_model.body(ci.name).id
    for pi in ctx.ports.values():
        pi.idx = mj_model.site(pi.name).id
    for ai in ctx.actuators.values():
        ai.idx = mj_model.actuator(ai.name).id
    for si in ctx.sensors.values():
        if not isinstance(si.object, sensors.Virtual):
            si.idx = mj_model.sensor(si.name).id
    for ji in ctx.joints.values():
        if not isinstance(ji.object, joints.Weld):
            ji.idx = mj_model.joint(ji.name).id
    for ti in ctx.tendons.values():
        ti.idx = mj_model.tendon(ti.name).id


def _attach_island(
    spec: mujoco.MjSpec,
    ctx: MujocoContext,
    root: Id,
    debug_ports: bool = False,
) -> mujoco.MjsBody:
    """Attach a kinematic tree to the worldbody."""

    visited: set[Id] = set()

    def _attach_tree(
        node: Id, parent_elem: mujoco.MjsBody, parent_id: Id | None, parent_pose: Pose
    ):
        if node in visited:
            return None
        visited.add(node)

        ci: ComponentInfo = evaluate(ctx.components[node])  # type: ignore
        rel_pose = ~parent_pose @ ci.object.pose
        body_elem = parent_elem.add_body(
            name=ci.name,
            pos=rel_pose.pos,
            quat=rel_pose.quat,
            mocap=ci.is_fixed,
        )
        _attach_ports(ctx, body_elem, ci.object, debug_ports=debug_ports)
        # One decomposition per body: the same convex hulls carry the inertia
        # and the geoms, so neither pass renders or runs COACD again.
        shape = _decomposed_shape(ci)
        _attach_inertia(body_elem, ci.object, shape)
        if shape is not None:
            _attach_geom(spec, body_elem, ci.object, body_elem.name, shape)

        for i, overlay in enumerate(ci.object.vshape):
            prefix = (
                body_elem.name
                if len(ci.object.vshape) == 1
                else f"{body_elem.name}__visual_{i}"
            )
            _attach_geom(
                spec,
                body_elem,
                ci.object,
                prefix,
                overlay.shape,
                visual=True,
                material=overlay.material,
            )

        # a joint j is reversed if j.a's component is child of j.b's component. this has
        # implications for mapping between what mujoco reports the joint state to be and
        # what we report it to be
        if parent_id is not None:
            child_id = ci.object.id
            for ji, other_id in ctx.joints_by_component[child_id]:
                if other_id != parent_id:
                    continue
                # NOTE this mutates ctx:
                ji.reversed = (child_id, parent_id) == (ji.comp_a, ji.comp_b)
                _attach_joint(ji, body_elem=body_elem, body_pose=ci.object.pose)

        for _, child in ctx.joints_by_component[node]:
            _attach_tree(child, body_elem, node, ci.object.pose)

        return body_elem

    root_body = _attach_tree(root, spec.worldbody, None, Pose())
    assert root_body is not None
    return root_body


def _decomposed_shape(ci: ComponentInfo) -> Term | None:
    """A component's shape with every ``decompose`` replaced by its convex hulls.

    ``None`` when the component has no ``shape``.
    """
    shape = getattr(ci.object, "shape", None)
    if shape is None:
        return None
    assert isinstance(shape, Term), shape
    with handler(DecomposeToMeshes(ci.name)):
        decomposed = evaluate(shape)
    assert isinstance(decomposed, Term), decomposed
    return decomposed


def _attach_inertia(body_elem: mujoco.MjsBody, comp: Component, shape: Term | None):
    """Set the body's inertia: explicit, integrated from ``shape``, or none.

    ``shape`` is the component's shape with ``decompose`` already rewritten,
    the same term the geoms come from, so a density integrates the convex
    hulls that also collide.
    """
    inertia: Inertia | None = getattr(comp, "inertia", None)
    if inertia is None:
        if shape is not None:
            material = comp.get_material()
            if material.density is not None:
                assert isinstance(shape, shapes.Shape), shape
                inertia = inertia_from_shape(shape, material)
        else:
            # mujoco requires either geometry or inertia
            inertia = Inertia(mass=1e-6, diag=1e-6 * jnp.ones([3]))
    if inertia is not None:
        body_elem.ipos = inertia.pose.pos
        body_elem.iquat = inertia.pose.quat
        body_elem.mass = inertia.mass
        body_elem.inertia = inertia.diag
        # tell spec.to_xml() to retain inertial information
        body_elem.explicitinertial = 1


def _attach_ports(
    ctx: MujocoContext,
    body_elem: mujoco.MjsBody,
    comp: Component,
    debug_ports: bool = False,
):
    # ports may be inherited by containers; only attach the port to its proper owner.
    # additionally, ports may be stored under multiple names in the component, so use
    # a set to deduplicate.
    ports = set(
        port.id
        for port in collect_children(comp).values()
        if is_port(port) and ctx.ports[port.id].owner.object.id == comp.id
    )
    # locate ports as sites inside the component's body, so they transform along
    for id in ports:
        pi: PortInfo = evaluate(ctx.ports[id])  # type: ignore
        pose = ~comp.pose @ pi.object.pose
        # group 3 to avoid visualization by default
        body_elem.add_site(name=pi.name, pos=pose.pos, quat=pose.quat, group=3)
        if debug_ports:
            # sphere at port origin
            body_elem.add_geom(
                type=mujoco.mjtGeom.mjGEOM_SPHERE,
                size=[0.001, 0, 0],
                pos=pose.pos,
                rgba=[1, 0, 0, 1],
                contype=0,
                conaffinity=0,
            )
            # shaft extending from origin along port z-axis
            shaft_offset = pose.rot @ jnp.array([0, 0, 0.004])
            body_elem.add_geom(
                type=mujoco.mjtGeom.mjGEOM_CYLINDER,
                size=[0.0005, 0.004, 0],
                pos=pose.pos + shaft_offset,
                quat=pose.quat,
                rgba=[1, 0, 0, 1],
                contype=0,
                conaffinity=0,
            )


def _attach_geom(
    spec: mujoco.MjSpec,
    parent: mujoco.MjsBody,
    c: Component,
    name: str,
    shape: Term | shapes.Shape,
    *,
    visual: bool = False,
    material: Material | None = None,
) -> None:
    """Emit geoms for ``shape``: ``c.shape``, or ``c.vshape`` when ``visual``.

    ``c.shape`` arrives with ``decompose`` already rewritten into convex
    ``mesh`` hulls by the caller, which shares it with the inertia. A
    ``vshape`` is a visual-only CAD expression sharing the same shape DSL as
    ``shape``: its geoms are emitted with ``contype=conaffinity=0`` and at full
    mesh resolution (no collision decimation), and the collision ``shape`` is
    pushed to render group 3 so only the visual overlay is seen.
    """
    assert isinstance(shape, Term), shape
    # Hide the collision primitive behind its visual overlay, if one exists.
    hidden = not visual and bool(c.vshape)

    def attach_primitive(**kwargs):
        if visual or c.disable_collision:
            kwargs = dict(contype=0, conaffinity=0) | kwargs
        if visual:
            # Visual overlays are massless, so a vshape never contributes to
            # the body's inertia when mass falls back to geom densities.
            kwargs["density"] = 0
        if hidden:
            # Hide the parametric collision primitive from the default
            # renderer by putting it on group 3 (``mjvOption.geomgroup``
            # default is ``[1,1,1,0,0,0]``). Collision bitmasks are
            # untouched, so it still drives contact as before.
            # Panda external collision meshes explicitly use group 0;
            # their visual shells must hide that group as well.
            kwargs["group"] = 3
        m = material if material is not None else c.get_material()
        if m.name is not None:
            # Reference a material registered on the MjSpec (e.g. the leap
            # mesh / cube-face materials from the visual-defaults pass).
            kwargs["material"] = m.name
        elif m.color is not None:
            kwargs["rgba"] = m.color
        elif "material" not in kwargs:
            # Use default material only if no material is already specified
            kwargs["material"] = "default_geom"
        if m.friction is not None:
            # MuJoCo friction is [sliding, torsional, rolling]
            # Accept only scalar friction for sliding component
            kwargs["friction"] = [m.friction, 0.005, 0.0001]
        if m.density is not None:
            kwargs.setdefault("density", m.density)
        if m.solref is not None:
            kwargs["solref"] = m.solref
        if m.solimp is not None:
            # MjSpec requires solimp to be exactly 5 elements; missing tail
            # entries keep MuJoCo's defaults for their positions.
            defaults = (0.9, 0.95, 0.001, 0.5, 2.0)
            kwargs["solimp"] = [*m.solimp, *defaults[len(m.solimp) :]][:5]
        if "size" in kwargs:
            # MjSpec requires size to be exactly 3 elements
            kwargs["size"] = [*kwargs["size"], 0, 0, 0][:3]
        return parent.add_geom(**kwargs)

    if not visual and isinstance(c, tendons.TendonPulley):
        assert shape.op is shapes.cylinder, "TendonPulley shape must be a cylinder"
        r = float(jnp.asarray(shape.kwargs["r"]))
        h = float(jnp.asarray(shape.kwargs["h"]))
        # Handle mismatching between Mujoco's positioning of cylinders and RoboTL's
        attach_primitive(
            type=mujoco.mjtGeom.mjGEOM_CYLINDER,
            size=[r, h / 2],
            pos=jnp.array([0, 0, h / 2]),
            name=f"{name}0",
        )
        return

    def get_transformed_geom(term):
        pos = jnp.zeros([3])
        rot = Rotation.identity()
        scl = jnp.ones([3])
        match term:
            case Term(shapes.translate, (term, pos)):
                pass
        match term:
            case Term(shapes.rotate, (term, rot)):
                pass
        match term:
            case Term(shapes.scale, (term, scl)):
                pass
        return term, jnp.asarray(pos), rot, jnp.asarray(scl)

    with (
        handler(NormalizeTransforms()),
        handler(FlattenLogicalOps()),
        handler(LogicalsOutward()),
    ):
        union_term = evaluate(shape)
    terms = [*union_term.args] if union_term.op is shapes.union else [union_term]
    assert isinstance(terms, list)

    def attach_general(term, name):
        with handler(ShapeToOpenSCAD()):
            model = evaluate(term)
        assert isinstance(model, OpenSCADObject)
        path = solid2_to_mesh(model, name)
        attach_external_mesh(path, name)

    def attach_external_mesh(path, name, scale=(1, 1, 1), **kwargs):
        # Visual overlays keep full resolution; only collision meshes decimate.
        frac_triangles = (
            1.0 if visual else FIDELITY_PARAMS[fidelity()]["frac_triangles"]
        )
        assert 0 < frac_triangles <= 1
        if frac_triangles == 1:
            dpath = path
        else:
            dpath = (Path("build/decimate") / name).with_suffix(".stl")
            o3d = _get_open3d()
            mesh = o3d.io.read_triangle_mesh(path)
            mesh.remove_duplicated_vertices()
            mesh.remove_degenerate_triangles()
            mesh.remove_non_manifold_edges()
            mesh.remove_unreferenced_vertices()
            # mujoco needs >= 4 vertices; fewer target triangles collapse to a flat sheet
            k = max(4, int(len(mesh.triangles) * frac_triangles))
            dmesh = mesh.simplify_quadric_decimation(target_number_of_triangles=k)
            dmesh.compute_vertex_normals()
            dmesh.compute_triangle_normals()
            dpath.parent.mkdir(parents=True, exist_ok=True)
            o3d.io.write_triangle_mesh(dpath, dmesh)

        spec.add_mesh(
            name=f"{name}__mesh",
            file=str(dpath),
            scale=scale,
            maxhullvert=64,  # limit convex hull complexity
        )
        attach_primitive(
            type=mujoco.mjtGeom.mjGEOM_MESH,
            name=name,
            meshname=f"{name}__mesh",
            group=0,
            **kwargs,
        )

    def handle_toplevel_term(term, name):
        # mjx does not support general collisions with ellipsoids and cylinders
        EXPORT_ELLIPSOID = False
        EXPORT_CYLINDER = False

        g, pos, rot, scl = get_transformed_geom(term)
        kwargs = dict(pos=pos, quat=rot.as_quat(scalar_first=True), name=name)
        match g:
            case Term(shapes.sphere, (r,)):
                if jnp.all(scl == 1):
                    attach_primitive(
                        type=mujoco.mjtGeom.mjGEOM_SPHERE,
                        size=[r],
                        **kwargs,
                    )
                elif EXPORT_ELLIPSOID:
                    attach_primitive(
                        type=mujoco.mjtGeom.mjGEOM_ELLIPSOID,
                        size=r * scl,
                        **kwargs,
                    )
                else:
                    attach_general(term, name=name)
            case Term(shapes.cube, extents):
                extents = scl * jnp.asarray(extents)
                # adjust pos to account for centering
                kwargs["pos"] = kwargs["pos"] + rot.apply(extents / 2)
                attach_primitive(
                    type=mujoco.mjtGeom.mjGEOM_BOX,
                    size=extents / 2,
                    **kwargs,
                )
            case Term(shapes.cylinder, (), kw):
                r, h, r2 = kw["r"], kw["h"], kw.get("r2", None)
                is_tapered = r2 is not None and r != r2
                is_elliptical = scl[0] != scl[1]
                if is_tapered or is_elliptical or not EXPORT_CYLINDER:
                    # not supported, fall back to mesh
                    attach_general(term, name=name)
                else:
                    # adjust pos to account for centering
                    kwargs["pos"] += rot.apply(jnp.array([0, 0, scl[2] * h / 2]))
                    attach_primitive(
                        type=mujoco.mjtGeom.mjGEOM_CYLINDER,
                        size=[scl[0] * r, scl[2] * h / 2],
                        **kwargs,
                    )
            case Term(shapes.capsule, (), {"r": r, "h": h}):
                is_elliptical = scl[0] != scl[1]
                if is_elliptical:
                    # not supported, fall back to mesh
                    attach_general(term, name=name)
                else:
                    # adjust pos to account for centering
                    kwargs["pos"] += rot.apply(jnp.array([0, 0, scl[2] * h / 2]))
                    attach_primitive(
                        type=mujoco.mjtGeom.mjGEOM_CAPSULE,
                        size=[scl[0] * r, scl[2] * h / 2],
                        **kwargs,
                    )
            case Term(shapes.external_mesh, (path,)):
                attach_external_mesh(path, scale=scl, **kwargs)
            case Term(shapes.mesh, (m,)):
                # A convex hull from ``DecomposeToMeshes`` or a part a
                # component built itself: written straight to STL, no
                # OpenSCAD round trip.
                path = Path("build/decompose") / f"{name}.stl"
                path.parent.mkdir(parents=True, exist_ok=True)
                m.to_trimesh().export(path)
                attach_external_mesh(str(path), scale=scl, **kwargs)
            case Term(shapes.plane):
                # Use floor material for planes if no explicit color/material
                if "rgba" not in kwargs and "material" not in kwargs:
                    kwargs["material"] = "floor_mat"
                attach_primitive(
                    type=mujoco.mjtGeom.mjGEOM_PLANE,
                    size=[0, 0, 1],
                    **kwargs,
                )
            case _:
                attach_general(term, name=name)

    suffix = "_vis" if visual else ""
    for i, term in enumerate(terms):
        handle_toplevel_term(term, name=f"{name}{suffix}{i}")


def _attach_joint(
    ji: JointInfo,
    body_elem: mujoco.MjsBody,
    body_pose: Pose,
) -> None:
    j: joints.Joint = evaluate(ji.object)  # type: ignore

    if isinstance(j, joints.Weld):
        return  # do nothing -- mujoco welds by default

    rel_pose = ~body_pose @ j.a.pose
    attrs = dict(
        name=ji.name,
        pos=rel_pose.pos,
        damping=j.damping,
        armature=j.armature,
        frictionloss=j.frictionloss,
    )

    def spring_attrs(
        j: joints.Hinge | joints.Hinge2 | joints.Slide,
    ) -> dict[str, jax.typing.ArrayLike]:
        """Spring attributes for ``j``, empty when it carries no spring."""
        if j.spring is None:
            return {}
        return dict(stiffness=j.spring.stiffness, springref=j.spring.rest)

    if isinstance(j, joints.Hinge | joints.Hinge2):
        # NOTE x.axis is specified relative to the frame of the ports x.a and x.b
        # (and is initially equal in those frames)
        world_axis = j.a.pose.rotational @ j.axis  # (using x.b.pose is equivalent)
        body_axis = ~body_pose.rotational @ world_axis
        axis = (-1 if ji.reversed else 1) * body_axis
        body_elem.add_joint(
            type=mujoco.mjtJoint.mjJNT_HINGE,
            axis=axis,
            ref=j.theta0,
            range=(0, 0) if j.range is None else j.range,
            **(attrs | spring_attrs(j)),
        )
    elif isinstance(j, joints.Slide):
        # NOTE x.axis is specified relative to the frame of the ports x.a and x.b
        # (and is initially equal in those frames)
        world_axis = j.a.pose.rotational @ j.axis  # (using x.b.pose is equivalent)
        body_axis = ~body_pose.rotational @ world_axis
        axis = (-1 if ji.reversed else 1) * body_axis
        body_elem.add_joint(
            type=mujoco.mjtJoint.mjJNT_SLIDE,
            axis=axis,
            range=(0, 0) if j.range is None else j.range,
            **(attrs | spring_attrs(j)),
        )
    elif isinstance(j, joints.Ball):
        # NOTE unlike hinge/slide, ball does not have an axis argument we can
        # flip to handle the reverse case.  it is taken care of in
        # sensor_get_handler instead.
        body_elem.add_joint(
            type=mujoco.mjtJoint.mjJNT_BALL,
            range=(0, 0 if j.range is None else j.range),
            **attrs,
        )
    else:
        raise ValueError("Unexpected joint type ", j)


def _attach_tendons(
    spec: mujoco.MjSpec,
    ctx: MujocoContext,
) -> None:
    def port_name(p: Port) -> str:
        if p.id not in ctx.ports:
            raise ValueError("Tendon port must belong to the model")
        return ctx.ports[p.id].name

    def geom_name(c: Component, geom_index: int) -> str:
        if not hasattr(c, "shape"):
            raise ValueError("Tendon wrap component must define a shape")
        ci = ctx.components[c.id]
        return f"{ci.name}{geom_index}"

    for ti in ctx.tendons.values():
        t: tendons.Tendon = evaluate(ti.object)  # type: ignore

        rest = jnp.broadcast_to(jnp.asarray(t.rest_length), (2,)) - t.offset
        attrs: dict[str, object] = dict(
            name=ti.name,
            stiffness=t.stiffness,
            damping=t.damping,
            springlength=tuple(float(value) for value in rest),
        )
        if t.range is not None:
            attrs["limited"] = True
            attrs["range"] = t.range
        if t.limit_stiffness not in (0, None):
            logger.info(
                "MuJoCo does not expose a separate limit_stiffness for tendons; "
                "using range limits with default solver settings."
            )

        if isinstance(t, tendons.FixedTendon):
            tendon = spec.add_tendon(**attrs)
            assert t.gear_ratios is not None, (
                "gear_ratios must be provided for fixed tendons"
            )
            assert len(t.joints) == len(t.gear_ratios), (
                "joints and gear_ratios must have the same length"
            )
            for joint, coef in zip(t.joints, t.gear_ratios):
                tendon.wrap_joint(ctx.joints[joint.id].name, coef)
        elif isinstance(t, tendons.SpatialTendon):
            if t.color is not None:
                attrs["rgba"] = list(t.color)
            if t.width is not None:
                width = float(jnp.asarray(t.width))
                if width <= 0 and t.color is None:
                    attrs["rgba"] = [0.0, 0.0, 0.0, 0.0]
                attrs["width"] = width if width > 0 else 1e-6
            tendon = spec.add_tendon(**attrs)
            for entry in t.path:
                if isinstance(entry, Port):
                    tendon.wrap_site(port_name(entry))
                elif isinstance(entry, tendons.TendonPulley):
                    sidesite = port_name(entry.side) if hasattr(entry, "side") else ""
                    tendon.wrap_geom(geom_name(entry, 0), sidesite)
                else:
                    raise ValueError("Unexpected tendon path entry", entry)
        else:
            raise ValueError("Unknown tendon type", t)


def _attach_actuators(spec: mujoco.MjSpec, ctx: MujocoContext) -> None:
    def transmission(
        target: actuators.Actuatable[Any, Any, Any],
    ) -> tuple[str, mujoco.mjtTrn]:
        if isinstance(target, tendons.Tendon):
            return ctx.tendons[target.id].name, mujoco.mjtTrn.mjTRN_TENDON
        return ctx.joints[target.id].name, mujoco.mjtTrn.mjTRN_JOINT

    for ai in ctx.actuators.values():
        a: actuators.Actuator = evaluate(ai.object)  # type: ignore
        assert isinstance(a.target, actuators.Actuatable), a
        if isinstance(a, actuators.Position):
            # Position actuator with kp/kv gains
            # In MjSpec, we use gainprm and biasprm for position control
            # gainprm and biasprm must be size 10
            target_name, trntype = transmission(a.target)
            spec.add_actuator(
                name=ai.name,
                target=target_name,
                trntype=trntype,
                dyntype=mujoco.mjtDyn.mjDYN_NONE,
                gaintype=mujoco.mjtGain.mjGAIN_FIXED,
                biastype=mujoco.mjtBias.mjBIAS_AFFINE,
                gear=[a.gear, 0, 0, 0, 0, 0],
                forcerange=(0, 0) if a.forcerange is None else a.forcerange,
                ctrllimited=0 if a.ctrlrange is None else 1,
                ctrlrange=(0, 0) if a.ctrlrange is None else a.ctrlrange,
                dynprm=[0] * 10,  # size 10
                gainprm=[a.kp] + [0] * 9,  # size 10
                biasprm=[0, -a.kp, -a.kv] + [0] * 7,  # type: ignore
            )
        elif isinstance(a, actuators.Velocity):
            # Velocity actuator with kv gain
            target_name, trntype = transmission(a.target)
            spec.add_actuator(
                name=ai.name,
                target=target_name,
                trntype=trntype,
                dyntype=mujoco.mjtDyn.mjDYN_NONE,
                gaintype=mujoco.mjtGain.mjGAIN_FIXED,
                biastype=mujoco.mjtBias.mjBIAS_AFFINE,
                gear=[a.gear, 0, 0, 0, 0, 0],
                forcerange=(0, 0) if a.forcerange is None else a.forcerange,
                ctrllimited=0 if a.ctrlrange is None else 1,
                ctrlrange=(0, 0) if a.ctrlrange is None else a.ctrlrange,
                dynprm=[1] + [0] * 9,  # size 10
                gainprm=[a.kv] + [0] * 9,  # size 10
                biasprm=[0, 0, -a.kv] + [0] * 7,  # type: ignore
            )
        elif isinstance(a, actuators.Force):
            # Motor actuator (force control), on a joint or pulling a tendon.
            target_name, trntype = transmission(a.target)
            spec.add_actuator(
                name=ai.name,
                target=target_name,
                trntype=trntype,
                dyntype=mujoco.mjtDyn.mjDYN_NONE,
                gaintype=mujoco.mjtGain.mjGAIN_FIXED,
                biastype=mujoco.mjtBias.mjBIAS_NONE,
                gear=[a.gear, 0, 0, 0, 0, 0],
                forcerange=(0, 0) if a.forcerange is None else a.forcerange,
                ctrllimited=0 if a.ctrlrange is None else 1,
                ctrlrange=(0, 0) if a.ctrlrange is None else a.ctrlrange,
                dynprm=[1] + [0] * 9,  # size 10
                gainprm=[1] + [0] * 9,  # size 10
                biasprm=[0] * 10,  # size 10
            )
        else:
            raise ValueError("Unexpected actuator", a)


def _attach_sensors(spec: mujoco.MjSpec, ctx: MujocoContext) -> None:
    for si in ctx.sensors.values():
        if isinstance(si.object, sensors.Virtual):
            continue
        s: sensors.Sensor = evaluate(si.object)  # type: ignore
        if isinstance(s, sensors.Contact):
            spec.add_sensor(
                name=si.name,
                type=mujoco.mjtSensor.mjSENS_CONTACT,
                objtype=mujoco.mjtObj.mjOBJ_BODY,
                objname=ctx.components[s.first_id].name,
                reftype=mujoco.mjtObj.mjOBJ_BODY,
                refname=ctx.components[s.second_id].name,
                intprm=[s.mask, 0, s.capacity],
            )
        elif isinstance(s, sensors.MinimumContactDistance):
            spec.add_sensor(
                name=si.name,
                type=mujoco.mjtSensor.mjSENS_CONTACT,
                intprm=[sensors.ContactField.DISTANCE.value, 1, 1],
            )
        elif isinstance(s, sensors.Position):
            jname = ctx.joints[s.joint.id].name
            if isinstance(s.joint, joints.Ball):
                spec.add_sensor(
                    name=si.name,
                    type=mujoco.mjtSensor.mjSENS_BALLQUAT,
                    objtype=mujoco.mjtObj.mjOBJ_JOINT,
                    objname=jname,
                )
            else:
                spec.add_sensor(
                    name=si.name,
                    type=mujoco.mjtSensor.mjSENS_JOINTPOS,
                    objtype=mujoco.mjtObj.mjOBJ_JOINT,
                    objname=jname,
                )
        elif isinstance(s, sensors.Velocity):
            jname = ctx.joints[s.joint.id].name
            if isinstance(s.joint, joints.Ball):
                spec.add_sensor(
                    name=si.name,
                    type=mujoco.mjtSensor.mjSENS_BALLANGVEL,
                    objtype=mujoco.mjtObj.mjOBJ_JOINT,
                    objname=jname,
                )
            else:
                spec.add_sensor(
                    name=si.name,
                    type=mujoco.mjtSensor.mjSENS_JOINTVEL,
                    objtype=mujoco.mjtObj.mjOBJ_JOINT,
                    objname=jname,
                )
        elif isinstance(s, sensors.ActuatorFrc):
            aname = ctx.actuators[s.actuator.id].name
            spec.add_sensor(
                name=f"{aname}__actfrc",
                type=mujoco.mjtSensor.mjSENS_ACTUATORFRC,
                objname=aname,
                objtype=mujoco.mjtObj.mjOBJ_ACTUATOR,
            )
        elif isinstance(s, sensors.ActuatorVel):
            aname = ctx.actuators[s.actuator.id].name
            spec.add_sensor(
                name=f"{aname}__actvel",
                type=mujoco.mjtSensor.mjSENS_ACTUATORVEL,
                objname=aname,
                objtype=mujoco.mjtObj.mjOBJ_ACTUATOR,
            )
        elif isinstance(s, sensors.FrameSensor):
            sensor_type_map = {
                sensors.FrameLinPos: mujoco.mjtSensor.mjSENS_FRAMEPOS,
                sensors.FrameAngPos: mujoco.mjtSensor.mjSENS_FRAMEQUAT,
                sensors.FrameLinVel: mujoco.mjtSensor.mjSENS_FRAMELINVEL,
                sensors.FrameAngVel: mujoco.mjtSensor.mjSENS_FRAMEANGVEL,
                sensors.FrameLinAcc: mujoco.mjtSensor.mjSENS_FRAMELINACC,
                sensors.FrameAngAcc: mujoco.mjtSensor.mjSENS_FRAMEANGACC,
            }
            objtype = (
                mujoco.mjtObj.mjOBJ_SITE
                if is_port(si.owner.object)
                else mujoco.mjtObj.mjOBJ_XBODY
            )
            spec.add_sensor(
                name=si.name,
                type=sensor_type_map[type(s)],
                objtype=objtype,
                objname=si.owner.name,
            )
        else:
            raise ValueError("Unexpected sensor", s)


def _include_collisions(
    spec: mujoco.MjSpec, ctx: MujocoContext, id1: Id, id2: Id
) -> None:
    """Emit explicit contact pairs for two components' collision geoms.

    An explicit pair is checked regardless of MuJoCo's parent filtering,
    which is what lets jointed neighbours touch. A compiled explicit pair
    carries the global default contact parameters rather than the geoms'
    own, so the components' material solref and solimp are mixed onto each
    pair the way dynamically matched contacts mix them, by averaging.
    """

    def mixed(attr: str) -> jax.Array | None:
        values = [
            value
            for id in (id1, id2)
            if (value := getattr(ctx.components[id].object.get_material(), attr))
            is not None
        ]
        if not values:
            return None
        return jnp.stack([jnp.asarray(v, dtype=float) for v in values]).mean(axis=0)

    params: dict[str, jax.Array] = {}
    if (solref := mixed("solref")) is not None:
        params["solref"] = solref
    if (solimp := mixed("solimp")) is not None:
        defaults = (0.9, 0.95, 0.001, 0.5, 2.0)
        params["solimp"] = jnp.concatenate(
            [solimp, jnp.asarray(defaults[len(solimp) :])]
        )
    for g1 in spec.body(ctx.components[id1].name).geoms:
        if not (g1.contype or g1.conaffinity):
            continue
        for g2 in spec.body(ctx.components[id2].name).geoms:
            if not (g2.contype or g2.conaffinity):
                continue
            spec.add_pair(geomname1=g1.name, geomname2=g2.name, **params)


def _exclude_collisions(
    spec: mujoco.MjSpec,
    ctx: MujocoContext,
    rng: jax.Array,
    frac_collision: float | None = None,
):
    frac_collision = frac_collision or FIDELITY_PARAMS[fidelity()]["frac_collision"]
    assert 0 <= frac_collision <= 1
    if frac_collision < 1:
        body_names = [
            ci.name
            for ci in ctx.components.values()
            if ci.object.id != Origin.id and hasattr(ci.object, "shape")
        ]
        body_pairs = list(combinations(body_names, 2))
        k = int(jnp.round((1 - frac_collision) * len(body_pairs)))
        pair_indices = rax.choice(
            rng,
            len(body_pairs),
            shape=[k],
            replace=False,
        )
        for i in pair_indices:
            b1, b2 = body_pairs[i]
            spec.add_exclude(bodyname1=b1, bodyname2=b2)


def _islands(ctx: MujocoContext) -> Iterator[set[Id]]:
    g: nx.Graph = nx.Graph()
    g.add_nodes_from(ctx.components.keys())
    g.add_edges_from([(ji.comp_a, ji.comp_b) for ji in ctx.joints.values()])
    for island in nx.connected_components(g):
        if not nx.is_tree(nx.subgraph_view(g, filter_node=lambda n: n in island)):
            raise RuntimeError("Expected kinematic graph to be a tree.")
        yield island


def _register_named_materials(spec: mujoco.MjSpec, names: set[str]) -> None:
    """Register the domain materials referenced by ``Material(name=...)``.

    Only the names actually used by the model are added, so unrelated envs
    don't carry them (or read their texture assets). The definitions live here
    rather than being registered unconditionally.
    """
    if "leap_mesh_body" in names:
        # matte-black plastic; mild specular so the mesh detail catches the light
        spec.add_material(
            name="leap_mesh_body",
            rgba=[0.38, 0.38, 0.38, 1.0],
            shininess=0.35,
            specular=0.25,
            reflectance=0.08,
        )
    if "leap_mesh_tip" in names:
        # white silicone fingertip pad
        spec.add_material(
            name="leap_mesh_tip",
            rgba=[0.96, 0.96, 0.96, 1.0],
            shininess=0.2,
            specular=0.2,
            reflectance=0.04,
        )
    if "cube_faces_mat" in names:
        # Per-face cube texture — 6 solid colors from tiny PNGs in
        # assets/cube_faces/, one per face, so spin orientation is
        # visible. MuJoCo's XML serializer can't inline buffer textures, so we
        # use cubefiles= (order: right, left, up, down, front, back).
        cube_faces_dir = resources.files("robotl").parent.joinpath(  # type: ignore
            "assets", "cube_faces"
        )
        cube_face_files = [
            str(cube_faces_dir / f"{face}.png")
            for face in ("right", "left", "up", "down", "front", "back")
        ]
        spec.add_texture(
            name="cube_faces",
            type=mujoco.mjtTexture.mjTEXTURE_CUBE,
            cubefiles=cube_face_files,
        )
        texslots = [""] * int(mujoco.mjtTextureRole.mjNTEXROLE)
        texslots[int(mujoco.mjtTextureRole.mjTEXROLE_RGB)] = "cube_faces"
        spec.add_material(
            name="cube_faces_mat",
            textures=texslots,
            texuniform=True,
            rgba=[1.0, 1.0, 1.0, 1.0],
            shininess=0.2,
            specular=0.15,
        )


def compile(
    model: Component,
    init: Interpretation,
    rng: jax.Array = rax.key(0),
    build_path: Path | None = None,
    is_outermost: bool = True,
    *,
    frac_collision: float | None = None,
    memory: int | None = None,
    zoom: float = 1.0,
    elevation: float = -0.175,
    azimuth: float = 2.50,
    debug_ports: bool = False,
    settings: MujocoSettings | None = None,
) -> tuple[mujoco.MjModel, MujocoContext]:
    """Convert a RoboTL model to MuJoCo XML format.

    :param model: The RoboTL model to convert
    :param init: Initial poses (e.g. from solve_init)
    :param build_path: Directory in which to store the XML and assets
    :returns: Tuple containing MuJoCo XML root element and context with name-to-ID mappings
    :param frac_collision: Fraction of collisions to disable. If None, use the default fidelity parameter.
    """

    spec = mujoco.MjSpec()
    spec.compiler.degree = False  # Use radians instead of degrees
    if memory is not None:
        spec.memory = memory

    # Default material for geometries without an explicit color. Near-white
    # with a subtle cool tint so the robot reads as a clean plastic object
    # rather than muddy gray. Moderate specular + low shininess keeps top
    # facets from blowing out under the directional sun light.
    spec.add_material(
        name="default_geom",
        rgba=[0.88, 0.90, 0.93, 1.0],  # near-white with cool undertone
        shininess=0.2,
        specular=0.25,
        reflectance=0.05,
    )

    # Floor material — matches mujoco_menagerie/leap_hand/scene_right.xml:
    # dark navy checker with light edge marks, 5×5 repeats, reflectance 0.2.
    # Gives the muted-navy ground that the menagerie LEAP hand renders use.
    spec.add_texture(
        name="floor_checker",
        type=mujoco.mjtTexture.mjTEXTURE_2D,
        builtin=mujoco.mjtBuiltin.mjBUILTIN_CHECKER,
        mark=mujoco.mjtMark.mjMARK_EDGE,
        rgb1=[0.2, 0.3, 0.4],
        rgb2=[0.1, 0.2, 0.3],
        markrgb=[0.8, 0.8, 0.8],
        width=300,
        height=300,
    )
    _floor_texslots = [""] * int(mujoco.mjtTextureRole.mjNTEXROLE)
    _floor_texslots[int(mujoco.mjtTextureRole.mjTEXROLE_RGB)] = "floor_checker"
    spec.add_material(
        name="floor_mat",
        textures=_floor_texslots,
        texrepeat=[5.0, 5.0],
        texuniform=True,
        reflectance=0.2,
    )

    ctx = make_context(model)

    def is_fixed(id: Id):
        return id == Origin.id or ctx.components[id].is_fixed

    # Register on-demand domain materials (leap mesh, cube faces) only when a
    # component references them by name, so unrelated envs neither carry them
    # nor read their texture assets on every compile.
    referenced_materials = {
        m.name
        for ci in ctx.components.values()
        if (m := ci.object.get_material()).name is not None
    }
    referenced_materials.update(
        overlay.material.name
        for ci in ctx.components.values()
        for overlay in ci.object.vshape
        if overlay.material.name is not None
    )
    _register_named_materials(spec, referenced_materials)

    with handler(init):
        for island in _islands(ctx):
            # choose a node to be the root
            candidates = [cc for cc in island if is_fixed(cc)]
            if len(candidates) > 1:
                raise ValueError(
                    "absolutely positioned components cannot be mechanically connected",
                    [ctx.components[cc].name for cc in candidates],
                )
            elif len(candidates) == 1:
                [root] = candidates
            elif len(candidates) == 0:
                # choose arbitrarily with _mujoco_root hint
                root = next(iter(island))
                for cc in island:
                    if getattr(ctx.components[cc].object, "_mujoco_root", False):
                        root = cc

            root_body = _attach_island(spec, ctx, root, debug_ports=debug_ports)

            # Add freejoint to root component if it isn't attached to the origin
            if is_outermost and not is_fixed(root):
                root_body.add_joint(type=mujoco.mjtJoint.mjJNT_FREE)

        _attach_tendons(spec, ctx)
        _attach_actuators(spec, ctx)
        _attach_sensors(spec, ctx)
        for id1, id2 in ctx.pair_collision_excludes:
            spec.add_exclude(
                bodyname1=ctx.components[id1].name,
                bodyname2=ctx.components[id2].name,
            )
        for id1, id2 in ctx.pair_collision_includes:
            _include_collisions(spec, ctx, id1, id2)
        _exclude_collisions(
            spec, ctx, utils.rscope(rng, "frac_collision"), frac_collision
        )

    # Add visual defaults before compilation
    if is_outermost:
        _add_visual_defaults(spec, elevation=elevation, azimuth=azimuth, zoom=zoom)

    # MJX reads these two numeric fields at ``mjx.make_data`` time to size
    # its contact / constraint buffers. Without them, MJX falls back to
    # ``ngeom**2`` worst-case allocation, which on scenes with many geoms
    # produces a huge contact buffer (and a correspondingly huge HLO
    # graph, because contact-handling code paths are unrolled per slot).
    # The caps are hard upper bounds — actual contact count at runtime
    # is still determined by the physics, just clamped here. They must be
    # baked into the spec pre-compile; the rest of ``settings`` (solver
    # opts) is applied post-compile by the caller via ``settings.apply``.
    if settings is not None and settings.max_contact_points is not None:
        spec.add_numeric(
            name="max_contact_points", data=[float(settings.max_contact_points)]
        )
    if settings is not None and settings.max_geom_pairs is not None:
        spec.add_numeric(name="max_geom_pairs", data=[float(settings.max_geom_pairs)])

    # Optionally write XML for debugging
    if build_path is not None:
        build_path.mkdir(parents=True, exist_ok=True)
        (build_path / "model.xml").write_text(spec.to_xml())

    # Compile the model directly from spec
    mj_model = spec.compile()

    update_context(ctx, mj_model)
    return (mj_model, ctx)


def _add_visual_defaults(
    spec: mujoco.MjSpec,
    elevation: float = -0.175,
    azimuth: float = 2.5,
    zoom: float = 1.0,
):
    """Add default lighting and skybox — matches mujoco_menagerie/leap_hand."""
    # Standardize high-res offscreen rendering
    spec.visual.global_.offwidth = 1280
    spec.visual.global_.offheight = 1024
    # Multisample anti-aliasing for cleaner edges. Renderer default is 4;
    # 8 samples cuts the staircasing visibly at negligible compute cost.
    spec.visual.quality.offsamples = 8
    # Larger shadow map reduces the pixelation that shows up when the sun
    # casts a directional shadow onto the floor (default 1024). MuJoCo
    # supports up to 8192 which is worth the few extra milliseconds on
    # polished renders.
    spec.visual.quality.shadowsize = 8192
    # Lighting: Menagerie's scene uses a matte-specular headlight, but
    # with our visual-mesh materials that carry specular/shininess we
    # turn on a modest specular component so highlights actually show
    # on fingertips and servo housings. Ambient slightly lowered so the
    # fill light below has room to model the side of the hand.
    spec.visual.headlight.ambient = [0.25, 0.25, 0.25]
    spec.visual.headlight.diffuse = [0.55, 0.55, 0.55]
    spec.visual.headlight.specular = [0.25, 0.25, 0.25]
    # Atmospheric haze — tints distant geometry to match the skybox horizon,
    # giving depth to far-field surfaces. Matches menagerie verbatim.
    spec.visual.rgba.haze = [0.15, 0.25, 0.35, 1.0]

    # Compile temporarily to compute camera framing
    m = spec.compile()
    d = mujoco.MjData(m)
    mujoco.mj_forward(m, d)

    center = m.stat.center
    extent = m.stat.extent

    dist = (extent * 2) * zoom
    phi = azimuth
    theta = elevation

    direction = jnp.array(
        [
            jnp.cos(theta) * jnp.cos(phi),
            jnp.cos(theta) * jnp.sin(phi),
            jnp.sin(theta),
        ]
    )

    cam_pos = center - dist * direction

    # Build camera frame with z-axis pointing at target and y-axis as "up"
    z_cam = -direction
    up = jnp.array([0, 0, 1])
    # Handle gimbal lock when looking straight up/down
    if jnp.abs(jnp.dot(up, z_cam)) > 0.99:
        up = jnp.array([0, 1, 0])
    x_cam = jnp.cross(up, z_cam)
    y_cam = jnp.cross(z_cam, x_cam)
    # Camera rotation matrix with rows as the camera axes
    camera_axes = jnp.stack([x_cam, y_cam, z_cam], axis=0)
    camera_pose = Pose(pos=cam_pos, axes=camera_axes)

    spec.worldbody.add_camera(
        name="cinematic",
        pos=camera_pose.pos,
        quat=camera_pose.quat,
    )

    # Menagerie-matching skybox: gradient blue (top) → black (horizon),
    # 512×3072 tall so the blue only appears at the true top of the sphere
    # — cleaner against a low camera than our previous full-sphere blue.
    spec.add_texture(
        name="skybox",
        type=mujoco.mjtTexture.mjTEXTURE_SKYBOX,
        builtin=mujoco.mjtBuiltin.mjBUILTIN_GRADIENT,
        rgb1=[0.3, 0.5, 0.7],
        rgb2=[0.0, 0.0, 0.0],
        width=512,
        height=3072,
    )

    # Directional sun — straight down, default intensity. Matches menagerie:
    # `<light pos="0 0 1" dir="0 0 -1" directional="true"/>`. Combined with
    # the bright headlight above, this produces soft cast shadows without
    # over-lighting any facet.
    spec.worldbody.add_light(
        name="sun",
        pos=[0, 0, 1],
        dir=[0, 0, -1],
        type=mujoco.mjtLightType.mjLIGHT_DIRECTIONAL,
        castshadow=True,
    )

    # Side fill light from 45° off to one side — no cast shadow, modest
    # diffuse — to bring out the sculpted detail of the servo housings
    # that the overhead sun alone tends to flatten into silhouette.
    spec.worldbody.add_light(
        name="fill",
        pos=[0.6, 0.3, 0.6],
        dir=[-0.7, -0.35, -0.7],
        type=mujoco.mjtLightType.mjLIGHT_DIRECTIONAL,
        castshadow=False,
        diffuse=[0.35, 0.35, 0.35],
        specular=[0.15, 0.15, 0.15],
    )

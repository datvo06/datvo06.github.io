import dataclasses
from collections.abc import Callable
from functools import partial
from typing import TYPE_CHECKING, Any, Protocol, Self, overload

import effectful.handlers.jax.numpy as jnp
import jax
import jax.random as rax
import mujoco
import numpy as np
from effectful.ops.semantics import coproduct, evaluate, handler
from effectful.ops.syntax import defop
from effectful.ops.types import Interpretation, NotHandled, Operation, Term
from flax import struct
from mujoco import mjx

try:
    from tqdm import tqdm
except ImportError:
    tqdm = None

from robotl.handlers.mujoco.compiler import (
    FIDELITY_PARAMS,
    MujocoContext,
)
from robotl.handlers.mujoco.mappings import Layout, get_codec
from robotl.handlers.mujoco.types import QV, FixedQ, Q, V
from robotl.internals import utils
from robotl.internals.utils import (
    deepstack,
    treepath_to_str,
)
from robotl.ops import actuators, joints, sensors
from robotl.ops.actuators import ControlValue
from robotl.ops.coords import Coordinate, CoordinateTangent, norm
from robotl.ops.id import Id
from robotl.ops.losses import Loss
from robotl.ops.sensors import SensorValue
from robotl.ops.syntax import (
    Component,
    Pose,
    PoseTangent,
    component_state,
    fidelity,
    time,
)

if TYPE_CHECKING:
    from robotl.handlers.mujoco.rollouts import Runner

# an action is a mapping from actuator Id to typed ctrl value
type Action = dict[Id, ControlValue]


def _make_frame_intp(model: Component, context: MujocoContext) -> Interpretation:
    """Traverse model and construct handlers for pos/vel/acc variables."""

    def xpos_handler(c):
        linear = c._linpos.get()
        angular = c._angpos.get()
        return Pose(lin=linear, rot=angular)

    def xvel_handler(c):
        linear = c._linvel.get()
        angular = c._angvel.get()
        return PoseTangent(linear, angular)

    def xacc_handler(c):
        linear = c._linacc.get()
        angular = c._angacc.get()
        return PoseTangent(linear, angular)

    frame_handlers: dict[Operation, Callable] = {}

    def add_frame_handlers(component: Component):
        pos, vel, acc = component.pose, component.velocity, component.acceleration
        if isinstance(pos, Term):
            if pos.args or pos.kwargs:
                raise ValueError("Unexpected term in component pose", pos)
            frame_handlers[pos.op] = partial(xpos_handler, component)
        if isinstance(vel, Term):
            if vel.args or vel.kwargs:
                raise ValueError("Unexpected term in component velocity", vel)
            frame_handlers[vel.op] = partial(xvel_handler, component)
        if isinstance(acc, Term):
            if acc.args or acc.kwargs:
                raise ValueError("Unexpected term in component acceleration", acc)
            frame_handlers[acc.op] = partial(xacc_handler, component)

    for info in (context.components | context.ports).values():
        add_frame_handlers(info.object)

    def actuator_power_handler(a: actuators.Actuator):
        ss = {
            type(si.object): si
            for si in context.sensors.values()
            if getattr(getattr(si.object, "actuator", None), "id", None) == a.id
        }
        actfrc = ss[sensors.ActuatorFrc].object.get()
        actvel = ss[sensors.ActuatorVel].object.get()
        return norm(actfrc) * norm(actvel)

    frame_handlers[actuators.Actuator._power] = actuator_power_handler

    def total_actuation_power_handler():
        # ideally an env component would construct this by itself, but it doesn't
        # have easy access to its set of actuators
        return sum(ai.object.power for ai in context.actuators.values())

    frame_handlers[total_actuation_power] = total_actuation_power_handler

    return frame_handlers


@defop
def total_actuation_power() -> jax.Array:
    raise NotHandled


# MjModel is backed by C structs and cannot be made transparent to jit/vmap
jax.tree_util.register_static(mujoco.MjModel)


class EnvSpec(struct.PyTreeNode):
    model: Component = struct.field(pytree_node=False)
    context: MujocoContext = struct.field(pytree_node=False)
    _frame_intp: Interpretation = struct.field(pytree_node=False)
    layout: Layout = struct.field(pytree_node=False)
    runner: "Runner" = struct.field(pytree_node=False)

    @property
    def mj_model(self) -> mujoco.MjModel | mjx.Model:
        return self.layout.mj_model

    @property
    def dt(self):
        return self.mj_model.opt.timestep

    @property
    def is_mjx(self):
        return isinstance(self.mj_model, mjx.Model)

    @classmethod
    def make(
        cls,
        model,
        context,
        mj_model,
        use_mjx=False,
        runner: "Callable[[EnvSpec], Runner] | None" = None,
    ) -> Self:
        from robotl.handlers.mujoco.rollouts import JaxableThreadedRunner, MjxRunner

        if use_mjx:
            with utils.maybe_enable_x64(FIDELITY_PARAMS[fidelity()]["x64"]):
                mm = mjx.put_model(mj_model)
        else:
            mm = mj_model
        layout = Layout.make(mm, context)
        frame_intp = _make_frame_intp(model, context)
        # the runner is built from the spec, so the spec starts without one
        spec = cls(model, context, frame_intp, layout, None)  # type: ignore[arg-type]
        if runner is None:
            runner = lambda spec: (
                MjxRunner() if spec.is_mjx else JaxableThreadedRunner.make(spec)
            )
        return spec.replace(runner=runner(spec))

    def init(self, rng) -> "EnvState":
        if self.is_mjx:
            with utils.maybe_enable_x64(FIDELITY_PARAMS[fidelity()]["x64"]):
                md = mjx.make_data(self.mj_model)
                # call forward to make sure qLD doesn't change shape after this
                md = mjx.forward(self.mj_model, md)
        else:
            md = mujoco.MjData(self.mj_model)
            # call forward to populate sensordata
            mujoco.mj_forward(self.mj_model, md)
        return self.layout.state_from_data(md, rng)

    def step(self, state: "EnvState", *, action: Action | None = None) -> "EnvState":
        state = self.set_action(state, action) if action is not None else state
        with utils.maybe_enable_x64(FIDELITY_PARAMS[fidelity()]["x64"]):
            next_state = self.runner.step(self, state, state.u)
        return next_state.replace(rng=rax.fold_in(state.rng, 0))

    def forward(self, state: "EnvState") -> "EnvState":
        with utils.maybe_enable_x64(FIDELITY_PARAMS[fidelity()]["x64"]):
            return self.runner.forward(self, state)

    def set_action(self, state: "EnvState", action: Action) -> "EnvState":
        for id, value in action.items():
            assert not isinstance(value, Term), value
            self.layout.u.check(id, value)
        return state.replace(u={**state.u, **action})

    def intp(self, state: "EnvState") -> Interpretation:
        """Extract component positions and rotations from physics state."""

        def sensor_get(s: sensors.Sensor):
            if isinstance(s, sensors.Virtual):
                return evaluate(s.expr)
            return state.y[s.id]

        return coproduct(
            self._frame_intp,
            {
                time: lambda: state.t,
                sensors.Sensor._get: sensor_get,
            },
        )

    def get_losses(self, state: "EnvState") -> dict[str, jax.Array]:
        losses = dict()
        for ci in self.context.components.values():
            for k, v in jax.tree.leaves_with_path(
                component_state(ci.object), is_leaf=lambda x: isinstance(x, Loss)
            ):
                if isinstance(v, Loss):
                    name = treepath_to_str((ci.name, *k))
                    losses[name] = v.value

        with handler(self.intp(state)):
            losses: dict[str, jax.Array] = evaluate(losses)  # type: ignore

        return losses

    def get_loss(self, state: "EnvState") -> jax.Array:
        return jnp.stack(list(self.get_losses(state).values())).sum()


class EnvState(struct.PyTreeNode):
    t: jax.Array
    qv: QV
    fixed_q: FixedQ
    y: dict[Id, SensorValue]
    u: dict[Id, ControlValue]
    rng: jax.Array

    @property
    def q(self) -> Q:
        """Position factor (base point) of the ``qv`` bundle."""
        return self.qv.x

    @property
    def v(self) -> V:
        """Velocity fiber of the ``qv`` bundle, matching ``q`` key-for-key."""
        return self.qv.dx

    @overload
    def position[Q_: Coordinate](self, key: joints.DofJoint[Q_, Any]) -> Q_: ...
    @overload
    def position(self, key: Id | joints.Joint | Component) -> Coordinate: ...

    def position(self, key: Id | joints.Joint | Component) -> Any:
        """Position of a joint or component, falling through to the fixed
        poses in :attr:`fixed_q` (which have no :meth:`velocity`)."""
        id = key if isinstance(key, Id) else key.id
        return self.q.parts[id] if id in self.q.parts else self.fixed_q.parts[id]

    @overload
    def velocity[DQ: CoordinateTangent](self, key: joints.DofJoint[Any, DQ]) -> DQ: ...
    @overload
    def velocity(self, key: Id | joints.Joint | Component) -> CoordinateTangent: ...

    def velocity(self, key: Id | joints.Joint | Component) -> Any:
        return self.v.parts[key if isinstance(key, Id) else key.id]

    @overload
    def sensor[V_: SensorValue](self, key: sensors.Sensor[V_]) -> V_: ...
    @overload
    def sensor(self, key: Id) -> SensorValue: ...

    def sensor(self, key: Id | sensors.Sensor[Any]) -> Any:
        return self.y[key if isinstance(key, Id) else key.id]


class EnvProcess(struct.PyTreeNode):
    spec: EnvSpec
    state: EnvState

    @property
    def is_mjx(self):
        return self.spec.is_mjx

    @classmethod
    def make(
        cls,
        model,
        context,
        mj_model,
        rng,
        use_mjx=False,
        runner: "Callable[[EnvSpec], Runner] | None" = None,
    ):
        spec = EnvSpec.make(model, context, mj_model, use_mjx=use_mjx, runner=runner)
        state = spec.init(rng)
        return cls(spec, state)

    def copy(self) -> Self:
        return self

    def intp(self) -> Interpretation:
        return self.spec.intp(self.state)

    def step(self, action: Action | None = None) -> Self:
        return self.replace(state=self.spec.step(self.state, action=action))

    def set_action(self, action: Action) -> Self:
        return self.replace(state=self.spec.set_action(self.state, action))


class Controller[T](Protocol):
    def init(self, rng: jax.Array, env: EnvProcess) -> T: ...
    def __call__(self, state: T, env: EnvProcess) -> T: ...


@defop
def set_ctrl(ctrl: jax.Array) -> None:
    """Set current env control vector."""
    raise NotHandled


@dataclasses.dataclass(eq=False)
class RatedController[T]:
    """Wrapper to rate-limit expensive controller calls."""

    controller: Controller[T]
    dt: float

    def init(self, rng, env: EnvProcess) -> tuple[float, T]:
        return -jax.numpy.inf, self.controller.init(rng, env)

    def __call__(self, state, env: EnvProcess) -> tuple[float, T]:
        # this is hard to do with jax; cond works but not inside vmap
        assert not env.is_mjx
        last_ctime, cstate = state
        if env.state.t > last_ctime + self.dt:
            cstate = self.controller(cstate, env)
            last_ctime = env.state.t
        # if we do not call the controller, then mj_data.ctrl remains unchanged
        return last_ctime, cstate


class ControlProcess[T](struct.PyTreeNode):
    controller: Controller[T] = struct.field(pytree_node=False)
    state: T

    @classmethod
    def make(cls, controller, env0: EnvProcess, rng):
        with utils.maybe_enable_x64(FIDELITY_PARAMS[fidelity()]["x64"]):
            state = controller.init(rng, env0)
        return cls(controller, state)

    def act(self, env: EnvProcess) -> tuple[Self, Action]:
        action: Action = dict(env.state.u)

        def set_ctrl_handler(ctrl: jax.Array):
            action.update(env.spec.layout.u.unpack(ctrl))

        def actuator_set_handler(a: actuators.Actuator, v: ControlValue):
            action[a.id] = v

        action_intp: Interpretation = {
            set_ctrl: set_ctrl_handler,
            actuators.Actuator.set: actuator_set_handler,
        }

        with utils.maybe_enable_x64(FIDELITY_PARAMS[fidelity()]["x64"]):
            with handler(env.intp()), handler(action_intp):
                state = self.controller(self.state, env)
                action = evaluate(action)  # type: ignore
        return self.replace(state=state), action


def simple_controller(fn: Callable[[EnvProcess], None]) -> Controller[None]:
    @struct.dataclass
    class SimpleController:
        def init(self, rng=None, env=None):
            return None

        def __call__(self, state, env):
            fn(env)
            return None

    return SimpleController()


def step_episode(
    env: EnvProcess, control: ControlProcess
) -> tuple[EnvProcess, ControlProcess]:
    control, action = control.act(env)
    env = env.step(action=action)
    return env, control


class Episode(struct.PyTreeNode):
    """A recorded closed-loop episode.

    ``states`` is the stacked :class:`EnvState` trajectory (leading ``[T]``
    axis); ``channels`` holds any per-step quantities recorded alongside it
    (``{}`` when nothing was recorded). Pure array data — jit/vmap friendly;
    a batch of episodes is an ``Episode`` with ``[B, T]`` leaves.
    """

    states: EnvState
    channels: dict = struct.field(default_factory=dict)

    def to_npz_dict(self, spec: EnvSpec) -> dict:
        """Flatten to a dict of numpy arrays for ``np.savez``. Each entry of
        ``states.q``/``v``/``fixed_q``/``u``/``y`` becomes a
        ``q__<name>``-style key with its typed value unwrapped to a flat
        array; time is ``t``; nested channel paths join with ``__``
        (``loss_terms__onaxis``).
        """
        things = (
            spec.context.components
            | spec.context.joints
            | spec.context.sensors
            | spec.context.actuators
        )

        def unwrap(x):
            return np.asarray(get_codec(type(x)).unwrap(x))

        dicts: dict[str, dict[Id, Any]] = {
            "q": self.states.q.parts,
            "v": self.states.v.parts,
            "fixed_q": self.states.fixed_q.parts,
            "u": self.states.u,
            "y": self.states.y,
        }
        out = {
            f"{k}__{things[l].name}": (
                np.asarray(spec.layout.y.template[l].unwrap(x))
                if k == "y"
                else unwrap(x)
            )
            for k, d in dicts.items()
            for l, x in d.items()
        } | {"t": np.asarray(self.states.t)}
        for path, leaf in jax.tree_util.tree_leaves_with_path(self.channels):
            name = jax.tree_util.keystr(path).replace("['", ".").replace("']", "")
            out[name.strip(".").replace(".", "__")] = np.asarray(leaf)
        return out


def run_episode(
    env: EnvProcess,
    control: ControlProcess,
    *,
    length=1,
    record=None,
    progress=False,
    scan: bool | None = None,
) -> Episode:
    """Run an episode of a controller interacting with an environment.

    ``record(env, control) -> dict`` is called after each step; its outputs
    are stacked into ``Episode.channels`` with a leading ``[T]`` axis.

    ``scan`` (default: whether ``spec.runner`` is jaxable) runs a single
    ``lax.scan`` (callers own the jit boundary — and the clock, if timing;
    ``progress`` is ignored). Otherwise a Python loop, so controllers and
    ``record`` may use Python control flow.
    """

    def fn(carry, _):
        env, control = step_episode(*carry)
        channels = {} if record is None else record(env, control)
        return (env, control), (env.state, channels)

    if scan is None:
        scan = env.spec.runner.jaxable
    if scan:
        _, out = jax.lax.scan(fn, (env, control), length=length)
    else:
        carry = env, control
        frames = []
        iterator = range(length)
        if progress and tqdm is not None:
            iterator = tqdm(iterator)
        for _ in iterator:
            carry, frame = fn(carry, None)
            frames.append(frame)
        out = deepstack(frames)

    states, channels = out
    return Episode(states=states, channels=channels)

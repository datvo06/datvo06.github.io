"""MuJoCo model-predictive control: a receding-horizon driver over a planner.

:class:`MPCController` is the *driver* — the adapter between a
:class:`~robotl.handlers.mujoco.control.planners.Planner` (which only ever rolls
out candidate futures in the model) and the runtime's ``Controller`` interface
(which acts on the live env). Every tick it does the same three things: ask the planner to replan
(the planner runs its improvement steps, or skips if its
``replan_interval`` says the plan is still fresh), apply the plan's first
action via ``set_ctrl``, and shift the plan by one step::

    MPCController(SamplingPlanner(horizon=1.0, rounds=4, batch_size=64, ...))

All cadence — ``rounds`` per tick and ``replan_interval`` between replans — is
the planner's configuration; the controller holds no knobs.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import partial

import effectful.handlers.jax.numpy as jnp
import jax
import mujoco
import numpy as np

from robotl.handlers.mujoco.process import (
    EnvProcess,
    EnvSpec,
    EnvState,
    set_ctrl,
)

from .planners import Planner, PlannerState


@dataclass(eq=False)
class MPCController:
    """Receding-horizon driver over a :class:`Planner` (see module docstring)."""

    planner: Planner

    def init(self, rng, env0: EnvProcess):
        return self.planner.init(rng, env0)

    def __call__(self, state, env: EnvProcess):
        state = self.planner.replan(state, env)
        next_state, control = self._step_plan(state, env.spec.dt)
        control = self.planner.check_control(state, control)
        set_ctrl(control)
        return next_state

    @partial(jax.jit, static_argnums=0)
    def _step_plan(
        self, state: PlannerState, dt: float
    ) -> tuple[PlannerState, jax.Array]:
        control = self.planner.get_plan(state)(0)
        return self.planner.shift(state, dt), control


def compute_contact_penalty(
    spec: EnvSpec,
    rollouts: EnvState,
    *,
    max_samples: int | None = None,
) -> jax.Array:
    """Average squared penetration depth over subsampled trajectory frames.

    For each trajectory, reconstruct body positions from the rollout state and run
    collision detection on up to ``max_samples`` evenly-spaced frames (``None``
    checks all frames). Returns shape ``[B]``. Runs on CPU (not JIT-compatible).
    """
    mj_model = spec.mj_model
    B, T = rollouts.t.shape
    if T == 0:
        return jnp.zeros(B)
    pen = np.zeros(B, dtype=np.float32)
    d = mujoco.MjData(mj_model)
    # Subsample frames to keep cost manageable (each sample runs mj_collision).
    sample_step = 1 if max_samples is None else max(1, T // max_samples)
    n_samples = len(range(0, T, sample_step))
    for b in range(B):
        for t in range(0, T, sample_step):
            state = jax.tree.map(lambda x: x[b, t], rollouts)
            d = spec.layout.state_to_data(state, d)
            mujoco.mj_kinematics(mj_model, d)
            mujoco.mj_collision(mj_model, d)
            ncon = d.ncon
            if ncon == 0:
                continue
            dists = d.contact.dist[:ncon]
            mask = dists < 0
            pen[b] += np.sum(dists[mask] ** 2)
    return jnp.asarray(pen / n_samples)

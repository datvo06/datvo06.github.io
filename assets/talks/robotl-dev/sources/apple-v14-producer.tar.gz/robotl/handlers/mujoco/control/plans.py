from typing import Protocol, Self

import effectful.handlers.jax.numpy as jnp
import jax
import jax.random as rax
from flax import struct

from robotl.handlers.mujoco.process import EnvProcess, EnvSpec
from robotl.internals.utils import CSpline


class Plan(Protocol):
    def __call__(self, t: jax.typing.ArrayLike) -> jax.Array: ...

    def shift(self, dt: float) -> Self: ...

    def params(self) -> jax.Array: ...

    def with_params(self, params: jax.Array, spec: EnvSpec) -> Self: ...

    def reanchor(self, control: jax.Array) -> Self:
        """Bind any command constraints to the last issued control."""
        return self


def initial_knots(
    env: EnvProcess, horizon: float, knot_interval: float
) -> tuple[jax.Array, jax.Array]:
    """Knot times over ``[0, horizon)`` at ``knot_interval`` spacing and the constant
    initial knot values (current actuated pose); shapes ``[n_knots]``, ``[n_knots, nu]``."""
    horizon_steps = max(1, int(round(horizon / env.spec.dt)))
    knot_di = max(1, int(round(knot_interval / env.spec.dt)))
    knot_i = list(range(0, horizon_steps, knot_di))
    if knot_i[-1] != horizon_steps - 1:
        knot_i.append(horizon_steps - 1)
    knot_t = jnp.asarray(knot_i) * env.spec.dt
    dof_idx = env.spec.mj_model.jnt_dofadr[env.spec.mj_model.actuator_trnid[:, 0]]
    q0 = env.spec.layout.state_to_data(env.state).qpos[dof_idx]
    knot_x = jnp.broadcast_to(q0, [len(knot_i), env.spec.mj_model.nu])
    return knot_t, knot_x


class DensePlan(struct.PyTreeNode, Plan):
    x: jax.Array
    dt: float = struct.field(pytree_node=False)

    @classmethod
    def make(cls, env: EnvProcess, horizon: float, knot_interval: float = 0.25) -> Self:
        knot_t, knot_x = initial_knots(env, horizon, knot_interval)
        return cls(knot_x, float(knot_t[1] - knot_t[0]))

    def __call__(self, t):
        grid = jnp.arange(self.x.shape[0]) * self.dt
        i = jnp.searchsorted(grid, t, side="right") - 1
        return self.x[jnp.clip(i, 0, self.x.shape[0] - 1)]

    def shift(self, dt):
        di = jnp.floor(dt / self.dt).astype(int)
        return self.replace(x=jnp.roll(self.x, -di, axis=0))

    def params(self) -> jax.Array:
        return self.x

    def with_params(self, params: jax.Array, spec: EnvSpec) -> Self:
        return self.replace(x=params)


class BoundedDensePlan(DensePlan):
    """Dense commands projected against position and per-step slew bounds."""

    previous_control: jax.Array
    velocity_limits: tuple[float, ...] = struct.field(pytree_node=False)

    @classmethod
    def from_env(
        cls, env: EnvProcess, horizon: float, *, velocity_limits: tuple[float, ...]
    ) -> Self:
        """Anchor a nonempty plan to the actual issued actuator commands."""
        count = round(horizon / env.spec.dt)
        if count < 1:
            raise ValueError("Bounded plan horizon must contain at least one timestep")
        control = env.spec.layout.u.pack(env.state.u)
        if len(velocity_limits) != len(control):
            raise ValueError("Velocity limits must match the actuator count")
        x = jnp.broadcast_to(control, (count, len(control)))
        return cls(x, float(env.spec.dt), control, velocity_limits)

    def with_params(self, params: jax.Array, spec: EnvSpec) -> Self:
        model = spec.mj_model
        ranges = jnp.asarray(model.actuator_ctrlrange)
        lo = jnp.where(model.actuator_ctrllimited, ranges[:, 0], -jnp.inf)
        hi = jnp.where(model.actuator_ctrllimited, ranges[:, 1], jnp.inf)
        return self.replace(
            x=self._slew(jnp.clip(params, lo, hi), self.previous_control)
        )

    def _slew(self, params: jax.Array, previous_control: jax.Array) -> jax.Array:
        delta = jnp.asarray(self.velocity_limits) * self.dt
        dtype = jnp.result_type(params, previous_control, delta)
        params = params.astype(dtype)
        previous_control = previous_control.astype(dtype)

        def project(previous, desired):
            command = jnp.clip(desired, previous - delta, previous + delta)
            return command, command

        _, x = jax.lax.scan(project, previous_control, params)
        return x

    def reanchor(self, control: jax.Array) -> Self:
        """Retain position bounds while projecting from the issued elite command."""
        return self.replace(x=self._slew(self.x, control), previous_control=control)

    def shift(self, dt):
        di = jnp.floor(dt / self.dt).astype(int)
        consumed = self.x.at[jnp.maximum(di - 1, 0)].get(mode="clip")
        previous = jnp.where(di > 0, consumed, self.previous_control)
        indices = jnp.arange(self.x.shape[0]) + di
        return self.replace(
            x=self.x.at[indices].get(mode="clip"), previous_control=previous
        )


class ZeroOrderHoldPlan(struct.PyTreeNode, Plan):
    t: jax.Array
    x: jax.Array

    @classmethod
    def make(cls, env: EnvProcess, horizon: float, knot_interval: float = 0.25) -> Self:
        return cls(*initial_knots(env, horizon, knot_interval))

    def __call__(self, t):
        assert self.t.ndim == 1
        assert self.x.ndim == 2
        order = jnp.argsort(self.t)

        @jax.vmap
        def fn(t):
            ia = jnp.searchsorted(self.t, t, sorter=order, method="compare_all") - 1
            ia = jnp.clip(ia, 0, self.x.shape[0] - 1)
            return self.x[ia]

        x = fn(jnp.ravel(t))
        return x.reshape([*jnp.shape(t), self.x.shape[1]])

    def shift(self, dt):
        # move expired time points to the end
        t = jnp.where(self.t >= dt, self.t - dt, jnp.max(self.t))
        return self.replace(t=t, x=self(t))

    def params(self) -> jax.Array:
        return self.x

    def with_params(self, params: jax.Array, spec: EnvSpec) -> Self:
        return self.replace(x=params)


class LinearSplinePlan(struct.PyTreeNode, Plan):
    t: jax.Array
    x: jax.Array

    @classmethod
    def make(cls, env: EnvProcess, horizon: float, knot_interval: float = 0.25) -> Self:
        return cls(*initial_knots(env, horizon, knot_interval))

    def __call__(self, t):
        assert self.t.ndim == 1
        assert self.x.ndim == 2
        assert self.t.shape[0] == self.x.shape[0]
        t_shape = jnp.shape(t)
        order = jnp.argsort(self.t)
        x = jax.vmap(
            lambda x: jnp.interp(jnp.ravel(t), self.t[order], x[order]),
            in_axes=1,
            out_axes=1,
        )(self.x)
        return x.reshape([*t_shape, self.x.shape[1]])

    def shift(self, dt):
        # move expired time points to the end
        t = jnp.where(self.t >= dt, self.t - dt, jnp.max(self.t))
        return self.replace(t=t, x=self(t))

    def params(self) -> jax.Array:
        return self.x

    def with_params(self, params: jax.Array, spec: EnvSpec) -> Self:
        return self.replace(x=params)


def actuated_joint_limits(mj_model) -> tuple[jax.Array, jax.Array]:
    """Per-actuated-joint limits ``(q_min, q_max)``, each shape ``[n_act]``;
    ``±inf`` where the joint is unlimited."""
    jmin = jnp.where(mj_model.jnt_limited, mj_model.jnt_range[:, 0], -jax.numpy.inf)
    jmax = jnp.where(mj_model.jnt_limited, mj_model.jnt_range[:, 1], +jax.numpy.inf)
    actuated = mj_model.actuator_trnid[:, 0]
    return jmin[actuated], jmax[actuated]


def _actuator_span(q_min: jax.Array, q_max: jax.Array) -> jax.Array:
    """Per-actuator joint range span; unit span for unlimited joints."""
    finite = jnp.isfinite(q_min) & jnp.isfinite(q_max)
    return jnp.where(finite, jnp.maximum(q_max - q_min, 1e-6), 1.0)


def knot_sigma(
    spec: EnvSpec,
    knot_t: jax.Array,
    sigma0: float | tuple[float, ...],
    sigma_slope: float,
) -> jax.Array:
    """Per-knot, per-actuator absolute σ from a linear schedule over ``knot_t``,
    shape ``[n_knots, n_act]``. ``sigma0``/``sigma_slope`` are dimensionless: a
    value of ``1`` means ±3σ spans each actuator's finite joint range (unit span
    for unlimited joints). A tuple ``sigma0`` gives each actuator its own."""
    span = _actuator_span(*actuated_joint_limits(spec.mj_model))
    return (jnp.asarray(sigma0) + knot_t[:, None] * sigma_slope) * span[None, :] / 6


def colored_noise(key: jax.Array, shape: tuple, noise_color: float) -> jax.Array:
    """Gaussian noise with power spectrum ``1/f^noise_color`` along axis 0.

    ``noise_color=0`` is plain white noise; ``>0`` produces temporally
    correlated noise along axis 0, independent across the remaining axes. The
    DC component (``f=0``) is zeroed so the colored noise has zero mean, and
    the result is renormalised to unit std along axis 0 so ``noise_color``
    controls the *shape* of the spectrum without leaking into the marginal
    variance.

    iCEM (Pinneri et al. 2020) uses ``noise_color ≈ 2.5`` for robotics.
    """
    if noise_color == 0.0:
        return rax.normal(key, shape)
    n = shape[0]
    white = rax.normal(key, shape)
    # ``jnp`` here is effectful's shim, which doesn't proxy ``fft``; call the
    # real ``jax.numpy.fft`` directly.
    fft = jax.numpy.fft.rfft(white, axis=0)
    freqs = jax.numpy.fft.rfftfreq(n)
    # Zero DC contribution; scale remaining bins by f^{-noise_color/2}.
    weight = jnp.where(freqs == 0, 0.0, freqs ** (-noise_color / 2))
    weight = weight.reshape((-1,) + (1,) * (len(shape) - 1))
    colored = jax.numpy.fft.irfft(fft * weight, n=n, axis=0)
    std = jnp.std(colored, axis=0, keepdims=True)
    return colored / jnp.maximum(std, 1e-8)


class CSplinePlan(struct.PyTreeNode, Plan):
    spline: CSpline

    @classmethod
    def make(cls, env: EnvProcess, horizon: float, knot_interval: float = 0.25) -> Self:
        """Initial constant plan (current pose) with cubic-spline knots at ``knot_interval``."""
        knot_t, knot_x = initial_knots(env, horizon, knot_interval)
        return cls(CSpline(knot_t, knot_x, jnp.zeros_like(knot_x)))

    def __call__(self, t):
        q, _ = self.spline(t)
        return q

    def shift(self, dt):
        return self.replace(spline=self.spline.shift(dt))

    def params(self) -> jax.Array:
        """Decision variables ``[2, n_knots, nu]``: knot positions and scaled
        tangents ``v·Δt``, both in position units."""
        dt = self.spline.t[1] - self.spline.t[0]
        return jnp.stack([self.spline.x, self.spline.v * dt])

    def clip_params(self, params: jax.Array, spec: EnvSpec) -> jax.Array:
        """Project ``[..., 2, n_knots, nu]`` decision matrices onto the feasible
        box: knot positions clipped to the actuated joint ranges, tangents
        clamped so a joint limit cannot be exceeded within half a sim timestep;
        unlimited joints (``±inf`` range) pass through."""
        q_min, q_max = actuated_joint_limits(spec.mj_model)
        x = jnp.clip(params[..., 0, :, :], q_min, q_max)
        margin = jnp.maximum(0, jnp.minimum(q_max - x, x - q_min))
        dt = self.spline.t[1] - self.spline.t[0]
        bound = margin * dt / (spec.dt / 2.0)
        v = jnp.clip(params[..., 1, :, :], -bound, bound)
        return jnp.stack([x, v], axis=-3)

    def with_params(self, params: jax.Array, spec: EnvSpec) -> Self:
        """Build a plan of this type from decision variables ``[2, n_knots, nu]``
        (see :meth:`params`), automatically projected onto the feasible set by
        :meth:`clip_params` — an out-of-range spline is not constructible."""
        clipped = self.clip_params(params, spec)
        dt = self.spline.t[1] - self.spline.t[0]
        return self.replace(spline=CSpline(self.spline.t, clipped[0], clipped[1] / dt))

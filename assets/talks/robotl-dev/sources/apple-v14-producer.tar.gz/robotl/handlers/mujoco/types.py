from robotl.ops.coords import (
    Coordinate,
    CoordinateTangent,
    Pose,
    ProductCoordinate,
    ProductCoordinateTangent,
    TangentBundle,
    TangentBundleTangent,
)
from robotl.ops.id import Id

type Q = ProductCoordinate[dict[Id, Coordinate]]
type V = ProductCoordinateTangent[dict[Id, CoordinateTangent]]
type QV = TangentBundle[Q, V]
type QVTangent = TangentBundleTangent[V, V]
type FixedQ = ProductCoordinate[dict[Id, Pose]]

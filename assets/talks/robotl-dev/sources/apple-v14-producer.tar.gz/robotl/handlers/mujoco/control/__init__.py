"""Sampling- and gradient-based MPC for MuJoCo envs.

Layout
------
- ``mpc``         : :class:`MPCController`, the receding-horizon driver.
- ``planners``    : the inner optimiser (:class:`Planner` base class) —
                    :class:`SamplingPlanner` (MPPI/CEM),
                    :class:`GradientPlanner` (finite-diff + optax), and
                    :class:`GaussNewtonPlanner` (finite-diff + Levenberg-Marquardt).
- ``plans``       : action-trajectory parameterizations (``CSplinePlan``,
                    colored noise) sampled by the planner.
- ``ik_solver``   : inverse-kinematics solver (``solve_ik``).
"""

from .mpc import MPCController, compute_contact_penalty
from .planners import (
    GaussNewtonPlanner,
    GradientPlanner,
    HybridPlanner,
    Planner,
    SamplingPlanner,
)
from .stages import Stage, StagedController, StageState, StageStatus

__all__ = [
    "MPCController",
    "Planner",
    "SamplingPlanner",
    "GradientPlanner",
    "GaussNewtonPlanner",
    "HybridPlanner",
    "compute_contact_penalty",
    "Stage",
    "StagedController",
    "StageState",
    "StageStatus",
]

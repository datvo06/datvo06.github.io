import effectful.handlers.jax.numpy as jnp
import jax
from effectful.ops.semantics import evaluate, handler
from effectful.ops.syntax import ObjectInterpretation, implements
from jax.scipy.spatial.transform import Rotation

from robotl.handlers.cad.decomposition import as_trimesh
from robotl.internals.utils import Bbox, Mesh, Polygon, bbox_difference
from robotl.ops import shapes


class BboxShape(shapes.Shape, Bbox):
    def __add__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.union(self, other)

    def __radd__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.union(other, self)

    def __and__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.intersection(self, other)

    def __rand__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.intersection(other, self)

    def __sub__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.difference(self, other)

    def __rsub__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.difference(other, self)


class ShapeToBbox(ObjectInterpretation):
    @implements(shapes.cube)
    @staticmethod
    def cube_bbox(dx, dy, dz) -> BboxShape:
        d = jnp.array([dx, dy, dz], dtype=float)
        return BboxShape(lo=jnp.zeros_like(d), hi=d)

    @implements(shapes.sphere)
    @staticmethod
    def sphere_bbox(r: float) -> BboxShape:
        d = jnp.array([r, r, r], dtype=float)
        return BboxShape(lo=-d, hi=d)

    @implements(shapes.cylinder)
    @staticmethod
    def cylinder_bbox(*, r: float, h: float, r2: float | None = None) -> BboxShape:
        rmax = r if r2 is None else jnp.maximum(r, r2)
        return BboxShape(lo=jnp.array([-rmax, -rmax, 0]), hi=jnp.array([rmax, rmax, h]))

    @implements(shapes.capsule)
    @staticmethod
    def capsule_bbox(*, r: float, h: float) -> BboxShape:
        return BboxShape(lo=-jnp.array([r, r, r]), hi=jnp.array([r, r, h + r]))

    @implements(shapes.extrude)
    @staticmethod
    def extrude_bbox(polygon: Polygon, h: float) -> BboxShape:
        v = jnp.asarray(polygon.points, dtype=float)
        lo, hi = v.min(axis=0), v.max(axis=0)
        return BboxShape(
            lo=jnp.array([lo[0], lo[1], 0.0]), hi=jnp.array([hi[0], hi[1], h])
        )

    @implements(shapes.revolve)
    @staticmethod
    def revolve_bbox(polygon: Polygon) -> BboxShape:
        v = jnp.asarray(polygon.points, dtype=float)
        rmax = v[:, 0].max()
        return BboxShape(
            lo=jnp.array([-rmax, -rmax, v[:, 1].min()]),
            hi=jnp.array([rmax, rmax, v[:, 1].max()]),
        )

    @implements(shapes.translate)
    @staticmethod
    def translate_bbox(shape, vec: jax.Array) -> BboxShape:
        assert isinstance(shape, BboxShape)
        vec = jnp.asarray(vec)
        return BboxShape(lo=shape.lo + vec, hi=shape.hi + vec)

    @implements(shapes.rotate)
    @staticmethod
    def rotate_bbox(shape, rot: Rotation) -> BboxShape:
        assert isinstance(shape, BboxShape)
        # https://zeux.io/2010/10/17/aabb-from-obb-with-component-wise-abs/
        c = (shape.lo + shape.hi) / 2
        r = (shape.hi - shape.lo) / 2
        rmat = rot.as_matrix()
        new_c = rmat @ c
        new_r = jnp.abs(rmat) @ r
        return BboxShape(lo=new_c - new_r, hi=new_c + new_r)

    @implements(shapes.scale)
    @staticmethod
    def scale_sdf(shape, vec: jax.Array) -> BboxShape:
        assert isinstance(shape, BboxShape)
        return BboxShape(lo=shape.lo * vec, hi=shape.hi * vec)

    @implements(shapes.union)
    @staticmethod
    def union_bbox(*shapes) -> BboxShape:
        assert all(isinstance(shape, BboxShape) for shape in shapes), shapes
        if shapes:
            lo = jnp.stack([shape.lo for shape in shapes]).min(axis=0)
            hi = jnp.stack([shape.hi for shape in shapes]).max(axis=0)
        else:
            lo = jnp.full([3], +jnp.inf)
            hi = jnp.full([3], -jnp.inf)
        return BboxShape(lo, hi)

    @implements(shapes.intersection)
    @staticmethod
    def intersection_bbox(*shapes) -> BboxShape:
        assert all(isinstance(shape, BboxShape) for shape in shapes)
        # the intersection is guaranteed to contain the shape, but may not be
        # minimal as the child bboxes are already supersets. this could be made
        # more accurate if we deferred unions, tracking a collection of bboxes
        # instead of one big bbox, at the cost of potential exponential growth
        # of the number of boxes due to difference operations.
        if shapes:
            lo = jnp.stack([shape.lo for shape in shapes]).max(axis=0)
            hi = jnp.stack([shape.hi for shape in shapes]).min(axis=0)
        else:
            lo = jnp.full([3], -jnp.inf)
            hi = jnp.full([3], +jnp.inf)
        return BboxShape(lo, hi)

    @implements(shapes.difference)
    @staticmethod
    def difference_bbox(shape1, shape2) -> shapes.Shape:
        assert all(isinstance(shape, BboxShape) for shape in [shape1, shape2])
        slabs = bbox_difference(shape1, shape2)
        return shapes.union(*(BboxShape(slab.lo, slab.hi) for slab in slabs))

    @implements(shapes.decompose)
    @staticmethod
    def decompose_bbox(shape, *, max_parts: int = 8) -> BboxShape:
        # ``decompose`` only affects collision emission; the bbox is that of ``shape``.
        assert isinstance(shape, BboxShape)
        return shape

    @implements(shapes.mesh)
    @staticmethod
    def mesh_bbox(m: Mesh) -> BboxShape:
        v = jnp.asarray(m.vertices, dtype=float)
        return BboxShape(lo=v.min(axis=0), hi=v.max(axis=0))

    @implements(shapes.external_mesh)
    @staticmethod
    def external_mesh_bbox(path: str) -> BboxShape:
        mesh = as_trimesh(path)
        return ShapeToBbox.mesh_bbox(
            Mesh(vertices=jnp.asarray(mesh.vertices), faces=jnp.asarray(mesh.faces))
        )

    @implements(shapes.plane)
    @staticmethod
    def notimplemented(*args):
        raise NotImplementedError("cannot compute a finite bbox for a plane")


def bbox_from_shape(shape: shapes.Shape) -> Bbox:
    """Return an axis-aligned bounding box enclosing the shape."""
    with handler(ShapeToBbox()):
        result = evaluate(shape)
    assert isinstance(result, Bbox)
    return result

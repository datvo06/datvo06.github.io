"""SDF handler module for RoboTL.

This file implements a compact signed‑distance function (SDF) backend that mirrors the
public API of the existing CAD handler while returning analytical distance fields.
Primitives, boolean combinators and geometric transforms are defined inline with
``@SDFShape.define``.  The :class:`ShapeToSDF` interpreter is used in the test suite
to evaluate shapes directly as JAX callables.

The SDF implementations follow the formulations described in the article
"Signed Distance Functions" (https://iquilezles.org/articles/distfunctions/).
"""

from __future__ import annotations

import dataclasses
import functools
from collections.abc import Callable
from typing import Any, Concatenate, Self

import effectful.handlers.jax.numpy as jnp
import effectful.handlers.jax.numpy.linalg  # noqa: F401
import jax
from effectful.ops.syntax import ObjectInterpretation, implements
from jax.scipy.spatial.transform import Rotation

from robotl.internals.utils import Polygon
from robotl.ops import shapes


@dataclasses.dataclass(frozen=True)
class SDFShape[**P](shapes.Shape):
    """Concrete wrapper for a signed‑distance function (SDF).

    Instances are created via the :meth:`define` classmethod, which turns an ordinary
    Python callable ``fn(p, *args, **kwargs)`` into a shape object that satisfies the
    :class:`robotl.ops.shapes.Shape` protocol.  The wrapped function is invoked with
    query points ``p`` of shape ``(..., 3)`` and must return the signed distance to
    the surface as a JAX array.  The class provides operator overloads for boolean
    operations (union, intersection, difference) through its base class.
    """

    _fn: Callable[Concatenate[jax.Array, P], jax.Array]
    _args_kwargs: tuple[tuple, tuple[tuple[str, Any], ...]]

    def __add__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.union(self, other)

    def __radd__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.union(other, self)

    def __and__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.intersection(self, other)

    def __rand__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.intersection(other, self)

    def __sub__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.difference(self, other)

    def __rsub__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.difference(other, self)

    def __call__(self, p: jax.Array) -> jax.Array:
        """Return the signed distance for point(s) *p*.

        Parameters
        ----------
        p : jax.typing.ArrayLike
            Array of points with trailing dimension 3.
        """
        args, kwargs = self._args_kwargs
        return self._fn(p, *args, **dict(kwargs))

    @classmethod
    def define(
        cls: type[Self],
        fn: Callable[Concatenate[jax.Array, P], jax.Array],
    ) -> Callable[P, Self]:
        """Define a new SDF shape class from a function.

        This is a convenience method that wraps the given function *fn* into a curried
        form and returns a factory function that constructs ``SDFShape`` instances.
        """

        @functools.wraps(fn)
        def wrapper(*args: P.args, **kwargs: P.kwargs):
            return cls(fn, (args, tuple(kwargs.items())))

        return wrapper


def _polygon_distance(
    q: jax.Array, polygon: Polygon, surface: jax.Array | None = None
) -> jax.Array:
    r"""Exact signed distance in the plane to a closed polygon outline.

    ``q`` has shape ``(..., 2)``. The unsigned distance is the minimum over
    the polygon's edges of the distance to that edge segment. The sign
    comes from the even-odd rule: a point is inside when a horizontal ray
    from it crosses the outline an odd number of times, so the sign starts
    positive and flips once per crossed edge. An edge going upward is
    crossed when the point's height falls in the edge's half-open vertical
    span and the point lies left of the edge's line; an edge going downward
    is crossed under the complementary conditions; one test covers both by
    flipping when all three conditions hold or none do. Counting crossings
    makes the sign independent of the outline's winding direction.

    :param q: Query points, shape ``(..., 2)``.
    :param polygon: The outline, a :class:`robotl.internals.utils.Polygon`.
    :param surface: Optional per-edge booleans; an edge marked False bounds
        the region for the sign but is not part of the measured surface, as
        with the axis edges of a revolved meridian outline.
    """
    v = jnp.asarray(polygon.points, dtype=float)  # (n, 2)
    v_next = jnp.roll(v, -1, axis=0)
    e = v_next - v  # (n, 2)
    w = q[..., None, :] - v  # (..., n, 2)
    t = jnp.clip(jnp.sum(w * e, axis=-1) / jnp.sum(e * e, axis=-1), 0.0, 1.0)
    b = w - t[..., None] * e
    edge_d = jnp.linalg.norm(b, axis=-1)
    if surface is not None:
        edge_d = jnp.where(surface, edge_d, jnp.inf)
    d = jnp.min(edge_d, axis=-1)
    c1 = q[..., None, 1] >= v[:, 1]
    c2 = q[..., None, 1] < v_next[:, 1]
    c3 = e[:, 0] * w[..., 1] > e[:, 1] * w[..., 0]
    flip = (c1 & c2 & c3) | (~c1 & ~c2 & ~c3)
    s = jnp.prod(jnp.where(flip, -1.0, 1.0), axis=-1)
    return s * d


class ShapeToSDF(ObjectInterpretation):
    """Handler for the pure‑SDF backend.

    Each method returns an instantiated ``SDFShape`` (or a combinator/wrapper) that
    can be called with JAX arrays of points. The interpreter mirrors the API of the
    existing CAD backend (`Solid2Backend`) but produces analytical distance fields
    instead of mesh objects.

    These implementations follow the formulations described in the article
    "Signed Distance Functions" (https://iquilezles.org/articles/distfunctions/).
    """

    # -------------------------- external mesh fallback --------------------------
    @implements(shapes.external_mesh)
    def external_mesh_sdf(self, path: str):
        raise NotImplementedError(
            "external_mesh is not supported by the SDF backend, "
            "consider using the CAD backend or a pre‑computed distance field."
        )

    @implements(shapes.mesh)
    def mesh_sdf(self, m):
        raise NotImplementedError(
            "mesh is not supported by the SDF backend, "
            "consider using the CAD backend or a pre‑computed distance field."
        )

    # -------------------------- primitives --------------------------
    @implements(shapes.cube)
    @staticmethod
    @SDFShape.define
    def cube_sdf(p: jax.Array, dx: float, dy: float, dz: float) -> jax.Array:
        r"""SDF for an axis-aligned box with corner at origin.

        The box has a corner at the origin and extends into the positive octant
        to ``(dx, dy, dz)``, matching the OpenSCAD ``cube()`` convention.

        .. math::

            \mathbf{c} &= (d_x/2, d_y/2, d_z/2) \\
            \mathbf{q} &= |\mathbf{p} - \mathbf{c}| - \mathbf{c} \\
            f(\mathbf{p}) &= \|\max(\mathbf{q}, 0)\| + \min(\max(q_x, q_y, q_z), 0)

        where :math:`\mathbf{c}` is both the center and the half-extent vector.
        """
        # Half-extents and center (same for corner-at-origin box)
        b = jnp.asarray([dx, dy, dz]) / 2.0
        # Translate to centered coordinates, then apply standard box SDF
        q = jnp.abs(p - b) - b
        # max(q, 0) gives distance outside, length of negative part inside
        outside = jnp.linalg.norm(jnp.maximum(q, 0.0), axis=-1)
        inside = jnp.minimum(jnp.max(q, axis=-1), 0.0)
        return outside + inside

    @implements(shapes.sphere)
    @staticmethod
    @SDFShape.define
    def sphere_sdf(p: jax.Array, r: float) -> jax.Array:
        r"""SDF for a sphere centered at the origin.

        .. math::

            f(\mathbf{p}) = \|\mathbf{p}\| - r

        where :math:`r` is the radius.
        """
        return jnp.linalg.norm(p) - r

    @implements(shapes.cylinder)
    @staticmethod
    @SDFShape.define
    def cylinder_sdf(
        p: jax.Array, *, r: float, h: float, r2: float | None = None
    ) -> jax.Array:
        r"""SDF for a capped cone with base at origin, aligned along Z axis.

        The cylinder/cone has its bottom cap centered at the origin (z=0) with
        radius ``r``, and top cap at z=h with radius ``r2``, matching the
        OpenSCAD ``cylinder()`` convention.

        When r2 is None or equal to r, this produces a cylinder. Otherwise it
        produces a capped cone with bottom radius r1 and top radius r2.

        The 3D problem is reduced to 2D by cylindrical symmetry:

        .. math::

            \mathbf{q} = \bigl(\|(p_x, p_y)\|,\; p_z - h/2\bigr)

        The z coordinate is shifted by :math:`h/2` to work in centered coordinates
        internally. The distance is computed as the minimum of distances to the
        caps and the sloped edge, with sign determined by whether the point is inside.
        """
        r1 = r
        if r2 is None:
            r2 = r  # pure cylinder case

        half_h = h / 2.0

        # q = (radial distance in XY plane, Z height shifted to centered coords)
        q_x = jnp.linalg.norm(p[..., :2], axis=-1)
        q_y = p[..., 2] - half_h  # shift z so cylinder is centered at z=0

        # Cap distance vector: horizontal and vertical distances to cap edges
        cap_radius = jnp.where(q_y < 0.0, r1, r2)
        ca_x = q_x - jnp.minimum(q_x, cap_radius)
        ca_y = jnp.abs(q_y) - half_h

        # Cone body distance: project onto the sloped edge
        # k1 = (r2, half_h), k2 = (r2 - r1, h)
        k2_x = r2 - r1
        k2_y = h

        dot_k1_minus_q_k2 = (r2 - q_x) * k2_x + (half_h - q_y) * k2_y
        dot_k2_k2 = k2_x * k2_x + k2_y * k2_y

        t = jnp.clip(dot_k1_minus_q_k2 / dot_k2_k2, 0.0, 1.0)

        cb_x = q_x - r2 + k2_x * t
        cb_y = q_y - half_h + k2_y * t

        # Sign: negative (inside) when cb_x < 0 and ca_y < 0
        s = jnp.where((cb_x < 0.0) & (ca_y < 0.0), -1.0, 1.0)

        # Return signed distance
        dot_ca = ca_x * ca_x + ca_y * ca_y
        dot_cb = cb_x * cb_x + cb_y * cb_y

        return s * jnp.sqrt(jnp.minimum(dot_ca, dot_cb))

    @implements(shapes.capsule)
    @staticmethod
    @SDFShape.define
    def capsule_sdf(p: jax.Array, *, r: float, h: float) -> jax.Array:
        r"""SDF for a capsule aligned along the Z axis with base at origin.

        The capsule has hemispherical caps of radius ``r`` centered at z=0 and
        z=h, connected by a cylindrical body, matching the ``shapes.capsule``
        convention.

        Given endpoints :math:`\mathbf{a} = (0, 0, 0)` and
        :math:`\mathbf{b} = (0, 0, h)`:

        .. math::

            t &= \text{clamp}\!\left(
                \frac{(\mathbf{p} - \mathbf{a}) \cdot (\mathbf{b} - \mathbf{a})}
                     {\|\mathbf{b} - \mathbf{a}\|^2}, 0, 1
            \right) \\
            f(\mathbf{p}) &= \|\mathbf{p} - \mathbf{a} - t(\mathbf{b} - \mathbf{a})\| - r

        For the Z-aligned case, this simplifies to clamping :math:`p_z` to
        :math:`[0, h]` and computing the distance to that point minus :math:`r`.
        """
        # Clamp z to find closest point on the axis segment [0, h]
        clamped_z = jnp.clip(p[..., 2], 0.0, h)

        # Distance from p to closest point on axis, minus radius
        dx = p[..., 0]
        dy = p[..., 1]
        dz = p[..., 2] - clamped_z

        return jnp.sqrt(dx * dx + dy * dy + dz * dz) - r

    @implements(shapes.extrude)
    @staticmethod
    @SDFShape.define
    def extrude_sdf(p: jax.Array, polygon: Polygon, h: float) -> jax.Array:
        r"""SDF for a polygon extruded along +Z over z in [0, h].

        The polygon distance in the XY plane combines with the slab
        distance along Z as perpendicular components outside and as the
        nearest surface inside:

        .. math::

            d &= f_{2D}(p_x, p_y) \\
            w &= \bigl(d,\; |p_z - h/2| - h/2\bigr) \\
            f(\mathbf{p}) &= \min(\max(w_x, w_y), 0) + \|\max(w, 0)\|
        """
        d = _polygon_distance(p[..., :2], polygon)
        wz = jnp.abs(p[..., 2] - h / 2.0) - h / 2.0
        w = jnp.stack([d, wz], axis=-1)
        return jnp.minimum(jnp.maximum(d, wz), 0.0) + jnp.linalg.norm(
            jnp.maximum(w, 0.0), axis=-1
        )

    @implements(shapes.revolve)
    @staticmethod
    @SDFShape.define
    def revolve_sdf(p: jax.Array, polygon: Polygon) -> jax.Array:
        r"""SDF for a polygon revolved one full turn about the +Z axis.

        By symmetry the nearest surface point lies in the meridian plane
        through the query, so the 3D distance is the 2D polygon distance at
        the query's (radial, axial) coordinates:

        .. math::

            f(\mathbf{p}) = f_{2D}\bigl(\|(p_x, p_y)\|,\; p_z\bigr)

        Edges of the outline lying on the axis close the meridian region but
        revolve to no surface, so they carry the sign and not the distance;
        the radial coordinate is nudged off exact zero so the sign test on
        the axis itself is well posed.
        """
        v = jnp.asarray(polygon.points, dtype=float)
        on_axis = (v[:, 0] == 0.0) & (jnp.roll(v[:, 0], -1) == 0.0)
        q = jnp.stack(
            [
                jnp.maximum(jnp.linalg.norm(p[..., :2], axis=-1), 1e-12),
                p[..., 2],
            ],
            axis=-1,
        )
        return _polygon_distance(q, polygon, surface=~on_axis)

    @implements(shapes.plane)
    @staticmethod
    @SDFShape.define
    def plane_sdf(p: jax.Array) -> jax.Array:
        r"""SDF for an infinite plane at Z=0.

        For a plane with unit normal :math:`\mathbf{n}` and offset :math:`d`:

        .. math::

            f(\mathbf{p}) = \mathbf{p} \cdot \mathbf{n} + d

        For the XY plane at :math:`z=0` with :math:`\mathbf{n} = (0, 0, 1)` and
        :math:`d = 0`, this simplifies to :math:`f(\mathbf{p}) = p_z`.
        """
        return p[..., 2]

    # -------------------------- boolean ops --------------------------
    @implements(shapes.union)
    @staticmethod
    @SDFShape.define
    def union_sdf(p: jax.Array, *shapes: SDFShape) -> jax.Array:
        r"""Inline the union SDF.

        .. math::

            (A \cup B)(\mathbf{p}) = \min\bigl(A(\mathbf{p}), B(\mathbf{p})\bigr)

        .. warning::

            This produces a **bound** SDF, not an exact one. The gradient magnitude
            :math:`\|\nabla f\|` may be less than 1 near the interface between shapes,
            which can cause artifacts in sphere tracing and other SDF algorithms.
        """
        return jnp.stack([shape(p) for shape in shapes]).min(axis=0)

    @implements(shapes.intersection)
    @staticmethod
    @SDFShape.define
    def intersection_sdf(p: jax.Array, *shapes: SDFShape) -> jax.Array:
        r"""Inline the intersection SDF.

        .. math::

            (A \cap B)(\mathbf{p}) = \max\bigl(A(\mathbf{p}), B(\mathbf{p})\bigr)

        .. warning::

            This produces a **bound** SDF, not an exact one. The gradient magnitude
            :math:`\|\nabla f\|` may be less than 1 near the interface between shapes,
            which can cause artifacts in sphere tracing and other SDF algorithms.
        """
        return jnp.stack([shape(p) for shape in shapes]).max(axis=0)

    @implements(shapes.difference)
    @staticmethod
    @SDFShape.define
    def difference_sdf(p: jax.Array, shape1: SDFShape, shape2: SDFShape) -> jax.Array:
        r"""Inline the difference SDF.

        .. math::

            (A \setminus B)(\mathbf{p}) = \max\bigl(A(\mathbf{p}), -B(\mathbf{p})\bigr)

        .. warning::

            This produces a **bound** SDF, not an exact one. The gradient magnitude
            :math:`\|\nabla f\|` may be less than 1 near the interface between shapes,
            which can cause artifacts in sphere tracing and other SDF algorithms.
        """
        return jnp.maximum(shape1(p), -shape2(p))

    # -------------------------- transforms --------------------------
    @implements(shapes.translate)
    @staticmethod
    @SDFShape.define
    def translate_sdf(p: jax.Array, shape: SDFShape, vec: jax.Array) -> jax.Array:
        r"""Inline translation transform.

        .. math::

            f_{\text{translated}}(\mathbf{p}) = f(\mathbf{p} - \mathbf{v})

        where :math:`\mathbf{v}` is the translation vector.
        """
        return shape(p - jnp.asarray(vec))

    @implements(shapes.rotate)
    @staticmethod
    @SDFShape.define
    def rotate_sdf(p: jax.Array, shape: SDFShape, rot: Rotation) -> jax.Array:
        r"""Inline rotation transform.

        .. math::

            f_{\text{rotated}}(\mathbf{p}) = f(R^{-1} \mathbf{p})

        where :math:`R` is the rotation matrix. The inverse rotation is applied
        to query points before evaluating the inner SDF.
        """
        inv_rot = rot.inv()
        p_rot = jnp.einsum("...ij,...j->...i", inv_rot.as_matrix(), p)
        return shape(p_rot)

    @implements(shapes.scale)
    @staticmethod
    @SDFShape.define
    def scale_sdf(p: jax.Array, shape: SDFShape, vec: jax.Array) -> jax.Array:
        r"""Inline scaling transform.

        For uniform scaling by factor :math:`s`:

        .. math::

            f_{\text{scaled}}(\mathbf{p}) = s \cdot f(\mathbf{p} / s)

        The point is inversely scaled before evaluation, then the distance is
        scaled back.

        .. warning::

            **Non-uniform scaling** (where :math:`s_x \neq s_y \neq s_z`) produces
            a **bound** SDF, not an exact one. The current implementation assumes
            uniform scaling; for non-uniform scaling, distances will be approximate.
        """
        scaled_p = p / vec
        return shape(scaled_p) * vec

    @implements(shapes.decompose)
    def decompose_sdf(self, x: SDFShape, *, max_parts: int = 8) -> SDFShape:
        # ``decompose`` only affects collision emission; the field is that of ``x``.
        return x

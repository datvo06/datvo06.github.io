import contextlib
import functools
import zlib
from collections.abc import Callable
from typing import Any, Concatenate, Self, overload

import effectful.handlers.jax.numpy as jnp
import effectful.handlers.jax.numpy.linalg  # noqa: F401
import evosax
import jax
import jax.random as rax
import matplotlib
import numpy as np
import optax
import trimesh
from effectful.ops.syntax import defop
from effectful.ops.types import NotHandled, Term
from evosax.algorithms.base import EvolutionaryAlgorithm
from flax import struct
from jax.custom_batching import custom_vmap
from jax.scipy.spatial.transform import Rotation
from jaxtyping import Float, Int


def normalized(x: jax.Array) -> jax.Array:
    """Normalize vector(s) along the last axis. Supports batched inputs [..., n]."""
    return x / jnp.linalg.norm(x, axis=-1, keepdims=True)


def ema(x: jax.Array, inertia: float = 0.9, debias=True):
    def fn(xbar, x_t):
        [x, t] = x_t
        xbar = xbar + (1 - inertia) * (x - xbar)
        y = xbar
        if debias:
            y = y / (1 - inertia ** (t + 1))
        return xbar, y

    _, y = jax.lax.scan(fn, jnp.zeros_like(x[0]), [x, jnp.arange(x.shape[0])])
    return y  # y.shape == x.shape


# `jnp.any` over the axes of every containing vmap, leaving the result unbatched
# so e.g. a `lax.cond` on it stays a cond rather than becoming a select
@custom_vmap
def any_across_batch(x: jax.Array) -> jax.Array:
    return x


@any_across_batch.def_vmap
def _any_across_batch_vmap(axis_size, in_batched, x):
    [batched] = in_batched
    # recurse, so enclosing vmaps collapse their axes too
    return (any_across_batch(jnp.any(x, axis=0)) if batched else x), False


@defop
def matrix_from_quat(quat: jax.Array):
    """Convert quaternion (wxyz) to rotation matrix.

    Supports batched inputs with shape [..., 4].
    """
    # NOTE `axes` is the transpose of `matrix`
    if isinstance(quat, Term):
        raise NotHandled
    # Roll along last axis to convert wxyz -> xyzw for scipy
    return Rotation.from_quat(jnp.roll(quat, -1, axis=-1)).as_matrix()


@defop
def quat_from_matrix(matrix: jax.Array):
    # NOTE `axes` is the transpose of `matrix`
    if isinstance(matrix, Term):
        raise NotHandled
    # NOTE this fails silently if not a rotation matrix (orthogonal and determinant +1)
    return Rotation.from_matrix(matrix).as_quat(canonical=True, scalar_first=True)


def get_a_normal(u: np.typing.ArrayLike):
    # construct a vector that is orthogonal to the nonzero 3d vector u
    u = jnp.asarray(u)
    x, y, z = u[0], u[1], u[2]
    return jnp.where(
        jnp.abs(x) <= jnp.abs(y),
        jnp.array([0, -z, y]),
        jnp.array([-z, 0, x]),
    )


def rv_solve(a: np.typing.ArrayLike, b: np.typing.ArrayLike):
    # find a rotation vector R s.t. b = R(a).  a and b must be unit vectors.
    # if a \approx -b, rotate 180 around any axis orthogonal to a
    a, b = jnp.asarray(a), jnp.asarray(b)
    v, w = jnp.dot(a, b), jnp.cross(a, b)
    axis = normalized(jnp.where(1 - abs(v) < 1e-6, get_a_normal(a), w))
    theta = jnp.atan2(jnp.linalg.norm(w), v)
    return theta * axis


def parallel_axis(d: jax.Array) -> jax.Array:
    """The parallel axis term of a unit mass displaced by ``d``.

    ``|d|^2 I - d d^T``: the matrix that rejects the component along ``d``,
    scaled by ``|d|^2``. Multiply by the mass to shift an inertia tensor from
    the center of mass to a point displaced by ``d``.
    """
    return jnp.dot(d, d) * jnp.eye(d.shape[-1]) - jnp.outer(d, d)


def deepstack[T](
    xs: list[T], axis=0, *, stack: Callable[..., jax.Array] = jnp.stack
) -> T:
    return jax.tree.map(lambda *xs: stack(xs, axis=axis), *xs)


def deeprepeat[T](x: T, n: int) -> T:
    """Replicate a pytree ``n`` times along a new leading axis."""
    return jax.tree.map(lambda v: jnp.broadcast_to(v[None], (n, *v.shape)).copy(), x)


def deepunstack[T](xs: T, axis=0) -> list[T]:
    [n] = np.unique([x.shape[axis] for x in jax.tree.leaves(xs)])
    return [jax.tree.map(lambda x: jnp.take(x, i, axis=axis), xs) for i in range(n)]


def rscope(rng: jax.Array, *path: str) -> jax.Array:
    return rax.fold_in(rng, zlib.crc32("".join(path).encode()))


@contextlib.contextmanager
def maybe_enable_x64(enable_x64):
    if enable_x64:
        with jax.enable_x64():
            yield
    else:
        yield


def safeproperty(fn):
    """Decorator to catch and reraise AttributeErrors.

    The Python __getattr__ mechanism silently catches AttributeErrors in
    @property methods and raises new ones that are missing the original context.
    This leads to silent bugs that are hard to find.

    ```
    class Foo:
        @property
        def bar(self):
            return jnp.arary([1, 2, 3])  # AttributeError: module 'numpy' has no attribute 'arary'
        def __getattr__(self, key):
            raise AttributeError(key)
    Foo().bar  # AttributeError: bar
    ```

    In this example, the AttributeError in the `bar` property causes the `__getattr__` method to be
    invoked, at which point information about the original exception is lost.
    """

    @functools.wraps(fn)
    def wfn(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except AttributeError:
            raise RuntimeError("AttributeError inside safeproperty")

    return property(wfn)


def jit_for[T, **P, R](
    instance: T, fn: Callable[Concatenate[T, P], R], **jit_kwargs: Any
) -> Callable[P, R]:
    """``fn`` bound to ``instance`` and jitted once, cached on the instance.

    The compiled code is released with ``instance``. ``jax.jit`` with
    ``instance`` as a static argument would instead key JAX's global cache on
    it, keeping every identity-hashed instance and its executable for the
    process.
    """
    jitted = vars(instance).setdefault("_jit_methods", {})
    key = (fn, tuple(sorted(jit_kwargs.items())))
    if key not in jitted:
        jitted[key] = jax.jit(functools.partial(fn, instance), **jit_kwargs)
    return jitted[key]


class _JitMethod[T, **P, R]:
    def __init__(
        self, fn: Callable[Concatenate[T, P], R], jit_kwargs: dict[str, Any]
    ) -> None:
        self.fn = fn
        self.jit_kwargs = jit_kwargs
        # Sphinx and help() read the method's documentation from here.
        self.__doc__ = fn.__doc__
        self.__wrapped__ = fn

    @overload
    def __get__(self, instance: None, owner: type[T] | None = None) -> Self: ...

    @overload
    def __get__(self, instance: T, owner: type[T] | None = None) -> Callable[P, R]: ...

    def __get__(
        self, instance: T | None, owner: type[T] | None = None
    ) -> "Self | Callable[P, R]":
        if instance is None:
            return self
        # Keyed by function, so ``super().method`` and an override that
        # calls it each keep their own compiled function.
        return jit_for(instance, self.fn, **self.jit_kwargs)


@overload
def jit_method[T, **P, R](
    fn: Callable[Concatenate[T, P], R], /
) -> _JitMethod[T, P, R]: ...


@overload
def jit_method[T, **P, R](
    fn: None = None, /, **jit_kwargs: Any
) -> Callable[[Callable[Concatenate[T, P], R]], _JitMethod[T, P, R]]: ...


def jit_method(fn=None, /, **jit_kwargs):
    """Decorator that jits a method once per instance.

    Use it bare or with :func:`jax.jit` options for the remaining arguments,
    e.g. ``@jit_method(static_argnames=("length",))``. The compiled code is
    cached on the instance and released with it.
    ``partial(jax.jit, static_argnames=("self",))`` would instead key JAX's
    global cache on ``self``, recompiling for every identity-hashed instance
    and keeping each one, with its executable, alive for the process.
    """
    if fn is None:
        return functools.partial(jit_method, **jit_kwargs)
    return _JitMethod(fn, jit_kwargs)


def treepath_to_str(path) -> str:
    def fn(elem):
        if isinstance(elem, jax.tree_util.DictKey):
            return elem.key
        if isinstance(elem, jax.tree_util.SequenceKey):
            return str(elem.idx)
        if isinstance(elem, jax.tree_util.GetAttrKey):
            return elem.name
        return elem

    return "_".join(map(fn, path))


class Colors:
    blue = matplotlib.colors.to_rgba("tab:blue")
    orange = matplotlib.colors.to_rgba("tab:orange")
    green = matplotlib.colors.to_rgba("tab:green")
    red = matplotlib.colors.to_rgba("tab:red")
    purple = matplotlib.colors.to_rgba("tab:purple")
    brown = matplotlib.colors.to_rgba("tab:brown")
    pink = matplotlib.colors.to_rgba("tab:pink")
    gray = matplotlib.colors.to_rgba("tab:gray")
    olive = matplotlib.colors.to_rgba("tab:olive")
    cyan = matplotlib.colors.to_rgba("tab:cyan")


@struct.dataclass
class Polygon:
    """A closed polygon outline in the plane.

    Vertices are (x, y) rows; consecutive vertices are joined by edges and
    the last vertex joins back to the first.
    """

    points: Float[jax.Array, "n 2"]  # noqa: F722


@struct.dataclass
class Mesh:
    """A triangle mesh given by its vertices and faces.

    A pytree of jax arrays like :class:`Bbox` and :class:`Polygon`, so it can
    pass through jax transformations; ``to_trimesh`` materializes it for
    trimesh.

    :param vertices: Vertex positions, one (x, y, z) row each.
    :param faces: Triangles as rows of three vertex indices, wound
        counterclockwise seen from outside, as trimesh and STL have them.
    """

    vertices: Float[jax.Array, "n 3"]  # noqa: F722
    faces: Int[jax.Array, "m 3"]  # noqa: F722

    def to_trimesh(self) -> trimesh.Trimesh:
        return trimesh.Trimesh(
            vertices=np.asarray(self.vertices),
            faces=np.asarray(self.faces),
            process=False,
        )


# TODO overload operators
@struct.dataclass
class Bbox:
    lo: jax.Array
    hi: jax.Array

    @property
    def empty(self) -> jax.Array:
        return (self.hi - self.lo < 1e-8).any(axis=-1)


def bbox_difference(bbox1: Bbox, bbox2: Bbox) -> list[Bbox]:
    """Compute the difference between bounding boxes by breaking up bbox1 along
    bbox2's edges. Returns a list of bboxes whose union represents the
    difference."""
    if (bbox2.hi < bbox1.lo).any() or (bbox1.hi < bbox2.lo).any():
        return [bbox1]  # no overlap
    # at most 6 slabs, which happens when bbox2 is fully contained inside bbox1
    slabs = [
        Bbox(bbox1.lo, bbox1.hi.at[0].min(bbox2.lo[0])),
        Bbox(bbox1.lo, bbox1.hi.at[1].min(bbox2.lo[1])),
        Bbox(bbox1.lo, bbox1.hi.at[2].min(bbox2.lo[2])),
        Bbox(bbox1.lo.at[0].max(bbox2.hi[0]), bbox1.hi),
        Bbox(bbox1.lo.at[1].max(bbox2.hi[1]), bbox1.hi),
        Bbox(bbox1.lo.at[2].max(bbox2.hi[2]), bbox1.hi),
    ]
    return [slab for slab in slabs if not slab.empty]


@struct.dataclass
class Optimizer:
    algorithm: optax.GradientTransformation = struct.field(pytree_node=False)
    state: optax.OptState

    @classmethod
    def make(cls, algorithm: optax.GradientTransformation, x0: optax.Params):
        state = algorithm.init(x0)
        return cls(algorithm, state)

    def __call__(self, x, dx):
        dx, state = self.algorithm.update(dx, self.state, x)
        x = optax.apply_updates(x, dx)
        return self.replace(state=state), x


class Evolver(struct.PyTreeNode):
    algorithm: EvolutionaryAlgorithm = struct.field(pytree_node=False)
    params: evosax.types.Params = struct.field(pytree_node=False)
    state: evosax.types.State
    rng: jax.Array

    @classmethod
    def make(
        cls,
        algorithm: EvolutionaryAlgorithm,
        solution: evosax.types.Solution,
        rng: jax.Array,
        params: evosax.types.Params | None = None,
    ):
        if params is None:
            params = algorithm.default_params
        state = algorithm.init(rng, solution, params)
        return cls(algorithm, params, state, rng)

    def ask(self) -> tuple[Self, evosax.types.Population]:
        rng, rngt = rax.split(self.rng)
        population, state = self.algorithm.ask(rngt, self.state, self.params)
        return self.replace(state=state, rng=rng), population

    def tell(
        self, population: evosax.types.Population, fitness: jax.Array
    ) -> tuple[Self, Any]:
        rng, rngt = rax.split(self.rng)
        state, metrics = self.algorithm.tell(
            rngt, population, fitness, self.state, self.params
        )
        return self.replace(state=state, rng=rng), metrics

    @property
    def best_solution(self):
        return self.algorithm._unravel_solution(self.state.best_solution)

    @property
    def best_fitness(self):
        return self.state.best_fitness


def hermite_basis(tau: jax.Array):
    """Cubic Hermite basis polynomials evaluated at normalised parameter τ ∈ [0,1]."""
    tau2 = tau * tau
    tau3 = tau2 * tau
    h00 = 2 * tau3 - 3 * tau2 + 1
    h10 = tau3 - 2 * tau2 + tau
    h01 = -2 * tau3 + 3 * tau2
    h11 = tau3 - tau2
    return h00, h10, h01, h11


def hermite_basis_deriv(tau: jax.Array):
    """Derivatives of cubic Hermite basis polynomials w.r.t. normalised τ ∈ [0,1]."""
    tau2 = tau * tau
    dh00 = 6 * tau2 - 6 * tau
    dh10 = 3 * tau2 - 4 * tau + 1
    dh01 = -6 * tau2 + 6 * tau
    dh11 = 3 * tau2 - 2 * tau
    return dh00, dh10, dh01, dh11


class CSpline(struct.PyTreeNode):
    t: jax.Array  # [K]
    x: jax.Array  # [K, D]
    v: jax.Array  # [K, D]

    def __call__(self, t: jax.Array) -> jax.Array:
        def interp(t):
            # find previous and next knots
            ia = jnp.searchsorted(self.t, t, method="compare_all") - 1
            ib = ia + 1
            ia = jnp.clip(ia, 0, self.t.shape[0] - 1)
            ib = jnp.clip(ib, 0, self.t.shape[0] - 1)
            ta, tb = self.t[ia], self.t[ib]

            # compute tau relative to adjacent knots
            dt = jnp.maximum(1e-5, tb - ta)
            tau = (t - ta) / dt

            # evaluate polynomial
            h00, h10, h01, h11 = hermite_basis(tau)
            dh00, dh10, dh01, dh11 = hermite_basis_deriv(tau)

            p0, p1 = self.x[ia, :], self.x[ib, :]
            m0, m1 = self.v[ia, :], self.v[ib, :]

            x = h00 * p0 + h10 * m0 * dt + h01 * p1 + h11 * m1 * dt
            # dh/dτ / dt_seg converts from dq/dτ to dq/dt
            v = dh00 * p0 / dt + dh10 * m0 + dh01 * p1 / dt + dh11 * m1

            x = jnp.where(ia == ib, p0, x)
            v = jnp.where(ia == ib, m0, v)

            return x, v

        t_shape = jnp.shape(t)
        t = jnp.ravel(t)
        x, v = jax.vmap(interp)(t)
        return jax.tree.map(lambda x: x.reshape([*t_shape, *self.x.shape[1:]]), (x, v))

    def shift(self, dt) -> Self:
        x, v = self(self.t + dt)
        return self.replace(t=self.t, x=x, v=v)

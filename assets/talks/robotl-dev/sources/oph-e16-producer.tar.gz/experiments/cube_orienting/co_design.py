"""Search OPH morphology/loss pairs under one fixed controller protocol."""

import json
from contextlib import ExitStack
from functools import partial
from pathlib import Path

import jax.random as rax
import langfuse
from effectful.handlers.llm import Agent, Skill
from effectful.handlers.llm.harness.hooks import completion
from effectful.ops.semantics import handler
from effectful.ops.types import NotHandled

from experiments.cli import study_arguments
from experiments.cube_orienting.environment import build_environment, native_runner
from experiments.cube_orienting.evaluation import (
    CoDesignEvaluator,
    CoDesignStudyConfig,
    CoDesignSummary,
    Evaluation,
    Search,
    new_run,
    resume,
    selected_pair,
    verify_codesign,
)
from experiments.search import (
    ProposalAllowanceExhausted,
    SearchLimitReached,
    meter_completion,
    search_harness,
)
from robotl.handlers.mujoco.process import EnvProcess


class CoDesignSearchAgent(Agent):
    """Improve cube retention and orientation by changing one axis at a time.

    Inspect the evaluator and its completed training records first. Choose
    either a whole robot factory or a loss factory, retaining the other axis
    from a completed parent. Use evaluate_morphology or evaluate_loss.
    Both choices share the same proposal and compute allowances. Keep the
    evaluator's task contract throughout. Explain decisions with supporting
    measurements and keep REPL output focused.

    On the realistic Stretch base, design the hand anatomy, its motors, which
    motor pulls each cable, and the wrist mounting geometry; the Stretch wrist
    drives stay fixed. Motor choice and cable assignment are design axes on a
    par with anatomy. When ``allow_independent_fingers`` is true,
    ``OpenParametricHand.make(drives=(CableDrive(digit, role, motor), ...))``
    puts digit cables on chosen motors: ``role`` is ``"flexor"`` (distal
    flexor), ``"intermediate"`` (every joint but the distal),
    ``"splay_pos"`` or ``"splay_neg"`` (the MCP abduction hinge, by the
    direction a pull turns it). Digits count fingers then thumbs. Motors 0 and
    1 are the OPH mixers; each higher index adds a motor, numbered without
    gaps, and every motor must pull a cable. Unlisted cables keep the stock
    wiring: every distal flexor on mixer 1, the index and thumb intermediate
    flexors and the thumb splay pair on mixer 0, other intermediate and splay
    cables passive springs; driving a passive cable replaces its spring.
    Cables on one mixer move together, so under the stock wiring no digit,
    the index included, can move while the others hold, and adding cables to
    a mixer couples digits further.
    ``independent_fingers=(0, 1)`` is shorthand for those fingers' distal
    flexors on motors 2 and 3. When ``allow_motor_models`` is true,
    ``motor_model`` picks each motor from the same-envelope X430 catalog
    (``"XL430-W250"`` 1.4 N·m, ``"XM430-W210"`` 2.7 N·m, ``"XM430-W350"``
    3.8 N·m stall at 11.1 V): one model for all, or a tuple in motor-index
    order. Torque, speed and housing mass come from the published model; do
    not edit actuator gains, force ranges or masses. Stronger motors and added
    motors cost mass on the hand and wrist. Keep the elastic cable laws and
    moment arms. Added housings need physical support and clearance;
    ``StretchHandWithWrist.make`` extends its connected shelves for the motor
    count. Account for added mass and controller dimensions.
    For a spatial base, retain ``spatial_transmission=True`` and the existing
    ``SpatialTendon`` routes over actual spool geometry. Bone, palm and spool
    components own their guide and anchor ports. Represent connected guide
    supports when changing the anatomy or motor placement. The prototype uses
    uniform drums, ideal frictionless guides, lumped springs and zero pretension;
    cable-solid collision and support deformation are not modeled. Do not add
    custom cable laws, hidden forces or unrepresented pulleys.
    ``StretchHandWithWrist.make``
    exposes ``palm_height`` in metres; the mount must remain connected, seat
    the palm and every housing, and clear the spools and upstream wrist.
    Retain the base's 12 mm motor backset unless you also represent supports
    that actually meet the relocated housings. Keep the source wrist links,
    inertias, joint frames, voltage and torque/speed law fixed. The mount's
    ``command_ranges`` may vary within source joint stops; admission samples
    the proposed envelope for hand/mount clearance. This is not a continuous
    or dynamic clearance certificate. Report envelope-only gains as workspace
    improvements, not hand-geometry improvements.
    The modeled thumb-base antagonists share a mixer. Co-contraction can change
    effective stiffness; it does not provide an independent thumb-position
    command. Use anatomy and opposed contacts rather than assuming fully
    actuated thumb joints.
    Consider longer fingers and revised attachment points when the recorded
    contact and closure traces indicate insufficient enclosure, accounting for
    the added leverage, inertia and changed cube placement.
    Each metacarpal is fixed in the palm and each finger abducts at its MCP.
    Inspect the base source and retain its visual-mesh choice. Keep all factory
    imports inside its body with a ``# local-import:`` marker for worker replay.
    Proposals may improve just one error metric as intermediate parents, but
    final selection requires at least one retained training episode and
    improvements in both episode-mean and mean-final error without increasing
    drops. Inspect training contact and motion traces to distinguish enclosure
    from open-finger support; low error after floor contact is not a successful
    manipulation. Return the starting pair when no proposal
    meets that criterion; do not report a tradeoff as joint improvement.
    If the initial loss prioritizes capture, first inspect its digit-load and
    mixer-angle virtual sensors. Keep thumb and finger support during rotation;
    a palm-only resting cube does not satisfy that planning gate. An increased
    finger length also moves fingertip-centred cube placement, so inspect the
    actual initial cube position before interpreting a morphology comparison.
    """

    @Skill.define
    def improve(
        self, environment: EnvProcess, evaluator: CoDesignEvaluator
    ) -> Evaluation:
        """Return the best completed training pair in this run."""
        raise NotHandled


def run_codesign_study(search: Search) -> CoDesignSummary:
    """Search, freeze the training winner, then verify its factorial controls."""
    config = search.config
    if not isinstance(config, CoDesignStudyConfig):
        raise ValueError(f"{config.output} is not a co-design study")
    with (
        ExitStack() as resources,
        langfuse.propagate_attributes(session_id=config.output.name),
        langfuse.get_client().start_as_current_observation(
            name="cube-orienting-co-design", input=config.model_dump(mode="json")
        ),
    ):
        search.save()
        search.save_cost()
        compiled = build_environment(
            config.base,
            dt=config.budget.dt,
            runner=partial(
                native_runner, resources=resources, nthread=config.budget.nthread
            ),
        )
        probe = EnvProcess(compiled, compiled.init(rax.key(0)))
        evaluator = CoDesignEvaluator(search, probe)
        evaluator.measure_initial()
        try:
            with (
                handler(search_harness(config)),
                handler({completion: partial(meter_completion, evaluator)}),
            ):
                CoDesignSearchAgent().improve(probe, evaluator)
        except (SearchLimitReached, ProposalAllowanceExhausted) as error:
            print(error, flush=True)
        search.record_cost()
        best = selected_pair(search)
        initial = evaluator.initial
        summary = CoDesignSummary(search=search, held_out=[])
        for robot, loss in (
            (initial.robot, initial.loss),
            (best.robot, initial.loss),
            (initial.robot, best.loss),
            (best.robot, best.loss),
        ):
            row = Evaluation(robot=robot, loss=loss, budget=config.budget)
            if not any(saved.key == row.key for saved in summary.held_out):
                summary.held_out.append(row)
        summary.save()
    return verify_codesign(summary)


if __name__ == "__main__":
    study, trial_workers = study_arguments(__doc__)
    if study.is_dir():
        resume(study, trial_workers, run_codesign_study)
    else:
        settings = json.loads(study.read_text())
        source = Search.load(Path(settings.pop("source")))
        if trial_workers is not None:
            settings["trial_workers"] = trial_workers
        run_codesign_study(new_run(CoDesignStudyConfig.from_source(source, settings)))

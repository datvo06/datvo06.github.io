"""Visual, segment-wise loss design over a gated native MPC session."""

from collections.abc import Callable, Sequence
from dataclasses import dataclass, field, replace
from math import ceil
from pathlib import Path
from time import perf_counter
from typing import Annotated

import effectful.handlers.llm.harness.synthesis.function  # noqa: F401
import jax
import mediapy
import mujoco
import numpy as np
import PIL.Image
from effectful.handlers.llm import Encodable, Skill, Tool
from effectful.ops.semantics import coproduct, evaluate, handler
from effectful.ops.syntax import defop
from effectful.ops.types import Interpretation, NotHandled, Term
from pydantic import AfterValidator, Field, InstanceOf, PlainSerializer, TypeAdapter
from pydantic.dataclasses import dataclass as checked_dataclass

from robotl.handlers.mujoco.compiler import FIDELITY_PARAMS
from robotl.handlers.mujoco.control import MPCController, SamplingPlanner
from robotl.handlers.mujoco.control.planners import NoFeasiblePlan, SamplingState
from robotl.handlers.mujoco.control.stages import (
    Stage,
    StagedController,
    StageState,
    StageStatus,
)
from robotl.handlers.mujoco.process import (
    ControlProcess,
    EnvProcess,
    EnvSpec,
    EnvState,
)
from robotl.handlers.mujoco.render import Camera, render_trajectory
from robotl.handlers.mujoco.rollouts import JaxableThreadedRunner
from robotl.internals.utils import deepstack, maybe_enable_x64
from robotl.ops import sensors
from robotl.ops.id import Id
from robotl.ops.losses import Loss
from robotl.ops.syntax import Component, fidelity

type RewardFn = Callable[[Component], dict[str, Loss]]


@defop
def probe_env() -> EnvProcess:
    """Compiled scene used when checking an agent's proposed loss."""
    raise NotHandled


def check_reward(reward: RewardFn) -> RewardFn:
    """Check scene dependence and finite scalar evaluation before agent return."""
    env = probe_env()
    terms = TypeAdapter(dict[str, InstanceOf[Loss]]).validate_python(
        reward(env.spec.model)
    )
    if not any(isinstance(term.value, Term) for term in terms.values()):
        raise ValueError("Auxiliary loss must depend on the simulated scene")

    dependencies: set[Id] = set()

    @jax.jit
    def evaluate_terms(state: EnvState) -> dict[str, jax.Array]:
        interpretation = env.spec.intp(state)

        def sensor_get(sensor: sensors.Sensor):
            if not isinstance(sensor, sensors.Virtual):
                dependencies.add(sensor.id)
            return interpretation[sensors.Sensor._get](sensor)

        return auxiliary_terms(
            env.spec,
            terms,
            state,
            interpretation=coproduct(interpretation, {sensors.Sensor._get: sensor_get}),
        )

    # Dependencies are collected during this evaluator's single first trace.
    values = evaluate_terms(env.state)
    if any(
        np.shape(value) != () or not bool(np.isfinite(value))
        for value in values.values()
    ):
        raise ValueError("Auxiliary loss must be finite and scalar")

    model = env.spec.mj_model

    def is_moving(sensor_id: Id) -> bool:
        info = env.spec.context.sensors[sensor_id]
        if not isinstance(info.object, sensors.FrameSensor):
            return True
        body = int(model.sensor_objid[info.idx])
        if model.sensor_objtype[info.idx] == mujoco.mjtObj.mjOBJ_SITE:
            body = int(model.site_bodyid[body])
        if model.body_weldid[body] != 0:
            return True
        while body != 0:
            if model.body_mocapid[body] >= 0:
                return True
            body = int(model.body_parentid[body])
        return False

    if not any(is_moving(sensor_id) for sensor_id in dependencies):
        raise ValueError("Auxiliary loss must depend on moving physical state")
    return reward


@checked_dataclass(frozen=True)
class MPCConfig:
    """Bounded settings for the active stage's sampling planner."""

    horizon: Annotated[float, Field(ge=0.1, le=2)] = 0.5
    replan_interval: Annotated[float, Field(ge=0.05, le=1)] = 0.1
    batch_size: Annotated[int, Field(ge=2, le=64)] = 16
    rounds: Annotated[int, Field(ge=1, le=4)] = 1
    sigma: Annotated[float, Field(gt=0, le=2)] = 0.1


@dataclass(frozen=True)
class RuntimeBudget:
    """Measured warm cost model; estimates are not timing guarantees."""

    dt: float
    threads: int
    live_step_s: float
    rollout_step_s: float

    def estimate(self, config: MPCConfig) -> float:
        """Estimate simulated seconds per wall second."""
        cost = config.rounds * (
            ceil(config.batch_size / self.threads)
            * round(config.horizon / self.dt)
            * self.rollout_step_s
        )
        return 1 / (self.live_step_s / self.dt + cost / config.replan_interval)


@defop
def probe_budget() -> RuntimeBudget:
    """Measured budget used when decoding a segment's MPC configuration."""
    raise NotHandled


def check_mpc(config: MPCConfig) -> MPCConfig:
    """Reject agent settings that exceed the measured warm-runtime budget."""
    if probe_budget().estimate(config) < 1:
        raise ValueError(
            "Proposed MPC configuration exceeds the measured real-time budget"
        )
    return config


@checked_dataclass(frozen=True)
class Segment:
    """An auxiliary loss and simulation budget; stage gates remain fixed."""

    duration: Annotated[float, Field(ge=1, le=10)]
    mpc: Annotated[MPCConfig, AfterValidator(check_mpc)]
    reward: Annotated[Encodable[RewardFn], AfterValidator(check_reward)]


def auxiliary_terms(
    spec: EnvSpec,
    terms: dict[str, Loss],
    state: EnvState,
    *,
    interpretation: Interpretation | None = None,
) -> dict[str, jax.Array]:
    """Evaluate symbolic auxiliary terms at a simulated state."""
    with handler(spec.intp(state) if interpretation is None else interpretation):
        values: dict[str, jax.Array] = evaluate(  # type: ignore[assignment]
            {name: term.value for name, term in terms.items()}
        )
        return values


def bind_auxiliary_terms(
    spec: EnvSpec, terms: dict[str, Loss]
) -> Callable[[EnvState], dict[str, jax.Array]]:
    """Bind fixed auxiliary terms to their compiled numerical evaluation."""

    @jax.jit
    def bound(state: EnvState) -> dict[str, jax.Array]:
        return auxiliary_terms(spec, terms, state)

    return bound


@dataclass(frozen=True)
class Snapshot:
    """Simulator and controller state at a segment boundary."""

    env: EnvProcess
    control: ControlProcess[StageState[SamplingState]]
    integration: np.ndarray
    frame_count: int


@dataclass(frozen=True)
class SegmentRecord:
    """Executed attempt, including attempts later undone during training."""

    segment: Segment
    start: float
    end: float
    wall_s: float
    prepare_s: float
    stage: int
    status: StageStatus
    states: EnvState
    snapshot: Snapshot
    undone: bool = False


def stack_observations(arrays: Sequence[jax.Array], axis: int = 0) -> jax.Array:
    """Stack native CPU recordings without per-frame JAX conversion."""
    if jax.dtypes.issubdtype(arrays[0].dtype, jax.dtypes.prng_key):
        return jax.numpy.stack(arrays, axis=axis)
    # Concrete recording leaves can be packed before a single JAX conversion.
    return jax.numpy.asarray(np.stack(arrays, axis=axis))


@dataclass
class Trajectory:
    """Recorded observations available to the agent and native renderer."""

    spec: EnvSpec
    states: EnvState

    def evaluate[T](self, expression: T) -> T:
        """Evaluate a scene expression over the recorded observations."""

        def one(state):
            with handler(self.spec.intp(state)):
                return evaluate(expression)

        return jax.vmap(one)(self.states)

    def __repr__(self) -> str:
        return (
            f"Trajectory: {len(self.states.t)} frames, "
            f"t={float(self.states.t[0]):.3f}..{float(self.states.t[-1]):.3f}s"
        )


@Encodable.register(Trajectory)  # type: ignore[attr-defined]
def _encode_trajectory(ty):
    return Annotated[ty, InstanceOf, PlainSerializer(repr, return_type=str)]


@Encodable.register(Component)  # type: ignore[attr-defined]
def _encode_scene(ty):
    return Annotated[
        ty, InstanceOf, PlainSerializer(lambda scene: scene.name, return_type=str)
    ]


def native_step[State](
    env: EnvProcess, control: ControlProcess[State], data: mujoco.MjData
) -> tuple[EnvProcess, ControlProcess[State]]:
    """Keep continuous native integration data for audited pickup trajectories."""
    control, action = control.act(env)
    with maybe_enable_x64(FIDELITY_PARAMS[fidelity()]["x64"]):
        env = env.set_action(action)
        env.spec.layout.state_to_data(env.state, data)
        mujoco.mj_step(data.model, data)
        state = env.spec.layout.state_from_data(
            data, rng=jax.random.fold_in(env.state.rng, 0)
        )
    return env.replace(state=state), control


class Session:
    """Own the scene, controller and full-rate native observations for motion audit."""

    def __init__(
        self,
        env: EnvProcess,
        stages: tuple[Stage[SamplingState], ...],
        *,
        data: mujoco.MjData,
        pool: JaxableThreadedRunner,
        motion_invariant: Callable[[EnvProcess, EnvProcess], bool],
    ) -> None:
        self.env = env
        self.pool = pool
        self.stages = stages
        self.control = ControlProcess.make(StagedController(stages), env, env.state.rng)
        self.data = data
        self.motion_invariant = motion_invariant
        self.frames = [env.state]
        self.attempts: list[SegmentRecord] = []

    def step(self) -> None:
        """Retain each native tick and recheck stage and motion invariants."""
        before = self.env
        try:
            self.env, self.control = native_step(self.env, self.control, self.data)
        except NoFeasiblePlan as failure:
            self.control = self.control.replace(state=failure.state)
            return
        self.frames.append(self.env.state)
        stage = self.stages[self.control.state.index]
        if not stage.invariant(self.env) or not self.motion_invariant(before, self.env):
            self.control = self.control.replace(
                state=replace(self.control.state, status=StageStatus.INVARIANT_FAILED)
            )

    def planner(self) -> SamplingPlanner:
        """Read the active stage's sampling planner."""
        controller = self.stages[self.control.state.index].controller
        if not isinstance(controller, MPCController) or not isinstance(
            controller.planner, SamplingPlanner
        ):
            raise TypeError("Director proposals require a sampling MPC stage")
        return controller.planner

    @jax.enable_x64()
    def calibrate(self) -> RuntimeBudget:
        """Measure native plan following and two warm replan horizons."""
        base_planner = self.planner()
        env = self.env
        data = env.spec.layout.state_to_data(env.state)
        follower = replace(base_planner, replan_interval=np.inf, feasible=None)
        control = ControlProcess.make(MPCController(follower), env, env.state.rng)
        control = control.replace(state=control.state.replace(valid_until=np.inf))
        for _ in range(10):
            env, control = native_step(env, control, data)
        start = perf_counter()
        for _ in range(30):
            env, control = native_step(env, control, data)
        live_step = (perf_counter() - start) / 30
        threads = self.pool.pool.manager.nthread
        timings = []
        horizons = (0.1, 0.2)
        for horizon in horizons:
            planner = replace(
                base_planner,
                horizon=horizon,
                rounds=1,
                batch_size=max(2, threads),
                replan_interval=0,
            )
            state = planner.init(self.env.state.rng, self.env)
            for _ in range(2):
                jax.block_until_ready(planner.replan(state, self.env))
            samples = []
            for _ in range(3):
                start = perf_counter()
                jax.block_until_ready(planner.replan(state, self.env))
                samples.append(perf_counter() - start)
            timings.append(max(samples))
        steps = [round(horizon / self.env.spec.dt) for horizon in horizons]
        # The upper envelope includes fixed replan overhead in the step cost.
        per_step = max(
            timing / count for timing, count in zip(timings, steps, strict=True)
        )
        return RuntimeBudget(float(self.env.spec.dt), threads, live_step, per_step)

    def close(self) -> None:
        """Release the native rollout threads."""
        self.pool.pool.manager.close()

    def restore(self, snapshot: Snapshot) -> None:
        """Restore a segment boundary, including native integration state."""
        self.env, self.control = snapshot.env, snapshot.control
        mujoco.mj_setState(
            self.env.spec.mj_model,
            self.data,
            snapshot.integration,
            mujoco.mjtState.mjSTATE_INTEGRATION,
        )
        mujoco.mj_forward(self.env.spec.mj_model, self.data)
        del self.frames[snapshot.frame_count :]


@dataclass
class PickupDirector:
    """Design auxiliary losses for the active pickup stage.

    Inspect the scene and trajectory in the REPL or through view(). Gates,
    masses, contact acceptance and joint limits are fixed. Undo is available
    for training exploration; failed attempts remain recorded. Build scalar
    Loss terms from scene expressions without mutating the scene.
    """

    session: Session = field(metadata={"persist": False}, repr=False)
    goal: str
    budget: RuntimeBudget

    @property
    def trajectory(self) -> Trajectory:
        return Trajectory(
            self.session.env.spec,
            deepstack(self.session.frames, stack=stack_observations),
        )

    @Skill.define
    def act(self, scene: Component, trajectory: Trajectory) -> Segment:
        """Propose the next short segment for {self.goal}.

        Scene: {scene}
        Observations: {trajectory}
        Active stage: {self.session.control.state.index}
        Measured runtime model: {self.budget}
        Use self.budget.estimate(config) in the REPL; it must be at least 1.
        Use the REPL to inspect component definitions and read current state.
        Return a reward factory using robotl.ops.losses, with no scene mutation.
        The segment stops at a stage boundary even if its duration is longer.
        """
        raise NotHandled

    def next_segment(self) -> Segment:
        """Ask the agent from the current simulator state."""
        env = self.session.env
        with handler(
            {probe_env: lambda: self.session.env, probe_budget: lambda: self.budget}
        ):
            return self.act(env.spec.model, self.trajectory)

    @Tool.define
    def undo(self) -> str:
        """Restore the latest recorded training segment and controller state."""
        session = self.session
        for attempt_index in reversed(range(len(session.attempts))):
            record = session.attempts[attempt_index]
            if not record.undone:
                break
        else:
            raise ValueError("No recorded segment to undo")
        session.restore(record.snapshot)
        session.attempts[attempt_index] = replace(
            session.attempts[attempt_index], undone=True
        )
        return (
            f"Restored t={float(session.env.state.t):.3f}s; attempts remain recorded."
        )

    @Tool.define
    def view(
        self,
        times: list[float],
        lookat: tuple[float, float, float],
        distance: float = 1,
        azimuth: float = 120,
        elevation: float = -20,
        width: int = 640,
        height: int = 480,
    ) -> PIL.Image.Image:
        """Render a filmstrip at recorded times; camera angles are degrees."""
        trajectory = self.trajectory
        indices = [
            int(np.argmin(np.abs(np.asarray(trajectory.states.t) - t))) for t in times
        ]
        states = jax.tree.map(lambda x: x[np.asarray(indices)], trajectory.states)
        frames = render_trajectory(
            trajectory.spec,
            states,
            width=width,
            height=height,
            camera=Camera(
                lookat=jax.numpy.asarray(lookat),
                distance=distance,
                azimuth=np.deg2rad(azimuth),
                elevation=np.deg2rad(elevation),
            ),
        )
        return PIL.Image.fromarray(np.concatenate(np.asarray(frames), axis=1))

    def clip(self, output: Path, start: float, end: float, camera: Camera) -> Path:
        """Save a native trajectory clip for the notebook at simulation speed."""
        trajectory = self.trajectory
        times = np.asarray(trajectory.states.t)
        indices = np.flatnonzero((times >= start) & (times <= end))
        if len(indices) < 2:
            raise ValueError("A clip needs at least two recorded frames")
        states = jax.tree.map(lambda x: x[indices], trajectory.states)
        frames = render_trajectory(trajectory.spec, states, camera=camera)
        mediapy.write_video(
            str(output), np.asarray(frames), fps=1 / np.diff(times[indices]).mean()
        )
        return output

    @jax.enable_x64()
    def run(self, segment: Segment) -> SegmentRecord:
        """Execute the active-stage proposal until a boundary or duration cap."""
        session = self.session
        env = session.env
        terms = segment.reward(env.spec.model)
        base_stage = session.stages[session.control.state.index]
        base_planner = session.planner()

        extra = bind_auxiliary_terms(env.spec, terms)

        @jax.jit
        def loss(spec, rollouts):
            values = jax.vmap(jax.vmap(extra))(rollouts)
            return base_planner.loss(spec, rollouts) + sum(values.values()).mean(axis=1)

        config = segment.mpc
        planner = replace(
            base_planner,
            horizon=config.horizon,
            rounds=config.rounds,
            batch_size=config.batch_size,
            replan_interval=config.replan_interval,
            sigma0=config.sigma,
            loss=loss,
        )
        integration = np.empty(
            mujoco.mj_stateSize(env.spec.mj_model, mujoco.mjtState.mjSTATE_INTEGRATION)
        )
        mujoco.mj_getState(
            env.spec.mj_model,
            session.data,
            integration,
            mujoco.mjtState.mjSTATE_INTEGRATION,
        )
        snapshot = Snapshot(env, session.control, integration, len(session.frames))
        index = session.control.state.index
        stages = list(session.stages)
        stages[index] = replace(base_stage, controller=MPCController(planner))
        prepare_start = perf_counter()
        inner = planner.replan(
            planner.init(jax.random.fold_in(env.state.rng, len(session.attempts)), env),
            env,
        )
        jax.block_until_ready(inner)
        prepare_s = perf_counter() - prepare_start
        state = replace(
            session.control.state,
            inner=inner,
        )
        session.control = session.control.replace(
            controller=StagedController(tuple(stages)), state=state
        )
        start = perf_counter()
        first_frame = len(session.frames) - 1
        try:
            for _ in range(round(segment.duration / env.spec.dt)):
                session.step()
                if (
                    session.control.state.index != index
                    or session.control.state.status != StageStatus.ACTIVE
                ):
                    break
        except Exception:
            session.restore(snapshot)
            raise
        record = SegmentRecord(
            segment,
            float(env.state.t),
            float(session.env.state.t),
            perf_counter() - start + prepare_s,
            prepare_s,
            index,
            session.control.state.status,
            deepstack(session.frames[first_frame:], stack=stack_observations),
            snapshot,
        )
        session.attempts.append(record)
        return record

"""Planners: the inner optimiser that improves a :class:`Plan` from rollouts.

* :class:`SamplingPlanner` -- MPPI: sample variations, roll out, softmax-average.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass
from functools import partial
from math import ceil, prod
from typing import Any, Literal

import effectful.handlers.jax.numpy as jnp
import jax
import jax.random as rax
import optax
from flax import struct
from jax.experimental import io_callback

from robotl.handlers.mujoco.process import Action, EnvProcess, EnvSpec, EnvState
from robotl.handlers.mujoco.rollouts import (
    batched_stage_loss_fn,
    default_batched_loss_fn,
    openloop_rollouts,
)
from robotl.internals.utils import any_across_batch, deeprepeat

from .gradients import (
    gn_hessian,
    lm_deltas,
    lm_update,
    rollout_candidates,
    stage_jacobian,
    sweep_grad,
)
from .plans import CSplinePlan, Plan, colored_noise, knot_sigma


class PlannerState(struct.PyTreeNode):
    """State shared by every planner."""

    mean: Plan  # current best plan
    time_grid: jax.Array  # rollout control times; shape needs a concrete dt
    valid_until: jax.Array  # plan is fresh until this sim time
    diagn: dict[str, jax.Array]  # diagnostics


class NoFeasiblePlan[T](RuntimeError):
    """Planning refusal carrying the controller state that failed admission."""

    def __init__(self, state: T) -> None:
        super().__init__("MPC found no feasible rollout; no control was issued")
        self.state = state


def softmax_weights(
    losses: jax.Array, temperature: float, feasible: jax.Array | None = None
) -> jax.Array:
    """Cost-weighted softmax over candidates. Losses are min-max normalised so
    ``temperature`` is scale-free; the floor is a genuine 0/0 guard for the case
    where every candidate scores the same."""
    if feasible is None:
        span = jnp.maximum(1e-5, jnp.max(losses) - jnp.min(losses))
        return jax.nn.softmax(-(losses - jnp.min(losses)) / span / temperature)
    feasible = feasible & jnp.isfinite(losses)
    any_feasible = jnp.any(feasible)
    low = jnp.where(any_feasible, jnp.min(jnp.where(feasible, losses, jnp.inf)), 0)
    high = jnp.where(any_feasible, jnp.max(jnp.where(feasible, losses, -jnp.inf)), 0)
    span = jnp.maximum(1e-5, high - low)
    logits = -(jnp.where(feasible, losses, high) - low) / span / temperature
    weights = jnp.where(feasible, jnp.exp(logits), 0)
    return weights / jnp.maximum(jnp.sum(weights), 1e-30)


@dataclass(eq=False, kw_only=True)
class Planner(ABC):
    """Base planner. :meth:`replan` is the per-tick entry point (``rounds`` ×
    :meth:`improve`, skipped while the plan is fresh); :meth:`get_plan` returns the
    current plan; :meth:`shift` warm-starts the next tick.

    :param horizon: Planning horizon in seconds.
    :param rounds: Improvement steps per tick.
    :param replan_interval: Minimum sim-time (s) between replans (0 = every tick).
    :param plan_init: Builds the initial :class:`Plan`, ``(env, horizon) -> Plan``.
        Default constructs a :class:`CSplinePlan`; pass e.g.
        ``partial(CSplinePlan.make, knot_interval=0.05)`` to configure it, or any
        other builder to swap the parameterization.
    :param rollout: How candidates are executed, ``(spec, state, u) -> EnvState``.
        Default picks MJX-vmap or CPU-sequential from ``spec``; pass
        ``threadpool.rollout`` for CPU-threaded, or any other executor.
    :param plan_spec: Optional softened model for the planner's rollouts (e.g.
        compliant contact); the episode still steps the real ``env``. ``None``
        plans on ``env`` itself.
    """

    horizon: float = 1
    rounds: int = 4
    replan_interval: float = 0.0
    plan_init: Callable[[EnvProcess, float], Plan] = CSplinePlan.make
    rollout: Callable[[EnvSpec, EnvState, Action], EnvState] = openloop_rollouts
    plan_spec: EnvSpec | None = None

    @abstractmethod
    def init(self, rng: jax.Array, env: EnvProcess) -> Any: ...

    @abstractmethod
    def improve(
        self, state: Any, env: EnvProcess, iteration: int
    ) -> tuple[Any, dict]: ...

    @abstractmethod
    def shift(self, state: Any, dt: float) -> Any: ...

    def replan(self, state: Any, env: EnvProcess) -> Any:
        """Run this tick's ``rounds`` improvement steps, unless the plan is still fresh."""

        def replan(state):
            for iteration in range(self.rounds):
                state, diagn = self.improve(state, env, iteration)
            return state.replace(
                valid_until=env.state.t + self.replan_interval, diagn=diagn
            )

        # skip if plan is still valid
        fresh = (self.replan_interval > 0) & (env.state.t < state.valid_until)
        # use lax.cond only if necessary
        if isinstance(fresh, jax.core.Tracer):
            # reduce to a single scalar condition across any enclosing vmaps, else both
            # branches will be evaluated. concretely: skip if ALL vmap cases are fresh.
            # almost always, all batch cases will agree.
            fresh = ~any_across_batch(~fresh)
            return jax.lax.cond(fresh, lambda state: state, replan, state)
        return state if fresh else replan(state)

    def get_plan(self, state: Any) -> Plan:
        """The current best plan"""
        return state.mean

    def check_control(self, state: Any, control: jax.Array) -> jax.Array:
        """Return the control, or fail if the planning result cannot actuate."""
        return control

    def init_plan(self, env: EnvProcess) -> Plan:
        """The initial constant plan at the current pose."""
        return self.plan_init(env, self.horizon)

    def control_times(self, spec: EnvSpec) -> jax.Array:
        """Rollout control times ``[0, dt, ..., horizon)``."""
        dt = float(spec.dt)
        return jnp.arange(ceil(self.horizon / dt)) * dt

    def stage_losses(
        self,
        state: PlannerState,
        candidates: jax.Array,
        env: EnvProcess,
        soft: bool = True,
    ) -> jax.Array:
        # Per-(candidate, timestep) stage costs [B, T]; their time-mean is the
        # scalar objective the samplers score with. ``soft`` rolls out on the
        # softened ``plan_spec`` when set; the loss itself is state-based either
        # way.
        plan_spec = self.plan_spec if soft else None
        rollouts = rollout_candidates(
            env, state.mean, state.time_grid, candidates, self.rollout, plan_spec
        )
        return batched_stage_loss_fn(env.spec, rollouts)


class SamplingState(PlannerState):
    rng: jax.Array  # sampling key
    best_plans: Plan  # top-carry_n elite plans, batched over leading axis


@dataclass(eq=False, kw_only=True)
class SamplingPlanner(Planner):
    """MPPI: sample plan variations about the mean, roll them out, move the mean
    to their cost-weighted (softmax) average.

    :param batch_size: Candidate trajectories per step.
    :param decay: Scale annealing per round: ``σ × decay**iteration``.
    :param temperature: Softmax temperature (on min-max normalised losses).
    :param smoothing: Mean damping ``(1 − smoothing)·new + smoothing·prev``.
    :param carry_n: Top plans carried into the next step.
    :param sigma0: Sampling σ at the start of the horizon, one value for every
        actuator or a tuple with one per actuator.
    :param sigma_slope: Slope of the σ schedule over the horizon.
    :param noise_color: PSD exponent ``1/f^noise_color`` (0 = white, 2.5 = iCEM).
    :param loss: ``(spec, rollouts) -> [batch]`` scores; default = env task loss.
    :param feasible: Optional ``(spec, rollouts) -> [batch]`` boolean admission
        predicate. Rejected candidates have zero weight and cannot be elites.
        Requires ``carry_n > 0`` so controls come from a tested candidate.
    """

    batch_size: int = 32
    decay: float = 0.5
    temperature: float = 0.01
    smoothing: float = 0.1
    carry_n: int = 1
    sigma0: float | tuple[float, ...] = 1.0
    sigma_slope: float = 0.0
    noise_color: float = 0.0
    loss: Any = default_batched_loss_fn
    feasible: Callable[[EnvSpec, EnvState], jax.Array] | None = None

    def __post_init__(self) -> None:
        if self.feasible is not None and self.carry_n < 1:
            raise ValueError("Constrained sampling requires carry_n > 0")
        if self.feasible is not None and self.replan_interval > self.horizon:
            raise ValueError("Constrained sampling requires replan_interval <= horizon")

    def init(self, rng: jax.Array, env: EnvProcess) -> SamplingState:
        plan0 = self.init_plan(env)
        # Initial elite set: carry_n copies of the constant initial plan.
        best_plans = deeprepeat(plan0, self.carry_n)
        return SamplingState(
            mean=plan0,
            time_grid=self.control_times(env.spec),
            valid_until=env.state.t,
            # f32 scalar placeholders: keeps diagn a scan-stable pytree from tick 0.
            diagn={"loss_min": jnp.float32(0.0), "loss_mean": jnp.float32(0.0)}
            | ({"feasible_n": jnp.int32(0)} if self.feasible is not None else {}),
            rng=rng,
            best_plans=best_plans,
        )

    def mppi_round(
        self, state: SamplingState, env: EnvProcess, iteration: int
    ) -> tuple[SamplingState, Plan, jax.Array]:
        """One MPPI round: sample about the mean, roll out, move to the
        softmax-weighted mean. Returns the new state with the round's population
        and losses (which :meth:`improve` reduces to diagnostics and
        :meth:`plan_trace` records)."""
        scale = self.decay**iteration
        state, population, u = self.sample(state, env.spec, scale)
        rollouts = self.rollout(env.spec, env.state, env.spec.layout.u.unpack(u))
        losses = self.loss(env.spec, rollouts)
        feasible = (
            self.feasible(env.spec, rollouts) if self.feasible is not None else None
        )
        state = self.softmax_mean(state, population, losses, feasible)
        return state, population, losses

    def improve(
        self, state: SamplingState, env: EnvProcess, iteration: int
    ) -> tuple[SamplingState, dict]:
        state, _, losses = self.mppi_round(state, env, iteration)
        return state, state.diagn | {
            "loss_min": jnp.min(losses),
            "loss_mean": jnp.mean(losses),
        }

    def plan_trace(self, state: SamplingState, env: EnvProcess):
        """Run this tick's rounds once, recording the per-round
        ``{"population": Plan, "losses": [B], "mean": Plan}`` — the trace
        :func:`~robotl.handlers.mujoco.control.plots.plot_mpc_samples` draws."""
        trace = []
        for iteration in range(self.rounds):
            state, population, losses = self.mppi_round(state, env, iteration)
            trace.append(
                {"population": population, "losses": losses, "mean": state.mean}
            )
        return state, trace

    def get_plan(self, state: SamplingState) -> Plan:
        # Action from the top-1 elite (carry_n > 0), or the mean directly
        # (carry_n=0 → textbook MPPI).
        if self.carry_n > 0:
            return jax.tree.map(lambda x: x[0], state.best_plans)
        return state.mean

    def check_control(self, state: SamplingState, control: jax.Array) -> jax.Array:
        if self.feasible is None:
            return control

        def require_candidate(count: jax.Array, command: jax.Array) -> jax.Array:
            if count == 0:
                raise NoFeasiblePlan(state)
            return command

        count = state.diagn["feasible_n"]
        if isinstance(count, jax.core.Tracer):
            return io_callback(
                require_candidate,
                jax.ShapeDtypeStruct(control.shape, control.dtype),
                count,
                control,
            )
        return require_candidate(count, control)

    def shift(self, state: SamplingState, dt: float) -> SamplingState:
        mean = state.mean.shift(dt)
        best = jax.vmap(lambda p: p.shift(dt))(state.best_plans)
        issued = self.get_plan(state)(0)
        mean = mean.reanchor(issued)
        best = jax.vmap(lambda plan: plan.reanchor(issued))(best)
        return state.replace(
            mean=mean,
            best_plans=best,
        )

    @partial(jax.jit, static_argnums=0)
    def sample(
        self, state: SamplingState, spec: EnvSpec, scale: float
    ) -> tuple[SamplingState, Plan, jax.Array]:
        """``carry_n`` carried elites plus fresh colored-noise variations,
        proposed in the plan's decision-variable space and projected back onto
        its feasible set by :meth:`Plan.with_params`."""
        n = self.batch_size - self.carry_n
        p = state.mean.params()
        knot_t = jnp.linspace(0.0, self.horizon, p.shape[-2])
        sigma = knot_sigma(spec, knot_t, self.sigma0, self.sigma_slope) * scale

        def propose(rng: jax.Array) -> jax.Array:
            keys = rax.split(rng, prod(p.shape[:-2]))
            noise = jax.vmap(
                lambda key: colored_noise(key, p.shape[-2:], self.noise_color)
            )(keys).reshape(p.shape)
            return p + sigma * noise

        fresh_params = jax.vmap(propose)(rax.split(state.rng, n))
        fresh = jax.vmap(lambda a: state.mean.with_params(a, spec))(fresh_params)
        # Candidate order: [carry_n elites, fresh].
        population = jax.tree.map(
            lambda *xs: jnp.concatenate(xs), state.best_plans, fresh
        )
        u = jax.vmap(lambda plan: plan(state.time_grid))(population)
        return state.replace(rng=rax.fold_in(state.rng, 0)), population, u

    @partial(jax.jit, static_argnums=0)
    def softmax_mean(
        self,
        state: SamplingState,
        population: Plan,
        losses: jax.Array,
        feasible: jax.Array | None = None,
    ) -> SamplingState:
        """Move the mean to the softmax-weighted population average (damped by
        ``smoothing``) and carry the top-``carry_n`` elites."""
        if feasible is not None:
            feasible = feasible & jnp.isfinite(losses)
        w = softmax_weights(losses, self.temperature, feasible)
        admitted = population
        if feasible is not None:
            admitted = jax.tree.map(
                lambda x: jnp.where(
                    feasible.reshape((-1,) + (1,) * (x.ndim - 1)), x, 0
                ),
                population,
            )
        new_mean = jax.tree.map(lambda x: jnp.einsum("i,i...->...", w, x), admitted)
        mean = jax.tree.map(
            lambda old, new: (1.0 - self.smoothing) * new + self.smoothing * old,
            state.mean,
            new_mean,
        )
        top_idx = jnp.argsort(losses)[: self.carry_n]
        diagn = state.diagn
        if feasible is not None:
            ranked = jnp.argsort(jnp.where(feasible, losses, jnp.inf))
            top_idx = jnp.where(
                feasible[ranked[: self.carry_n]], ranked[: self.carry_n], ranked[0]
            )
            mean = jax.tree.map(
                lambda new, old: jnp.where(jnp.any(feasible), new, old),
                mean,
                state.mean,
            )
            diagn = diagn | {"feasible_n": jnp.sum(feasible, dtype=jnp.int32)}
        return state.replace(
            mean=mean,
            best_plans=jax.tree.map(lambda x: x[top_idx], population),
            diagn=diagn,
        )


class GradientState(PlannerState):
    opt_state: optax.OptState  # the optimiser's memory on the knot values


@dataclass(eq=False, kw_only=True)
class GradientPlanner(Planner):
    """First-order planner: descend the open-loop objective w.r.t. the spline
    knots with an optax optimiser. The gradient source is pluggable —
    :func:`sweep_grad` (finite differences) or :func:`adjoint_grad`.

    :param eps: Finite-difference step (:func:`sweep_grad` only).
    :param opt: The optax gradient transformation.
    :param grad_fn: ``(planner, state, env, params0) -> [2, n_knots, nu]``.
    :param loss: ``(spec, rollouts) -> [batch]`` scores; default = env task loss.
    """

    eps: float = 1e-2
    opt: optax.GradientTransformation = optax.adam(0.05)
    grad_fn: Any = sweep_grad
    loss: Any = default_batched_loss_fn

    def init(self, rng: jax.Array, env: EnvProcess) -> GradientState:
        mean = self.init_plan(env)
        opt_state = self.opt.init(mean.params())
        return GradientState(
            mean=mean,
            time_grid=self.control_times(env.spec),
            valid_until=env.state.t,
            diagn={"grad_norm": jnp.float32(0.0)},
            opt_state=opt_state,
        )

    def improve(
        self, state: GradientState, env: EnvProcess, iteration: int
    ) -> tuple[GradientState, dict]:
        params0 = state.mean.params()
        g = self.grad_fn(self, state, env, params0)
        updates, opt_state = self.opt.update(g, state.opt_state, params0)
        params = jnp.asarray(optax.apply_updates(params0, updates))
        # with_params projects onto the feasible box (folds the old clip_params).
        mean = state.mean.with_params(params, env.spec)
        return state.replace(mean=mean, opt_state=opt_state), {
            "grad_norm": jax.numpy.linalg.norm(g)
        }

    def shift(self, state: GradientState, dt: float) -> GradientState:
        # Fresh optimiser moments each tick: the shifted plan is a new problem.
        mean = state.mean.shift(dt)
        return state.replace(mean=mean, opt_state=self.opt.init(mean.params()))


class GaussNewtonState(PlannerState):
    lam: jax.Array  # LM damping; warm across rounds, reset per tick by ``shift``
    rng: jax.Array  # bundle-sampling key (grad_mode="bundle")


@dataclass(eq=False, kw_only=True)
class GaussNewtonPlanner(Planner):
    """Second-order planner: Levenberg-Marquardt over the spline knots with a
    stage-wise generalized Gauss-Newton Hessian.

    The task loss is a sum of heterogeneous non-negative terms, not a clean
    least-squares residual, so each timestep's stage cost ``ℓ_t`` is treated as a
    residual ``r_t = √ℓ_t``. The resulting
    ``H = (1/2T) Σ_t ∇ℓ_t ∇ℓ_tᵀ / max(ℓ_t, loss_floor)`` is PSD and, with
    ``T ≫ P``, full rank. The step ``δ = -(H + λI)⁻¹ ∇L`` is damped by a batched
    λ-ladder line search.

    :param eps: Finite-difference step for the stage-loss Jacobian.
    :param loss_floor: Lower clip on ``ℓ_t`` in the GN weight.
    :param lam0: Initial LM damping; each tick's ladder starts here.
    :param max_trials: Size of the batched per-step λ ladder.
    :param grad_mode: ``"fd"`` = ``2P`` central-difference sweep (biased through
        contact); ``"bundle"`` = zeroth-order randomized-smoothing Jacobian
        ``J_t = mean_i Δℓ_t(θ+w_i)w_i/σ²``, which stays informative through
        non-smooth contact (Suh et al., RA-L 2022).
    :param bundle_sigma: Smoothing std (rad) of the bundled Jacobian.
    :param bundle_samples: Perturbation count of the bundled Jacobian.
    """

    eps: float = 1e-2
    loss_floor: float = 1e-3
    lam0: float = 1e-3
    max_trials: int = 8
    grad_mode: Literal["fd", "bundle"] = "fd"
    bundle_sigma: float = 0.1
    bundle_samples: int = 128
    accept: Literal["soft", "stiff"] = (
        "soft"  # line search on soft plan_spec or true model
    )

    def init(self, rng: jax.Array, env: EnvProcess) -> GaussNewtonState:
        mean = self.init_plan(env)
        return GaussNewtonState(
            mean=mean,
            time_grid=self.control_times(env.spec),
            valid_until=env.state.t,
            diagn={"loss": jnp.float32(0.0), "lam": jnp.float32(self.lam0)},
            lam=jnp.full((), self.lam0, dtype="float32"),
            rng=rng,
        )

    def improve(
        self, state: GaussNewtonState, env: EnvProcess, iteration: int
    ) -> tuple[GaussNewtonState, dict]:
        params0 = state.mean.params()  # [2, n_knots, nu]

        ell0, jac = stage_jacobian(self, state, params0, env)  # [T], [P, T]
        grad, hess, l0 = gn_hessian(jac, ell0, self.loss_floor)

        # Batched LM line search over a λ ladder: pick the smallest damping
        # whose step reduces the loss (else keep the plan).
        deltas = lm_deltas(hess, grad, state.lam, self.max_trials)  # [M, P]
        cand = (params0.reshape(-1)[None] + deltas).reshape(
            -1, *params0.shape
        )  # [M, 2, n_knots, nu]

        # Project the LM candidates onto the feasible box before scoring (a
        # with_params round-trip clips through the plan's own invariant). With
        # ``accept="stiff"`` the soft model only proposes the step (via the
        # Jacobian) and the true model disposes, so a step that wins only on the
        # softened contact is rejected rather than executed.
        cand = jax.vmap(lambda c: state.mean.with_params(c, env.spec).params())(cand)
        lcand = self.stage_losses(state, cand, env, soft=self.accept == "soft").mean(
            axis=1
        )

        improved = lcand < l0
        any_imp = jnp.any(improved)
        idx = jnp.argmin(jnp.where(improved, lcand, float("inf")))
        mean = state.mean.with_params(jnp.where(any_imp, cand[idx], params0), env.spec)
        lam = lm_update(state.lam, idx, any_imp, self.max_trials)
        return state.replace(mean=mean, lam=lam, rng=rax.fold_in(state.rng, 1)), {
            "loss": jnp.where(any_imp, lcand[idx], l0),
            "lam": lam,
        }

    def shift(self, state: GaussNewtonState, dt: float) -> GaussNewtonState:
        # Shift the plan; reset λ so the next tick starts a fresh trust region.
        return state.replace(
            mean=state.mean.shift(dt), lam=jnp.full((), self.lam0, dtype="float32")
        )


@dataclass(eq=False, kw_only=True)
class HybridPlanner(SamplingPlanner):
    """MPPI with contact-implicit particle injection. Each round augments the
    sampled population with a fan of bundle Gauss-Newton descent candidates from
    the current mean, rolled out on the soft ``plan_spec``. The softmax fit then
    adjudicates over the union, so an injected particle gains weight only when
    its (soft-model) descent direction also lowers the true-model loss — MPPI
    keeps exploring and opportunistically exploits the contact-implicit
    direction when it helps, ignoring it (zero weight) when it does not.

    :param inject_n: Bundle-GN λ-ladder candidates injected per round.
    :param bundle_sigma: Smoothing std (rad) of the bundled Jacobian.
    :param bundle_samples: Perturbation count of the bundled Jacobian.
    :param grad_mode: Stage-loss Jacobian source, ``"bundle"`` or ``"fd"``.
    :param lam0: LM damping seeding the injected λ ladder.
    :param loss_floor: Lower clip on the stage cost in the GN weight.
    :param eps: Finite-difference step (``grad_mode="fd"`` only).
    """

    inject_n: int = 4
    bundle_sigma: float = 0.3
    bundle_samples: int = 128
    grad_mode: Literal["fd", "bundle"] = "bundle"
    lam0: float = 1e-3
    loss_floor: float = 1e-3
    eps: float = 1e-2

    def gn_fan(self, state: SamplingState, env: EnvProcess) -> Plan:
        # Bundle-GN λ-ladder of descent candidates from the mean, on the soft
        # planning model — the contact-implicit direction offered to MPPI.
        params0 = state.mean.params()
        ell0, jac = stage_jacobian(self, state, params0, env)
        grad, hess, _ = gn_hessian(jac, ell0, self.loss_floor)
        deltas = lm_deltas(hess, grad, jnp.full((), self.lam0), self.inject_n)
        cand = (params0.reshape(-1)[None] + deltas).reshape(-1, *params0.shape)
        # with_params clips each candidate onto the feasible box and builds it.
        return jax.vmap(lambda c: state.mean.with_params(c, env.spec))(cand)

    def improve(
        self, state: SamplingState, env: EnvProcess, iteration: int
    ) -> tuple[SamplingState, dict]:
        scale = self.decay**iteration
        state, population, u = self.sample(state, env.spec, scale)
        fan = self.gn_fan(state, env)
        fan_u = jax.vmap(lambda p: p(state.time_grid))(fan)
        population = jax.tree.map(lambda *xs: jnp.concatenate(xs), population, fan)
        u = jnp.concatenate([u, fan_u])
        rollouts = self.rollout(env.spec, env.state, env.spec.layout.u.unpack(u))
        losses = self.loss(env.spec, rollouts)
        feasible = (
            self.feasible(env.spec, rollouts) if self.feasible is not None else None
        )
        state = self.softmax_mean(state, population, losses, feasible)
        inject_w = softmax_weights(losses, self.temperature, feasible)[
            -self.inject_n :
        ].sum()
        return state, state.diagn | {
            "loss_min": jnp.min(losses),
            "loss_mean": jnp.mean(losses),
            "inject_w": inject_w,
        }

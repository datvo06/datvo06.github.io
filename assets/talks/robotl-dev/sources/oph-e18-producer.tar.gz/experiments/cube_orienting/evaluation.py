"""Run the loss-design and MPC-horizon study in isolated trial processes."""

import dataclasses
import inspect
import json
import math
import time
from collections import Counter
from collections.abc import Callable, Iterable, Iterator, Mapping, Sequence
from contextlib import ExitStack
from functools import partial
from itertools import combinations, product
from pathlib import Path
from typing import Annotated, Any, Literal, Self, cast

import jax
import jax.numpy as jnp
import jax.random as rax
import langfuse
import mujoco
import numpy as np
import pydantic
from effectful.handlers.llm import Encodable
from effectful.handlers.llm.harness.execution.builtin import BuiltinExecutor
from effectful.ops.semantics import evaluate, handler
from pydantic import BaseModel, ConfigDict, Discriminator, Field, Tag, model_validator
from solid2.core.object_base import OpenSCADObject

import experiments.search as search
import robotl.examples.loss_designer as loss_module
from experiments.cube_orienting.diagnostics import save_states
from experiments.cube_orienting.environment import (
    build_environment,
    native_runner,
    primitive_stock,
    same_design,
    sparse_loss,
    stock_robot,
)
from experiments.search import (
    CountedRollouts,
    Evaluator,
    RobotFn,
    SearchConfig,
    SearchCost,
    SearchLimitReached,
    Timing,
    loss_adapter,
    measured,
    pending_cases,
    robot_adapter,
    run_held_out,
    run_trials,
)
from robotl.examples.dynamixel import X430, X430Model
from robotl.examples.hand_with_wrist import (
    OPH_FLANGE_SEAT,
    HandWithWrist,
    StretchHandWithWrist,
)
from robotl.examples.leap_hand_space import MenagerieDesign
from robotl.examples.loss_designer import LossFn, set_losses
from robotl.examples.open_parametric_hand import (
    FLEXOR_MIXER_INDEX,
    SHARED_MIXER_COUNT,
    OpenParametricHand,
    Palm,
    SpatialCableRoute,
    spatial_cable_routes,
)
from robotl.examples.stretch_wrist import STRETCH_FLANGE_COLLISION_INSET
from robotl.handlers.cad.openscad import ShapeToOpenSCAD
from robotl.handlers.mujoco.compiler import InternalCollisionError
from robotl.handlers.mujoco.control.mpc import MPCController
from robotl.handlers.mujoco.control.planners import SamplingPlanner
from robotl.handlers.mujoco.control.plans import CSplinePlan
from robotl.handlers.mujoco.process import (
    Action,
    ControlProcess,
    EnvProcess,
    EnvSpec,
    EnvState,
    Episode,
    run_episode,
)
from robotl.handlers.mujoco.rollouts import JaxableThreadedRunner
from robotl.ops import actuators, joints, shapes, tendons
from robotl.ops.coords import Rotation
from robotl.ops.syntax import Component, LegacyComponent, Port

EXECUTION_REVISION = "native-561-592-stretch-x430-flexors-v15"

type SpatialBinding = tuple[tendons.SpatialTendon, SpatialCableRoute, int | None]

_ASSEMBLY_CLEARANCE = 0.001
_SEAT_TOLERANCE = 1e-5
_MATERIAL_TOLERANCE = 1e-6

DECODE_CONTEXT = {
    **vars(loss_module),
    "Component": Component,
    "HandWithWrist": HandWithWrist,
    "MenagerieDesign": MenagerieDesign,
    "X430Model": X430Model,
}
"""Names a saved loss or robot source may use: ``HandWithWrist`` and
``MenagerieDesign`` are ``stock_robot``'s free names, ``X430Model`` the OPH
factories' motor annotation."""


class SamplingParameters(BaseModel):
    """Noise schedule searched with the episode and rollout budgets fixed."""

    model_config = ConfigDict(frozen=True, allow_inf_nan=False)
    decay: float = Field(default=0.8, gt=0, le=1)
    sigma0: float = Field(default=0.1, gt=0)
    sigma_slope: float = Field(default=0.1, ge=0)


class Budget(BaseModel):
    """A fixed episode duration with independently selected MPC lookahead."""

    model_config = ConfigDict(frozen=True, allow_inf_nan=False)
    dt: float = Field(default=0.005, gt=0)
    horizon: float = Field(default=2.0, gt=0)
    duration: float = Field(default=6.0, gt=0)
    batch_size: int = Field(default=64, gt=1)
    rounds: int = Field(default=4, gt=0)
    replan_interval: float = Field(default=0.02, gt=0)
    knot_interval: float = Field(default=1 / 16, gt=0)
    nthread: int = Field(default=16, ge=0)
    sampling: SamplingParameters = Field(default_factory=SamplingParameters)
    temperature: float = Field(default=0.05, gt=0)
    smoothing: float = Field(default=0.1, ge=0, le=1)
    carry_n: int = Field(default=1, ge=0)
    noise_color: float = Field(default=2.5, ge=0)
    grasp_seed: float | None = Field(default=None, ge=0, le=math.pi / 2)

    def initial_plan(self, env: EnvProcess, horizon: float) -> CSplinePlan:
        """Seed OPH mixer targets without changing physical state or wrist targets."""
        plan = CSplinePlan.make(env, horizon, knot_interval=self.knot_interval)
        if self.grasp_seed is None:
            return plan
        hand = cast(LegacyComponent, env.spec.model).robot.hand
        if not isinstance(hand, OpenParametricHand):
            raise ValueError("grasp_seed requires a tendon-driven OPH")
        params = plan.params()
        for motor in hand.motors:
            index = env.spec.context.actuators[motor.actuator.id].idx
            params = params.at[0, :, index].set(self.grasp_seed)
        return plan.with_params(params, env.spec)

    @model_validator(mode="after")
    def _has_rollouts(self) -> "Budget":
        if self.carry_n >= self.batch_size:
            raise ValueError("batch_size must leave room for fresh samples")
        if self.horizon < self.dt or self.duration < self.dt:
            raise ValueError("horizon and duration must include at least one step")
        return self

    def make_planner(
        self, rollout: Callable[[EnvSpec, EnvState, Action], EnvState]
    ) -> SamplingPlanner:
        """Build the fixed-budget planner for trials and matched runner benchmarks."""
        return SamplingPlanner(
            horizon=self.horizon,
            rounds=self.rounds,
            batch_size=self.batch_size,
            **self.sampling.model_dump(),
            temperature=self.temperature,
            smoothing=self.smoothing,
            carry_n=self.carry_n,
            noise_color=self.noise_color,
            plan_init=self.initial_plan,
            replan_interval=self.replan_interval,
            rollout=rollout,
        )


PROTOCOL = {"training_targets", "evaluation_targets", "controller_seeds", "budget"}
"""The loss study's measurement protocol, a hand study's default; only the budget may not be restated."""


class CubeProtocol(SearchConfig):
    """The controller budget a cube-orienting search measures its cases with."""

    budget: Budget = Field(default_factory=Budget)
    # Record a video of each trial's episode for the report.
    render: bool = True


class LossStudyConfig(CubeProtocol):
    """A loss search on the stock hand, measured against a longer reference horizon."""

    kind: Literal["loss"] = "loss"
    # Folder of sparse-baseline trials shared by loss studies.
    baselines: Path
    reference_horizon: float = Field(gt=0)
    """The longer MPC horizon the sparse baseline is also measured at, so the
    report shows what the searched horizon gives up before any loss design."""

    @model_validator(mode="after")
    def _reference_horizon(self) -> "LossStudyConfig":
        if self.reference_horizon <= self.budget.horizon:
            raise ValueError(
                "the reference horizon must be longer than the searched one"
            )
        return self


class HandStudyConfig(CubeProtocol):
    """A hand search with the initial robot's hardware kept fixed."""

    base: Encodable[RobotFn] = stock_robot
    """The initial hand, whose wrist and motor hardware remain fixed."""
    allow_independent_fingers: bool = False
    """Allow additional OPH finger flexor motors with the base flexor's hardware."""
    allow_motor_models: bool = False
    """Allow each OPH motor to be any same-envelope X430 model. The base
    factory takes a ``motor_model`` keyword; a swapped motor must match its
    slot in the base built with that model."""

    @model_validator(mode="after")
    def _motor_models_need_keyword(self) -> Self:
        if (
            self.allow_motor_models
            and "motor_model" not in inspect.signature(self.base).parameters
        ):
            raise ValueError(
                "allow_motor_models needs a base factory with a motor_model "
                f"keyword; {self.base.__name__} has none"
            )
        return self


class CoDesignStudyConfig(HandStudyConfig):
    """Search hand/loss pairs with separately bounded final verification."""

    kind: Literal["co-design"] = "co-design"
    initial_loss: Encodable[LossFn]
    verification_wall_s: float = Field(default=2 * 3600, gt=0)
    verification_rollout_steps: int = Field(default=300_000_000, gt=0)

    @classmethod
    def from_source(cls, source: "Search", settings: Mapping[str, Any]) -> Self:
        """Freeze a completed training pair and its exact measurement protocol."""
        if not isinstance(source.config, MorphologyStudyConfig):
            raise ValueError(f"{source.config.output} is not a morphology study")
        restated = settings.keys() & (PROTOCOL | {"base", "initial_loss"})
        if restated:
            raise ValueError(
                f"source-owned settings may not be restated: {sorted(restated)}"
            )
        best = selected_hand(source)
        data = {
            **source.config.model_dump(include=PROTOCOL),
            "base": best.robot,
            "initial_loss": best.loss,
            **settings,
        }
        with handler(BuiltinExecutor()):
            return cls.model_validate(data, context=DECODE_CONTEXT)


class MorphologyStudyConfig(HandStudyConfig):
    """A hand search under the losses a finished loss study selected."""

    kind: Literal["morphology"] = "morphology"
    losses: Path
    """The loss study's ``summary.json`` whose held-out rows are the objectives."""
    sparse_in_search: bool = True
    """Also measure every hand under ``sparse_loss`` during the search, next to
    the loss study's selected loss. Selection never reads those rows, so
    dropping them halves the trials per hand; the held-out targets are always
    measured under both objectives."""

    @classmethod
    def from_source(cls, source: "Summary", settings: dict[str, Any]) -> Self:
        """A new hand study: the loss study's protocol with the file's own settings.

        The budget is the loss study's. Targets and controller seeds may be
        restated as a subset of the loss study's, so a quicker study still
        copies the stock hand's trials for its cases. A ``base`` given as
        saved source is decoded as the trial worker decodes it.
        """
        protocol = source.search.config
        if not isinstance(protocol, LossStudyConfig):
            raise ValueError(f"{protocol.output} is not a loss study")
        if "budget" in settings:
            raise ValueError(
                f"the budget belongs to the loss study in {protocol.output}"
            )
        with handler(BuiltinExecutor()):
            config = cls.model_validate(
                {**protocol.model_dump(include=PROTOCOL), **settings},
                context=DECODE_CONTEXT,
            )
        unmeasured = set(config.training_cases) - set(protocol.training_cases)
        unmeasured |= set(config.evaluation_cases) - set(protocol.evaluation_cases)
        if unmeasured:
            raise ValueError(
                f"cases {sorted(unmeasured)} were not measured by the loss study "
                f"in {protocol.output}"
            )
        return config


def _study_kind(value: Any) -> str | None:
    """The explicit study tag at the configuration boundary."""
    if isinstance(value, dict):
        return value.get("kind")
    return value.kind


AnyStudyConfig = Annotated[
    Annotated[LossStudyConfig, Tag("loss")]
    | Annotated[MorphologyStudyConfig, Tag("morphology")]
    | Annotated[CoDesignStudyConfig, Tag("co-design")],
    Discriminator(_study_kind),
]


class HandProposalRefused(ValueError):
    """A hand proposal is outside the study's morphology search space."""


@pydantic.dataclasses.dataclass(
    frozen=True, config=pydantic.ConfigDict(allow_inf_nan=False)
)
class CubeMeasurements:
    """Fixed orientation and retention outcomes stored in a trial."""

    orientation_final_deg: float
    orientation_mean_deg: float
    dropped: bool

    @classmethod
    def from_episode(cls, spec: EnvSpec, episode: Episode) -> Self:
        """Refuse truncated native readings before scoring an episode."""
        model = cast(LegacyComponent, spec.model)
        for sensor in (*model.hand_contact_data, model.floor_contact_data):
            count = int(jnp.max(episode.states.sensor(sensor).x[..., 0]))
            if count > sensor.capacity:
                name = spec.context.sensors[sensor.id].name
                raise ValueError(
                    f"contact sensor {name!r} matched {count} contacts, "
                    f"exceeding capacity {sensor.capacity}"
                )
        return cls.from_channels(episode.channels, float(spec.dt))

    @classmethod
    def from_channels(cls, channels: Mapping[str, Any], dt: float) -> Self:
        """Reduce state-backed readings in JAX before result serialization."""
        angles = jnp.asarray(channels["orientation_deg"])
        retained = jnp.asarray(channels["cube_hand_contacts"]) > 0
        floor = jnp.asarray(channels["cube_floor_contact"])
        window_size = math.ceil(0.5 / dt) + 1
        released = (
            jnp.any(
                jnp.convolve(
                    (~retained).astype(jnp.int32),
                    jnp.ones(window_size, dtype=jnp.int32),
                    mode="valid",
                )
                == window_size
            )
            if retained.shape[0] >= window_size
            else jnp.asarray(False)
        )
        # A cube that leaves the hand just before the episode ends is falling;
        # its final angle is a tumble, not a turn.
        released |= ~jnp.any(retained[-math.ceil(0.05 / dt) :])
        return cls(
            float(angles[-1]), float(jnp.mean(angles)), bool(jnp.any(floor) | released)
        )


def record_cube(env: EnvProcess, control: ControlProcess | None) -> dict[str, Any]:
    """Read the cube's virtual sensors and losses from the supplied state."""
    model = cast(LegacyComponent, env.spec.model)
    with handler(env.intp()):
        orientation = jnp.rad2deg(model.orientation_error.get().theta)
        hand_contacts = model.cube_hand_contacts.get().x[0].astype(jnp.int32)
        floor_contact = model.cube_floor_contact.get().x[0] > 0
    losses = env.spec.get_losses(env.state)
    return {
        "orientation_deg": orientation,
        "cube_hand_contacts": hand_contacts,
        "cube_floor_contact": floor_contact,
        "loss_terms": losses,
        "loss": jnp.stack(list(losses.values())).sum(),
    }


Trial = search.Trial[Budget, CubeMeasurements]
"""A completed cube-orienting episode."""


class Evaluation(search.Evaluation[Budget]):
    """A design measured on the stock hand unless a hand is named."""

    robot: Encodable[RobotFn] = stock_robot

    @property
    def name(self) -> str:
        """The stock hand's rows carry the loss name alone."""
        return self.loss.__name__ if self.is_stock else super().name

    @property
    def is_stock(self) -> bool:
        return is_stock_hand(self.robot)

    @property
    def is_baseline(self) -> bool:
        return self.is_stock and loss_adapter.dump_python(
            self.loss
        ) == loss_adapter.dump_python(sparse_loss)


def ranking(trials: Sequence[Trial]) -> tuple[int, float, float]:
    """Fewer drops, then lower final angle, then lower episode-mean angle."""
    return (
        sum(t.measurements.dropped for t in trials),
        float(np.mean([t.measurements.orientation_final_deg for t in trials])),
        float(np.mean([t.measurements.orientation_mean_deg for t in trials])),
    )


def is_stock_hand(robot: RobotFn) -> bool:
    """Whether a factory is ``stock_robot`` by saved source."""
    return robot_adapter.dump_python(robot) == robot_adapter.dump_python(stock_robot)


class Search(search.Search[AnyStudyConfig, Evaluation, Trial]):
    """A cube-orienting search, decoded with the names its saved sources may use."""

    @classmethod
    def load(cls, path: Path) -> Self:
        """A saved search, its synthesized factories decoded as the trial worker decodes them."""
        with handler(BuiltinExecutor()):
            return cls.model_validate_json(path.read_text(), context=DECODE_CONTEXT)


class Summary(search.Summary[AnyStudyConfig, Evaluation, Trial]):
    """A cube-orienting study, decoded with the names its saved sources may use."""

    search: Search

    @classmethod
    def load(cls, path: Path) -> Self:
        with handler(BuiltinExecutor()):
            return cls.model_validate_json(path.read_text(), context=DECODE_CONTEXT)


class CoDesignSummary(Summary):
    """Frozen factorial comparisons and their persisted verification allowance."""

    training_controls: list[Trial] = Field(default_factory=list)
    verification_cost: SearchCost = Field(default_factory=SearchCost)


def verify_codesign(summary: CoDesignSummary) -> CoDesignSummary:
    """Resume frozen factorial comparisons under their own persisted allowance.

    Preflight all missing cases so the fixed comparison table fits its work cap.
    """
    config = summary.search.config
    assert isinstance(config, CoDesignStudyConfig)
    training = [*summary.search.trials, *summary.training_controls]
    missing = 0
    for row in summary.held_out:
        missing += len(
            pending_cases(config, training, row, config.training_cases, cube_orienting)
        )
        missing += len(
            pending_cases(
                config, summary.trials, row, config.evaluation_cases, cube_orienting
            )
        )
    archived = {(t.stage, t.case) for t in summary.search.trials}
    summary.training_controls = [
        t for t in training if (t.stage, t.case) not in archived
    ]
    summary.save()
    steps_per_case = max(t.timing.simulated_steps for t in summary.search.trials)
    if (
        summary.verification_cost.rollout_steps + missing * steps_per_case
        > config.verification_rollout_steps
    ):
        raise SearchLimitReached(
            "remaining factorial comparisons exceed verification work allowance"
        )

    def remaining() -> float:
        return summary.verification_cost.remaining_time(config.verification_wall_s)

    def charge(steps: int) -> None:
        summary.verification_cost.charge(
            steps, config.verification_wall_s, config.verification_rollout_steps
        )
        summary.save()

    for row in summary.held_out:
        run_trials(
            config,
            training,
            row,
            config.training_cases,
            cube_orienting,
            timeout=remaining,
            on_work=charge,
        )
        summary.training_controls = [
            t for t in training if (t.stage, t.case) not in archived
        ]
        summary.save()
        run_trials(
            config,
            summary.trials,
            row,
            config.evaluation_cases,
            cube_orienting,
            timeout=remaining,
            on_work=charge,
        )
        summary.save()
    return summary


def selected_pair(result: Search) -> Evaluation:
    """Select joint error improvement without worse retention, or retain the base."""
    config = result.config
    assert isinstance(config, CoDesignStudyConfig)
    candidates = [
        row
        for row in result.evaluations
        if row.budget == config.budget
        and Counter(t.case for t in measured(result.trials, row))
        == Counter(config.training_cases)
    ]
    initial = Evaluation(
        robot=config.base,
        loss=config.initial_loss,
        budget=config.budget,
    )
    reference = next((row for row in candidates if row.key == initial.key), None)
    if reference is None:
        raise RuntimeError("the initial pair has no complete fixed-budget measurements")
    return joint_improvement(result, candidates, reference)


def joint_improvement(
    result: Search, candidates: Sequence[Evaluation], reference: Evaluation
) -> Evaluation:
    """Improve both mean angles without more drops, retaining at least one cube."""
    baseline = ranking(measured(result.trials, reference))
    eligible = [reference]
    for row in candidates:
        score = ranking(measured(result.trials, row))
        if (
            score[0] <= baseline[0]
            and score[0] < len(result.config.training_cases)
            and score[1] < baseline[1]
            and score[2] < baseline[2]
        ):
            eligible.append(row)
    return min(eligible, key=lambda row: ranking(measured(result.trials, row)))


def selected_hand(result: Search) -> Evaluation:
    """Select joint error improvement under the study's objective, or the base.

    The objective is the study's first design, since the loss study's
    selected loss is measured before the sparse row. With a base other than
    stock, the stock hand's copied rows are only a reference: selection is
    among the base and the proposals.
    """
    config = result.config
    assert isinstance(config, MorphologyStudyConfig)
    objective = result.evaluations[0]
    base = robot_adapter.dump_json(config.base)
    candidates = [
        e
        for e in result.evaluations
        if e.budget == objective.budget
        and loss_adapter.dump_json(e.loss) == loss_adapter.dump_json(objective.loss)
        and (not e.is_stock or robot_adapter.dump_json(e.robot) == base)
        and Counter(t.case for t in measured(result.trials, e))
        == Counter(config.training_cases)
    ]
    reference = next(
        (row for row in candidates if robot_adapter.dump_json(row.robot) == base), None
    )
    if reference is None:
        raise RuntimeError(
            f"the allowance ran out before the base hand {config.base.__name__} "
            "was measured"
        )
    return joint_improvement(result, candidates, reference)


def _run_cases(
    output: Path,
    stage: str,
    seed: int,
    budget: Budget,
    loss: LossFn,
    *,
    robot: RobotFn = stock_robot,
    controller_seeds: tuple[int, ...] = (0,),
    report_work: Callable[[int], None] = lambda steps: None,
    trial_workers: int = 1,
) -> Iterable[Trial]:
    """Run aligned controller seeds on one target and yield closed case artifacts."""
    start = time.perf_counter()
    target_rotation = Rotation.make_random(rax.key(seed))
    length = round(budget.duration / budget.dt)
    with ExitStack() as resources:
        compiled = build_environment(
            robot,
            target_rotation=target_rotation,
            dt=budget.dt,
            runner=partial(native_runner, resources=resources, nthread=budget.nthread),
        )
        base = pydantic.TypeAdapter(
            pydantic.InstanceOf[LegacyComponent]
        ).validate_python(compiled.model)
        set_losses(base, loss)
        env = EnvProcess(compiled, compiled.init(rax.key(seed)))
        counted = CountedRollouts(report_work)
        episode_runner = env.spec.runner
        assert isinstance(episode_runner, JaxableThreadedRunner)
        planning_runner = dataclasses.replace(episode_runner, on_work=counted)
        planner = budget.make_planner(planning_runner.rollout)
        controller = MPCController(planner)
        controls = [
            ControlProcess.make(controller, env, rax.key(controller_seed))
            for controller_seed in controller_seeds
        ]
        stacked = jax.tree.map(lambda *xs: jnp.stack(xs), *controls)
        inputs, structure = jax.tree.flatten((env, stacked))
        execute_cases = jax.vmap(
            partial(
                run_episode,
                length=length,
                record=record_cube,
                scan=True,
            ),
            in_axes=(None, 0),
        )

        @jax.jit
        def execute(*leaves: jax.Array) -> Episode:
            return execute_cases(*jax.tree.unflatten(structure, leaves))

        build_s = time.perf_counter() - start
        start = time.perf_counter()
        executable = execute.lower(*inputs).compile()
        compile_s = time.perf_counter() - start
        start = time.perf_counter()
        episodes = jax.block_until_ready(executable(*inputs))
        total_s = time.perf_counter() - start
        timing = Timing(
            total_s=total_s,
            compile_s=compile_s,
            build_s=build_s,
            per_step_ms=1000 * total_s / length,
            rollout_batches=counted.batches,
            candidate_rollouts=counted.candidates // len(controller_seeds),
            simulated_steps=counted.steps // len(controller_seeds),
            warmup_simulated_steps=0,
            episode_steps=length,
            replans=counted.batches // budget.rounds,
        )
        for index, controller_seed in enumerate(controller_seeds):
            name = f"{stage}-seed-{seed}-controller-{controller_seed}"
            episode = jax.tree.map(lambda x: x[index], episodes)
            measurements = CubeMeasurements.from_episode(env.spec, episode)
            series = output / f"{name}.npz"
            np.savez_compressed(series, **episode.to_npz_dict(env.spec))
            save_states(series, episode.states)
            result = Trial(
                stage=stage,
                seed=seed,
                controller_seed=controller_seed,
                budget=budget,
                measurements=measurements,
                timing=timing,
                loss=loss,
                robot=robot,
                series=str(series),
                trial_workers=trial_workers,
            )
            print(
                f"{name}: final={measurements.orientation_final_deg:.2f} deg, "
                f"dropped={measurements.dropped}, "
                f"online={total_s:.1f}s, rollout steps={timing.simulated_steps}",
                flush=True,
            )
            yield result


class CubeOrienting:
    """Execute compatible case groups and name shared sparse baseline records."""

    decode_context = DECODE_CONTEXT
    evaluation_type = Evaluation
    trial_type = Trial

    def case_batches(
        self, cases: tuple[tuple[int, int], ...]
    ) -> tuple[tuple[tuple[int, int], ...], ...]:
        """Pair pending controller seeds that share a compiled target."""
        batches: list[tuple[tuple[int, int], ...]] = []
        for target in dict.fromkeys(target for target, _ in cases):
            compatible = tuple(case for case in cases if case[0] == target)
            batches.extend(
                compatible[index : index + 2] for index in range(0, len(compatible), 2)
            )
        return tuple(batches)

    def run_cases(
        self,
        evaluation: Evaluation,
        stage: str,
        cases: tuple[tuple[int, int], ...],
        output: Path,
        report_work: Callable[[int], None],
        trial_workers: int,
    ) -> Iterable[Trial]:
        """Yield a nonempty group of controller seeds for one compiled target.

        Callers may supply batches directly rather than through :meth:`case_batches`.
        """
        if len({target for target, _ in cases}) != 1:
            raise ValueError("a cube batch must have exactly one target")
        seed = cases[0][0]
        yield from _run_cases(
            output,
            stage,
            seed,
            evaluation.budget,
            evaluation.loss,
            robot=evaluation.robot,
            controller_seeds=tuple(controller_seed for _, controller_seed in cases),
            report_work=report_work,
            trial_workers=trial_workers,
        )

    def shared_record(
        self, config: AnyStudyConfig, evaluation: Evaluation, case: tuple[int, int]
    ) -> Path | None:
        """Loss studies share sparse trials measured under the configured budget.

        A diagnostic sparse evaluation with another sampling schedule is
        measured, and a hand study copies its stock rows from its source.
        """
        if not (
            isinstance(config, LossStudyConfig)
            and evaluation.is_baseline
            and evaluation.budget
            == config.budget.model_copy(update={"horizon": evaluation.budget.horizon})
        ):
            return None
        seed, controller_seed = case
        return (
            config.baselines
            / EXECUTION_REVISION
            / (
                f"sparse-horizon-{evaluation.budget.horizon:g}"
                f"-seed-{seed}-controller-{controller_seed}"
            )
        )


cube_orienting = CubeOrienting()


# The agent's prompt renders every evaluator base, so this docstring carries
# the task's objective to both the loss and the hand evaluator.
class CubeOrientingEvaluator(Evaluator[AnyStudyConfig, Evaluation]):
    """Measure cube-orienting designs on the fixed training suite.

    Minimize the cube's angular error to its target without dropping it. Floor
    contact, a continuous 0.5-second release, or a release through the final
    0.05 seconds counts as a drop. Rank designs
    by fewer drops, lower final angle, then lower episode-mean angle, as
    ``ranking(trials)`` does. Evaluations use ``config.training_cases`` at
    the MPC horizon of ``config.budget``. ``build_environment(robot)`` builds
    the environment for any hand factory.
    """

    result: Search

    def __init__(self, result: Search, environment: EnvProcess) -> None:
        super().__init__(result, environment, cube_orienting)


class CubeEvaluator(CubeOrientingEvaluator):
    """Design planning losses for cube orientation at a shorter MPC horizon.

    The hand is the stock one. Compare against the sparse baseline at the
    study's horizon and the longer reference at ``config.reference_horizon``,
    which the host measures before the search. Only the loss and sampling
    parameters vary.
    """

    def design(self, evaluation: Evaluation) -> bytes:
        return loss_adapter.dump_json(evaluation.loss)

    def charged(self, evaluation: Evaluation) -> bool:
        return not evaluation.is_baseline

    def reference(self) -> list[Trial]:
        """The sparse baseline at the longer reference horizon, measured by the host."""
        assert isinstance(self.config, LossStudyConfig)
        budget = self.config.budget.model_copy(
            update={"horizon": self.config.reference_horizon}
        )
        return self._run(self._place(sparse_loss, stock_robot, budget))

    def evaluate(
        self,
        loss: LossFn,
        sampling: SamplingParameters,
    ) -> list[Trial]:
        """Measure a factory on the fixed training suite at the study's horizon.

        ``loss`` is a ``LossFn``: the mapping it returns is the whole planning
        objective for the root ``LegacyComponent``, so start from
        ``sparse_loss(env)`` and drop, scale or add terms. It is replayed in a
        fresh process, so keep imports, constants and helpers inside the
        factory. Validation errors reach the REPL without spending a valid
        proposal slot; each distinct valid loss counts. Repeating an identical
        request resumes its completed trials.
        """
        budget = self.config.budget.model_copy(update={"sampling": sampling})
        with langfuse.get_client().start_as_current_observation(
            name="evaluate",
            input={
                "budget": budget.model_dump(mode="json"),
                "cases": self.config.training_cases,
            },
        ) as observation:
            placed = self._place(
                self._trace(loss, self.environment), stock_robot, budget
            )
            trials = self._run(placed)
            observation.update(output=[t.model_dump(mode="json") for t in trials])
            return trials


class HandFixtureEvaluator(CubeOrientingEvaluator):
    """Validate hand anatomy against the initial robot's hardware fixtures."""

    @property
    def config(self) -> MorphologyStudyConfig | CoDesignStudyConfig:
        config = super().config
        assert isinstance(config, (MorphologyStudyConfig, CoDesignStudyConfig))
        return config

    @staticmethod
    def _actuation(
        actuator: actuators.Actuator, *, fixed_range: bool, fixed_commands: bool = True
    ) -> tuple[object, ...]:
        if not isinstance(actuator, actuators.Position) or not isinstance(
            actuator.target, (joints.Hinge, joints.Hinge2)
        ):
            raise HandProposalRefused(
                "hand and wrist motors must remain position servos"
            )
        target = actuator.target
        values = [
            actuator.gear,
            actuator.kp,
            actuator.kv,
            actuator.forcerange,
            target.axis,
            target.damping,
            target.armature,
            target.frictionloss,
        ]
        if target.spring is not None:
            raise HandProposalRefused("motor and wrist joints must remain spring-free")
        if fixed_range:
            values.append(target.range)
            if fixed_commands:
                values.append(actuator.ctrlrange)
        elif not np.array_equal(
            np.asarray(actuator.ctrlrange), np.asarray(target.range)
        ):
            raise HandProposalRefused("motor controls must use their joint's travel")
        return (
            type(actuator),
            type(target),
            *(
                None
                if value is None
                else (
                    np.asarray(value, dtype=float).shape,
                    tuple(np.asarray(value, dtype=float).ravel()),
                )
                for value in values
            ),
        )

    def __init__(
        self,
        result: Search,
        environment: EnvProcess,
    ) -> None:
        super().__init__(result, environment)
        # The stock hand as shipped and as primitives; a proposal matching
        # either part for part is the reference in disguise.
        self._stock = []
        with ExitStack() as resources:
            for factory in (stock_robot, primitive_stock):
                reference = build_environment(
                    factory,
                    dt=self.config.budget.dt,
                    runner=partial(native_runner, resources=resources, nthread=1),
                )
                self._stock.append(reference.mj_model)
        self._motor_references: dict[X430Model, EnvSpec] = {}

    def _motor_slot(
        self, index: int, motor: X430, base_motor: X430
    ) -> tuple[EnvSpec, X430]:
        """The reference spec and motor a proposed OPH motor must match.

        Extra independent-finger motors share the base flexor's slot.
        """
        if motor.model == base_motor.model:
            return self.environment.spec, base_motor
        if not self.config.allow_motor_models:
            raise HandProposalRefused("OPH motor models must match the base")
        reference = self._motor_reference(motor.model)
        assert isinstance(reference.model, LegacyComponent)
        slot = index if index < SHARED_MIXER_COUNT else FLEXOR_MIXER_INDEX
        return reference, reference.model.robot.hand.motors[slot]

    def _motor_reference(self, model: X430Model) -> EnvSpec:
        """The base factory's robot with every OPH motor of ``model``."""
        if model not in self._motor_references:
            # The config validator requires a motor_model keyword on the base
            # whenever motor models are allowed.
            base = cast(Callable[..., Component], self.config.base)
            self._motor_references[model] = build_environment(
                partial(base, motor_model=model),
                dt=self.config.budget.dt,
            )
        return self._motor_references[model]

    def validate_robot(self, robot: RobotFn, resources: ExitStack) -> EnvProcess:
        """Compile and validate a proposal using caller-owned native resources."""
        with handler(BuiltinExecutor()):
            robot = robot_adapter.validate_json(
                robot_adapter.dump_json(robot), context=DECODE_CONTEXT
            )

        try:
            compiled = build_environment(
                robot,
                dt=self.config.budget.dt,
                check=True,
                runner=partial(
                    native_runner,
                    resources=resources,
                    nthread=self.config.budget.nthread,
                ),
            )
        except InternalCollisionError as error:
            raise HandProposalRefused(str(error)) from error
        assert isinstance(compiled.model, LegacyComponent)
        base = self.environment.spec.model
        assert isinstance(base, LegacyComponent)
        if isinstance(compiled.model.robot.hand, OpenParametricHand) != isinstance(
            base.robot.hand, OpenParametricHand
        ):
            raise HandProposalRefused("proposals must use the base hand family")
        stretch = isinstance(base.robot, StretchHandWithWrist)
        if isinstance(compiled.model.robot, StretchHandWithWrist) != stretch:
            raise HandProposalRefused("proposals must retain their base wrist hardware")
        proposed = EnvProcess(compiled, compiled.init(rax.key(0)))
        anchors = [
            compiled.model.robot.base,
            compiled.model.robot.wrist.base,
            compiled.model.robot.wrist.tip,
            *(
                port
                for joint in compiled.model.robot.joints
                for port in (joint.a, joint.b)
            ),
        ]
        base_anchors = [
            base.robot.base,
            base.robot.wrist.base,
            base.robot.wrist.tip,
            *(port for joint in base.robot.joints for port in (joint.a, joint.b)),
        ]
        if len(anchors) != len(base_anchors) or any(
            not np.allclose(
                np.asarray(
                    evaluate(
                        getattr(port, field),
                        intp=proposed.spec.intp(proposed.state),
                    )
                ),
                np.asarray(
                    evaluate(
                        getattr(base_port, field),
                        intp=self.environment.spec.intp(self.environment.state),
                    )
                ),
                rtol=0,
                atol=1e-6,
            )
            for port, base_port in zip(anchors, base_anchors, strict=True)
            for field in ("pos", "axes")
        ):
            raise HandProposalRefused("wrist attachments must match the base")
        wrist = compiled.model.robot.actuators
        base_wrist = base.robot.actuators
        if [a.target.id for a in wrist] != [j.id for j in compiled.model.robot.joints]:
            raise HandProposalRefused("wrist motors must drive their wrist joints")
        if [
            self._actuation(a, fixed_range=True, fixed_commands=not stretch)
            for a in wrist
        ] != [
            self._actuation(a, fixed_range=True, fixed_commands=not stretch)
            for a in base_wrist
        ]:
            raise HandProposalRefused("wrist actuator settings must match the base")
        structures: list[dict[str, int]] = []
        for robot_model, context in (
            (compiled.model.robot, compiled.context),
            (base.robot, self.environment.spec.context),
        ):
            hand_ids = {part.id for part in robot_model.hand.components()}
            if stretch:
                hand_ids.update(part.id for part in robot_model.mount.components())
            outside = {
                context.components[part.id].name: context.components[part.id].idx
                for part in robot_model.components()
                if part.id not in hand_ids
            }
            structures.append(outside)
        outside, base_outside = structures
        if outside.keys() != base_outside.keys():
            raise HandProposalRefused(
                "robot structure outside the hand must match the base"
            )
        base_spec = self.environment.spec
        # Each proposed body or joint is compared against its reference: the
        # base, or the base rebuilt with that slot's motor model.
        fixture_bodies = [
            (body, base_spec, base_outside[name]) for name, body in outside.items()
        ]
        for body, _, base_body in fixture_bodies:
            if any(
                not np.allclose(
                    getattr(compiled.mj_model, field)[body],
                    getattr(base_spec.mj_model, field)[base_body],
                    rtol=0,
                    atol=1e-6,
                )
                for field in ("body_pos", "body_quat")
            ) or (
                compiled.mj_model.body(compiled.mj_model.body_parentid[body]).name
                != base_spec.mj_model.body(
                    base_spec.mj_model.body_parentid[base_body]
                ).name
            ):
                raise HandProposalRefused(
                    "robot fixtures must keep their base transforms"
                )
        oph = isinstance(compiled.model.robot.hand, OpenParametricHand)
        if oph:
            motors = compiled.model.robot.hand.motors
            if (
                len(motors) != len(base.robot.hand.motors)
                and not self.config.allow_independent_fingers
            ):
                raise HandProposalRefused(
                    "additional OPH motors require independent-finger search"
                )
            if len(motors) < SHARED_MIXER_COUNT or any(
                not isinstance(motor, X430)
                or motor.actuator.target.id != motor.hinge.id
                for motor in motors
            ):
                raise HandProposalRefused("OPH motors must drive their own X430 shafts")
            motor_pairs = [
                (
                    motor,
                    base.robot.hand.motors[i]
                    if i < SHARED_MIXER_COUNT
                    else base.robot.hand.motors[FLEXOR_MIXER_INDEX],
                )
                for i, motor in enumerate(motors)
            ]
            motor_references = [
                self._motor_slot(i, motor, base_motor)
                for i, (motor, base_motor) in enumerate(motor_pairs)
            ]
            fixture_bodies.extend(
                (
                    compiled.context.components[motor.id].idx,
                    ref_spec,
                    ref_spec.context.components[ref_motor.id].idx,
                )
                for motor, (ref_spec, ref_motor) in zip(
                    motors, motor_references, strict=True
                )
            )
        native = compiled.mj_model
        fixed_joints = [
            (joint, base_spec, base_joint)
            for joint, base_joint in zip(
                compiled.model.robot.joints, base.robot.joints, strict=True
            )
        ]
        if oph:
            fixed_joints.extend(
                (motor.hinge, ref_spec, ref_motor.hinge)
                for motor, (ref_spec, ref_motor) in zip(
                    motors, motor_references, strict=True
                )
            )
        joint_bodies = fixture_bodies + [
            (
                native.jnt_bodyid[compiled.context.joints[joint.id].idx],
                ref_spec,
                ref_spec.mj_model.jnt_bodyid[ref_spec.context.joints[ref_joint.id].idx],
            )
            for joint, ref_spec, ref_joint in fixed_joints
        ]
        for body, ref_spec, base_body in joint_bodies:
            reference = ref_spec.mj_model
            joints_here = np.flatnonzero(native.jnt_bodyid == body)
            base_joints_here = np.flatnonzero(reference.jnt_bodyid == base_body)
            dofs_here = np.flatnonzero(native.dof_bodyid == body)
            base_dofs_here = np.flatnonzero(reference.dof_bodyid == base_body)
            if any(
                not np.array_equal(
                    getattr(native, field)[indices],
                    getattr(reference, field)[base_indices],
                )
                for indices, base_indices, fields in (
                    (
                        joints_here,
                        base_joints_here,
                        (
                            "jnt_type",
                            "jnt_pos",
                            "jnt_axis",
                            "jnt_range",
                            "jnt_limited",
                            "jnt_stiffness",
                            "jnt_solref",
                            "jnt_solimp",
                            "jnt_margin",
                        ),
                    ),
                    (
                        dofs_here,
                        base_dofs_here,
                        (
                            "dof_damping",
                            "dof_armature",
                            "dof_frictionloss",
                            "dof_solref",
                            "dof_solimp",
                        ),
                    ),
                )
                for field in fields
            ):
                raise HandProposalRefused("wrist and motor joints must match the base")
        for body, ref_spec, base_body in fixture_bodies:
            reference = ref_spec.mj_model
            if any(
                not np.array_equal(
                    getattr(compiled.mj_model, field)[body],
                    getattr(reference, field)[base_body],
                )
                for field in (
                    "body_mass",
                    "body_inertia",
                    "body_ipos",
                    "body_iquat",
                )
            ):
                raise HandProposalRefused(
                    "wrist and motor hardware must match the base"
                )
            geoms = np.flatnonzero(compiled.mj_model.geom_bodyid == body)
            base_geoms = np.flatnonzero(reference.geom_bodyid == base_body)
            if any(
                not np.array_equal(
                    getattr(compiled.mj_model, field)[geoms],
                    getattr(reference, field)[base_geoms],
                )
                for field in (
                    "geom_type",
                    "geom_size",
                    "geom_pos",
                    "geom_quat",
                    "geom_contype",
                    "geom_conaffinity",
                    "geom_friction",
                    "geom_solref",
                    "geom_solimp",
                    "geom_margin",
                )
            ):
                raise HandProposalRefused(
                    "wrist and motor geometry must match the base"
                )
            for geom, base_geom in zip(geoms, base_geoms, strict=True):
                if native.geom_type[geom] != mujoco.mjtGeom.mjGEOM_MESH:
                    continue
                mesh, base_mesh = (
                    native.geom_dataid[geom],
                    reference.geom_dataid[base_geom],
                )
                for field, address, count in (
                    ("mesh_vert", "mesh_vertadr", "mesh_vertnum"),
                    ("mesh_face", "mesh_faceadr", "mesh_facenum"),
                ):
                    start, size = (
                        getattr(native, address)[mesh],
                        getattr(native, count)[mesh],
                    )
                    base_start, base_size = (
                        getattr(reference, address)[base_mesh],
                        getattr(reference, count)[base_mesh],
                    )
                    if not np.array_equal(
                        getattr(native, field)[start : start + size],
                        getattr(reference, field)[base_start : base_start + base_size],
                    ):
                        raise HandProposalRefused(
                            "wrist and motor meshes must match the base"
                        )
        wrist_ids = {a.id for a in wrist}
        base_wrist_ids = {a.id for a in base_wrist}
        hand = [
            info.object
            for info in compiled.context.actuators.values()
            if info.object.id not in wrist_ids
        ]
        if len({a.target.id for a in hand}) != len(hand):
            raise HandProposalRefused("each hand joint must have only one motor")
        if oph and (
            {a.id for a in hand}
            != {motor.actuator.id for motor in compiled.model.robot.hand.motors}
        ):
            raise HandProposalRefused(
                "OPH must be driven only by its tendon motor shafts"
            )
        if oph:
            spatial = any(
                isinstance(cable, tendons.SpatialTendon)
                for cable in base.robot.hand.tendons
            )
            cable_type = tendons.SpatialTendon if spatial else tendons.FixedTendon
            if any(
                not isinstance(info.object, cable_type)
                for info in compiled.context.tendons.values()
            ):
                raise HandProposalRefused("OPH transmission mode must match the base")
            if spatial:
                self._check_spatial_transmission(
                    compiled,
                    compiled.model.robot.hand,
                    base.robot.hand,
                    self.environment.spec,
                    motor_pairs,
                )
        if not oph:
            wrist_joints = {j.id for j in compiled.model.robot.joints}
            motor_joints = {
                info.object.id
                for info in compiled.context.joints.values()
                if isinstance(info.object, (joints.Hinge, joints.Hinge2))
                and info.object.id not in wrist_joints
            }
            if {a.target.id for a in hand} != motor_joints:
                raise HandProposalRefused(
                    "LEAP must drive every hand hinge exactly once"
                )
            for component in compiled.context.components.values():
                owner = component.object
                if (
                    not isinstance(owner, LegacyComponent)
                    or not {"joints", "actuators"} <= owner.attributes.keys()
                ):
                    continue
                if [a.target.id for a in owner.actuators] != [
                    j.id for j in owner.joints
                ]:
                    raise HandProposalRefused(
                        "LEAP motors must drive their owning joints"
                    )
        if oph:
            if any(
                self._actuation(motor.actuator, fixed_range=True)
                != self._actuation(ref_motor.actuator, fixed_range=True)
                for motor, (_, ref_motor) in zip(motors, motor_references, strict=True)
            ):
                raise HandProposalRefused(
                    "hand actuator constants must match their motor model"
                )
        else:
            reference_settings: dict[str, set[tuple[object, ...]]] = {}
            for info in self.environment.spec.context.actuators.values():
                if info.object.id not in base_wrist_ids:
                    reference_settings.setdefault(info.owner.object.name, set()).add(
                        self._actuation(info.object, fixed_range=False)
                    )
            for info in compiled.context.actuators.values():
                if info.object.id not in wrist_ids and self._actuation(
                    info.object, fixed_range=False
                ) not in reference_settings.get(info.owner.object.name, set()):
                    raise HandProposalRefused(
                        "hand actuator constants must match their base hardware"
                    )
        if robot_adapter.dump_json(robot) != robot_adapter.dump_json(
            self.config.base
        ) and any(same_design(stock, compiled.mj_model) for stock in self._stock):
            raise HandProposalRefused("the stock hand is the reference, not a proposal")
        if stretch:
            self._check_mount(compiled, compiled.model.robot)
        if oph:
            self._check_palm_built(compiled.model.robot.hand)
        return proposed

    @staticmethod
    def _check_palm_built(hand: OpenParametricHand) -> None:
        """Refuse a palm whose shape term is not the one its own parameters
        build: thumb supports and palm size come from ``HandParams`` through
        :meth:`Palm.make`, not from edits to a built palm. Both shapes are
        compared as OpenSCAD source, so any added, carved or replaced
        material is refused."""
        palm = hand.palm
        rebuilt = Palm.make(
            palm.params,
            len(palm.finger_ports),
            len(palm.thumb_ports),
            routed=bool(palm.cable_anchors),
        )

        def source(shape: shapes.Shape) -> str:
            with handler(ShapeToOpenSCAD()):
                model = evaluate(shape)
            assert isinstance(model, OpenSCADObject)
            return model.as_scad()

        if source(palm.shape) != source(rebuilt.shape):
            raise HandProposalRefused(
                "the palm material must be the one Palm.make builds from the "
                "hand parameters; move thumbs through HandParams, which adds struts"
            )

    @staticmethod
    def _cable_law(
        cable: tendons.Tendon,
    ) -> tuple[float, float, float, float, tuple[float, float] | None]:
        """Read the elastic and limit law independently of route geometry."""
        return (
            float(np.asarray(cable.stiffness)),
            float(np.asarray(cable.damping)),
            float(np.asarray(cable.limit_stiffness)),
            float(np.asarray(cable.offset)),
            None
            if cable.range is None
            else (
                float(np.asarray(cable.range[0])),
                float(np.asarray(cable.range[1])),
            ),
        )

    @classmethod
    def _check_spatial_transmission(
        cls,
        spec: EnvSpec,
        hand: OpenParametricHand,
        reference: OpenParametricHand,
        base_spec: EnvSpec,
        motor_pairs: Sequence[tuple[X430, X430]],
    ) -> None:
        """Check the constructed cable bindings and their compiled physical model."""
        if {cable.id for cable in hand.tendons} != set(spec.context.tendons):
            raise HandProposalRefused("all compiled OPH cables must belong to the hand")
        baseline = cls._spatial_bindings(reference)
        proposed = cls._spatial_bindings(hand)
        model = spec.mj_model
        data = mujoco.MjData(model)
        mujoco.mj_forward(model, data)
        baseline_data = mujoco.MjData(base_spec.mj_model)
        mujoco.mj_forward(base_spec.mj_model, baseline_data)
        neutral = data.ten_length.copy()
        cls._check_spatial_laws(spec, hand, reference, proposed, baseline, neutral)
        cls._check_spatial_port_ownership(spec, hand)
        cls._check_spatial_drums(
            spec, data, hand, base_spec, baseline_data, motor_pairs
        )
        cls._check_spatial_openings(
            spec, data, hand, base_spec, baseline_data, reference
        )
        cls._check_spatial_leverage(spec, data, hand, proposed, neutral)

    @staticmethod
    def _spatial_bindings(owner: OpenParametricHand) -> list[SpatialBinding]:
        """Match actual tendons to the constructor's anatomical route intents."""
        digits = (*owner.fingers, *owner.thumbs)
        if (
            len(owner.routing_guides) != len(owner.motors)
            or len(owner.routing_welds) != len(owner.motors)
            or len(owner.palm.cable_anchors) != len(digits)
            or any(
                len(bone.flexor_guides) != 2 or len(bone.extensor_guides) != 2
                for digit in digits
                for bone in digit.bones
            )
            or any(len(digit.bones[1].lateral_anchors) != 2 for digit in digits)
        ):
            raise HandProposalRefused("spatial OPH must retain its owned cable guides")
        for motor, guide, weld in zip(
            owner.motors, owner.routing_guides, owner.routing_welds, strict=True
        ):
            if len(motor.spool.cable_anchors) != len(guide.eyes):
                raise HandProposalRefused("each drum track needs one guide eye")
            if weld.a.id != motor.output_mount.id or weld.b.id != guide.base.id:
                raise HandProposalRefused(
                    "cable guides must attach to their own static casings"
                )
        expected = {
            (
                route.motor_index({}) is not None,
                tuple(port.id for port in route.path),
            ): route
            for route in spatial_cable_routes(digits, len(owner.fingers), owner.palm)
        }
        consumed = set()
        anchors = set()
        assignments: set[int] = set()
        result = []
        for cable in owner.tendons:
            assert isinstance(cable, tendons.SpatialTendon)
            wraps = [
                entry for entry in cable.path if isinstance(entry, tendons.TendonWrap)
            ]
            motor_index = None
            tail = cable.path
            if wraps:
                wrap = cable.path[1] if len(cable.path) >= 4 else None
                if len(wraps) != 1 or not isinstance(wrap, tendons.TendonWrap):
                    raise HandProposalRefused(
                        "active cables must wrap one actual spool"
                    )
                anchor, _, eye, *tail = cable.path
                motor_index = next(
                    (
                        i
                        for i, motor in enumerate(owner.motors)
                        if wrap.component_id == motor.spool.id
                    ),
                    None,
                )
                if motor_index is None:
                    raise HandProposalRefused(
                        "active cables must wrap an owning motor spool"
                    )
                motor = owner.motors[motor_index]
                guide = owner.routing_guides[motor_index]
                tracks = {
                    (port.id, exit_port.id)
                    for port, exit_port in zip(
                        motor.spool.cable_anchors, guide.eyes, strict=True
                    )
                }
                if (
                    not isinstance(anchor, Port)
                    or not isinstance(eye, Port)
                    or wrap.side_id != guide.side.id
                    or (anchor.id, eye.id) not in tracks
                    or anchor.id in anchors
                ):
                    raise HandProposalRefused(
                        "each active cable must use its own drum track"
                    )
                anchors.add(anchor.id)
            ports = [entry for entry in tail if isinstance(entry, Port)]
            if len(ports) != len(tail):
                raise HandProposalRefused(
                    "digit cable routes must use their owned ports"
                )
            key = (bool(wraps), tuple(entry.id for entry in ports))
            if key not in expected or key in consumed:
                raise HandProposalRefused(
                    "OPH must retain every spatial cable role exactly once"
                )
            route = expected[key]
            allowed = (
                tuple(range(FLEXOR_MIXER_INDEX, len(owner.motors)))
                if route.role == "flexor" and route.digit_index < len(owner.fingers)
                else (route.motor_index({}),)
            )
            if motor_index is not None and motor_index not in allowed:
                raise HandProposalRefused(
                    "spatial cables must retain their mixer roles"
                )
            if motor_index is not None and motor_index >= SHARED_MIXER_COUNT:
                if motor_index in assignments:
                    raise HandProposalRefused(
                        "each extra motor must drive one full finger flexor"
                    )
                assignments.add(motor_index)
            consumed.add(key)
            result.append((cable, route, motor_index))
        if consumed != expected.keys() or assignments != set(
            range(SHARED_MIXER_COUNT, len(owner.motors))
        ):
            raise HandProposalRefused(
                "independent flexors must replace complete distinct finger routes"
            )
        if anchors != {
            port.id for motor in owner.motors for port in motor.spool.cable_anchors
        }:
            raise HandProposalRefused("every drum anchor must drive one elastic cable")
        return result

    @classmethod
    def _check_spatial_laws(
        cls,
        spec: EnvSpec,
        hand: OpenParametricHand,
        reference: OpenParametricHand,
        proposed: Sequence[SpatialBinding],
        baseline: Sequence[SpatialBinding],
        neutral: np.ndarray,
    ) -> None:
        """Preserve role-specific elasticity, zero pretension and the native cut."""
        for guide in hand.routing_guides:
            if any(
                getattr(guide.material, field)
                != getattr(reference.routing_guides[0].material, field)
                for field in ("density", "friction", "solref", "solimp")
            ):
                raise HandProposalRefused("cable guide materials must match the base")
        laws: dict[
            str, set[tuple[float, float, float, float, tuple[float, float] | None]]
        ] = {}
        for cable, route, _ in baseline:
            laws.setdefault(route.role, set()).add(cls._cable_law(cable))
        for cable, route, _ in proposed:
            index = spec.context.tendons[cable.id].idx
            if (
                cls._cable_law(cable) not in laws.get(route.role, set())
                or cable.slack_length != 0
                or not np.allclose(
                    spec.mj_model.tendon_lengthspring[index],
                    (0, neutral[index]),
                    rtol=0,
                    atol=1e-9,
                )
            ):
                raise HandProposalRefused(
                    "spatial cables must retain their elastic law and neutral cut"
                )

    @staticmethod
    def _spatial_ports(
        owner: OpenParametricHand,
    ) -> list[tuple[str | None, Component, Port]]:
        return (
            [
                (role, bone, port)
                for digit in (*owner.fingers, *owner.thumbs)
                for bone in digit.bones
                for role, ports in (
                    ("digit-guide", (*bone.flexor_guides, *bone.extensor_guides)),
                    ("digit-anchor", bone.lateral_anchors),
                )
                for port in ports
            ]
            + [
                ("palm-anchor", owner.palm, port)
                for pair in owner.palm.cable_anchors
                for port in pair
            ]
            + [
                (None, motor.spool, port)
                for motor in owner.motors
                for port in motor.spool.cable_anchors
            ]
            + [
                ("guide-eye" if port.id != guide.side.id else None, guide, port)
                for guide in owner.routing_guides
                for port in (guide.side, *guide.eyes)
            ]
        )

    @classmethod
    def _check_spatial_port_ownership(
        cls, spec: EnvSpec, hand: OpenParametricHand
    ) -> None:
        """Check graph ownership as well as native bodies, which may be welded."""
        if any(
            spec.context.ports[port.id].owner.object.id != owner.id
            or spec.mj_model.site_bodyid[spec.context.ports[port.id].idx]
            != spec.context.components[owner.id].idx
            for _, owner, port in cls._spatial_ports(hand)
        ):
            raise HandProposalRefused(
                "spatial cable ports must belong to their physical bodies"
            )

    @staticmethod
    def _opening_rays(
        compiled: EnvSpec,
        state: mujoco.MjData,
        owner: Component,
        port: Port,
    ) -> Iterator[np.ndarray]:
        """Query opposing site-axis rays separately for each owned native solid."""
        native = compiled.mj_model
        site = compiled.context.ports[port.id].idx
        axes = state.site_xmat[site].reshape(3, 3).T
        for geom in compiled.context.geom_ids(native, owner):
            if not (native.geom_contype[geom] or native.geom_conaffinity[geom]):
                continue
            distances = []
            for direction in np.concatenate((axes, -axes)):
                distance = (
                    mujoco.mj_rayMesh(
                        native, state, geom, state.site_xpos[site], direction
                    )
                    if native.geom_type[geom] == mujoco.mjtGeom.mjGEOM_MESH
                    else mujoco.mju_rayGeom(
                        state.geom_xpos[geom],
                        state.geom_xmat[geom],
                        native.geom_size[geom],
                        state.site_xpos[site],
                        direction,
                        native.geom_type[geom],
                    )
                )
                distances.append(distance)
            yield np.asarray(distances)

    @staticmethod
    def _opening_support(rays: Iterable[np.ndarray]) -> float:
        """Bound opening support along six site axes, not nearest distance."""
        return min(
            (float(distance) for solid in rays for distance in solid if distance >= 0),
            default=float("inf"),
        )

    @staticmethod
    def _check_spatial_drums(
        spec: EnvSpec,
        data: mujoco.MjData,
        hand: OpenParametricHand,
        base_spec: EnvSpec,
        baseline_data: mujoco.MjData,
        motor_pairs: Sequence[tuple[X430, X430]],
    ) -> None:
        """Keep tracks on finite drums rather than native axially infinite wraps."""
        model = spec.mj_model
        baseline_model = base_spec.mj_model
        for (motor, base_motor), guide in zip(
            motor_pairs, hand.routing_guides, strict=True
        ):
            geom = spec.context.geom_ids(model, motor.spool)[0]
            base_geom = base_spec.context.geom_ids(baseline_model, base_motor.spool)[0]
            base_positions = [
                baseline_data.geom_xmat[base_geom].reshape(3, 3).T
                @ (
                    baseline_data.site_xpos[base_spec.context.ports[port.id].idx]
                    - baseline_data.geom_xpos[base_geom]
                )
                for port in base_motor.spool.cable_anchors
            ]
            if not base_positions:
                if motor.spool.cable_anchors:
                    raise HandProposalRefused(
                        "spatial motor tracks must retain a represented base drum"
                    )
                continue
            radial_offset = (
                np.linalg.norm(base_positions[0][:2])
                - baseline_model.geom_size[base_geom, 0]
            )
            end_margin = min(
                baseline_model.geom_size[base_geom, 1] - abs(position[2])
                for position in base_positions
            )
            for anchor, eye in zip(motor.spool.cable_anchors, guide.eyes, strict=True):
                positions = [
                    data.geom_xmat[geom].reshape(3, 3).T
                    @ (
                        data.site_xpos[spec.context.ports[port.id].idx]
                        - data.geom_xpos[geom]
                    )
                    for port in (anchor, eye)
                ]
                if not np.isclose(
                    np.linalg.norm(positions[0][:2]) - model.geom_size[geom, 0],
                    radial_offset,
                    rtol=0,
                    atol=_MATERIAL_TOLERANCE,
                ) or any(
                    abs(position[2])
                    > model.geom_size[geom, 1] - end_margin + _MATERIAL_TOLERANCE
                    for position in positions
                ):
                    raise HandProposalRefused(
                        "spatial tracks must remain on the finite represented drum"
                    )

    @classmethod
    def _check_spatial_openings(
        cls,
        spec: EnvSpec,
        data: mujoco.MjData,
        hand: OpenParametricHand,
        base_spec: EnvSpec,
        baseline_data: mujoco.MjData,
        reference: OpenParametricHand,
    ) -> None:
        """Bound supported openings using the initial physical geometry."""
        support_bounds: dict[str, float] = {}
        for opening_role, owner, port in cls._spatial_ports(reference):
            if opening_role is not None:
                support_bounds[opening_role] = max(
                    support_bounds.get(opening_role, 0),
                    cls._opening_support(
                        cls._opening_rays(base_spec, baseline_data, owner, port)
                    ),
                )
        for opening_role, owner, port in cls._spatial_ports(hand):
            if opening_role is None:
                continue
            rays = list(cls._opening_rays(spec, data, owner, port))
            if opening_role == "guide-eye" and any(
                np.any((solid[:3] >= 0) & (solid[3:] >= 0)) for solid in rays
            ):
                raise HandProposalRefused(
                    "spatial guide eyes must remain outside their physical solids"
                )
            if not np.isfinite(support_bounds[opening_role]) or (
                cls._opening_support(rays)
                > support_bounds[opening_role] + _MATERIAL_TOLERANCE
            ):
                raise HandProposalRefused(
                    "spatial cable openings must retain nearby physical supports"
                )

    @staticmethod
    def _check_spatial_leverage(
        spec: EnvSpec,
        data: mujoco.MjData,
        hand: OpenParametricHand,
        proposed: Sequence[SpatialBinding],
        neutral: np.ndarray,
    ) -> None:
        """Sample native tendon leverage and drum uptake without advancing time."""
        model = spec.mj_model
        for cable, route, motor_index in proposed:
            index = spec.context.tendons[cable.id].idx
            for hinge in route.hinges:
                joint = spec.context.joints[hinge.id].idx
                address = model.jnt_qposadr[joint]
                lower, upper = model.jnt_range[joint]
                for angle in np.linspace(lower, upper, 97):
                    lengths = []
                    for delta in (-1e-6, 1e-6):
                        data.qpos[:] = model.qpos0
                        data.qpos[address] = angle + delta
                        mujoco.mj_forward(model, data)
                        lengths.append(data.ten_length[index])
                    if route.sign * (lengths[1] - lengths[0]) / 2e-6 <= 1e-8:
                        raise HandProposalRefused(
                            "spatial cable leverage must retain its flexion sign"
                        )
            if motor_index is not None:
                motor = hand.motors[motor_index]
                joint = spec.context.joints[motor.hinge.id].idx
                address = model.jnt_qposadr[joint]
                geom = spec.context.geom_ids(model, motor.spool)[0]
                radius = model.geom_size[geom, 0]
                lower, upper = model.jnt_range[joint]
                # Native soft stops can overshoot the commanded shaft range.
                for angle in np.linspace(lower - 0.02, upper + 0.02, 97):
                    data.qpos[:] = model.qpos0
                    data.qpos[address] = angle
                    mujoco.mj_forward(model, data)
                    if not np.isclose(
                        data.ten_length[index] - neutral[index],
                        radius * angle,
                        rtol=0,
                        atol=1e-8,
                    ):
                        raise HandProposalRefused(
                            "spatial cables must retain real drum uptake"
                        )

    @classmethod
    def _check_mount(cls, spec: EnvSpec, robot: StretchHandWithWrist) -> None:
        """Reject unsupported or intersecting assembly geometry independent of masks."""
        model = spec.mj_model
        data = mujoco.MjData(model)
        mujoco.mj_forward(model, data)

        def physical(component: Component) -> list[int]:
            return [
                geom
                for geom in spec.context.geom_ids(model, component)
                if model.geom_contype[geom] or model.geom_conaffinity[geom]
            ]

        mount = physical(robot.mount)
        if not mount or any(
            part.disable_collision for part in robot.mount.components()
        ):
            raise HandProposalRefused(
                "mounting hardware must retain physical collisions"
            )

        def gap(first: Iterable[int], second: Iterable[int]) -> float:
            return cls._geometry_gap(model, data, first, second)

        palm = set(physical(robot.hand.palm))
        cls._check_flange(spec, robot, data, mount)
        cls._check_connected(model, data, mount + list(palm))
        if abs(gap(palm, mount)) > _SEAT_TOLERANCE:
            raise HandProposalRefused("the palm must seat on the mount")
        for part in robot.hand.motors:
            geoms = np.flatnonzero(
                model.geom_bodyid == spec.context.components[part.id].idx
            )
            if abs(gap(geoms, mount)) > _SEAT_TOLERANCE:
                raise HandProposalRefused("motor housings must seat on the mount")
        motors = {
            geom
            for motor in robot.hand.motors
            for geom in spec.context.geom_ids(model, motor)
        }
        for first, second in combinations(robot.hand.motors, 2):
            if (
                gap(
                    spec.context.geom_ids(model, first),
                    spec.context.geom_ids(model, second),
                )
                < _ASSEMBLY_CLEARANCE
            ):
                raise HandProposalRefused(
                    "motor assemblies must clear each other by 1 mm"
                )
        anatomy = set(physical(robot.hand)) - motors
        supports = {
            geom for guide in robot.hand.routing_guides for geom in physical(guide)
        }
        for motor, guide in zip(
            robot.hand.motors,
            robot.hand.routing_guides,
            strict=bool(robot.hand.routing_guides),
        ):
            guide_geoms = set(physical(guide))
            housing = np.flatnonzero(
                model.geom_bodyid == spec.context.components[motor.id].idx
            )
            if (
                guide.disable_collision
                or model.body_mass[spec.context.components[guide.id].idx] <= 0
                or abs(gap(guide_geoms, housing)) > _SEAT_TOLERANCE
            ):
                raise HandProposalRefused(
                    "each cable guide must physically seat on its own casing"
                )
            cls._check_connected(model, data, [*guide_geoms, *housing])
            if (
                gap(guide_geoms, spec.context.geom_ids(model, motor.spool))
                < _ASSEMBLY_CLEARANCE - _MATERIAL_TOLERANCE
            ):
                raise HandProposalRefused(
                    "cable guides must clear their rotating spools by 1 mm"
                )
            others = motors - set(spec.context.geom_ids(model, motor))
            if others and gap(guide_geoms, others) < _ASSEMBLY_CLEARANCE:
                raise HandProposalRefused(
                    "cable guides must clear other motors by 1 mm"
                )
            if gap(guide_geoms, anatomy - supports) < _ASSEMBLY_CLEARANCE:
                raise HandProposalRefused(
                    "cable guides must clear the hand anatomy by 1 mm"
                )
        if gap(motors, anatomy - supports) < _ASSEMBLY_CLEARANCE:
            raise HandProposalRefused(
                "motor housings and spools must clear the hand by 1 mm"
            )
        for digit in (*robot.hand.fingers, *robot.hand.thumbs):
            if gap(palm, physical(digit.bones[0])) > _MATERIAL_TOLERANCE:
                raise HandProposalRefused("each digit root must meet the palm material")
        if gap(mount, anatomy - palm) < -_MATERIAL_TOLERANCE:
            raise HandProposalRefused("mount material must not penetrate the digits")
        spools = {
            geom
            for motor in robot.hand.motors
            for geom in spec.context.geom_ids(model, motor.spool)
        }
        if gap(spools, mount) < _ASSEMBLY_CLEARANCE:
            raise HandProposalRefused("motor spools must clear the mount by 1 mm")
        cls._check_wrist_clearance(spec, robot, data, mount + list(anatomy | motors))

    @staticmethod
    def _geometry_gap(
        model: mujoco.MjModel,
        data: mujoco.MjData,
        first: Iterable[int],
        second: Iterable[int],
    ) -> float:
        left, right = tuple(first), tuple(second)
        if not left or not right:
            raise HandProposalRefused("structural parts must have physical geometry")
        return min(
            mujoco.mj_geomDistance(model, data, a, b, 0.1, np.zeros(6))
            for a, b in product(left, right)
        )

    @classmethod
    def _check_connected(
        cls, model: mujoco.MjModel, data: mujoco.MjData, geoms: list[int]
    ) -> None:
        connected = {geoms[0]}
        remaining = set(geoms) - connected
        while remaining:
            neighbors = {
                second
                for first, second in product(connected, remaining)
                if cls._geometry_gap(model, data, [first], [second])
                <= _MATERIAL_TOLERANCE
            }
            if not neighbors:
                raise HandProposalRefused(
                    "mount and palm must form a connected load path"
                )
            connected.update(neighbors)
            remaining.difference_update(neighbors)

    @classmethod
    def _check_flange(
        cls,
        spec: EnvSpec,
        robot: StretchHandWithWrist,
        data: mujoco.MjData,
        mount: list[int],
    ) -> None:
        model = spec.mj_model
        roll = [
            geom
            for geom in spec.context.geom_ids(
                model, robot.wrist.links["link_wrist_roll"]
            )
            if model.geom_contype[geom] or model.geom_conaffinity[geom]
        ]
        if not roll:
            raise RuntimeError("the fixed wrist flange has no physical geometry")
        gap = cls._geometry_gap(model, data, mount, roll)
        if (
            not -_SEAT_TOLERANCE
            <= gap
            <= STRETCH_FLANGE_COLLISION_INSET + _SEAT_TOLERANCE
        ):
            raise HandProposalRefused("mount material must meet the wrist flange")
        tip = spec.context.ports[robot.wrist.tip.id].idx
        rotation = data.site_xmat[tip].reshape(3, 3)
        depth = STRETCH_FLANGE_COLLISION_INSET
        start = data.site_xpos[tip] + rotation @ (
            np.asarray(OPH_FLANGE_SEAT) - [0, 0, depth]
        )
        direction = rotation @ [0, 0, 1]
        hits = []
        for geom in mount:
            if model.geom_type[geom] == mujoco.mjtGeom.mjGEOM_MESH:
                hit = mujoco.mj_rayMesh(model, data, geom, start, direction)
            else:
                hit = mujoco.mju_rayGeom(
                    data.geom_xpos[geom],
                    data.geom_xmat[geom],
                    model.geom_size[geom],
                    start,
                    direction,
                    int(model.geom_type[geom]),
                )
            if hit >= 0:
                hits.append(hit)
        if not hits or abs(min(hits) - depth) > _SEAT_TOLERANCE:
            raise HandProposalRefused("mount material must seat at the tool datum")

    @classmethod
    def _check_wrist_clearance(
        cls,
        spec: EnvSpec,
        robot: StretchHandWithWrist,
        data: mujoco.MjData,
        moving: list[int],
    ) -> None:
        model = spec.mj_model
        upstream = [
            geom
            for name, link in robot.wrist.links.items()
            if name != "link_wrist_roll"
            for geom in spec.context.geom_ids(model, link)
            if model.geom_contype[geom] or model.geom_conaffinity[geom]
        ]
        if not upstream:
            raise RuntimeError("the fixed wrist links have no physical geometry")
        joint_ids = [spec.context.joints[j.id].idx for j in robot.joints]
        addresses = model.jnt_qposadr[joint_ids]
        controls = [spec.context.actuators[a.id].idx for a in robot.actuators]
        limits = model.actuator_ctrlrange[controls]
        stops = model.jnt_range[joint_ids]
        if (
            not np.all(model.actuator_ctrllimited[controls])
            or not np.all(np.isfinite(limits))
            or np.any(limits[:, 0] < stops[:, 0])
            or np.any(limits[:, 1] > stops[:, 1])
        ):
            raise HandProposalRefused(
                "wrist command envelopes must be finite, limited and within source joint stops"
            )
        # Endpoint-only checks miss intermediate link sweeps; sample each axis
        # jointly before running an expensive episode. This is not a certificate.
        for angles in product(
            *(
                np.unique(np.r_[np.linspace(float(bounds[0]), float(bounds[1]), 5), 0])
                for bounds in limits
            )
        ):
            data.qpos[addresses] = angles
            mujoco.mj_kinematics(model, data)
            if cls._geometry_gap(model, data, moving, upstream) < _ASSEMBLY_CLEARANCE:
                raise HandProposalRefused(
                    "hand and mount must clear upstream wrist hardware by 1 mm"
                )


class HandEvaluator(HandFixtureEvaluator):
    """Design the hand for cube orientation under a loss study's objectives.

    ``training`` holds the loss study's rows at the study's horizon: the loss
    it selected and ``sparse_loss``, each with the budget it was measured under.
    Every hand is measured under each of them at that budget. Only the hand
    varies. The search starts from ``config.base``, whose rows are measured
    before the first model call and cost no proposal; the hand returned must
    belong to the same hand family. Return the base if no proposal beats it.
    The stock hand is the study's reference, not a proposal: a hand that
    compiles to it is refused, and its rows join the records only after the
    search.
    """

    def __init__(
        self, result: Search, environment: EnvProcess, training: Sequence[Evaluation]
    ) -> None:
        super().__init__(result, environment)
        self.training = training

    def design(self, evaluation: Evaluation) -> bytes:
        return robot_adapter.dump_json(evaluation.robot)

    def charged(self, evaluation: Evaluation) -> bool:
        return not evaluation.is_stock and self.design(
            evaluation
        ) != robot_adapter.dump_json(self.config.base)

    def evaluate(self, robot: RobotFn) -> list[Trial]:
        """Measure a hand factory under every objective at the study's horizon.

        ``robot`` is a ``RobotFn`` returning the whole robot the environment
        mounts, wrist included, as ``stock_robot`` does. It is replayed in a
        fresh process, so keep imports, constants and helpers inside the
        factory. The hand is compiled with the kinematic check and every
        objective's loss is traced on it before any evaluation is saved, so a
        failure reaches the REPL without spending a proposal slot; each distinct
        valid hand counts. Repeating an identical request resumes its
        completed trials.
        """
        with (
            ExitStack() as resources,
            langfuse.get_client().start_as_current_observation(
                name="evaluate",
                input={
                    "objectives": [row.name for row in self.training],
                    "cases": self.config.training_cases,
                },
            ) as observation,
        ):
            proposed = self.validate_robot(robot, resources)
            losses = [self._trace(row.loss, proposed) for row in self.training]
            placed = [
                self._place(loss, robot, row.budget)
                for loss, row in zip(losses, self.training, strict=True)
            ]
            trials = [t for evaluation in placed for t in self._run(evaluation)]
            observation.update(output=[t.model_dump(mode="json") for t in trials])
            return trials


class CoDesignEvaluator(HandFixtureEvaluator):
    """Change one axis of a completed training pair and rank physical outcomes.

    Call ``evaluate_morphology`` with a new whole robot factory, or
    ``evaluate_loss`` with a new loss factory. The other axis comes from the
    supplied completed parent in this run. Both choices share one allowance.
    Controller settings, motor constants and simulation physics remain fixed.
    With Stretch, hand anatomy and wrist mounting geometry may change, but
    published wrist hardware, joint frames and motor limits must remain fixed.
    Keep the base hand's tendon-driven X430 motor hardware and palm-up mounting.
    Neighbouring structural parts must meet through represented interfaces;
    kinematic parenting or a massless weld does not connect floating geometry.
    Losses must also execute on the initial hand, and proposed hands must
    support the initial loss, so the final factorial comparisons are defined.
    Selection requires lower episode-mean and mean-final error, with no more
    drops than the initial pair. Synthesized loss values are not task scores.
    Return ``best``, a completed Evaluation. Inspect training records only.
    """

    @property
    def config(self) -> CoDesignStudyConfig:
        config = super().config
        assert isinstance(config, CoDesignStudyConfig)
        return config

    @property
    def initial(self) -> Evaluation:
        return Evaluation(
            robot=self.config.base,
            loss=self.config.initial_loss,
            budget=self.config.budget,
        )

    @property
    def best(self) -> Evaluation:
        return selected_pair(self.result)

    def design(self, evaluation: Evaluation) -> bytes:
        return evaluation.stage.encode()

    def charged(self, evaluation: Evaluation) -> bool:
        return evaluation.key != self.initial.key

    def check_parent(self, parent: Evaluation) -> None:
        if parent.budget != self.config.budget or not any(
            row.key == parent.key for row in self.result.evaluations
        ):
            raise ValueError("parent must belong to the current training archive")
        if Counter(t.case for t in measured(self.result.trials, parent)) != Counter(
            self.config.training_cases
        ):
            raise ValueError(
                "parent must contain every fixed training case exactly once"
            )

    def evaluate_morphology(self, robot: RobotFn, parent: Evaluation) -> list[Trial]:
        """Measure a new anatomy with a completed parent's loss held fixed."""
        self.check_parent(parent)
        with ExitStack() as resources:
            proposed = self.validate_robot(robot, resources)
            self._trace(self.config.initial_loss, proposed)
            loss = self._trace(parent.loss, proposed)
            return self._run(self._place(loss, robot, self.config.budget))

    def evaluate_loss(self, loss: LossFn, parent: Evaluation) -> list[Trial]:
        """Measure a new loss with a completed parent's anatomy held fixed."""
        self.check_parent(parent)
        with ExitStack() as resources:
            proposed = (
                self.environment
                if robot_adapter.dump_json(parent.robot)
                == robot_adapter.dump_json(self.config.base)
                else self.validate_robot(parent.robot, resources)
            )
            checked = self._trace(loss, self.environment)
            if proposed is not self.environment:
                checked = self._trace(loss, proposed)
            return self._run(self._place(checked, parent.robot, self.config.budget))

    def measure_initial(self) -> list[Trial]:
        """Measure the initial pair without consuming an agent proposal."""
        loss = self._trace(self.config.initial_loss, self.environment)
        return self._run(self._place(loss, self.config.base, self.config.budget))


def new_run(config: AnyStudyConfig) -> Search:
    """A study's first checkpoint; an existing checkpoint is never overwritten."""
    result = Search(config=config)
    config.output.mkdir(parents=True, exist_ok=True)
    with (config.output / "search.json").open("x") as checkpoint:
        checkpoint.write(result.model_dump_json(indent=2))
    (config.output / "execution.txt").write_text(EXECUTION_REVISION)
    result.save_cost()
    return result


def load_run(directory: Path, trial_workers: int | None) -> Search | Summary:
    """A saved run to resume, its output moved to ``directory``.

    A ``summary.json`` means the search has selected and only held-out
    measurements may be left; otherwise the search itself resumes. The saved
    config keeps its decoded factories; only the run location and the worker
    count are replaced.
    """
    result: Search | Summary
    if (directory / "summary.json").exists():
        data = json.loads((directory / "summary.json").read_text())
        model = (
            CoDesignSummary
            if _study_kind(data["search"]["config"]) == "co-design"
            else Summary
        )
        with handler(BuiltinExecutor()):
            result = model.model_validate(data, context=DECODE_CONTEXT)
        search = result.search
    else:
        result = search = Search.load(directory / "search.json")
    search.cost = SearchCost.model_validate_json((directory / "cost.json").read_text())
    settings = {**dict(search.config), "output": directory}
    if trial_workers is not None:
        settings["trial_workers"] = trial_workers
    with handler(BuiltinExecutor()):
        search.config = type(search.config).model_validate(
            settings, context=DECODE_CONTEXT
        )
    return result


def resume(
    directory: Path, trial_workers: int | None, run: Callable[[Search], Summary]
) -> Summary:
    """Continue a saved run: a search that selected measures what its held-out
    designs lack; one that did not searches on with ``run``."""
    result = load_run(directory, trial_workers)
    incomplete = isinstance(result, Search) or any(
        Counter(trial.case for trial in measured(result.trials, evaluation))
        != Counter(result.search.config.evaluation_cases)
        for evaluation in result.held_out
    )
    if incomplete:
        execution = directory / "execution.txt"
        if not execution.is_file() or execution.read_text() != EXECUTION_REVISION:
            raise ValueError(
                "unfinished run uses another execution revision; start a fresh output directory"
            )
    match result:
        case CoDesignSummary() as summary:
            return verify_codesign(summary)
        case Summary() as summary:
            return run_held_out(summary, cube_orienting)
        case Search() as search:
            return run(search)

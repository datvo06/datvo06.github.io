"""Reconstruct saved simulator states for REPL analysis and rendering."""

import gzip
import pickle
from pathlib import Path
from typing import Annotated

import jax
import numpy as np
from pydantic import (
    Field,
    InstanceOf,
    TypeAdapter,
)

from robotl.handlers.mujoco.process import EnvProcess, EnvState

type SampleTimes = Annotated[
    list[Annotated[float, Field(ge=0, allow_inf_nan=False)]],
    Field(min_length=1),
]


def save_states(series: Path, states: EnvState) -> None:
    """Write an episode's complete states beside its ``series`` traces.

    Level 1 gzip, since the write sits on every trial's path.
    """
    with gzip.open(series.with_suffix(".pkl"), "wb", compresslevel=1) as snapshot:
        pickle.dump(states, snapshot, protocol=pickle.HIGHEST_PROTOCOL)


def recorded_states(
    env: EnvProcess, path: Path, times_s: SampleTimes
) -> list[EnvState]:
    """Load complete states, rebinding process-local IDs to the same model build."""
    requested: SampleTimes = TypeAdapter(SampleTimes).validate_python(times_s)
    with gzip.open(path.with_suffix(".pkl"), "rb") as snapshot:
        saved_states = TypeAdapter(InstanceOf[EnvState]).validate_python(
            pickle.load(snapshot)
        )
    times = np.asarray(saved_states.t)
    if any(t > float(times[-1]) + 1e-6 for t in requested):
        raise ValueError("requested time is beyond the recorded episode")
    states = jax.tree.unflatten(
        jax.tree.structure(env.state), jax.tree.leaves(saved_states)
    )
    selected = []
    for t in requested:
        index = int(np.argmin(np.abs(times - t)))
        state = jax.tree.map(lambda x: x[index], states)
        selected.append(state)
    return selected

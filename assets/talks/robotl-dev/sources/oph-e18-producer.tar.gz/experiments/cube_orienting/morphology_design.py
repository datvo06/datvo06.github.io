"""Design the hand for cube orienting under a finished loss study."""

import json
import shutil
from contextlib import ExitStack
from functools import partial
from pathlib import Path

import jax.random as rax
import langfuse
from effectful.handlers.llm import Agent, Skill
from effectful.handlers.llm.harness.hooks import completion
from effectful.ops.semantics import handler
from effectful.ops.types import NotHandled

from experiments.cli import study_arguments
from experiments.cube_orienting.environment import build_environment, native_runner
from experiments.cube_orienting.evaluation import (
    Evaluation,
    HandEvaluator,
    HandProposalRefused,
    MorphologyStudyConfig,
    Search,
    Summary,
    Trial,
    cube_orienting,
    is_stock_hand,
    new_run,
    resume,
    selected_hand,
)
from experiments.search import (
    ProposalAllowanceExhausted,
    RobotFn,
    SearchLimitReached,
    measured,
    meter_completion,
    run_held_out,
    save_record,
    search_harness,
)
from robotl.handlers.mujoco.process import EnvProcess


class MorphologySearchAgent(Agent):
    """Improve measured task performance by changing the hand, not the objective.

    The evaluator measures every hand under the study's fixed objectives.
    The search starts from ``evaluator.config.base``, already measured in
    ``evaluator.result.evaluations``; read its source there and keep every
    proposal in the same hand family the base builds from, so a proposal
    stays comparable with the base and its records. The wrist gains and the
    hand's actuator constants are fixtures, not search space; the family's
    anatomy record owns the rest of the space and its bounds.
    OPH proposals must retain the base wrist's 20 mm link length and 3 mm
    capsule radius: call ``HandWithWrist(hand, radius=0.003, kp=20.0, kv=1.0)``.
    Keep its joint anchors unchanged. This motor-clearance fixture does not
    guarantee clearance from proposed palm supports throughout wrist motion.
    Keep a physical load path from the unchanged benchmark wrist through the
    palm to each digit and motor housing: neighboring rigid parts must meet
    or connect through represented joint or structural interfaces throughout motion.
    Do not propose detached, floating or disconnected pieces; a shared
    kinematic parent or massless weld alone is not a physical connection.
    Joint clearances and freely routed tendon spans are allowed. The fixed,
    elevated wrist mount is the benchmark fixture, not a disconnected hand
    part, and does not require floor support. Use feasible interface geometry
    and mechanical clearances; arbitrary interpenetration is not a structural
    connection. Inspect the assembled geometry and explain how these
    connections are maintained. Imports stay
    inside the factory body with a ``# local-import:`` marker so the saved
    source replays in a trial worker. Inspect the evaluator's documentation,
    source and saved results before proposing. Keep REPL output focused and
    explain decisions with supporting measurements. Respect the evaluator's
    task contract and allowances.
    """

    @Skill.define
    def improve(self, environment: EnvProcess, evaluator: HandEvaluator) -> RobotFn:
        """Return your best fully evaluated hand factory for ``environment``.

        Return ``selected_hand(evaluator.result).robot``, a ``RobotFn`` factory,
        not a constructed ``Component``. It uses the study's primary objective,
        with the base included.
        On resume, use the saved rows and remaining allowances. When the
        proposal allowance is used, return that selection without further
        proposals or diagnostics.
        Explain measured improvements, remaining failures and uncertainties
        in the conversation.
        """
        raise NotHandled


def objectives(source: Summary, config: MorphologyStudyConfig) -> list[Evaluation]:
    """The designs the loss study sent to held-out at the study's horizon.

    The selected loss comes first when the study selected one, then the sparse
    row, so the first entry is the objective hands are ranked under. The
    reference-horizon row stays out: hands are measured at one horizon. Every
    held-out design is one of the loss study's training designs, which is
    how its selection builds the list.
    """
    horizon = config.budget.horizon
    held_out = [e for e in source.held_out if e.budget.horizon == horizon]
    sparse = [
        e
        for e in held_out
        if e.is_baseline and e.budget.sampling == source.search.config.budget.sampling
    ]
    # A sparse row the agent measured at its own sampling can be the
    # selected one, so anything but the default-sampling sparse row counts.
    winners = [e for e in held_out if e not in sparse]
    if len(sparse) != 1 or len(winners) > 1:
        raise ValueError(
            f"expected one sparse and at most one selected held-out row at "
            f"{horizon:g} s in {config.losses}"
        )
    return [*winners, *sparse]


def saved_series(
    source_dir: Path,
    trials: list[Trial],
    design: Evaluation,
    cases: tuple[tuple[int, int], ...],
) -> list[tuple[Trial, Path, Path]]:
    """Each source trial of ``design`` on ``cases`` with its series and state
    files next to the source summary.

    Files are found by name, since the source may live in another checkout.
    """
    files = []
    selected = [trial for trial in measured(trials, design) if trial.case in cases]
    if sorted(trial.case for trial in selected) != sorted(cases):
        raise ValueError(
            f"source trials for {design.name} are incomplete or duplicated; "
            "resume the loss study before starting morphology search"
        )
    for trial in selected:
        saved = source_dir / Path(trial.series).name
        files.append((trial, saved, saved.with_suffix(".pkl")))
    return files


def copy_trials(
    source_dir: Path,
    trials: list[Trial],
    output: Path,
    design: Evaluation,
    cases: tuple[tuple[int, int], ...],
) -> list[Trial]:
    """The source trials of ``design`` on ``cases``, their files copied into
    ``output`` under the design's own stage."""
    copied = []
    for trial, saved, state in saved_series(source_dir, trials, design, cases):
        name = f"{design.stage}-seed-{trial.seed}-controller-{trial.controller_seed}"
        series = output / f"{name}.npz"
        shutil.copyfile(saved, series)
        shutil.copyfile(state, series.with_suffix(".pkl"))
        restored = trial.model_copy(
            update={"stage": design.stage, "series": str(series)}
        )
        save_record(restored, output / f"{name}.json")
        copied.append(restored)
    return copied


def _copy_training(
    source: Summary, source_dir: Path, search: Search, design: Evaluation
) -> None:
    """List the loss study's training design in ``search`` with its trials,
    unless it is there already."""
    if any(e.key == design.key for e in search.evaluations):
        return
    search.trials.extend(
        copy_trials(
            source_dir,
            source.search.trials,
            search.config.output,
            design,
            search.config.training_cases,
        )
    )
    search.evaluations.append(design)
    search.save()


def run_morphology_study(search: Search) -> Summary:
    """Run or resume a hand search, select, and measure the held-out cases.

    The loss study's series files are found next to its summary.
    """
    config = search.config
    if not isinstance(config, MorphologyStudyConfig):
        raise ValueError(
            f"{config.output} holds a {type(config).__name__}; run it with loss_design"
        )
    source_dir = config.losses.parent
    source = Summary.load(config.losses)
    rows = objectives(source, config)
    search_rows = rows if config.sparse_in_search else rows[:1]
    client = langfuse.get_client()
    with (
        ExitStack() as resources,
        langfuse.propagate_attributes(session_id=config.output.name),
        client.start_as_current_observation(
            name="cube-orienting-hand-study",
            input=config.model_dump(mode="json"),
            metadata={"output": str(config.output)},
        ),
    ):
        search.save()
        search.save_cost()
        print(f"Langfuse session: {config.output.name}", flush=True)
        base_is_stock = is_stock_hand(config.base)
        # Held-out rows are copied after the search; their files are checked
        # now so a missing file fails before any model call. With a base other
        # than stock, the stock hand's training rows are copied after the
        # search too, so the study's records hold no stock measurement while
        # the agent searches.
        deferred = [(source.trials, row, config.evaluation_cases) for row in rows]
        if not base_is_stock:
            deferred += [
                (source.search.trials, row, config.training_cases)
                for row in search_rows
            ]
        for trials, row, cases in deferred:
            missing = [
                path
                for _, *paths in saved_series(source_dir, trials, row, cases)
                for path in paths
                if not path.exists()
            ]
            if missing:
                raise FileNotFoundError(
                    f"series for objective {row.name} missing from {source_dir}: "
                    f"{', '.join(map(str, missing))}"
                )
        if base_is_stock:
            for row in search_rows:
                _copy_training(source, source_dir, search, row)

        compiled = build_environment(
            config.base,
            dt=config.budget.dt,
            runner=partial(
                native_runner, resources=resources, nthread=config.budget.nthread
            ),
        )
        probe = EnvProcess(compiled, compiled.init(rax.key(0)))
        evaluator = HandEvaluator(search, probe, search_rows)
        try:
            # The base's rows precede the first model call and cost no
            # proposal; the agent reads them as its start. The stock base
            # replays its copied rows.
            evaluator.evaluate(config.base)
            with (
                handler(search_harness(config)),
                handler({completion: partial(meter_completion, evaluator)}),
            ):
                robot = MorphologySearchAgent().improve(probe, evaluator)
                try:
                    evaluator.evaluate(robot)
                except (ProposalAllowanceExhausted, HandProposalRefused) as error:
                    print(f"Design returned left unmeasured: {error}", flush=True)
        except SearchLimitReached as error:
            print(error, flush=True)
        search.record_cost()
        for row in search_rows:
            _copy_training(source, source_dir, search, row)
        best = selected_hand(search)
        # The stock rows come from the loss study; the selected hand and the
        # base are measured here. A base that is the stock hand or the
        # selection itself is deduplicated by key.
        summary = Summary(search=search, held_out=[])
        for row in rows:
            summary.held_out.append(row)
            summary.trials.extend(
                copy_trials(
                    source_dir,
                    source.trials,
                    config.output,
                    row,
                    config.evaluation_cases,
                )
            )
            for robot in (best.robot, config.base):
                candidate = Evaluation(loss=row.loss, robot=robot, budget=row.budget)
                if not any(e.key == candidate.key for e in summary.held_out):
                    summary.held_out.append(candidate)
        summary.save()
        return run_held_out(summary, cube_orienting)


if __name__ == "__main__":
    study, trial_workers = study_arguments(__doc__)
    if study.is_dir():
        resume(study, trial_workers, run_morphology_study)
    else:
        settings = json.loads(study.read_text())
        if trial_workers is not None:
            settings["trial_workers"] = trial_workers
        source = Summary.load(Path(settings["losses"]))
        run_morphology_study(
            new_run(MorphologyStudyConfig.from_source(source, settings))
        )

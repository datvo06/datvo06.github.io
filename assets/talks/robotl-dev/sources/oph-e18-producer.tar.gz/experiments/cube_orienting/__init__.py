"""Loss design and planning-horizon comparisons for cube orientation."""

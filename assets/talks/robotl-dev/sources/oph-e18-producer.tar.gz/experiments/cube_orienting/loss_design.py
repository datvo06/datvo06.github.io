"""Design the planning loss for cube orienting in isolated trial processes."""

import json
from contextlib import ExitStack
from functools import partial

import jax.random as rax
import langfuse
from effectful.handlers.llm import Agent, Skill
from effectful.handlers.llm.harness.hooks import completion
from effectful.ops.semantics import handler
from effectful.ops.types import NotHandled

from experiments.cli import study_arguments
from experiments.cube_orienting.environment import (
    build_environment,
    native_runner,
    sparse_loss,
)
from experiments.cube_orienting.evaluation import (
    CubeEvaluator,
    LossStudyConfig,
    Search,
    Summary,
    cube_orienting,
    new_run,
    ranking,
    resume,
)
from experiments.search import (
    ProposalAllowanceExhausted,
    SearchLimitReached,
    measured,
    meter_completion,
    run_held_out,
    search_harness,
)
from robotl.examples.loss_designer import LossFn
from robotl.handlers.mujoco.process import EnvProcess


class LossSearchAgent(Agent):
    """Improve measured task performance using the supplied environment and evaluator.

    Inspect their documentation, source and saved results before experimenting.
    Keep REPL output focused and explain decisions with supporting measurements.
    Use the evaluator for task scoring and simulator APIs in the REPL for probes
    and diagnostic measurements. Use image Skills when visual evidence would help.
    Respect the evaluator's task contract and allowances.
    """

    @Skill.define
    def improve(self, environment: EnvProcess, evaluator: CubeEvaluator) -> LossFn:
        """Improve the task defined by ``environment`` and ``evaluator``.

        Read the evaluator's documentation for the objective, permitted changes
        and evaluation procedure. Explain measured improvements, remaining
        failures and uncertainties in the conversation. Return your best
        fully evaluated loss factory.
        """
        raise NotHandled


def select(search: Search, config: LossStudyConfig) -> Summary:
    """The best design at the searched horizon and the default-sampling sparse
    rows, the reference included, sent to the held-out cases."""
    for horizon in (config.reference_horizon, config.budget.horizon):
        if not any(e.budget.horizon == horizon for e in search.evaluations):
            raise RuntimeError(
                f"No completed training evaluation at horizon {horizon:g}s"
            )
    best = min(
        (e for e in search.evaluations if e.budget.horizon == config.budget.horizon),
        key=lambda e: ranking(measured(search.trials, e)),
    )
    held_out = [
        e
        for e in search.evaluations
        if e is best or (e.is_baseline and e.budget.sampling == config.budget.sampling)
    ]
    return Summary(search=search, held_out=held_out)


def run_study(search: Search) -> Summary:
    """Run or resume a loss search, select, and measure the held-out cases."""
    config = search.config
    if not isinstance(config, LossStudyConfig):
        raise ValueError(
            f"{config.output} holds a {type(config).__name__}; run it with morphology_design"
        )
    client = langfuse.get_client()
    with (
        ExitStack() as resources,
        langfuse.propagate_attributes(session_id=config.output.name),
        client.start_as_current_observation(
            name="cube-orienting-study",
            input=config.model_dump(mode="json"),
            metadata={"output": str(config.output)},
        ),
    ):
        search.save()
        search.save_cost()
        print(f"Langfuse session: {config.output.name}", flush=True)

        compiled = build_environment(
            dt=config.budget.dt,
            runner=partial(
                native_runner, resources=resources, nthread=config.budget.nthread
            ),
        )
        probe = EnvProcess(compiled, compiled.init(rax.key(0)))
        evaluator = CubeEvaluator(search, probe)
        try:
            with (
                handler(search_harness(config)),
                handler({completion: partial(meter_completion, evaluator)}),
            ):
                evaluator.reference()
                evaluator.evaluate(sparse_loss, config.budget.sampling)
                loss = LossSearchAgent().improve(probe, evaluator)
                try:
                    evaluator.evaluate(loss, config.budget.sampling)
                except ProposalAllowanceExhausted as error:
                    # A returned design beyond the allowance stays
                    # unmeasured; selection uses measured designs.
                    print(f"Design returned left unmeasured: {error}", flush=True)
        except SearchLimitReached as error:
            print(error, flush=True)
        search.record_cost()
        summary = select(search, config)
        summary.save()
        return run_held_out(summary, cube_orienting)


if __name__ == "__main__":
    study, trial_workers = study_arguments(__doc__)
    if study.is_dir():
        resume(study, trial_workers, run_study)
    else:
        settings = json.loads(study.read_text())
        if trial_workers is not None:
            settings["trial_workers"] = trial_workers
        run_study(new_run(LossStudyConfig.model_validate(settings)))

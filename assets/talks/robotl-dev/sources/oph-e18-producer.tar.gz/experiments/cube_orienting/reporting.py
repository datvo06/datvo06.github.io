"""Render notebook reports from saved cube-orienting study results."""

import base64
import json
from contextlib import ExitStack
from functools import partial
from html import escape
from pathlib import Path
from typing import NamedTuple

import jax.numpy as jnp
import jax.random as rax
import matplotlib.pyplot as plt
import mediapy
import numpy as np
from effectful.handlers.llm.harness.execution.builtin import BuiltinExecutor
from effectful.ops.semantics import handler
from IPython.display import HTML, Code, Image, Markdown, Video, display
from pydantic import InstanceOf, TypeAdapter

from experiments.cube_orienting.diagnostics import recorded_states
from experiments.cube_orienting.environment import (
    build_environment,
    design_differences,
    native_runner,
    primitive_stock,
    shares_layout,
    sparse_loss,
    stock_robot,
)
from experiments.cube_orienting.evaluation import (
    DECODE_CONTEXT,
    CoDesignStudyConfig,
    CoDesignSummary,
    Evaluation,
    LossStudyConfig,
    MorphologyStudyConfig,
    Summary,
    Trial,
    is_stock_hand,
    ranking,
    selected_hand,
    selected_pair,
)
from experiments.search import loss_adapter, measured, robot_adapter
from robotl.handlers.mujoco.process import EnvProcess, EnvSpec
from robotl.handlers.mujoco.render import Camera, render_trajectory
from robotl.internals.utils import deepstack
from robotl.ops.coords import Rotation
from robotl.ops.syntax import LegacyComponent


def _from_archive(data: dict) -> dict:
    """The search and held-out records of an archived candidate-based notebook result."""
    config = data["config"]
    cost = data["cost"]
    if isinstance(calls := cost["model_calls"], list):
        cost.update(model_calls=len(calls), tokens=sum(c["tokens"] for c in calls))
    if "search_wall_s" in data:
        cost["wall_s"] = data["search_wall_s"]
    designs = {
        c["index"]: {
            "source": c.get("source") or None,
            "budget": config["budget"]
            | {"horizon": c["horizon"], "sampling": c["sampling"]},
        }
        for c in data["candidates"]
    }
    held_out = {
        index: [t for t in data["evaluation"] if t["stage"] == f"held-out-{index}"]
        for index in designs
    }
    return {
        "search": {
            "config": config,
            "cost": cost,
            "evaluations": list(designs.values()),
            "trials": [t for c in data["candidates"] for t in c["trials"]],
        },
        "held_out": [designs[index] for index, trials in held_out.items() if trials],
        "trials": [t for trials in held_out.values() for t in trials],
    }


def load_summary(path: Path) -> Summary:
    """Read a finished study, runs recorded before ``LossFn`` or archived
    candidate-based notebook results."""
    data = json.loads(path.read_text())
    if data.get("search", {}).get("config", {}).get("kind") == "co-design":
        return CoDesignSummary.load(path)
    if "candidates" in data:
        data = _from_archive(data)
    baseline = loss_adapter.dump_python(sparse_loss)
    fields = (
        LossStudyConfig.model_fields.keys() | MorphologyStudyConfig.model_fields.keys()
    )
    search = data["search"]
    search["config"].setdefault("kind", "loss")
    search["config"] = {
        name: value for name, value in search["config"].items() if name in fields
    }
    for record in [
        *search["evaluations"],
        *search["trials"],
        *data["held_out"],
        *data["trials"],
    ]:
        if "source" in record:
            record["loss"] = record.pop("source") or baseline
        # Runs recorded before LossFn stored the sparse baseline as an empty
        # auxiliary factory.
        elif record["loss"]["code"].startswith("def no_auxiliary_loss("):
            record["loss"] = baseline
    for records in (search, data):
        records["trials"] = [
            {name: value for name, value in trial.items() if name in Trial.model_fields}
            for trial in records["trials"]
        ]
    with handler(BuiltinExecutor()):
        return Summary.model_validate(data, context=DECODE_CONTEXT)


def render_trial(trial: Trial, output: Path) -> tuple[Path, Path]:
    """Render a saved episode for a report or an agent's REPL inspection."""
    name = Path(trial.series).stem
    video, plot = output / f"{name}.mp4", output / f"{name}.png"
    if video.exists() and plot.exists():
        return video, plot
    with np.load(output / Path(trial.series).name) as saved:
        times = saved["t"]
        channels = dict(saved)
    channels["loss_terms"] = {
        k.removeprefix("loss_terms__"): v
        for k, v in channels.items()
        if k.startswith("loss_terms__")
    }
    fig, axes = plt.subplots(1, 3, figsize=(13, 3.5), constrained_layout=True)
    axes[0].plot(times, channels["orientation_deg"], color="#1864ab")
    axes[0].set(ylabel="Angular error to target (degrees)", title="Target orientation")
    for name, values in channels["loss_terms"].items():
        axes[1].plot(times, values, label=name.removeprefix("root_"))
    axes[1].set(ylabel="Weighted loss", title="Per-term losses")
    axes[1].legend(fontsize=7)
    axes[2].plot(times, channels["cube_hand_contacts"], label="cube-hand")
    axes[2].plot(times, channels["cube_floor_contact"], label="cube-floor")
    axes[2].set(ylabel="Active contacts", title="Cube retention")
    axes[2].legend()
    for ax in axes.flat:
        ax.set_xlabel("Simulation time (s)")
        ax.grid(alpha=0.2)
    fig.savefig(plot, dpi=145)
    plt.close(fig)

    with ExitStack() as resources:
        compiled = build_environment(
            trial.robot,
            target_rotation=Rotation.make_random(rax.key(trial.seed)),
            dt=trial.budget.dt,
            runner=partial(
                native_runner, resources=resources, nthread=trial.budget.nthread
            ),
        )
        env = EnvProcess(compiled, compiled.init(rax.key(trial.seed)))
        stride = max(1, len(times) // 90)
        states = recorded_states(
            env, output / Path(trial.series).name, times[::stride].tolist()
        )
        trajectory = deepstack(states)
        close = render_trajectory(
            env.spec,
            trajectory,
            max_frames=len(states),
            camera=Camera(
                lookat=jnp.array([0.12, -0.04, 0.28]),
                distance=0.85,
                elevation=-0.65,
                azimuth=1.57,
            ),
        )
        overview = render_trajectory(
            env.spec,
            trajectory,
            max_frames=len(states),
            width=480,
            camera=Camera(
                lookat=jnp.array([0.05, -0.12, -0.02]),
                distance=1.55,
                elevation=-0.3,
                azimuth=1.57,
            ),
        )
        mediapy.write_video(
            video,
            np.concatenate((np.asarray(close), np.asarray(overview)), axis=2),
            fps=1 / (trial.budget.dt * stride),
        )
        return video, plot


class Row(NamedTuple):
    """A design of the report with its number, phase and measurements."""

    number: int
    stage: str
    design: Evaluation
    trials: list[Trial]
    cases: tuple[tuple[int, int], ...]

    @property
    def label(self) -> str:
        incomplete = "" if len(self.trials) == len(self.cases) else ", incomplete"
        return (
            f"{self.design.name} #{self.number} "
            f"({self.design.budget.horizon:g} s{incomplete})"
        )


def rows(summary: Summary) -> list[Row]:
    """Training designs then held-out designs, numbered in that order."""
    config = summary.search.config
    training = [
        Row(n, "training", e, measured(summary.search.trials, e), config.training_cases)
        for n, e in enumerate(summary.search.evaluations)
    ]
    if isinstance(summary, CoDesignSummary):
        for design in summary.held_out:
            if not any(row.design.key == design.key for row in training):
                training.append(
                    Row(
                        len(training),
                        "training",
                        design,
                        measured(summary.training_controls, design),
                        config.training_cases,
                    )
                )
    return training + [
        Row(
            len(training) + n,
            "held-out",
            e,
            measured(summary.trials, e),
            config.evaluation_cases,
        )
        for n, e in enumerate(summary.held_out)
    ]


def _display_comparison(
    summary: Summary,
    groups: list[Row],
    *,
    title: str,
    filename: str,
) -> None:
    """Compare methods within targets, keeping controller repeats as observations."""
    display(Markdown(f"### {title}"))
    config = summary.search.config
    if not groups:
        display(Markdown("No completed trials."))
        return
    display(
        Markdown(
            "Physical angle measurements use the recorded pose timestamp and do not depend on the planning loss."
        )
    )
    targets = sorted({t.seed for row in groups for t in row.trials})
    if isinstance(config, (MorphologyStudyConfig, CoDesignStudyConfig)):
        reference_robot = config.base
        reference_loss = (
            config.initial_loss
            if isinstance(config, CoDesignStudyConfig)
            else selected_hand(summary.search).loss
        )
        reference_label = "starting pair"
    else:
        reference_robot = stock_robot
        reference_loss = sparse_loss
        reference_label = "sparse"
    reference_rows = {
        row.number
        for row in groups
        if robot_adapter.dump_json(row.design.robot)
        == robot_adapter.dump_json(reference_robot)
        and loss_adapter.dump_json(row.design.loss)
        == loss_adapter.dump_json(reference_loss)
    }
    baselines = {
        (t.budget.model_dump_json(), t.seed, t.controller_seed): t.measurements
        for row in groups
        if row.number in reference_rows
        for t in row.trials
        if t.budget == config.budget.model_copy(update={"horizon": t.budget.horizon})
    }
    table = [
        f"| Target | Method (MPC horizon) | Final recorded error to target Δθ (deg), mean ± SD | Episode mean error to target (deg), mean ± SD | Drops | Succeeded vs {reference_label}: final | Succeeded vs {reference_label}: episode mean | Online s/episode, mean ± SD | Rollout steps/episode | Trial workers |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    fig, axes = plt.subplots(
        len(targets),
        3,
        figsize=(15, 3.8 * len(targets) + 0.6),
        squeeze=False,
        constrained_layout=True,
        gridspec_kw={"width_ratios": [1.7, 1.2, 1]},
    )
    fig.suptitle(title)
    tick_labels = [
        f"{row.design.name} #{row.number}\n{row.design.budget.horizon:g} s"
        for row in groups
    ]
    for target_index, target_seed in enumerate(targets):
        trajectory_ax, final_ax, drop_ax = axes[target_index]
        for method_index, row in enumerate(groups):
            repeats = [t for t in row.trials if t.seed == target_seed]
            if not repeats:
                continue
            matched = [
                (t.measurements, baselines[key])
                for t in repeats
                if row.number not in reference_rows
                and (key := (t.budget.model_dump_json(), t.seed, t.controller_seed))
                in baselines
            ]
            succeeded_counts = (
                sum(
                    not outcome.dropped
                    and outcome.orientation_final_deg < baseline.orientation_final_deg
                    for outcome, baseline in matched
                ),
                sum(
                    not outcome.dropped
                    and outcome.orientation_mean_deg < baseline.orientation_mean_deg
                    for outcome, baseline in matched
                ),
            )
            succeeded = [
                f"{count}/{len(matched)}" if matched else "n/a"
                for count in succeeded_counts
            ]
            metrics = [
                [t.measurements.orientation_final_deg for t in repeats],
                [t.measurements.orientation_mean_deg for t in repeats],
                [t.timing.total_s for t in repeats],
            ]
            means = [float(np.mean(values)) for values in metrics]
            deviations = [
                float(np.std(values, ddof=1)) if len(values) > 1 else None
                for values in metrics
            ]
            formatted = [
                f"{value:.2f} ± {sd:.2f}" if sd is not None else f"{value:.2f} (SD n/a)"
                for value, sd in zip(means, deviations)
            ]
            drops = sum(t.measurements.dropped for t in repeats)
            table.append(
                f"| {target_seed} | {row.label} | {formatted[0]} | {formatted[1]} | "
                f"{drops}/{len(repeats)} | {succeeded[0]} | {succeeded[1]} | "
                f"{formatted[2]} | "
                f"{np.mean([t.timing.simulated_steps for t in repeats]):,.0f} | "
                f"{', '.join(str(w) for w in sorted({t.trial_workers for t in repeats}))} |"
            )
            color = f"C{row.number % 10}"
            trajectories = []
            for trial in repeats:
                with np.load(config.output / Path(trial.series).name) as series:
                    times = series["t"]
                    trajectories.append(series["orientation_deg"])
            errors = np.stack(trajectories)
            mean_error = errors.mean(axis=0)
            trajectory_ax.plot(times, mean_error, color=color, label=row.label)
            if len(repeats) > 1:
                deviation = errors.std(axis=0, ddof=1)
                trajectory_ax.fill_between(
                    times,
                    mean_error - deviation,
                    mean_error + deviation,
                    color=color,
                    alpha=0.15,
                )
            bars = final_ax.bar(
                method_index,
                means[0],
                yerr=deviations[0],
                capsize=3,
                color=color,
            )
            if matched:
                final_ax.bar_label(
                    bars,
                    labels=[succeeded[0]],
                    padding=3,
                    fontsize=7,
                )
            bars = drop_ax.bar(method_index, drops, color=color)
            drop_ax.bar_label(bars, labels=[f"{drops}/{len(repeats)}"], padding=4)
        trajectory_ax.set(
            title=f"Target {target_seed}: error over time",
            xlabel="Recorded episode time (s)",
            ylabel="Angular error to target Δθ (degrees)",
            xlim=(0, config.budget.duration),
        )
        final_ax.set(
            title=f"Target {target_seed}: final recorded error\nBar labels: succeeded vs {reference_label}",
            ylabel="Error to target Δθ (degrees)",
        )
        final_ax.margins(y=0.2)
        drop_ax.set(
            ylabel="Dropped trials",
            title=f"Target {target_seed}: cube drops",
            ylim=(0, len(config.controller_seeds) + 0.6),
            yticks=range(len(config.controller_seeds) + 1),
        )
        for ax in (final_ax, drop_ax):
            ax.set_xticks(
                range(len(groups)), tick_labels, rotation=45, ha="right", fontsize=8
            )
        for ax in axes[target_index]:
            ax.set_ylim(bottom=0)
            ax.set_axisbelow(True)
            ax.grid(axis="y", alpha=0.2)
    handles_and_labels = {
        label: handle
        for ax in axes[:, 0]
        for handle, label in zip(*ax.get_legend_handles_labels())
    }
    fig.legend(
        list(handles_and_labels.values()),
        list(handles_and_labels),
        loc="outside lower center",
        ncols=min(4, len(groups)),
        fontsize=9,
        frameon=False,
    )
    path = config.output / filename
    fig.savefig(path, dpi=150)
    plt.close(fig)
    display(Image(filename=str(path), width=1200))
    display(Markdown("\n".join(table)))


def _display_representative_videos(summary: Summary, training: list[Row]) -> None:
    """Show the best training example with matched target and controller seeds."""
    display(Markdown("### Representative video comparison"))
    config = summary.search.config
    candidates = [row for row in training if row.trials]
    if not candidates or not config.render:
        display(Markdown("No rendered training trials are available."))
        return
    if isinstance(config, (MorphologyStudyConfig, CoDesignStudyConfig)):
        selected = (
            selected_pair(summary.search)
            if isinstance(config, CoDesignStudyConfig)
            else selected_hand(summary.search)
        )
        best = next(row for row in candidates if row.design.key == selected.key)
        base_key = Evaluation(
            robot=config.base,
            loss=config.initial_loss
            if isinstance(config, CoDesignStudyConfig)
            else selected.loss,
            budget=selected.budget,
        ).key
        baselines = [
            row
            for row in candidates
            if row.design.key == base_key and row.design.key != selected.key
        ]
        description = (
            "The example comes from the selected hand's best training repeat. "
            "The starting pair is shown under the same controller budget. "
            "Both videos use the same target and controller seed. "
            if baselines
            else "The starting hand was selected; showing its best training repeat. "
        )
    else:
        designed = [row for row in candidates if not row.design.is_baseline]
        best = min(designed or candidates, key=lambda row: ranking(row.trials))
        horizons = {best.design.budget.horizon, config.reference_horizon}
        baselines = [
            row
            for row in candidates
            if row.design.is_baseline and row.design.budget.horizon in horizons
        ]
        description = (
            "The example comes from the best tested designed method and its best "
            "training repeat, ranked by drops, final angular error "
            "and mean episode error. Baseline videos use the same target and controller "
            "seed. "
            if designed
            else "No designed method was measured. Showing a matched training example "
            "from the best tested sparse baseline. "
        )
    example = min(
        best.trials,
        key=lambda t: (
            t.measurements.dropped,
            t.measurements.orientation_final_deg,
            t.measurements.orientation_mean_deg,
        ),
    )
    display(
        Markdown(
            f"Target {example.seed}, controller seed {example.controller_seed}, "
            f"{config.budget.duration:g}-second episode for every method. "
            + description
            + "This is a selected illustration; the plots and tables above "
            "include every measured repeat."
        )
    )
    cards = []
    for row in [*baselines, best]:
        trial = next(t for t in row.trials if t.case == example.case)
        video_path, _ = render_trial(trial, config.output)
        video = Video(
            filename=str(video_path),
            embed=True,
            width=320,
        )
        outcome = trial.measurements
        label = row.label
        if isinstance(config, (MorphologyStudyConfig, CoDesignStudyConfig)):
            if row.design.key == best.design.key:
                role = (
                    "Starting hand (selected)"
                    if row.design.key == base_key
                    else "Selected hand"
                )
            else:
                role = "Starting hand"
            label = f"{role}: {label}"
        cards.append(
            '<div style="flex:1 1 320px;max-width:360px">'
            f"<h4>{escape(label)}</h4>"
            f"<p>Final recorded error to target: {outcome.orientation_final_deg:.2f}°; "
            f"dropped: {outcome.dropped}</p>"
            f"{video._repr_html_()}</div>"
        )
    display(
        HTML(
            '<div style="display:flex;flex-wrap:wrap;gap:16px">'
            + "".join(cards)
            + "</div>"
        )
    )


HIGHLIGHT = np.array([0.95, 0.15, 0.15, 1.0])
UNCHANGED = np.array([0.82, 0.82, 0.82, 1.0])
DESIGN_VIEWS = {
    "below": Camera(
        lookat=jnp.array([0.12, -0.04, 0.28]),
        distance=0.55,
        elevation=0.9,
        azimuth=1.57,
    ),
    "side": Camera(
        lookat=jnp.array([0.12, -0.04, 0.28]),
        distance=0.6,
        elevation=-0.55,
        azimuth=1.57,
    ),
}


def _robot_geoms(compiled: EnvSpec) -> set[int]:
    """Geoms owned by the robot's logical component graph, wrist included."""
    model = TypeAdapter(InstanceOf[LegacyComponent]).validate_python(compiled.model)
    return set(compiled.context.geom_ids(compiled.mj_model, model.robot))


def _render_design(
    compiled: EnvSpec, highlight: set[int], faint: set[int]
) -> dict[str, np.ndarray]:
    model = compiled.mj_model
    for geom in faint:
        model.geom_rgba[geom] = UNCHANGED
    for geom in highlight:
        model.geom_rgba[geom] = HIGHLIGHT
    trajectory = deepstack([compiled.init(rax.key(0))])
    return {
        view: np.asarray(
            render_trajectory(compiled, trajectory, max_frames=1, camera=camera)
        )[0]
        for view, camera in DESIGN_VIEWS.items()
    }


def display_hand_designs(summary: Summary) -> None:
    """Render every proposed hand next to the study's base hand, the
    primitive stock build when the base is the stock one.

    Parts a proposal changed are red and the rest of the robot is faint; a
    proposal with its own layout is shown whole. The grid is saved as
    ``hand-designs.png`` in the study's output directory; a study without
    proposed hands shows nothing.
    """
    config = summary.search.config
    proposals: dict[bytes, Evaluation] = {}
    for design in summary.search.evaluations:
        if not design.is_stock:
            proposals.setdefault(robot_adapter.dump_json(design.robot), design)
    if not proposals:
        return
    assert isinstance(config, (MorphologyStudyConfig, CoDesignStudyConfig))
    base = robot_adapter.dump_json(config.base)
    with ExitStack() as resources:
        reference = build_environment(
            config.base if not is_stock_hand(config.base) else primitive_stock,
            runner=partial(native_runner, resources=resources, nthread=1),
        )
        robot = _robot_geoms(reference)
        columns = [
            (
                "stock" if is_stock_hand(config.base) else config.base.__name__,
                _render_design(reference, set(), set()),
                ["reference"],
            )
        ]
    for key, design in proposals.items():
        with ExitStack() as resources:
            name = design.robot.__name__ + (" (base)" if key == base else "")
            candidate = build_environment(
                design.robot,
                runner=partial(native_runner, resources=resources, nthread=1),
            )
            if shares_layout(reference.mj_model, candidate.mj_model):
                changed, notes = design_differences(
                    reference.mj_model, candidate.mj_model
                )
                notes = notes or ["no compiled difference from the base"]
                frames = _render_design(candidate, changed, robot - changed)
            else:
                notes = ["own layout, shown whole"]
                frames = _render_design(candidate, set(), set())
            columns.append((name, frames, notes))
    fig, axes = plt.subplots(
        len(DESIGN_VIEWS),
        len(columns),
        figsize=(3.4 * len(columns), 3.0 * len(DESIGN_VIEWS)),
        squeeze=False,
    )
    for column, (name, frames, notes) in enumerate(columns):
        for row, view in enumerate(DESIGN_VIEWS):
            ax = axes[row, column]
            ax.imshow(frames[view])
            ax.set_xticks([])
            ax.set_yticks([])
            if row == 0:
                ax.set_title("\n".join([name, *notes]), fontsize=7)
            if column == 0:
                ax.set_ylabel(view, fontsize=11)
    fig.tight_layout()
    grid = config.output / "hand-designs.png"
    fig.savefig(grid, dpi=120)
    plt.close(fig)
    display(
        Markdown(
            "### Proposed hands\n\n"
            "Every hand the study measured, the base it started from included, "
            "next to the study's base hand, the stock hand built from the same "
            "primitives when the base is the stock one. Red marks the geoms a "
            "proposal resized or moved and the links of any actuator or joint it "
            "retuned; the rest of the robot is faint."
        )
    )
    display(Image(filename=str(grid)))


def _held_out_role(summary: Summary, chosen: Evaluation) -> str:
    """Label a held-out row as selected, base or stock reference.

    A hand study's selection is re-derived from its training rows the way the
    study made it; a loss study's held-out rows are all selections.
    """
    config = summary.search.config
    if isinstance(config, CoDesignStudyConfig):
        best = selected_pair(summary.search)
        hand_label = (
            "initial hand"
            if robot_adapter.dump_json(chosen.robot)
            == robot_adapter.dump_json(config.base)
            else "selected hand"
        )
        loss = (
            "initial loss"
            if loss_adapter.dump_json(chosen.loss)
            == loss_adapter.dump_json(config.initial_loss)
            else "selected loss"
        )
        return f"{hand_label}, {loss}" + (
            " (selected pair)" if chosen.key == best.key else ""
        )
    if not isinstance(config, MorphologyStudyConfig):
        return "selected"
    hand = robot_adapter.dump_json(chosen.robot)
    best = selected_hand(summary.search)
    if hand == robot_adapter.dump_json(best.robot):
        return "selected"
    if hand == robot_adapter.dump_json(config.base):
        return "base"
    return "stock reference"


def display_summary(summary: Summary) -> None:
    """Show target-wise method comparisons, selected losses and search outcomes."""
    config = summary.search.config
    cost = summary.search.cost
    display_hand_designs(summary)
    display(
        Markdown(
            f"Offline elapsed time: {cost.wall_s:.1f} s; "
            f"training rollout physics steps including warmup: {cost.rollout_steps:,}; "
            f"recorded model tokens: {cost.tokens:,} across {cost.model_calls} requests. "
            "Held-out evaluation is performed only after selection is frozen."
        )
    )
    display(
        Markdown(
            "Inspect individual requests and pricing in Langfuse. "
            "Setup, warmup and REPL inspection count toward the offline "
            "deadline; report rendering happens afterward. Online runtime excludes them. "
            f"The run currently permits {config.trial_workers} simultaneous trials, "
            f"each with {config.budget.nthread} rollout threads. "
            "The tables record the worker limit used for each trial. Online times "
            "include shared-host contention and are not isolated latency benchmarks."
        )
    )
    history = rows(summary)
    training = [row for row in history if row.stage == "training"]
    tested = [row for row in history if row.stage == "held-out"]
    _display_comparison(
        summary,
        [row for row in training if row.trials],
        title="Training targets: baselines and designed methods",
        filename="training-comparison.png",
    )
    evaluation = [row for row in tested if row.trials]
    _display_comparison(
        summary,
        evaluation,
        title="Held-out targets: frozen methods",
        filename="held-out-comparison.png",
    )
    if evaluation and all(row.design.is_baseline for row in evaluation):
        display(
            Markdown(
                "The recorded search selected sparse controllers, "
                "so held-out results contain sparse baselines only. "
                "Succeeded comparisons above report improvements independently of that selection."
            )
        )
    _display_representative_videos(summary, training)
    # Each row's number maps to the first row of the same loss source and of
    # the same hand source, so repeats and held-out rows point at the design
    # they re-measure.
    seen: dict[bytes, int] = {}
    first = {
        row.number: seen.setdefault(loss_adapter.dump_json(row.design.loss), row.number)
        for row in history
    }
    seen_hands: dict[bytes, int] = {}
    first_hand = {
        row.number: seen_hands.setdefault(
            robot_adapter.dump_json(row.design.robot), row.number
        )
        for row in history
    }
    for row in tested:
        chosen = row.design
        display(
            Markdown(
                f"### H={chosen.budget.horizon:g} s {_held_out_role(summary, chosen)}: "
                f"{chosen.name} "
                f"(evaluation {row.number}, loss of evaluation {first[row.number]}, "
                f"hand of evaluation {first_hand[row.number]})\n\n"
                f"Sampling: {chosen.budget.sampling.model_dump()}.\n\n"
            )
        )
        display(
            Code(chosen.model_dump(mode="json")["loss"]["code"], language="python"),
            include=["text/html"],
        )
        if not chosen.is_stock:
            display(
                Code(
                    chosen.model_dump(mode="json")["robot"]["code"], language="python"
                ),
                include=["text/html"],
            )
    display(Markdown("### Evaluation history"))
    lines = []
    for row in history:
        same = (
            "" if first[row.number] == row.number else f"evaluation {first[row.number]}"
        )
        same_hand = (
            ""
            if first_hand[row.number] == row.number
            else f"evaluation {first_hand[row.number]}"
        )
        outcome = " | | "
        if row.trials:
            final = np.mean([t.measurements.orientation_final_deg for t in row.trials])
            drops = sum(t.measurements.dropped for t in row.trials)
            outcome = f" {final:.2f} | {drops}/{len(row.trials)} "
        lines.append(
            f"| {row.number} | {row.stage} | {row.design.budget.horizon:g} s | {row.design.name} "
            f"| {same} | {same_hand} | {len(row.trials)}/{len(row.cases)} |{outcome}|"
        )
    display(
        Markdown(
            "Evaluations in the order they were measured. A held-out row re-measures "
            "the loss and hand of the training evaluations it names.\n\n"
            "| # | Stage | H | Design | Same loss as | Same hand as | Trials | Final error (deg), mean | Drops |\n"
            "|---:|---|---:|---|---|---|---:|---:|---:|\n" + "\n".join(lines)
        )
    )
    for row in history:
        design = row.design
        display(
            Markdown(
                f"#### Evaluation {row.number}: {design.name}, "
                f"{row.stage}, H={design.budget.horizon:g} s\n\n"
                f"Completed: {len(row.trials)}/{len(row.cases)} trials. "
                f"Episode: {design.budget.duration:g} s; "
                f"samples/rounds: {design.budget.batch_size}/{design.budget.rounds}.\n\n"
                "| Target | Controller seed | Final error (deg) | Episode mean error (deg) | Dropped |\n"
                "|---:|---:|---:|---:|---|\n"
                + "\n".join(
                    f"| {t.seed} | {t.controller_seed} "
                    f"| {t.measurements.orientation_final_deg:.2f} "
                    f"| {t.measurements.orientation_mean_deg:.2f} "
                    f"| {'yes' if t.measurements.dropped else 'no'} |"
                    for t in row.trials
                )
            )
        )
        if first[row.number] == row.number:
            display(
                Code(design.model_dump(mode="json")["loss"]["code"], language="python"),
                include=["text/html"],
            )
        else:
            display(Markdown(f"Loss source as evaluation {first[row.number]}."))
        if design.is_stock:
            continue
        if first_hand[row.number] == row.number:
            display(
                Code(
                    design.model_dump(mode="json")["robot"]["code"], language="python"
                ),
                include=["text/html"],
            )
        else:
            display(Markdown(f"Hand source as evaluation {first_hand[row.number]}."))


def display_artifacts(output: Path) -> None:
    """Embed downloads without repeating the comparison plots."""
    links = []
    for extension, mime in (("json", "application/json"), ("png", "image/png")):
        for path in sorted(output.glob(f"*.{extension}")):
            data = base64.b64encode(path.read_bytes()).decode("ascii")
            name = escape(path.name)
            links.append(
                f'<li><a download="{name}" href="data:{mime};base64,{data}">{name}</a></li>'
            )
    display(
        HTML(
            "<details><summary>Download embedded JSON and PNG records</summary><ul>"
            + "".join(links)
            + "</ul></details>"
        )
    )

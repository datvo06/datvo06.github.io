"""Supported stock-hand setup for the cube-orienting experiment."""

import re
from collections.abc import Callable, Sequence
from contextlib import ExitStack
from dataclasses import replace
from functools import partial

import effectful.handlers.jax.numpy as jnp
import jax
import mujoco
import numpy as np
import unxt
from effectful.ops.semantics import evaluate

from robotl.examples.cube_spinning import Cube, patch_cube
from robotl.examples.dynamixel import X430Model
from robotl.examples.hand_collision import (
    CUBE_BIT,
    FLOOR_BIT,
    PALM_BIT,
    apply_contact_response,
    assign_collision_masks,
    surface_masks,
)
from robotl.examples.hand_with_wrist import HandWithWrist
from robotl.examples.leap_hand_menagerie import (
    apply_hand_physics,
    setup_hand_collisions,
)
from robotl.examples.leap_hand_space import MenagerieDesign
from robotl.examples.open_parametric_hand import (
    CableDrive,
    OpenParametricHand,
    apply_oph_physics,
    setup_oph_collisions,
)
from robotl.handlers.mujoco import compile_model, view_model
from robotl.handlers.mujoco.compiler import check_internal_collisions
from robotl.handlers.mujoco.config import MujocoSettings
from robotl.handlers.mujoco.process import EnvSpec
from robotl.handlers.mujoco.render import Renderer
from robotl.handlers.mujoco.rollouts import JaxableThreadedRunner, Runner
from robotl.internals.utils import Colors
from robotl.ops import joints, sensors, shapes
from robotl.ops.coords import Angle, RawCoordinate, Rotation
from robotl.ops.losses import Loss, Minimize, Nullify
from robotl.ops.syntax import (
    Component,
    Inertia,
    LegacyComponent,
    Material,
    Origin,
    Port,
    Pose,
    assert_transform,
    defcomponent,
)
from robotl.ops.units import mm

X, Y, Z = jnp.eye(3)


def stock_robot() -> Component:
    """Build the menagerie hand with a damped two-axis wrist."""
    return HandWithWrist(MenagerieDesign.stock().build(), kp=20.0, kv=1.0)


def oph_robot() -> Component:
    """Build the XL430 tendon-driven OPH for the palm-up cube benchmark."""
    # local-import: the saved source replays in trial workers
    from robotl.examples.open_parametric_hand import OpenParametricHand
    from robotl.ops.units import volt

    return HandWithWrist(
        OpenParametricHand.make(motor_supply=volt(11.1)),
        radius=0.003,
        kp=20.0,
        kv=1.0,
    )


def oph_stretch_robot(
    *,
    use_meshes: bool = False,
    spatial_transmission: bool = False,
    motor_model: X430Model = "XL430-W250",
) -> Component:
    """Build the tendon-driven OPH on the source-derived Stretch wrist."""
    # local-import: the saved factory replays in trial workers.
    from robotl.examples.hand_with_wrist import StretchHandWithWrist
    from robotl.examples.open_parametric_hand import OpenParametricHand
    from robotl.examples.stretch_wrist import STRETCH_RE1_URDF
    from robotl.ops.units import mm, volt

    return StretchHandWithWrist.make(
        OpenParametricHand.make(
            motor_model=motor_model,
            motor_supply=volt(11.1),
            motor_backset=mm(12),
            spatial_transmission=spatial_transmission,
        ),
        STRETCH_RE1_URDF,
        palm_height=0.09 if spatial_transmission else 0.0755,
        use_meshes=use_meshes,
    )


def oph_power_grasp_robot(
    *,
    use_meshes: bool = False,
    motor_model: X430Model | tuple[X430Model, ...] = ("XM430-W350", "XL430-W250"),
    thumb_origin: unxt.AbstractQuantity = mm(np.array([140.0, -25.0, 45.0])),
    extra_drives: tuple[CableDrive, ...] = (),
) -> Component:
    """Build an OPH whose thumb opposes the fingers from beside their tips.

    The thumb sits on a printed palm strut; mixer 0 is a stronger XM430-W350
    and also pulls the middle, ring and little intermediate flexors, whose
    passive springs become driven cables.

    :param thumb_origin: Opposed thumb root in the palm frame.
    :param extra_drives: Cables to put on motors besides the middle, ring and
        little intermediate flexors on mixer 0; motors past the two mixers
        need a ``motor_model`` entry each.
    """
    # local-import: the saved factory replays in trial workers.
    from dataclasses import replace

    import jax.numpy as jnp

    from robotl.examples.hand_with_wrist import StretchHandWithWrist
    from robotl.examples.open_parametric_hand import (
        CableDrive,
        HandParams,
        OpenParametricHand,
    )
    from robotl.examples.stretch_wrist import STRETCH_RE1_URDF
    from robotl.ops.units import deg, mm, volt

    params = replace(
        HandParams(),
        origins_thumb=mm(
            jnp.stack(
                [
                    jnp.asarray(thumb_origin.to("mm").value),
                    jnp.array([-3.0, 5.5, -45.0]),
                ]
            )
        ),
        angles_thumb=deg(jnp.array([[0.0, 127.27922, 127.27922], [0.0, 100.0, 0.0]])),
    )
    return StretchHandWithWrist.make(
        OpenParametricHand.make(
            params=params,
            motor_model=motor_model,
            motor_supply=volt(11.1),
            motor_backset=mm(12),
            drives=(
                *(CableDrive(finger, "intermediate", 0) for finger in (1, 2, 3)),
                *extra_drives,
            ),
        ),
        STRETCH_RE1_URDF,
        palm_height=0.0755,
        use_meshes=use_meshes,
    )


def oph_two_thumb_robot(
    *,
    use_meshes: bool = False,
    motor_model: X430Model | tuple[X430Model, ...] = (
        "XL430-W250",
        "XL430-W250",
        "XM430-W350",
    ),
) -> Component:
    """Build an OPH with a thumb on each side of the finger row.

    Both thumbs root 57 mm along the fingers, one beyond the index and one
    beyond the little finger, angled toward each other; a third motor pulls
    both thumbs' flexor and intermediate cables, so the pair encloses the
    cube from both sides.
    """
    # local-import: the saved factory replays in trial workers.
    from dataclasses import replace

    import jax.numpy as jnp

    from robotl.examples.hand_with_wrist import StretchHandWithWrist
    from robotl.examples.open_parametric_hand import (
        CableDrive,
        HandParams,
        OpenParametricHand,
    )
    from robotl.examples.stretch_wrist import STRETCH_RE1_URDF
    from robotl.ops.units import deg, mm, volt

    params = replace(
        HandParams(),
        origins_thumb=mm(jnp.array([[57.0, 5.5, 15.0], [57.0, 5.5, -70.0]])),
        angles_thumb=deg(jnp.array([[0.0, -100.0, 0.0], [0.0, 100.0, 0.0]])),
    )
    return StretchHandWithWrist.make(
        OpenParametricHand.make(
            params=params,
            n_thumbs=2,
            motor_model=motor_model,
            motor_supply=volt(11.1),
            motor_backset=mm(12),
            drives=tuple(
                CableDrive(thumb, role, 2)
                for thumb in (4, 5)
                for role in ("flexor", "intermediate")
            ),
        ),
        STRETCH_RE1_URDF,
        palm_height=0.0755,
        use_meshes=use_meshes,
    )


def stubby_robot() -> Component:
    """A deliberately worse LEAP hand for a search to recover from.

    Every digit is 30% shorter and the thumb sits 50% further out. Imports
    stay inside the body so the saved source replays in a trial worker like
    a proposed hand.
    """
    from robotl.examples.leap_hand_menagerie import DigitDims, LeapHandConfig

    dims = DigitDims(widths=[1.0] * 5, lengths=[0.7] * 4)
    config = LeapHandConfig(
        finger_dims=dims, thumb_dims=dims, thumb_lateral=1.5, use_meshes=False
    )
    return HandWithWrist(MenagerieDesign(config=config).build(), kp=20.0, kv=1.0)


def primitive_stock() -> Component:
    """The stock hand from primitives: the layout every proposal built from
    ``MenagerieDesign`` with ``use_meshes=False`` shares, so reports compare
    models index by index. It mirrors ``stock_robot``, whose source text is the
    stock identity in saved studies and so keeps its own literals."""
    # Imported here so the saved source replays in a trial worker's decode
    # context, which holds only HandWithWrist and MenagerieDesign.
    from dataclasses import replace

    design = MenagerieDesign.stock()
    primitive = design.model_copy(
        update={"config": replace(design.config, use_meshes=False)}
    )
    return HandWithWrist(primitive.build(), kp=20.0, kv=1.0)


@defcomponent
def TargetCube(self):
    """Visual reference orientation with no mass or collision geometry."""
    self.shape = shapes.centered_cube(0.05, 0.05, 0.05)
    self.inertia = Inertia(mass=0.0, diag=jnp.zeros(3))
    self.disable_collision = True
    self.base = self.place(Port())
    self.material = Material(name="cube_faces_mat", friction=0.3)


@defcomponent
def CubeOrientingEnv(
    self, robot: Component, target_rotation=Rotation(rv=jnp.pi / 3 * Z)
):
    """Rotate a cube while retaining it in the hand.

    The compiled builder places the cube above the hand's collision surface
    and sets ``hold_position`` to that initial world position. Auxiliary
    losses can use this fixed position to guide retention during rotation.
    """
    self.shape = shapes.translate(shapes.plane(), [0, 0, -1 / 2])
    self.base = self.place(Port())
    self.robot = robot
    self.cube = Cube()
    robot_to_cube_pose = Pose(pos=[0, 0.1, 0.15])
    assert_transform(self.robot.base, self.cube, robot_to_cube_pose)
    self.hold_position = jnp.array([0.0, -0.15, 0.4])
    self.cube.color = Colors.olive
    self.reference = TargetCube()
    relative = ~self.reference.pose.rotational @ self.cube.pose.rotational
    self.orientation_error = sensors.Virtual(
        Angle(2 * jnp.arccos(jnp.clip(jnp.abs(relative.unit_quat[0]), 0, 1)))
    )
    self.hand_contact_data = sensors.subtree_contact_sensors(
        self.cube, self.robot.hand, capacity=32
    )
    self.floor_contact_data = sensors.Contact(self.cube, self, capacity=8)
    hand_contacts = jnp.concatenate(
        [
            sensor.get().x.reshape((sensor.capacity, 5))
            for sensor in self.hand_contact_data
        ],
        axis=0,
    )
    floor_contacts = jnp.reshape(self.floor_contact_data.get().x, (8, 5))
    self.cube_hand_contacts = sensors.Virtual(
        RawCoordinate(
            jnp.stack(
                [jnp.sum((hand_contacts[:, 0] > 0) & (hand_contacts[:, 1] > 1e-6))]
            )
        )
    )
    self.cube_floor_contact = sensors.Virtual(
        RawCoordinate(
            jnp.stack(
                [
                    jnp.any(
                        (floor_contacts[:, 0] > 0)
                        & ((floor_contacts[:, 1] > 1e-6) | (floor_contacts[:, 4] <= 0))
                    )
                ]
            )
        )
    )
    if isinstance(self.robot.hand, OpenParametricHand):
        self.mixer_angle_data = [
            sensors.Position(m.hinge) for m in self.robot.hand.motors
        ]
        self.wrist_angle_data = [sensors.Position(j) for j in self.robot.joints]
        self.mixer_angles = sensors.Virtual(
            RawCoordinate(
                jnp.stack([sensor.get().theta for sensor in self.mixer_angle_data])
            )
        )
        self.wrist_angles = sensors.Virtual(
            RawCoordinate(
                jnp.stack([sensor.get().theta for sensor in self.wrist_angle_data])
            )
        )
        contact_loads = []
        for sensor in self.hand_contact_data:
            values = sensor.get().x.reshape((sensor.capacity, 5))
            contact_loads.append(
                (
                    sensor.second_id,
                    jnp.sum(
                        jnp.where(values[:, 0] > 0, jnp.maximum(values[:, 1], 0), 0)
                    ),
                )
            )

        def load_for(digits: Sequence[Component]) -> jax.Array:
            bodies = {part.id for digit in digits for part in digit.components()}
            load = jnp.asarray(0.0)
            for body, normal_load in contact_loads:
                if body in bodies:
                    load = load + normal_load
            return load

        loads = [
            load_for(digits)
            for digits in (self.robot.hand.thumbs, self.robot.hand.fingers)
        ]
        self.digit_loads = sensors.Virtual(RawCoordinate(jnp.stack(loads)))
        # Match CableDrive digit numbering: fingers, then thumbs; loads are in N.
        self.per_digit_loads = sensors.Virtual(
            RawCoordinate(
                jnp.stack(
                    [
                        load_for((digit,))
                        for digit in (*self.robot.hand.fingers, *self.robot.hand.thumbs)
                    ]
                )
            )
        )
    # OPH flexion is toward local -Y; the menagerie grasp face is local +Y.
    mount_angle = (
        -jnp.pi / 2 if isinstance(self.robot.hand, OpenParametricHand) else jnp.pi / 2
    )
    self._welds = [
        joints.Weld(Origin.base, self.base),
        joints.Weld(self.base, self.robot.base, Pose(pos=0.3 * Z, rv=mount_angle * X)),
        joints.Weld(
            self.base,
            self.reference.base,
            Pose(pos=[0.3, 0, 0.15], rot=target_rotation),
        ),
    ]
    self.losses = sparse_loss(self)


def sparse_loss(env: LegacyComponent) -> dict[str, Loss]:
    """Penalize target orientation error and contact with the floor."""
    return dict(
        orientation=Nullify(
            (~env.reference.pose.rotational @ env.cube.pose.rotational).rv
        ),
        drop=Minimize(
            jnp.where(
                env.cube.pos[2] - 0.025 * jnp.sum(jnp.abs(env.cube.axes[:, 2])) <= -0.5,
                20.0,
                0.0,
            )
        ),
    )


def staged_grasp_loss(env: LegacyComponent) -> dict[str, Loss]:
    """Reactively prioritize mixer closure and digit support before orientation.

    This transfers the Panda stage-target strategy, not its host-side dwell
    controller or opposed-normal support certification. Loss of support returns
    to closure. The placement anchor is bound after ``build_environment``.
    """
    # local-import: the loss factory replays in isolated trial workers.
    import effectful.handlers.jax.numpy as jnp

    from experiments.cube_orienting.environment import sparse_loss
    from robotl.ops.losses import Minimize

    angles = env.mixer_angles.get().x
    loads = env.digit_loads.get().x
    offset = env.cube.pos - env.hold_position
    supported = (
        jnp.all(angles >= 0.45)
        & jnp.all(loads >= 0.1)
        & (jnp.sum(offset**2) <= 0.04**2)
        & (env.cube_floor_contact.get().x[0] == 0)
    )
    terms = sparse_loss(env)
    return {
        "orientation": Minimize(
            jnp.where(supported, env.orientation_error.get().theta, jnp.pi)
        ),
        "closure": Minimize(
            jnp.where(supported, 1.0, 20.0) * jnp.sum((angles - 0.8) ** 2)
        ),
        "digit_support": Minimize(10.0 * jnp.sum(jnp.maximum(0.1 - loads, 0.0) ** 2)),
        "hold": Minimize(400.0 * jnp.sum(offset**2)),
        "wrist_capture": Minimize(
            jnp.where(supported, 0.0, 10.0) * jnp.sum(env.wrist_angles.get().x ** 2)
        ),
        "drop": terms["drop"],
    }


def hand_relative_supported_loss(env: LegacyComponent) -> dict[str, Loss]:
    """Gate orientation on digit support, holding the cube near the knuckles.

    ``staged_grasp_loss`` measures the hold from the cube's starting
    position, so a closing grip that pulls the cube more than 4 cm keeps
    orientation off; this measures it from the mean finger metacarpal tip
    instead and lets the captured cube travel with the hand.
    """
    # local-import: the loss factory replays in isolated trial workers.
    import effectful.handlers.jax.numpy as jnp

    from robotl.ops.losses import Minimize

    angles = env.mixer_angles.get().x
    loads = env.digit_loads.get().x
    knuckles = jnp.mean(
        jnp.stack([finger.bones[0].tip.pos for finger in env.robot.hand.fingers]),
        axis=0,
    )
    distance2 = jnp.sum((env.cube.pos - knuckles) ** 2)
    supported = jnp.all(loads >= 0.1) & (env.cube_floor_contact.get().x[0] == 0)
    return {
        "orientation": Minimize(
            jnp.where(supported, 8.0 * env.orientation_error.get().theta, 8.0 * jnp.pi)
        ),
        "closure": Minimize(4.0 * jnp.sum((angles - 0.7) ** 2)),
        "digit_support": Minimize(50.0 * jnp.sum(jnp.maximum(0.2 - loads, 0.0) ** 2)),
        "hold": Minimize(1000.0 * jnp.maximum(distance2 - 0.06**2, 0.0)),
        "wrist_capture": Minimize(
            jnp.where(supported, 0.0, 1.0) * jnp.sum(env.wrist_angles.get().x ** 2)
        ),
        "drop": Minimize(100.0 * env.cube_floor_contact.get().x[0]),
    }


def firm_supported_loss(env: LegacyComponent) -> dict[str, Loss]:
    """``hand_relative_supported_loss`` with a firmer grip: closure weighs 20
    instead of 4, and each digit group is pushed toward 0.5 N of support
    instead of 0.2 N."""
    # local-import: the loss factory replays in isolated trial workers.
    import effectful.handlers.jax.numpy as jnp

    from experiments.cube_orienting.environment import hand_relative_supported_loss
    from robotl.ops.losses import Minimize

    angles = env.mixer_angles.get().x
    loads = env.digit_loads.get().x
    return {
        **hand_relative_supported_loss(env),
        "closure": Minimize(20.0 * jnp.sum((angles - 0.7) ** 2)),
        "digit_support": Minimize(50.0 * jnp.sum(jnp.maximum(0.5 - loads, 0.0) ** 2)),
    }


def held_cube_loss(env: LegacyComponent) -> dict[str, Loss]:
    """Turn the cube whenever the hand holds it, without waiting on the thumbs.

    ``hand_relative_supported_loss`` counts orientation only while the thumbs
    and the fingers each push at least 0.1 N in total; a cube held without
    thumb load keeps its orientation term at the ceiling. Here any hand contact with the cube
    off the floor and within 6 cm of the knuckles counts as held; digit
    support stays a separate soft term.
    """
    # local-import: the loss factory replays in isolated trial workers.
    import effectful.handlers.jax.numpy as jnp

    from robotl.ops.losses import Minimize

    angles = env.mixer_angles.get().x
    loads = env.digit_loads.get().x
    knuckles = jnp.mean(
        jnp.stack([finger.bones[0].tip.pos for finger in env.robot.hand.fingers]),
        axis=0,
    )
    distance2 = jnp.sum((env.cube.pos - knuckles) ** 2)
    off_floor = env.cube_floor_contact.get().x[0] == 0
    held = (env.cube_hand_contacts.get().x[0] > 0) & off_floor & (distance2 < 0.06**2)
    return {
        "orientation": Minimize(
            jnp.where(held, 8.0 * env.orientation_error.get().theta, 8.0 * jnp.pi)
        ),
        "closure": Minimize(4.0 * jnp.sum((angles - 0.7) ** 2)),
        "digit_support": Minimize(50.0 * jnp.sum(jnp.maximum(0.2 - loads, 0.0) ** 2)),
        "hold": Minimize(1000.0 * jnp.maximum(distance2 - 0.06**2, 0.0)),
        "wrist_capture": Minimize(
            jnp.where(held, 0.0, 1.0) * jnp.sum(env.wrist_angles.get().x ** 2)
        ),
        "drop": Minimize(100.0 * env.cube_floor_contact.get().x[0]),
    }


def _menagerie_layout(mj_model: mujoco.MjModel, geoms: list[int]) -> bool:
    """Whether the logical hand geometry carries menagerie body naming.

    The menagerie hand is a ``defcomponent`` build with no class of its own;
    its identity is the ``seg`` body naming its collision helpers classify.
    """
    return any(
        re.search(
            r"(fingers_\d+|thumb)_seg\d+",
            mj_model.body(int(mj_model.geom_bodyid[geom])).name,
        )
        for geom in geoms
    )


def shares_layout(reference: mujoco.MjModel, model: mujoco.MjModel) -> bool:
    """Whether the two models' bodies, geoms, joints and actuators pair by index.

    A hand that adds a finger or turns meshes on has its own layout and can
    only be compared whole.
    """
    return all(
        np.array_equal(getattr(reference, field), getattr(model, field))
        for field in (
            "geom_bodyid",
            "geom_type",
            "body_parentid",
            "jnt_bodyid",
            "dof_jntid",
            "actuator_trnid",
            "actuator_trntype",
        )
    )


# Derived subtree quantities and presentation data do not define hardware.
NON_DESIGN_FIELDS = frozenset(
    {
        "body_subtreemass",
        "body_invweight0",
        "dof_invweight0",
        "dof_M0",
        "actuator_acc0",
        "actuator_length0",
        "actuator_lengthrange",
        "geom_rgba",
        "geom_matid",
        "geom_group",
    }
)


def design_differences(
    reference: mujoco.MjModel, model: mujoco.MjModel
) -> tuple[set[int], list[str]]:
    """Geoms a design changed against the reference, with one note per kind.

    Physical fields MuJoCo indexes by geom, body, joint, dof or actuator are
    compared, floats within a tolerance and integers exactly; fields of sites,
    tendons and constraints are not. A changed geom marks itself; a changed
    body, joint, dof or actuator marks the geoms of the body it belongs to or
    drives. Both models must share the reference layout, since parts pair by
    index. An identical design yields no geoms and no notes.
    """
    if not shares_layout(reference, model):
        raise ValueError("model does not share the reference layout")
    counts = {
        "geom": model.ngeom,
        "body": model.nbody,
        "jnt": model.njnt,
        "dof": model.nv,
        "actuator": model.nu,
    }
    geoms: set[int] = set()
    notes: list[str] = []
    for kind, count in counts.items():
        changed = np.zeros(count, dtype=bool)
        fields = []
        for field in dir(model):
            if not field.startswith(f"{kind}_") or field in NON_DESIGN_FIELDS:
                continue
            ours = getattr(reference, field)
            if (
                not isinstance(ours, np.ndarray)
                or ours.dtype.kind not in "fiu"
                or ours.shape[:1] != (count,)
                or ours.size == 0
            ):
                continue
            theirs = getattr(model, field)
            if ours.dtype.kind == "f":
                gap = np.abs(ours - theirs).reshape(count, -1)
                differs = gap.max(axis=1) > 1e-6
            else:
                differs = (ours != theirs).reshape(count, -1).any(axis=1)
            if differs.any():
                changed |= differs
                fields.append(field.removeprefix(f"{kind}_"))
        if changed.any():
            for index in np.flatnonzero(changed):
                geoms |= _owned_geoms(model, kind, int(index))
            notes.append(f"{int(changed.sum())} {kind} changed: {', '.join(fields)}")
    return geoms, notes


def _owned_geoms(model: mujoco.MjModel, kind: str, index: int) -> set[int]:
    """The geoms a changed part of ``kind`` shows up on."""
    if kind == "geom":
        return {index}
    if kind == "body":
        body = index
    elif kind == "jnt":
        body = int(model.jnt_bodyid[index])
    elif kind == "dof":
        body = int(model.jnt_bodyid[model.dof_jntid[index]])
    else:
        if model.actuator_trntype[index] != mujoco.mjtTrn.mjTRN_JOINT:
            raise ValueError(f"actuator {index} does not drive a joint")
        body = int(model.jnt_bodyid[model.actuator_trnid[index, 0]])
    return {g for g in range(model.ngeom) if model.geom_bodyid[g] == body}


def same_design(reference: mujoco.MjModel, model: mujoco.MjModel) -> bool:
    """Whether a compiled hand is the reference hand part for part."""
    return (
        shares_layout(reference, model) and not design_differences(reference, model)[1]
    )


def native_runner(
    spec: EnvSpec, *, resources: ExitStack, nthread: int
) -> JaxableThreadedRunner:
    """Create a native runner whose effects and resources share one lifetime."""
    renderer = resources.enter_context(Renderer.make(spec, workers=1))
    runner = JaxableThreadedRunner.make(spec, nthread=nthread, renderer=renderer)
    resources.callback(runner.pool.manager.close)
    resources.callback(jax.effects_barrier)
    return runner


def build_environment(
    robot: Callable[[], Component] = stock_robot,
    *,
    target_rotation: Rotation = Rotation(rv=jnp.pi / 3 * Z),
    sim_preset: str = "standard",
    dt: float | None = None,
    runner: Callable[[EnvSpec], Runner] = partial(
        JaxableThreadedRunner.make, nthread=0
    ),
    check: bool = False,
) -> EnvSpec:
    """Compile the selected robot and place the cube on its collision surface."""
    presets = {
        "standard": MujocoSettings.standard,
        "fast": MujocoSettings.fast,
        "precise": MujocoSettings.precise,
    }
    if sim_preset not in presets:
        raise ValueError(f"unknown sim_preset {sim_preset!r}; choose {tuple(presets)}")
    settings = presets[sim_preset]()
    if dt is not None:
        if dt <= 0:
            raise ValueError("dt must be positive")
        settings = replace(settings, dt=dt)
    model, context, mj_model = compile_model(
        lambda: CubeOrientingEnv(
            robot(),
            target_rotation=target_rotation,
        ),
        settings=settings,
        memory=100 * 1024 * 1024,
    )
    hand_info = context.components[model.robot.hand.id]
    hand_obj = hand_info.object
    hand_geoms = context.geom_ids(mj_model, hand_obj)
    if isinstance(hand_obj, OpenParametricHand):
        cube_geoms = context.geom_ids(mj_model, model.cube)
        scene_geoms = cube_geoms + list(
            np.flatnonzero(mj_model.geom_type == int(mujoco.mjtGeom.mjGEOM_PLANE))
        )
        palm_geoms: list[int] = []
        support_geoms: list[int] = []
        if hand_obj.routing_guides:
            palm_geoms = [
                geom
                for geom in context.geom_ids(mj_model, hand_obj.palm)
                if int(mj_model.geom_group[geom]) != 1
                and (mj_model.geom_contype[geom] or mj_model.geom_conaffinity[geom])
            ]
            support_geoms = [
                geom
                for part in hand_obj.routing_guides
                for geom in context.geom_ids(mj_model, part)
                if int(mj_model.geom_group[geom]) != 1
                and (mj_model.geom_contype[geom] or mj_model.geom_conaffinity[geom])
            ]
        setup_oph_collisions(mj_model, hand_geoms + scene_geoms)
        if hand_obj.routing_guides:
            digit_bits = int(mj_model.geom_conaffinity[cube_geoms[0]]) & ~(
                CUBE_BIT | FLOOR_BIT | PALM_BIT
            )
            masks = surface_masks(PALM_BIT, digit_bits)
            assign_collision_masks(
                mj_model,
                "oph spatial supports",
                lambda geom: ("structure", masks),
                geoms=palm_geoms + support_geoms,
            )
        apply_oph_physics(mj_model, hand_geoms)
        if hand_obj.routing_guides:
            apply_contact_response(mj_model, set(), set(palm_geoms), geoms=palm_geoms)
    elif _menagerie_layout(mj_model, hand_geoms):
        setup_hand_collisions(mj_model)
        apply_hand_physics(mj_model)
    else:
        raise ValueError(
            f"no collision setup for the hand family {type(hand_obj).__name__}"
        )
    patch_cube(mj_model)
    settings.apply(mj_model)
    data = mujoco.MjData(mj_model)
    mujoco.mj_forward(mj_model, data)
    cube = context.components[model.cube.id].idx
    hand_geoms = [
        geom
        for geom in hand_geoms
        if mj_model.geom_contype[geom] or mj_model.geom_conaffinity[geom]
    ]
    if not hand_geoms:
        raise ValueError("the hand has no collision surface")
    spec = EnvSpec.make(model, context, mj_model, runner=runner)
    initial = spec.init(jax.random.key(0))
    tips = np.asarray(
        [evaluate(tip.pos, intp=spec.intp(initial)) for tip in model.robot.fingertips]
    )
    position = tips.mean(axis=0)
    cube_geom = np.flatnonzero(mj_model.geom_bodyid == cube)[0]
    cube_half_extent = (
        np.abs(data.geom_xmat[cube_geom].reshape(3, 3))
        @ mj_model.geom_aabb[cube_geom, 3:]
    )
    rotations = data.geom_xmat[hand_geoms].reshape(-1, 3, 3)
    aabbs = mj_model.geom_aabb[hand_geoms]
    centers = data.geom_xpos[hand_geoms] + np.einsum(
        "nij,nj->ni", rotations, aabbs[:, :3]
    )
    half_extents = np.einsum("nij,nj->ni", np.abs(rotations), aabbs[:, 3:])
    ray_height = (centers + half_extents)[:, 2].max() + 0.1
    down = np.array([0.0, 0.0, -1.0])
    hits = []
    for x in np.linspace(-cube_half_extent[0], cube_half_extent[0], 5):
        for y in np.linspace(-cube_half_extent[1], cube_half_extent[1], 5):
            ray_start = np.array([position[0] + x, position[1] + y, ray_height])
            for geom in hand_geoms:
                if mj_model.geom_type[geom] == mujoco.mjtGeom.mjGEOM_MESH:
                    distance = mujoco.mj_rayMesh(mj_model, data, geom, ray_start, down)
                else:
                    distance = mujoco.mju_rayGeom(
                        data.geom_xpos[geom],
                        data.geom_xmat[geom],
                        mj_model.geom_size[geom],
                        ray_start,
                        down,
                        int(mj_model.geom_type[geom]),
                    )
                if distance >= 0:
                    hits.append(distance)
    if not hits:
        raise ValueError("the fingertip center has no supporting collision surface")
    position[2] = ray_height - min(hits) + cube_half_extent[2] + 0.002
    address = mj_model.jnt_qposadr[mj_model.body_jntadr[cube]]
    mj_model.qpos0[address : address + 3] = position
    model.hold_position = jnp.asarray(position)
    if check:
        check_internal_collisions(
            mj_model,
            bodies={
                context.components[part.id].idx for part in model.robot.components()
            },
        )
    return spec


if __name__ == "__main__":
    view_model(lambda: CubeOrientingEnv(stock_robot()))

"""The command line of the study entry points."""

import argparse
import os
from pathlib import Path


def study_arguments(description: str) -> tuple[Path, int | None]:
    """The study path and worker override from the command line.

    Langfuse credentials must be present and tracing enabled before any
    checkpoint is created.
    """
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument(
        "study", type=Path, help="New configuration JSON or saved run directory"
    )
    parser.add_argument("--trial-workers", type=int)
    args = parser.parse_args()
    for key in ("LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY"):
        if not os.environ.get(key):
            raise RuntimeError(f"{key} is required")
    if (
        os.environ.get("LANGFUSE_TRACING_ENABLED", "true").lower() == "false"
        or os.environ.get("OTEL_SDK_DISABLED", "false").lower() == "true"
    ):
        raise RuntimeError("Langfuse tracing must be enabled")
    return args.study, args.trial_workers

"""An iterative agent search: its settings, records, trial runner and evaluator.

A task instantiates these with its own protocol: how one trial runs, how its
measurements compare, and which saved factories a record may reference. The
search process, the allowance accounting, the worker pool, the checkpoints
and the proposal rules, is the same for every task.
"""

import abc
import dataclasses
import hashlib
import inspect
import json
import math
import shutil
import time
import traceback
from collections import Counter
from collections.abc import Callable, Iterable
from multiprocessing import get_context
from multiprocessing.connection import Connection, wait
from multiprocessing.process import BaseProcess
from pathlib import Path
from typing import Annotated, Any, Literal, Protocol

import langfuse
import pydantic
from effectful.handlers.llm import Encodable
from effectful.handlers.llm.harness import harness
from effectful.handlers.llm.harness.execution.builtin import BuiltinExecutor
from effectful.ops.semantics import fwd, handler
from litellm import ModelResponse
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    InstanceOf,
    PlainSerializer,
    model_validator,
)

from robotl.examples.loss_designer import CheckedLossFn, LossFn, probe_env
from robotl.handlers.mujoco.process import EnvProcess
from robotl.ops.syntax import Component

loss_adapter: pydantic.TypeAdapter[LossFn] = pydantic.TypeAdapter(Encodable[LossFn])

RobotFn = Callable[[], Component]
"""A robot factory: the whole robot the environment mounts."""

robot_adapter: pydantic.TypeAdapter[RobotFn] = pydantic.TypeAdapter(Encodable[RobotFn])


class SearchConfig(BaseModel):
    """The model, its allowances, the trial grid and the run location of a search.

    A task's own settings, such as the controller budget it measures with,
    are layered on top by subclassing. Training cases pair each training
    target with each controller seed; the held-out cases do the same for the
    evaluation targets.
    """

    model_config = ConfigDict(
        frozen=True, allow_inf_nan=False, extra="forbid", ser_json_inf_nan="constants"
    )
    output: Path
    model: str = "gpt-5.4"
    reasoning_effort: Literal["low", "medium", "high", "xhigh", "max"] | None = None
    # Checks the agent's REPL code and returned factories before they run.
    type_checker: Literal["mypy", "ty"] = "ty"
    training_targets: tuple[int, ...] = (0, 5)
    evaluation_targets: tuple[int, ...] = (1, 2)
    controller_seeds: tuple[int, ...] = (11, 22, 33)
    # Distinct valid designs the agent may have measured.
    proposals: int = Field(default=6, ge=1)
    trial_workers: int = Field(default=1, ge=1)
    # Infinite by default: the search ends on proposals or rollout work alone.
    max_wall_s: float = Field(default=math.inf, gt=0, allow_inf_nan=True)
    max_rollout_steps: int = Field(default=1_000_000_000, gt=0)
    max_completion_tokens: int = Field(default=8192, gt=0)
    model_timeout_s: float = Field(default=300, gt=0)
    render_agent: bool = False

    @property
    def training_cases(self) -> tuple[tuple[int, int], ...]:
        return tuple(
            (t, c) for t in self.training_targets for c in self.controller_seeds
        )

    @property
    def evaluation_cases(self) -> tuple[tuple[int, int], ...]:
        return tuple(
            (t, c) for t in self.evaluation_targets for c in self.controller_seeds
        )

    @model_validator(mode="after")
    def _disjoint_trials(self) -> "SearchConfig":
        if not self.training_targets or not self.evaluation_targets:
            raise ValueError("training and evaluation targets must be nonempty")
        targets = self.training_targets + self.evaluation_targets
        if len(set(targets)) != len(targets):
            raise ValueError("training and evaluation targets must be distinct")
        if not self.controller_seeds or len(set(self.controller_seeds)) != len(
            self.controller_seeds
        ):
            raise ValueError("controller seeds must be nonempty and distinct")
        if any(s < 0 for s in (*targets, *self.controller_seeds)):
            raise ValueError("random seeds must be non-negative")
        return self


class SearchLimitReached(RuntimeError):
    """A host-owned allowance has been exhausted."""


class ProposalAllowanceExhausted(ValueError):
    """A new design was requested after the study's proposals were all spent."""


class Timing(BaseModel):
    """Online wall time and actual rollout work, excluding warmup and rendering."""

    total_s: float
    compile_s: float
    build_s: float
    per_step_ms: float
    rollout_batches: int
    candidate_rollouts: int
    simulated_steps: int
    warmup_simulated_steps: int
    episode_steps: int
    replans: int


@dataclasses.dataclass
class CountedRollouts:
    """Acknowledge and count work at the native rollout dispatch boundary."""

    report_work: Callable[[int], None]
    batches: int = 0
    candidates: int = 0
    steps: int = 0

    def __call__(self, batch: int, length: int) -> None:
        work = batch * length
        self.report_work(work)
        self.batches += 1
        self.candidates += batch
        self.steps += work


def _design_key[Settings: BaseModel](
    loss: LossFn, robot: RobotFn, budget: Settings
) -> tuple[bytes, bytes, Settings]:
    return (loss_adapter.dump_json(loss), robot_adapter.dump_json(robot), budget)


class Trial[Settings: BaseModel, Measurements](BaseModel):
    """A completed episode with its outcome, compute cost and artifacts.

    ``Settings`` is what the task measured under, such as an MPC budget, and
    ``Measurements`` the physical outcome it recorded.
    """

    model_config = ConfigDict(extra="forbid")

    stage: str
    seed: int
    controller_seed: int
    budget: Settings
    measurements: Measurements
    timing: Timing
    loss: Encodable[LossFn]
    robot: Encodable[RobotFn]
    series: str
    trial_workers: int = 1

    @property
    def key(self) -> tuple[bytes, bytes, Settings]:
        """The design this trial measured, as :attr:`Evaluation.key` spells it."""
        return _design_key(self.loss, self.robot, self.budget)

    @property
    def case(self) -> tuple[int, int]:
        return (self.seed, self.controller_seed)


class Evaluation[Settings: BaseModel](BaseModel):
    """A design: the two factories a search may vary and the settings it ran under.

    A task holds the axis it does not search fixed. Which cases a design was
    measured on follows from the list that holds it: a search's training
    cases or a summary's held-out cases.
    """

    loss: Encodable[LossFn]
    robot: Encodable[RobotFn]
    budget: Settings

    @property
    def name(self) -> str:
        """The factories' function names, which is how the agent named its design."""
        return f"{self.robot.__name__} / {self.loss.__name__}"

    @property
    def key(self) -> tuple[bytes, bytes, Settings]:
        """What the reuse lookup compares."""
        return _design_key(self.loss, self.robot, self.budget)

    @property
    def stage(self) -> str:
        """The stem of this design's trial files, the same in every run that measures it.

        The digest covers the saved JSON of the two factories and the budget
        in canonical form, so any JSON tool can rebuild it from a record.
        """
        loss, robot, budget = self.key
        canonical = json.dumps(
            [json.loads(loss), json.loads(robot), budget.model_dump(mode="json")],
            sort_keys=True,
            separators=(",", ":"),
        )
        digest = hashlib.sha256(canonical.encode()).hexdigest()[:12]
        return f"evaluation-{digest}"


def measured[T: Trial[Any, Any]](trials: list[T], design: Evaluation[Any]) -> list[T]:
    """The trials of one design, in the order they were run."""
    key = design.key
    return [t for t in trials if t.key == key]


def save_record(record: BaseModel, path: Path) -> None:
    """Write through a sibling temporary file, so an interrupted run never
    leaves a truncated record for a resume to read."""
    temporary = path.with_suffix(".tmp")
    temporary.write_text(record.model_dump_json(indent=2))
    temporary.replace(path)


class SearchCost(BaseModel):
    """Compute spent on synthesis and training evaluations."""

    started_at: float = Field(default_factory=time.time)
    wall_s: float = 0
    rollout_steps: int = 0
    model_calls: int = 0
    tokens: int = 0

    def remaining_time(self, max_wall_s: float) -> float:
        """Return the deadline remaining, including while paid work finishes."""
        remaining = max_wall_s - (time.time() - self.started_at)
        if remaining <= 0:
            raise SearchLimitReached("wall-clock allowance exhausted")
        return remaining

    def remaining(self, max_wall_s: float, max_rollout_steps: int) -> float:
        """Refuse new work when either compute allowance is exhausted."""
        remaining = self.remaining_time(max_wall_s)
        if self.rollout_steps >= max_rollout_steps:
            raise SearchLimitReached("rollout work allowance exhausted")
        return remaining

    def charge(self, steps: int, max_wall_s: float, max_rollout_steps: int) -> None:
        """Charge physics work before dispatch."""
        self.remaining(max_wall_s, max_rollout_steps)
        if self.rollout_steps + steps > max_rollout_steps:
            raise SearchLimitReached("rollout work allowance exhausted")
        self.rollout_steps += steps
        self.wall_s = time.time() - self.started_at


class Search[Config: SearchConfig, Ev: Evaluation[Any], T: Trial[Any, Any]](BaseModel):
    """Designs measured on every training case, their trials, and the compute spent.

    A design joins ``evaluations`` once all its training trials are in
    ``trials``, so every listed design is complete.
    """

    # The infinite default allowances must survive a JSON round trip.
    model_config = ConfigDict(extra="forbid", ser_json_inf_nan="constants")

    config: Config
    evaluations: list[Ev] = Field(default_factory=list)
    trials: list[T] = Field(default_factory=list)
    cost: SearchCost = Field(default_factory=SearchCost)

    def save(self) -> None:
        save_record(self, self.config.output / "search.json")

    def save_cost(self) -> None:
        save_record(self.cost, self.config.output / "cost.json")

    def record_cost(self) -> None:
        """Save the cost with the wall clock advanced; a render-only resume keeps it."""
        self.cost.wall_s = time.time() - self.cost.started_at
        self.save_cost()


class Summary[Config: SearchConfig, Ev: Evaluation[Any], T: Trial[Any, Any]](BaseModel):
    """A finished search and the designs its selection sent to the held-out cases.

    ``trials`` holds the held-out measurements; a design's training trials
    stay in ``search.trials``.
    """

    model_config = ConfigDict(extra="forbid", ser_json_inf_nan="constants")

    search: Search[Config, Ev, T]
    held_out: list[Ev]
    trials: list[T] = Field(default_factory=list)

    def save(self) -> None:
        save_record(self, self.search.config.output / "summary.json")


class Task[Config: SearchConfig, Ev: Evaluation[Any]](Protocol):
    """What a task gives the search process to measure designs.

    The search owns allowances, proposals, workers and checkpoints; the task
    owns what a trial is and which saved factories a record may reference.
    Each compatible case batch runs in a spawned worker,
    which receives the task and decodes the evaluation with
    ``decode_context`` before running it, so a task must pickle: an instance
    whose state is its class attributes does.
    """

    @property
    def decode_context(self) -> dict[str, object]:
        """Names a saved loss or robot source may use."""

    @property
    def evaluation_type(self) -> type[Ev]: ...

    @property
    def trial_type(self) -> type[Trial[Any, Any]]: ...

    def case_batches(
        self, cases: tuple[tuple[int, int], ...]
    ) -> tuple[tuple[tuple[int, int], ...], ...]:
        """Partition uncached cases into compatible execution batches."""

    def run_cases(
        self,
        evaluation: Ev,
        stage: str,
        cases: tuple[tuple[int, int], ...],
        output: Path,
        report_work: Callable[[int], None],
        trial_workers: int,
    ) -> Iterable[Trial[Any, Any]]:
        """Yield each case after closing its artifacts under ``output``.

        The search parent owns the atomic JSON checkpoint and acknowledges it
        before this iterator advances to the next result.
        """

    def shared_record(
        self, config: Config, evaluation: Ev, case: tuple[int, int]
    ) -> Path | None:
        """The stem under which this trial is shared between runs, if any."""


def _check_saved(
    saved: Trial[Any, Any],
    design: Evaluation[Any],
    case: tuple[int, int],
    where: Path,
) -> None:
    """Raise if the saved trial was measured under other settings than the design's."""
    if saved.key != design.key or saved.case != case:
        raise ValueError(f"settings changed for saved trial {where}")


def _copy_artifacts(series: Path, target: Path) -> Path:
    """Copy a trial's series and its state snapshot beside it to the ``target``
    stem, raising if either is missing; return the copied series path."""
    _check_artifacts(series)
    target.parent.mkdir(parents=True, exist_ok=True)
    copied = target.with_name(target.name + series.suffix)
    shutil.copyfile(series, copied)
    shutil.copyfile(series.with_suffix(".pkl"), copied.with_suffix(".pkl"))
    return copied


def _check_artifacts(series: Path) -> None:
    """Require a trial's series and state snapshot before committing or reusing it."""
    for artifact in (series, series.with_suffix(".pkl")):
        if not artifact.is_file():
            raise FileNotFoundError(f"missing trial artifact {artifact}")


def _trial_worker(
    connection: Connection,
    output: Path,
    stage: str,
    cases: tuple[tuple[int, int], ...],
    evaluation: str,
    task: Task[Any, Any],
    trial_workers: int,
) -> None:
    def record(steps: int) -> None:
        connection.send(steps)
        connection.recv()

    try:
        with handler(BuiltinExecutor()):
            decoded = task.evaluation_type.model_validate_json(
                evaluation, context=task.decode_context
            )
        for trial in task.run_cases(
            decoded, stage, cases, output, record, trial_workers
        ):
            connection.send(trial.model_dump_json())
            connection.recv()
        connection.send(None)
    except Exception:
        connection.send(RuntimeError(traceback.format_exc()[-6000:]))
    finally:
        connection.close()


def pending_cases[Config: SearchConfig, Ev: Evaluation[Any], T: Trial[Any, Any]](
    config: Config,
    trials: list[T],
    design: Ev,
    cases: tuple[tuple[int, int], ...],
    task: Task[Config, Ev],
) -> tuple[tuple[int, int], ...]:
    """Restore cached trials and return the cases requiring physics dispatch."""
    config.output.mkdir(parents=True, exist_ok=True)
    completed = {t.case for t in measured(trials, design)}
    stage = design.stage
    trial_type = task.trial_type
    missing = []
    for case in cases:
        if case in completed:
            continue
        seed, controller_seed = case
        name = f"{stage}-seed-{seed}-controller-{controller_seed}"
        checkpoint = config.output / f"{name}.json"
        if checkpoint.exists():
            with handler(BuiltinExecutor()):
                saved = trial_type.model_validate_json(
                    checkpoint.read_text(), context=task.decode_context
                )
            _check_saved(saved, design, case, checkpoint)
            _check_artifacts(Path(saved.series))
            trials.append(saved)  # type: ignore[arg-type]
            print(f"Reusing {checkpoint.stem}", flush=True)
            continue
        shared = task.shared_record(config, design, case)
        # Shared stems can contain dots, so append artifact suffixes.
        if (
            shared is not None
            and (record := shared.with_name(shared.name + ".json")).is_file()
        ):
            with handler(BuiltinExecutor()):
                saved = trial_type.model_validate_json(
                    record.read_text(), context=task.decode_context
                )
            _check_saved(saved, design, case, record)
            series = _copy_artifacts(
                shared.with_name(shared.name + Path(saved.series).suffix),
                config.output / name,
            )
            restored = saved.model_copy(update={"stage": stage, "series": str(series)})
            save_record(restored, checkpoint)
            trials.append(restored)  # type: ignore[arg-type]
            print(f"Reusing shared baseline {shared.name} as {name}", flush=True)
            continue
        missing.append(case)
    return tuple(missing)


def run_trials[Config: SearchConfig, Ev: Evaluation[Any], T: Trial[Any, Any]](
    config: Config,
    trials: list[T],
    design: Ev,
    cases: tuple[tuple[int, int], ...],
    task: Task[Config, Ev],
    *,
    timeout: Callable[[], float] = lambda: math.inf,
    on_work: Callable[[int], None] = lambda steps: None,
) -> list[T]:
    """Measure the cases of ``design`` that ``trials`` lacks, appending to it.

    Episodes run in spawned workers; work is accounted and each trial's
    checkpoint file written in the calling process, so a checkpoint on disk
    is reused by name. ``timeout`` returns the seconds left in the search and
    raises :class:`SearchLimitReached` once none remain; it is consulted
    again at least every minute, since a worker message may never come.
    Held-out designs run after the search without ``on_work``: their work
    is not charged against the search allowance.
    """
    missing = pending_cases(config, trials, design, cases, task)
    stage = design.stage
    trial_type = task.trial_type
    encoded = design.model_dump_json()
    batches = task.case_batches(tuple(missing))
    assigned = Counter(case for batch in batches for case in batch)
    if any(not batch for batch in batches) or assigned != Counter(missing):
        raise ValueError("case batches must partition the uncached cases exactly")
    pending = iter(batches)
    context = get_context("spawn")
    workers: list[BaseProcess] = []
    active: dict[Connection, set[tuple[int, int]]] = {}
    try:
        while True:
            while len(active) < config.trial_workers:
                batch = next(pending, None)
                if batch is None:
                    break
                receiver, sender = context.Pipe()
                worker = context.Process(
                    target=_trial_worker,
                    args=(
                        sender,
                        config.output,
                        stage,
                        batch,
                        encoded,
                        task,
                        config.trial_workers,
                    ),
                )
                active[receiver] = set(batch)
                try:
                    worker.start()
                    workers.append(worker)
                finally:
                    sender.close()
            if not active:
                break
            # The intersection narrows wait's result to Connection.
            for receiver in set(active).intersection(
                wait(active, min(timeout(), 60.0))
            ):
                try:
                    event: str | int | RuntimeError | None = receiver.recv()
                except EOFError as error:
                    raise RuntimeError(
                        "trial worker exited without an outcome"
                    ) from error
                if event is None:
                    if active[receiver]:
                        raise RuntimeError(
                            "worker completed without all assigned case outcomes"
                        )
                    del active[receiver]
                    receiver.close()
                elif isinstance(event, int):
                    on_work(event)
                    receiver.send(True)
                elif isinstance(event, RuntimeError):
                    raise event
                else:
                    with handler(BuiltinExecutor()):
                        trial = trial_type.model_validate_json(
                            event, context=task.decode_context
                        )
                    if trial.case not in active[receiver]:
                        raise ValueError(
                            "worker returned a duplicate or unassigned case"
                        )
                    seed, controller_seed = trial.case
                    name = f"{stage}-seed-{seed}-controller-{controller_seed}"
                    checkpoint = config.output / f"{name}.json"
                    _check_saved(trial, design, trial.case, checkpoint)
                    _check_artifacts(Path(trial.series))
                    save_record(trial, checkpoint)
                    trials.append(trial)  # type: ignore[arg-type]
                    active[receiver].remove(trial.case)
                    receiver.send(True)
                    shared = task.shared_record(config, design, trial.case)
                    if shared is not None:
                        _copy_artifacts(Path(trial.series), shared)
                        save_record(trial, shared.with_name(shared.name + ".json"))
    finally:
        for receiver in active:
            receiver.close()
        for process in workers:
            process.join(timeout=0.1)
            if process.is_alive():
                process.terminate()
                process.join(timeout=5)
            if process.is_alive():
                process.kill()
                process.join()
            process.close()
    return sorted(measured(trials, design), key=lambda t: cases.index(t.case))


class Evaluator[Config: SearchConfig, Ev: Evaluation[Any]](abc.ABC):
    """Measure designs on the task's fixed training suite.

    Every design in ``result.evaluations`` is measured on every training
    case; its trials are ``measured(result.trials, evaluation)`` from
    ``experiments.search``. Rank designs with the task's order; planning
    costs are not comparable across designs.

    Inspect ``result.evaluations`` for saved factories, ``result.trials``
    for measurements, and ``result.cost`` against the allowances in
    ``config``. Read a design's name through ``evaluation.name``. Trial
    ``series`` paths contain NumPy traces; matching ``.pkl`` files hold
    gzip-compressed pickled simulator states (``gzip.open``), which
    ``experiments.cube_orienting.diagnostics.recorded_states`` loads. Save
    inspection artifacts under ``config.output``.
    Conduct diagnostic probes in the REPL with your own environment,
    controller and ``run_episode`` from ``robotl.handlers.mujoco.process``.
    For MPC rollouts use
    ``CountedRollouts(report_work=evaluator.record_work)`` from
    ``experiments.search`` as the planner runner's ``on_work`` hook to share
    the search allowance. Keep environment stepping unhooked. NEVER print
    MujocoContext, including
    ``environment.spec.context``: its representation recursively expands the
    simulator graph. Print selected names or scalar values instead.
    Diagnostics stay outside ``result.evaluations``. Do not modify
    configuration, records or host state, or inspect held-out cases. The host
    selects designs before running those cases. Return when allowances run
    out or further attempts are unhelpful, completing promising evaluations
    first.
    """

    def __init__(
        self,
        result: Search[Config, Ev, Any],
        environment: EnvProcess,
        task: Task[Config, Ev],
    ) -> None:
        self.result = result
        self.environment = environment
        self.task = task

    @property
    def config(self) -> Config:
        return self.result.config

    @abc.abstractmethod
    def design(self, evaluation: Ev) -> bytes:
        """The allowance key of an evaluation on the searched axis."""

    @abc.abstractmethod
    def charged(self, evaluation: Ev) -> bool:
        """Whether an evaluation counts against the allowance."""

    def _check_limits(self) -> float:
        """Raise on an exhausted allowance; return the remaining wall-clock seconds."""
        return self.result.cost.remaining(
            self.config.max_wall_s, self.config.max_rollout_steps
        )

    def record_work(self, steps: int) -> None:
        """Charge dispatched physics steps against the shared search allowance."""
        self.result.cost.charge(
            steps, self.config.max_wall_s, self.config.max_rollout_steps
        )
        self.result.record_cost()

    def _trace(self, loss: LossFn, probe: EnvProcess) -> LossFn:
        """The loss, checked on ``probe``; nothing is saved yet."""
        with handler(BuiltinExecutor()), handler({probe_env: lambda: probe}):
            return pydantic.TypeAdapter[LossFn](Encodable[CheckedLossFn]).validate_json(
                loss_adapter.dump_json(loss), context=self.task.decode_context
            )

    def _place(self, loss: LossFn, robot: RobotFn, budget: BaseModel) -> Ev:
        """The saved evaluation for this design, or the design charged as a new one."""
        candidate = self.task.evaluation_type(loss=loss, robot=robot, budget=budget)
        evaluation = next(
            (e for e in self.result.evaluations if e.key == candidate.key), None
        )
        if evaluation is not None:
            return evaluation
        # New work needs allowance; replaying a saved row does not.
        self._check_limits()
        proposals = {self.design(e) for e in self.result.evaluations if self.charged(e)}
        if (
            self.charged(candidate)
            and self.design(candidate) not in proposals
            and len(proposals) >= self.config.proposals
        ):
            raise ProposalAllowanceExhausted("proposal allowance exhausted")
        return candidate

    def _run(self, evaluation: Ev) -> list[Trial[Any, Any]]:
        """Measure the design, then list it; a crash before that leaves only trial files."""
        trials = run_trials(
            self.config,
            self.result.trials,
            evaluation,
            self.config.training_cases,
            self.task,
            timeout=lambda: self.result.cost.remaining_time(self.config.max_wall_s),
            on_work=self.record_work,
        )
        if not any(e.key == evaluation.key for e in self.result.evaluations):
            self.result.evaluations.append(evaluation)
            self.result.save()
        return trials


@Encodable.register(EnvProcess)  # type: ignore[attr-defined]
@Encodable.register(Evaluator)  # type: ignore[attr-defined]
def _encode_runtime_argument(ty: type) -> Any:
    """Expose runtime interfaces as source without encoding their live state.

    The value's class body comes first, then its evaluator bases, so the
    prompt shows the whole contract.
    """

    def class_sources(value: object) -> str:
        cls = type(value)
        return "\n\n".join(
            inspect.getsource(c)
            for c in cls.__mro__
            if c is cls or Evaluator in c.__mro__
        )

    return Annotated[ty, InstanceOf, PlainSerializer(class_sources, return_type=str)]


def search_harness(config: SearchConfig):
    """The harness interpretation a study drives its agent with."""
    # The OpenAI responses route returns reasoning only as summaries,
    # and only when asked; LiteLLM maps them to reasoning_content.
    reasoning: str | dict[str, str] | None = config.reasoning_effort
    if config.reasoning_effort and config.model.startswith("openai/responses/"):
        reasoning = {"effort": config.reasoning_effort, "summary": "detailed"}
    return harness(
        model=config.model,
        reasoning_effort=reasoning,
        max_completion_tokens=config.max_completion_tokens,
        eval_provider="builtin",
        type_checker=config.type_checker,
        tool_collection="none",
        num_retries=3,
        langfuse=True,
        render=config.render_agent,
        dump_system_prompt=config.output / "system-prompt.md",
    )


def meter_completion(evaluator: Evaluator, **kwargs) -> ModelResponse:
    """Count requests and provider-reported usage, including nested Skills.

    The remaining wall-clock allowance bounds each request, and litellm's own
    retries are off because the harness already retries failed requests.
    """
    remaining_s = evaluator._check_limits()
    cost = evaluator.result.cost
    cost.model_calls += 1
    evaluator.result.record_cost()
    response = fwd(
        **{
            **kwargs,
            "timeout": min(remaining_s, evaluator.config.model_timeout_s),
            "num_retries": 0,
        }
    )
    if response.usage is not None and response.usage.total_tokens > 0:
        cost.tokens += response.usage.total_tokens
        evaluator.result.record_cost()
    return response


def run_held_out[S: Summary[Any, Any, Any]](summary: S, task: Task[Any, Any]) -> S:
    """Measure every held-out design on the evaluation cases, then write the record.

    Trials already in the summary or checkpointed on disk are reused, so a
    finished study runs through without work.
    """
    config = summary.search.config
    client = langfuse.get_client()
    for n, design in enumerate(summary.held_out):
        with client.start_as_current_observation(
            name="evaluate",
            input={"held_out": n, "cases": config.evaluation_cases},
        ) as observation:
            trials = run_trials(
                config, summary.trials, design, config.evaluation_cases, task
            )
            observation.update(output=[t.model_dump(mode="json") for t in trials])
        summary.save()
    summary.save()
    return summary

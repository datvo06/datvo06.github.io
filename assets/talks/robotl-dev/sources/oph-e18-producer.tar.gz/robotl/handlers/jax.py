"""JAX optimization handler for RoboTL constraint solving.

This module provides functionality to convert RoboTL components with
constraints into JAX optimization problems for finding valid configurations.
"""

import functools
import logging
import warnings
from collections.abc import Callable

import effectful.handlers.jax.numpy as jnp
import jax
import networkx as nx
import numpyro
import numpyro.distributions as dist
from effectful.ops.semantics import coproduct, evaluate, fvsof, fwd, handler, typeof
from effectful.ops.syntax import defdata, deffn
from effectful.ops.types import Interpretation, Operation, Term
from numpyro.infer import MCMC, NUTS
from numpyro.infer.util import log_density

from robotl.ops.losses import Loss
from robotl.ops.syntax import (
    Component,
    Pose,
    _component_state,
    assert_transform,
    choose,
    constrain,
)

log = logging.getLogger(__name__)


def runtime_loss(model: Component) -> jax.Array:
    # this is now superseded by EnvSpec.get_loss, but kept around for contexts where
    # EnvSpec is not available. it returns Terms whereas EnvSpec.get_loss returns
    # concrete values.
    warnings.warn(
        "runtime_loss is deprecated, use EnvSpec.get_loss instead.",
        DeprecationWarning,
        stacklevel=2,
    )

    terms = []
    for component in model.components():
        for v in jax.tree.leaves(
            _component_state(component), is_leaf=lambda x: isinstance(x, Loss)
        ):
            if isinstance(v, Loss):
                terms.append(v.value)  # noqa: PERF401
    return jnp.sum(jnp.stack(terms), axis=0)


def default_handler(model):
    return {
        v: Pose
        for v in fvsof(model)
        if len(v.__signature__.parameters) == 0 and issubclass(typeof(defdata(v)), Pose)
    }


def solve_init(
    model: Callable[[], Component],
    key: jax.typing.ArrayLike = jax.random.key(0),
    **mcmc_kwargs,
) -> tuple[Component, Interpretation]:
    """Solve for an initial configuration of a component model.

    Instantiates the model, collects kinematic constraints (``assert_transform``),
    soft constraints (``constrain``), and stochastic choices (``choose``), then
    returns an interpretation that assigns concrete poses and choice values.

    When the model contains no ``choose`` calls, poses are determined purely by
    propagating ``assert_transform`` edges through the kinematic graph. When
    ``choose`` calls are present, MCMC (NUTS) is used to sample choice values
    that satisfy the collected constraints, and the highest-log-density sample
    is selected.

    The returned Component retains symbolic (free-variable) poses so that
    callers can rebind them under a different interpretation (e.g. a MuJoCo
    runtime interpretation) without the init values being baked in.

    :param model: Zero-argument callable that constructs and returns a Component.
    :param key: JAX PRNG key used for MCMC sampling.
    :param mcmc_kwargs: Forwarded to :class:`numpyro.infer.MCMC` (e.g.
        ``num_warmup``, ``num_samples``, ``progress_bar``).
    :returns: A ``(component, interpretation)`` tuple. Evaluating the component
        under the interpretation yields a fully concrete configuration.
    """
    choices: dict[Operation, dist.Distribution] = {}
    constraints: list[jax.Array] = []
    kinematic: nx.DiGraph = nx.DiGraph()

    def _constrain(loss: Loss) -> None:
        constraints.append(loss.value)
        return fwd()

    def _choose(d: dist.Distribution) -> jax.Array:
        var = Operation.define(jax.Array)
        choices[var] = d
        return var()

    def _assert_transform(parent, child, pose=Pose()):
        kinematic.add_edge(parent, child, delta=pose)
        return fwd()

    log.debug("Collecting constraints...")
    with handler(
        {constrain: _constrain, choose: _choose, assert_transform: _assert_transform}
    ):
        m = model()

    if not isinstance(m, Component):
        raise TypeError("Expected a Component but got: ", m)

    # Collect all components with known poses.
    for v in kinematic.nodes:
        if not isinstance(v.pose, Term):
            kinematic.nodes[v]["pose"] = v.pose

    # For any group of related components where all poses are free, it is safe
    # to set one pose to the identity, fixing the other poses relative to it.
    # The anchor is chosen by insertion order: the components form a set, so
    # popping one would place the group differently from run to run.
    insertion_order = {v: i for (i, v) in enumerate(kinematic.nodes)}
    for comp in nx.weakly_connected_components(kinematic):
        if not any("pose" in kinematic.nodes[v] for v in comp):
            anchor = min(comp, key=insertion_order.__getitem__)
            kinematic.nodes[anchor]["pose"] = Pose()

    def _incident(v):
        """Yield ``(neighbour, reversed)`` for every edge touching *v*.

        Edges are stored in the direction they were asserted, so those reaching
        *v* need their delta inverted to move away from it.
        """
        for _, child in kinematic.out_edges(v):
            yield child, False
        for parent, _ in kinematic.in_edges(v):
            yield parent, True

    # Propagate pose constraints through the graph. The resulting poses are
    # symbolic expressions that may reference choice variables.
    worklist = [v for v in kinematic.nodes if "pose" in kinematic.nodes[v]]
    while worklist:
        parent = worklist.pop()
        for child, reversed_edge in _incident(parent):
            if "pose" in kinematic.nodes[child]:
                continue
            delta = (
                ~kinematic.edges[child, parent]["delta"]
                if reversed_edge
                else kinematic.edges[parent, child]["delta"]
            )
            kinematic.nodes[child]["pose"] = kinematic.nodes[parent]["pose"] @ delta
            worklist.append(child)

    assert all("pose" in kinematic.nodes[v] for v in kinematic.nodes)

    # Build interpretation mapping free pose variables to their (symbolic) propagated values.
    pose_intp: Interpretation = {}
    for v in kinematic.nodes:
        pose = v.pose
        if not isinstance(pose, Term):
            continue
        if pose.args or pose.kwargs:
            raise ValueError("Expected pose to be a free variable but got: ", pose)

        pose_intp[pose.op] = deffn(kinematic.nodes[v]["pose"])  # type: ignore[index]

    if not choices:
        intp = coproduct(default_handler(m), pose_intp)
    else:
        intp = _solve_choices_mcmc(m, choices, pose_intp, constraints, key, mcmc_kwargs)

    return m, intp


def _solve_choices_mcmc(
    m: Component,
    choices: dict[Operation, dist.Distribution],
    pose_intp: Interpretation,
    constraints: list[jax.Array],
    key: jax.typing.ArrayLike,
    mcmc_kwargs: dict,
) -> Interpretation:
    """Run NUTS over *choices* under *pose_intp* and *constraints*, then return
    an interpretation built from the highest-log-density sample."""
    choice_to_name = {v: f"choice{i}" for (i, v) in enumerate(choices.keys())}
    name_to_choice = {v: k for k, v in choice_to_name.items()}

    @handler(pose_intp)
    def numpyro_model():
        @functools.cache
        def _sample_rule(
            var: Operation[[], jax.typing.ArrayLike],
        ) -> jax.typing.ArrayLike:
            return numpyro.sample(choice_to_name[var], evaluate(choices[var]))  # type: ignore[arg-type]

        with handler({v: functools.partial(_sample_rule, v) for v in choices}):
            _, constraint_vals = evaluate(([var() for var in choices], constraints))
            for i, c in enumerate(constraint_vals):
                numpyro.factor(f"factor{i}", c)

    nuts_kernel = NUTS(numpyro_model)
    mcmc = MCMC(nuts_kernel, num_warmup=500, num_samples=10000, **mcmc_kwargs)
    mcmc.run(key)
    mcmc.print_summary()
    samples = mcmc.get_samples()

    def score_sample(site_values):
        ld, _ = log_density(numpyro_model, (), {}, site_values)
        return ld

    scores = jax.vmap(score_sample)(samples)
    best_idx = int(jnp.argmax(scores))
    log.debug(f"Best sample index: {best_idx}, log density: {scores[best_idx]:.4f}")

    choice_intp = {name_to_choice[v]: deffn(s[best_idx]) for (v, s) in samples.items()}

    with handler(choice_intp):
        pose_vals = evaluate(tuple(pose_intp.values()))
    pose_intp_eval = dict(zip(pose_intp, pose_vals))  # type: ignore[arg-type]
    return coproduct(default_handler(m), coproduct(pose_intp_eval, choice_intp))

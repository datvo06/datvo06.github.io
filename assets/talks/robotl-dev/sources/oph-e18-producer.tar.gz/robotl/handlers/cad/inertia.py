"""Inertia computation from shape geometry and uniform density.

This module provides a :class:`ShapeToInertia` interpreter that walks shape
Term trees and computes :class:`Inertia` objects for each shape.  The
top-level :func:`inertia_from_shape` function is the main entry point.

The interpreter follows the ``ObjectInterpretation`` pattern used by
:class:`~robotl.handlers.cad.sdf.ShapeToSDF` and
:class:`~robotl.handlers.cad.openscad.ShapeToOpenSCAD`.
"""

import collections.abc
import functools
import math
import operator
from collections.abc import Callable

import effectful.handlers.jax.numpy as jnp
import jax
import trimesh
from effectful.ops.semantics import evaluate, handler
from effectful.ops.syntax import ObjectInterpretation, implements

from robotl.handlers.cad.bbox import bbox_from_shape
from robotl.handlers.cad.decomposition import as_trimesh
from robotl.handlers.cad.sdf import ShapeToSDF
from robotl.internals.utils import Bbox, Mesh, Polygon, parallel_axis
from robotl.ops import shapes
from robotl.ops.syntax import Inertia, Material, Pose


def _polygon_moment(polygon: Polygon, k: int, j: int) -> jax.Array:
    r"""Exact area integral :math:`\iint_P x^k y^j \, dA` over a polygon.

    By Green's theorem the integral becomes a contour integral,

    .. math::

        \iint_P x^k y^j \, dA
        = \frac{1}{k+1} \oint_{\partial P} x^{k+1} y^j \, dy,

    and each linearly parameterized edge contributes a polynomial in the
    edge parameter, integrated in closed form via the binomial expansion.
    The result is signed by the outline's winding direction; callers
    normalize with the sign of the area moment ``(0, 0)``.
    """
    v = jnp.asarray(polygon.points, dtype=float)
    x0, y0 = v[:, 0], v[:, 1]
    dx, dy = jnp.roll(x0, -1) - x0, jnp.roll(y0, -1) - y0
    m = k + 1
    total = jnp.asarray(0.0)
    for a in range(m + 1):
        for b in range(j + 1):
            total = total + (
                math.comb(m, a)
                * math.comb(j, b)
                / (a + b + 1)
                * jnp.sum(x0 ** (m - a) * dx**a * y0 ** (j - b) * dy**b * dy)
            )
    return total / m


#: What a component can do when its shape has no closed-form inertia.
_REMEDY = (
    "wrap the shape in decompose(...) to integrate its rendered geometry, set "
    "explicit inertia on the component, or clear its density."
)


class ShapeToInertia(ObjectInterpretation):
    """Interpreter that computes :class:`Inertia` from shape terms.

    :param material: Material with density in kg/m^3.
    """

    material: Material

    def __init__(self, material: Material):
        self.material = material

    @property
    def density(self) -> float:
        assert self.material.density is not None
        return self.material.density

    # ---- primitives ----

    @implements(shapes.sphere)
    def sphere(self, r):
        r = jnp.asarray(r, dtype=float)
        M = self.density * 4 / 3 * jnp.pi * r**3
        return Inertia(mass=M, diag=jnp.full([3], 2 / 5 * r**2 * M, dtype=float))

    @implements(shapes.cube)
    def cube(self, dx, dy, dz):
        d = jnp.array([dx, dy, dz], dtype=float)
        M = self.density * d.prod()
        return Inertia(
            mass=M,
            diag=M / 12 * (d @ d - d**2),
            pose=Pose(pos=d / 2),
        )

    @implements(shapes.cylinder)
    def cylinder(self, *, r, h, r2=None):
        if r2 is not None and not jnp.allclose(jnp.asarray(r), jnp.asarray(r2)):
            raise NotImplementedError(
                "Inertia of a tapered cylinder (r != r2) is not integrated in "
                f"closed form; {_REMEDY}"
            )
        r = jnp.asarray(r, dtype=float)
        h = jnp.asarray(h, dtype=float)
        M = self.density * jnp.pi * r**2 * h
        Ixx = M / 12 * (3 * r**2 + h**2)
        Izz = M / 2 * r**2
        return Inertia(
            mass=M,
            diag=jnp.array([Ixx, Ixx, Izz]),
            pose=Pose(pos=jnp.array([0, 0, h / 2])),
        )

    @implements(shapes.capsule)
    def capsule(self, *, r, h):
        r = jnp.asarray(r, dtype=float)
        h = jnp.asarray(h, dtype=float)
        rho = self.density

        # Cylinder part: base at z=0, extends to z=h
        m_cyl = rho * jnp.pi * r**2 * h
        I_cyl_xx = m_cyl / 12 * (3 * r**2 + h**2)
        I_cyl_zz = m_cyl / 2 * r**2
        cyl = Inertia(
            mass=m_cyl,
            diag=jnp.array([I_cyl_xx, I_cyl_xx, I_cyl_zz]),
            pose=Pose(pos=jnp.array([0, 0, h / 2])),
        )

        # Each hemisphere: mass, CoM, moments about its own CoM
        m_h = rho * (2 / 3 * jnp.pi * r**3)
        I_h_trans = 83 / 320 * m_h * r**2  # transverse, about CoM
        I_h_sym = 2 / 5 * m_h * r**2  # symmetry axis, about CoM

        # Bottom hemisphere CoM at z = -3r/8
        bottom = Inertia(
            mass=m_h,
            diag=jnp.array([I_h_trans, I_h_trans, I_h_sym]),
            pose=Pose(pos=jnp.array([0, 0, -3 * r / 8])),
        )

        # Top hemisphere CoM at z = h + 3r/8
        top = Inertia(
            mass=m_h,
            diag=jnp.array([I_h_trans, I_h_trans, I_h_sym]),
            pose=Pose(pos=jnp.array([0, 0, h + 3 * r / 8])),
        )

        return cyl + bottom + top

    @implements(shapes.extrude)
    def extrude(self, polygon: Polygon, h: float) -> Inertia:
        r"""Inertia of a polygon extruded along +Z over z in [0, h].

        The polygon's exact area moments give the mass and the in-plane
        second moments; the extrusion adds the slab term :math:`M h^2 / 12`
        to the transverse axes, as for a prism.
        """
        sign = jnp.sign(_polygon_moment(polygon, 0, 0))
        area = sign * _polygon_moment(polygon, 0, 0)
        cx = sign * _polygon_moment(polygon, 1, 0) / area
        cy = sign * _polygon_moment(polygon, 0, 1) / area
        # Second moments of the cross-section about its centroid.
        ixx = sign * _polygon_moment(polygon, 0, 2) - area * cy**2
        iyy = sign * _polygon_moment(polygon, 2, 0) - area * cx**2
        ixy = sign * _polygon_moment(polygon, 1, 1) - area * cx * cy
        M = self.density * area * h
        rho_h = self.density * h
        return Inertia(
            mass=M,
            diag=jnp.array(
                [
                    rho_h * ixx + M * h**2 / 12,
                    rho_h * iyy + M * h**2 / 12,
                    rho_h * (ixx + iyy),
                ]
            ),
            offdiag=jnp.array([-rho_h * ixy, 0.0, 0.0]),
            pose=Pose(pos=jnp.array([cx, cy, h / 2])),
        )

    @implements(shapes.revolve)
    def revolve(self, polygon: Polygon) -> Inertia:
        r"""Inertia of a polygon revolved about the +Z axis.

        Each cross-section element at (radial, axial) = :math:`(r, z)`
        sweeps a ring of mass :math:`2 \pi \rho \, r \, dA` with moments
        :math:`r^2` about the axis and :math:`r^2/2 + z^2` transverse, so
        the tensor reduces to polygon area moments:

        .. math::

            I_z = 2 \pi \rho \iint r^3 \, dA, \qquad
            I_x = 2 \pi \rho \iint r \bigl(r^2/2 + z^2\bigr) \, dA
        """
        sign = jnp.sign(_polygon_moment(polygon, 0, 0))
        q1 = sign * _polygon_moment(polygon, 1, 0)
        M = self.density * 2 * jnp.pi * q1
        z_com = sign * _polygon_moment(polygon, 1, 1) / q1
        izz = self.density * 2 * jnp.pi * sign * _polygon_moment(polygon, 3, 0)
        ixx = (
            izz / 2
            + self.density * 2 * jnp.pi * sign * _polygon_moment(polygon, 1, 2)
            - M * z_com**2
        )
        return Inertia(
            mass=M,
            diag=jnp.array([ixx, ixx, izz]),
            pose=Pose(pos=jnp.array([0.0, 0.0, z_com])),
        )

    def _closed_mesh(self, mesh: trimesh.Trimesh) -> Inertia:
        """Inertia of a triangle mesh from its divergence-theorem integrals.

        ``volume``, ``center_mass`` and ``moment_inertia`` are exact for any
        watertight mesh, convex or not, and unreliable for an open one:
        wrap such a shape in :func:`~robotl.ops.shapes.decompose`, whose COACD
        hulls are closed. trimesh takes the moment tensor about the center of
        mass, so the pose sits there.
        """
        return Inertia(
            mass=self.density * mesh.volume,
            tensor=self.density * jnp.asarray(mesh.moment_inertia),
            pose=Pose(pos=jnp.asarray(mesh.center_mass)),
        )

    @implements(shapes.external_mesh)
    def external_mesh(self, path: str) -> Inertia:
        return self._closed_mesh(as_trimesh(path))

    @implements(shapes.mesh)
    def mesh(self, m: Mesh) -> Inertia:
        return self._closed_mesh(m.to_trimesh())

    @implements(shapes.plane)
    def plane(self):
        raise NotImplementedError(
            "An infinite plane has no inertia; set explicit inertia on the "
            "component or clear its density."
        )

    # ---- boolean operations ----

    @implements(shapes.union)
    def union(self, *args):
        return functools.reduce(operator.add, args)

    @implements(shapes.difference)
    def difference(self, a, b):
        neg_b = Inertia(mass=-b.mass, diag=-b.diag, pose=b.pose)
        return a + neg_b

    @implements(shapes.intersection)
    def intersection(self, *args):
        raise NotImplementedError(
            "Inertia of an intersection cannot be derived from its parts alone, "
            f"it needs the overlap geometry; {_REMEDY}"
        )

    # ---- transforms ----

    @implements(shapes.translate)
    def translate(self, inertia, v):
        v = jnp.asarray(v, dtype=float)
        return Inertia(
            mass=inertia.mass,
            diag=inertia.diag,
            pose=Pose(pos=inertia.pose.pos + v) @ inertia.pose.rotational,
        )

    @implements(shapes.rotate)
    def rotate(self, inertia, rot):
        R = jnp.asarray(rot.as_matrix())
        I_rot = R @ inertia.tensor @ R.T
        return Inertia(
            mass=inertia.mass, tensor=I_rot, pose=Pose(pos=R @ inertia.pose.pos)
        )

    @implements(shapes.scale)
    def scale(self, inertia, v):
        v = jnp.asarray(v, dtype=float)
        if jnp.allclose(v[0], v[1]) and jnp.allclose(v[1], v[2]):
            s = v[0]
            return Inertia(
                mass=inertia.mass * s**3,
                diag=inertia.diag * s**5,
                pose=Pose(pos=inertia.pose.pos * s) @ inertia.pose.rotational,
            )
        raise NotImplementedError(
            f"Inertia under non-uniform scaling is not integrated in closed form; "
            f"{_REMEDY}"
        )

    @implements(shapes.decompose)
    def decompose(self, inertia, *, max_parts: int = 8):
        # Children evaluate before parents, so by the time ``decompose`` is
        # reached its shape is already an Inertia and can no longer be rendered
        # into parts.
        raise NotImplementedError(
            "decompose has no inertia of its own; evaluate the shape under "
            "DecomposeToMeshes first, which replaces each decompose with its "
            "convex mesh hulls, as the MuJoCo compiler does."
        )


def inertia_from_shape(shape: shapes.Shape, material: Material) -> Inertia:
    """Compute inertia from a shape and material properties.

    :param shape: Shape term (from :mod:`robotl.ops.shapes`), with any
        ``decompose`` already rewritten by
        :class:`~robotl.handlers.cad.openscad.DecomposeToMeshes`.
    :param material: Material with density in kg/m^3.
    :returns: Inertia object with mass, principal moments, and inertial frame pose.
    :raises NotImplementedError: If the shape has no closed-form inertia: a
        plane, an intersection, a tapered cylinder, a non-uniform scale, or a
        ``decompose`` that was not rewritten first. All but the plane
        integrate once ``decompose`` has replaced them with convex hulls.
    """
    with handler(ShapeToInertia(material)):
        result = evaluate(shape)
    assert isinstance(result, Inertia)
    return result


def inertia_from_sdf(
    sdf: collections.abc.Callable[[jnp.ndarray], jnp.ndarray],
    material: Material,
    bbox: Bbox,
    n: int = 128,
) -> Inertia:
    """Estimate inertia by numerical integration over an SDF.

    Evaluates the SDF on a uniform grid inside *bbox* and accumulates mass
    and inertia contributions from interior points (SDF < 0).  This is an
    independent computation path from ShapeToInertia and provides a
    ground-truth comparison up to grid resolution.
    """
    density = material.density
    assert density is not None, (
        "Material must have a defined density for inertia computation."
    )

    # Use cell centers (midpoint rule) to avoid boundary artifacts
    dx = (bbox.hi - bbox.lo) / n
    dV = dx.prod()
    xs = bbox.lo[:, None] + dx[:, None] * (jnp.arange(n) + 0.5)[None, :]

    grid = jnp.stack(jnp.meshgrid(xs[0], xs[1], xs[2], indexing="ij"), axis=-1)
    flat = grid.reshape(-1, 3)  # [n**3, 3]
    d = jax.vmap(sdf)(flat)
    inside = d < 0
    pts = flat[inside]
    com = pts.mean(axis=0)

    M = density * dV * len(pts)
    I = density * dV * jax.vmap(parallel_axis)(pts - com).sum(axis=0)
    return Inertia(
        mass=jnp.array(M), tensor=jnp.array(I), pose=Pose(pos=jnp.array(com))
    )


def inertia_through_sdf(
    shape: shapes.Shape, material: Material, n: int = 128
) -> Inertia:
    with handler(ShapeToSDF()):
        sdf: Callable[[jax.Array], jax.Array] = evaluate(shape)  # type: ignore
    assert callable(sdf)
    bbox = bbox_from_shape(shape)
    return inertia_from_sdf(sdf, material, bbox=bbox, n=n)

import effectful.handlers.jax.numpy as jnp
from effectful.ops.semantics import fwd
from effectful.ops.syntax import ObjectInterpretation, implements
from effectful.ops.types import Term

from robotl.ops.shapes import (
    difference,
    intersection,
    rotate,
    scale,
    translate,
    union,
)


class LogicalsOutward(ObjectInterpretation):
    """
    The logical operations union, intersection and difference are equivariant to
    spatial transformations T, i.e. T(union(a, b, c)) == union(T(a), T(b), T(c)),
    where T is translation, rotation, scaling or mirroring.
    We can use this equivariance to move all the logical operations outward, after
    which we can do some boolean algebra to end up with a union as the outermost op.
    The reason for doing is that mujoco supports unions natively, so we can make
    multiple more specific geom elements rather than just one big mesh.
    Considerations:
    + We will be able to use primitive shapes for some geometries, which are faster
      and more accurate.
    + Non-convex geometries can be expressed as unions of convex (or less non-convex)
      geometries for more accurate simulation.
    - More geoms means more collision pairs for the simulator to check, which means
      more computation, particularly at jax jit time.
    It is not always a win to do this, so we should not go too far.
    * Intersections of unions can be rewritten as unions of many intersections,
      which results in more accurate simulation (the resulting intersections are
      "more convex") at the cost of introducing many more pairs.  TODO consider
      doing this.
    * Differences a - b are logically a AND NOT b, an intersection that can be
      distributed if a or b are unions into a union of differences, but because
      of the negation the resulting intersections tend to be less convex.
      Rewriting these is probably counterproductive.
    """

    @implements(translate)
    @staticmethod
    def translate(obj, vec):
        if isinstance(obj, Term) and obj.op == union:
            return union(*(translate(a, vec) for a in obj.args))
        elif isinstance(obj, Term) and obj.op == intersection:
            return intersection(*(translate(a, vec) for a in obj.args))
        else:
            return fwd()

    @implements(rotate)
    @staticmethod
    def rotate(obj, rot):
        if isinstance(obj, Term) and obj.op == union:
            return union(*(rotate(a, rot) for a in obj.args))
        elif isinstance(obj, Term) and obj.op == intersection:
            return intersection(*(rotate(a, rot) for a in obj.args))
        else:
            return fwd()

    @implements(scale)
    @staticmethod
    def scale(obj, vec):
        if isinstance(obj, Term) and obj.op == union:
            return union(*(scale(a, vec) for a in obj.args))
        elif isinstance(obj, Term) and obj.op == intersection:
            return intersection(*(scale(a, vec) for a in obj.args))
        else:
            return fwd()

    @implements(difference)
    @staticmethod
    def difference(a, b):
        if isinstance(a, Term) and a.op == intersection:
            return intersection(difference(a.args[0], b), *a.args[1:])
        else:
            return fwd()


class FlattenLogicalOps(ObjectInterpretation):
    """
    An interpretation to flatten nested unions and intersections.
    This is useful to reduce the depth of the expression tree, which
    can help other interpretations like LogicalsOutward to do their job.
    """

    @implements(union)
    @staticmethod
    def union(*children):
        if any(isinstance(c, Term) and c.op is union for c in children):
            return union(
                *(
                    cc
                    for c in children
                    for cc in (c.args if isinstance(c, Term) and c.op is union else [c])
                )
            )
        else:
            return fwd()

    @implements(intersection)
    @staticmethod
    def intersection(*children):
        if any(isinstance(c, Term) and c.op is intersection for c in children):
            return intersection(
                *(
                    cc
                    for c in children
                    for cc in (
                        c.args if isinstance(c, Term) and c.op is intersection else [c]
                    )
                )
            )
        else:
            return fwd()


class NormalizeTransforms(ObjectInterpretation):
    """
    An interpretation to move transforms into a translate(rotate(scale(...)))
    normal form.  When converting to the mujoco format, we can recognize
    translate(rotate(scale(primitive))) and output a primitive mujoco geom
    with those transformations applied to it. Specifically, the rotation
    and translation can go into the geom's pos and quat attributes. Scaling
    can often be implemented by modifying shape parameters.
    """

    @implements(translate)
    @staticmethod
    def translate(g, pos):
        if isinstance(g, Term) and g.op is translate:
            g2, pos2 = g.args
            return translate(g2, jnp.asarray(pos) + jnp.asarray(pos2))
        else:
            return fwd()

    @implements(rotate)
    @staticmethod
    def rotate(g, rot):
        if isinstance(g, Term) and g.op is translate:
            g2, pos2 = g.args
            return translate(rotate(g2, rot), rot.apply(jnp.asarray(pos2)))
        elif isinstance(g, Term) and g.op is rotate:
            g2, rot2 = g.args
            return rotate(g2, rot * rot2)
        else:
            return fwd()

    @implements(scale)
    @staticmethod
    def scale(g, scl):
        if isinstance(g, Term) and g.op is translate:
            g2, pos2 = g.args
            return translate(scale(g2, scl), jnp.asarray(scl) * jnp.asarray(pos2))
        elif isinstance(g, Term) and g.op is rotate and all(s == scl[0] for s in scl):
            g2, rot2 = g.args
            return rotate(scale(g2, scl), rot2)
        elif isinstance(g, Term) and g.op is scale:
            g2, scl2 = g.args
            return scale(g2, jnp.asarray(scl) * jnp.asarray(scl2))
        else:
            return fwd()

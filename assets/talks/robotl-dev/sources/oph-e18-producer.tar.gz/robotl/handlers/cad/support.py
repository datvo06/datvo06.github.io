"""Support function handler module for RoboTL.

This file implements a convex support function backend that mirrors the public API
of the existing CAD handler.  For a convex shape S, the support function is defined as

    h(n) = max_{x ∈ S}  n · x

and gives the signed extent of S in direction n.  Support functions enable efficient
non-overlap testing between convex shapes: two shapes with support functions h₁ and h₂
are separated if and only if there exists a unit vector n such that

    h₁(n) + h₂(−n) ≤ 0

Support functions compose cleanly with rigid transforms:

    h_{R,t}(n) = h(Rᵀ n) + t · n

and with convex hull unions:

    h_{A ∪ B}(n) = max(h_A(n), h_B(n))
"""

from __future__ import annotations

import dataclasses
import functools
from collections.abc import Callable
from typing import Any, Concatenate, Self

import effectful.handlers.jax.numpy as jnp
import effectful.handlers.numpyro as dist
import jax
from effectful.ops.semantics import evaluate, handler
from effectful.ops.syntax import ObjectInterpretation, defop, implements
from effectful.ops.types import NotHandled, Term
from jax.scipy.spatial.transform import Rotation

from robotl.internals.utils import Polygon
from robotl.ops import shapes
from robotl.ops.losses import Loss, Maximize
from robotl.ops.syntax import Component, choose


@defop
def rot_inv(rot):
    if isinstance(rot, Term):
        raise NotHandled
    return rot.inv()


@defop
def rot_apply(rot, n) -> jax.Array:
    if isinstance(rot, Term) or isinstance(n, Term):
        raise NotHandled
    return rot.apply(n)


@dataclasses.dataclass(frozen=True)
class SupportShape[**P](shapes.Shape):
    """Concrete wrapper for a convex support function.

    Instances are created via the :meth:`define` classmethod, which turns an ordinary
    Python callable ``fn(n, *args, **kwargs)`` into a shape object that satisfies the
    :class:`robotl.ops.shapes.Shape` protocol.  The wrapped function is invoked with
    a unit direction vector ``n`` of shape ``(..., 3)`` and must return the support
    value (a scalar per direction) as a JAX array.
    """

    _fn: Callable[Concatenate[jax.Array, P], jax.Array]
    _args_kwargs: tuple[tuple, tuple[tuple[str, Any], ...]]

    def __add__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.union(self, other)

    def __radd__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.union(other, self)

    def __and__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.intersection(self, other)

    def __rand__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.intersection(other, self)

    def __sub__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.difference(self, other)

    def __rsub__(self, other: shapes.Shape) -> shapes.Shape:
        return shapes.difference(other, self)

    def __call__(self, n: jax.Array) -> jax.Array:
        """Return the support value for direction(s) *n*.

        Parameters
        ----------
        n : jax.typing.ArrayLike
            Array of unit direction vectors with trailing dimension 3.
        """
        args, kwargs = self._args_kwargs
        return self._fn(n, *args, **dict(kwargs))

    @classmethod
    def define(
        cls: type[Self],
        fn: Callable[Concatenate[jax.Array, P], jax.Array],
    ) -> Callable[P, Self]:
        """Define a new support function shape from a function."""

        @functools.wraps(fn)
        def wrapper(*args: P.args, **kwargs: P.kwargs):
            return cls(fn, (args, tuple(kwargs.items())))

        return wrapper


class ShapeToSupport(ObjectInterpretation):
    """Handler that interprets shape operations as convex support functions.

    Each method returns an instantiated ``SupportShape`` that can be called with
    JAX arrays of unit direction vectors.  The support function h(n) returns the
    maximum projection of the shape onto direction n.

    For non-convex shapes (intersection, difference), the support function is a
    conservative overapproximation (the support of the convex hull).
    """

    # -------------------------- external mesh fallback --------------------------
    @implements(shapes.external_mesh)
    def external_mesh_support(self, path: str):
        raise NotImplementedError(
            "external_mesh is not supported by the support function backend."
        )

    @implements(shapes.mesh)
    def mesh_support(self, m):
        raise NotImplementedError(
            "mesh is not supported by the support function backend."
        )

    # -------------------------- primitives --------------------------
    @implements(shapes.cube)
    @staticmethod
    @SupportShape.define
    def cube_support(n: jax.Array, dx: float, dy: float, dz: float) -> jax.Array:
        r"""Support function for an axis-aligned box with corner at origin.

        The box occupies [0, dx] × [0, dy] × [0, dz].  Its center is at
        (dx/2, dy/2, dz/2) with half-extents (dx/2, dy/2, dz/2).

        .. math::

            h(\mathbf{n}) = \mathbf{c} \cdot \mathbf{n}
                          + \tfrac{dx}{2}|n_x| + \tfrac{dy}{2}|n_y| + \tfrac{dz}{2}|n_z|

        where :math:`\mathbf{c} = (dx/2, dy/2, dz/2)` is the center.
        """
        c = jnp.asarray([dx, dy, dz]) / 2.0
        half = c
        return jnp.sum(c * n, axis=-1) + jnp.sum(half * jnp.abs(n), axis=-1)

    @implements(shapes.sphere)
    @staticmethod
    @SupportShape.define
    def sphere_support(n: jax.Array, r: float) -> jax.Array:
        r"""Support function for a sphere centered at the origin.

        .. math::

            h(\mathbf{n}) = r \|\mathbf{n}\|

        For unit :math:`\mathbf{n}` this is simply :math:`r`.
        """
        return r * jnp.linalg.norm(n, axis=-1)

    @implements(shapes.cylinder)
    @staticmethod
    @SupportShape.define
    def cylinder_support(
        n: jax.Array, *, r: float, h: float, r2: float | None = None
    ) -> jax.Array:
        r"""Support function for a capped cone with base at origin along Z.

        For a cylinder (r2 is None or equal to r) occupying z ∈ [0, h] with
        radius r:

        .. math::

            h(\mathbf{n}) = r \sqrt{n_x^2 + n_y^2} + \max(0,\; h \, n_z)

        For a cone (r2 ≠ r), the support is the maximum over the two circular
        end-caps:

        .. math::

            h(\mathbf{n}) = \max\!\bigl(
                r_1 \sqrt{n_x^2 + n_y^2},\;
                r_2 \sqrt{n_x^2 + n_y^2} + h \, n_z
            \bigr)
        """
        r1 = r
        if r2 is None:
            r2 = r

        n_radial = jnp.linalg.norm(n[..., :2], axis=-1)
        n_z = n[..., 2]

        # Support of bottom cap (center at origin, radius r1)
        h_bottom = r1 * n_radial

        # Support of top cap (center at (0,0,h), radius r2)
        h_top = r2 * n_radial + h * n_z

        return jnp.maximum(h_bottom, h_top)

    @implements(shapes.capsule)
    @staticmethod
    @SupportShape.define
    def capsule_support(n: jax.Array, *, r: float, h: float) -> jax.Array:
        r"""Support function for a capsule along Z with endpoints at 0 and h.

        A capsule is the Minkowski sum of the line segment [0, h]·ẑ and a
        sphere of radius r.  The support of a Minkowski sum is the sum of
        supports:

        .. math::

            h(\mathbf{n}) = \max(0,\; h \, n_z) + r \|\mathbf{n}\|
        """
        n_z = n[..., 2]
        return jnp.maximum(0.0, h * n_z) + r * jnp.linalg.norm(n, axis=-1)

    @implements(shapes.extrude)
    @staticmethod
    @SupportShape.define
    def extrude_support(n: jax.Array, polygon: Polygon, h: float) -> jax.Array:
        r"""Support for a polygon extruded along +Z over z in [0, h].

        The prism is the Minkowski sum of the polygon and the segment
        [0, h]·ẑ, and the polygon's support is the maximum over its
        vertices:

        .. math::

            h(\mathbf{n}) = \max_i (n_x x_i + n_y y_i) + \max(0,\; h \, n_z)

        Exact for a convex outline; for a nonconvex one this is the support
        of its convex hull, a conservative overapproximation like
        :func:`difference_support`.
        """
        v = jnp.asarray(polygon.points, dtype=float)
        h_poly = jnp.max(n[..., :2] @ v.T, axis=-1)
        return h_poly + jnp.maximum(0.0, h * n[..., 2])

    @implements(shapes.revolve)
    @staticmethod
    @SupportShape.define
    def revolve_support(n: jax.Array, polygon: Polygon) -> jax.Array:
        r"""Support for a polygon revolved about the +Z axis.

        The farthest point in direction :math:`\mathbf{n}` lies in the
        meridian plane containing :math:`(n_x, n_y)`, where a vertex at
        (radial, axial) = :math:`(r_i, z_i)` contributes:

        .. math::

            h(\mathbf{n}) = \max_i \bigl(r_i \sqrt{n_x^2 + n_y^2} + z_i n_z\bigr)

        Exact for a convex meridian outline; for a nonconvex one this is the
        support of its revolved convex hull, a conservative
        overapproximation like :func:`difference_support`.
        """
        v = jnp.asarray(polygon.points, dtype=float)
        n_radial = jnp.linalg.norm(n[..., :2], axis=-1)
        return jnp.max(
            n_radial[..., None] * v[:, 0] + n[..., 2, None] * v[:, 1], axis=-1
        )

    @implements(shapes.plane)
    @staticmethod
    @SupportShape.define
    def plane_support(n: jax.Array) -> jax.Array:
        r"""Support function for an infinite plane at z=0.

        The plane is unbounded, so the support is infinite for any direction
        with a nonzero lateral component.  Planes should not appear in
        non-overlap constraints.
        """
        return jnp.where(
            (n[..., 0] == 0.0) & (n[..., 1] == 0.0) & (n[..., 2] <= 0.0),
            0.0,
            jnp.inf,
        )

    # -------------------------- boolean ops --------------------------
    @implements(shapes.union)
    @staticmethod
    @SupportShape.define
    def union_support(n: jax.Array, *support_shapes: SupportShape) -> jax.Array:
        r"""Support of the convex hull of the union.

        .. math::

            h_{A \cup B}(\mathbf{n}) = \max\bigl(h_A(\mathbf{n}), h_B(\mathbf{n})\bigr)
        """
        return functools.reduce(jnp.maximum, [s(n) for s in support_shapes])

    @implements(shapes.intersection)
    @staticmethod
    @SupportShape.define
    def intersection_support(n: jax.Array, *support_shapes: SupportShape) -> jax.Array:
        r"""Conservative support for the intersection.

        The intersection A ∩ B ⊆ A and A ∩ B ⊆ B, so

        .. math::

            h_{A \cap B}(\mathbf{n}) \le \min\bigl(h_A(\mathbf{n}), h_B(\mathbf{n})\bigr)

        This upper bound is not itself a valid support function (min of convex
        functions is not convex), but it is a safe overapproximation for
        non-overlap checking.
        """
        return functools.reduce(jnp.minimum, [s(n) for s in support_shapes])

    @implements(shapes.difference)
    @staticmethod
    @SupportShape.define
    def difference_support(
        n: jax.Array, shape1: SupportShape, shape2: SupportShape
    ) -> jax.Array:
        r"""Conservative support for the set difference.

        The difference A \ B ⊆ A, so we use A's support as an overapproximation:

        .. math::

            h_{A \setminus B}(\mathbf{n}) \le h_A(\mathbf{n})
        """
        return shape1(n)

    # -------------------------- transforms --------------------------
    @implements(shapes.translate)
    @staticmethod
    @SupportShape.define
    def translate_support(
        n: jax.Array, shape: SupportShape, vec: jax.Array
    ) -> jax.Array:
        r"""Support under translation.

        .. math::

            h_{\text{translated}}(\mathbf{n}) = h(\mathbf{n}) + \mathbf{v} \cdot \mathbf{n}
        """
        return shape(n) + jnp.sum(jnp.asarray(vec) * n, axis=-1)

    @implements(shapes.rotate)
    @staticmethod
    @SupportShape.define
    def rotate_support(n: jax.Array, shape: SupportShape, rot: Rotation) -> jax.Array:
        r"""Support under rotation.

        .. math::

            h_{\text{rotated}}(\mathbf{n}) = h(R^{-1} \mathbf{n})
        """
        inv_rot = rot_inv(rot)
        n_rot = rot_apply(inv_rot, n)
        return shape(n_rot)

    @implements(shapes.scale)
    @staticmethod
    @SupportShape.define
    def scale_support(n: jax.Array, shape: SupportShape, vec: jax.Array) -> jax.Array:
        r"""Support under scaling.

        For scaling by :math:`\mathbf{s}`, the support function of the scaled
        shape satisfies:

        .. math::

            h_{\text{scaled}}(\mathbf{n}) = h(\mathbf{s} \odot \mathbf{n})

        This follows from :math:`\max_{x} \mathbf{n} \cdot (\mathbf{s} \odot x)
        = \max_{x} (\mathbf{s} \odot \mathbf{n}) \cdot x`.
        """
        scaled_n = jnp.asarray(vec) * n
        return shape(scaled_n)

    @implements(shapes.decompose)
    def decompose_support(self, x: SupportShape, *, max_parts: int = 8) -> SupportShape:
        # ``decompose`` only affects collision emission; the support is that of ``x``.
        return x


def non_overlap(c1: Component, c2: Component, weight=1e4) -> Loss:
    """Loss function that penalizes overlap between the shapes of components c1
    and c2.

    """
    with handler(ShapeToSupport()):
        s1 = shapes.transform(evaluate(c1.shape), c1.pose)  # type: ignore
        s2 = shapes.transform(evaluate(c2.shape), c2.pose)  # type: ignore

    theta = choose(dist.Uniform(0, jnp.pi))
    phi = choose(dist.Uniform(0, 2 * jnp.pi))
    n = jnp.array(
        [
            jnp.sin(theta) * jnp.cos(phi),
            jnp.sin(theta) * jnp.sin(phi),
            jnp.cos(theta),
        ]
    )
    return Maximize(jnp.sum(jnp.maximum(s1(n) + s2(-n), 0.0) ** 2), weight=weight)  # type: ignore

import collections.abc
import functools
import itertools
import operator
import pathlib
import shutil
import subprocess
import tempfile

import jax
import solid2
from effectful.ops.semantics import evaluate, fwd, handler
from effectful.ops.syntax import ObjectInterpretation, implements
from effectful.ops.types import Term
from solid2.core.object_base import OpenSCADObject

import robotl.ops.shapes as shapes
from robotl.handlers.cad.decomposition import decompose_mesh_to_convex_parts
from robotl.internals.utils import Mesh, Polygon

if not shutil.which("openscad"):
    raise ImportError("The OpenSCAD CLI is required to use robotl.handlers.mujoco.")


shapes.Shape.register(OpenSCADObject)


def _concrete_impl[**P, T](
    fn: collections.abc.Callable[P, T],
) -> collections.abc.Callable[P, T]:
    @functools.wraps(fn)
    def wfn(*args, **kwargs):
        if any(isinstance(x, Term) for x in jax.tree.leaves((args, kwargs))):
            return fwd()
        return fn(*args, **kwargs)

    return wfn


def _arrayfree[**P, T](
    solid2_fn: collections.abc.Callable[P, T],
) -> collections.abc.Callable[P, T]:
    # solid2 does not handle jax arrays, including scalars boxed in ndim=0 arrays
    @functools.wraps(solid2_fn)
    def fn(*args: P.args, **kwargs: P.kwargs):
        [args, kwargs] = jax.tree.map(
            lambda x: x.tolist() if isinstance(x, jax.Array) else x, [args, kwargs]
        )
        return solid2_fn(*args, **kwargs)

    return fn


class ShapeToOpenSCAD(ObjectInterpretation):
    """Handler for the OpenSCAD/solid2 mesh backend.

    Each method returns an ``OpenSCADObject`` (from the solid2 library) that can be
    combined with boolean operations and transformations, then exported to STL mesh
    format via :func:`solid2_to_mesh`. The interpreter implements the shape API
    defined in :mod:`robotl.ops.shapes`.

    Coordinate system conventions (matching OpenSCAD defaults):

    - **cube**: Corner at the origin, extends into the positive octant.
    - **sphere**: Centered at the origin.
    - **cylinder/cone**: Base centered at the origin (z=0), extends along +Z to z=h.
    - **capsule**: Hemispherical cap centered at z=0, cylindrical body from z=0 to
      z=h, hemispherical cap centered at z=h.

    See Also
    --------
    solid2_to_mesh : Export an OpenSCADObject to an STL mesh file.
    ShapeToSDF : The pure-SDF backend with analytical distance fields.
    """

    @implements(shapes.cube)
    @staticmethod
    @functools.wraps(solid2.cube)
    @_concrete_impl
    @_arrayfree
    def cube(dx, dy, dz):
        return solid2.cube(dx, dy, dz)

    @implements(shapes.sphere)
    @staticmethod
    @functools.wraps(solid2.sphere)
    @_concrete_impl
    @_arrayfree
    def sphere(r):
        return solid2.sphere(r=r)

    @implements(shapes.cylinder)
    @staticmethod
    @functools.wraps(solid2.cylinder)
    @_concrete_impl
    @_arrayfree
    def cylinder(*, r: float, h: float, r2: float | None = None):
        return solid2.cylinder(r=r, h=h, r2=r2 if r2 is not None else r)

    @implements(shapes.capsule)
    @staticmethod
    @_concrete_impl
    @_arrayfree
    def capsule(*, r, h):
        # Bottom sphere at z=0, cylinder from z=0 to z=h, top sphere at z=h
        bottom_cap = shapes.sphere(r)
        body = shapes.cylinder(r=r, h=h)
        top_cap = shapes.translate(shapes.sphere(r), [0, 0, h])
        return bottom_cap + body + top_cap

    @implements(shapes.extrude)
    @staticmethod
    @_concrete_impl
    @_arrayfree
    def extrude(polygon: Polygon, h: float):
        return solid2.polygon(polygon.points).linear_extrude(h)

    @implements(shapes.revolve)
    @staticmethod
    @_concrete_impl
    @_arrayfree
    def revolve(polygon: Polygon):
        return solid2.polygon(polygon.points).rotate_extrude()

    @implements(shapes.external_mesh)
    @staticmethod
    @functools.wraps(solid2.import_stl)
    def external_mesh(path):
        return solid2.import_stl(path)

    @implements(shapes.mesh)
    @staticmethod
    @_concrete_impl
    def mesh(m: Mesh):
        # OpenSCAD winds polyhedron faces clockwise seen from outside, the
        # reverse of trimesh and STL; as-is faces render an inside-out solid.
        return solid2.polyhedron(
            points=m.vertices.tolist(), faces=m.faces[:, ::-1].tolist()
        )

    @implements(shapes.plane)
    @staticmethod
    def plane():
        raise RuntimeError("The `plane` geometry cannot be used in meshes.")

    @implements(shapes.union)
    @staticmethod
    @functools.wraps(solid2.union)
    @_concrete_impl
    @_arrayfree
    def union(*args):
        return functools.reduce(operator.add, args)

    @implements(shapes.intersection)
    @staticmethod
    @functools.wraps(solid2.intersection)
    @_concrete_impl
    @_arrayfree
    def intersection(*args):
        return functools.reduce(operator.and_, args)

    @implements(shapes.difference)
    @staticmethod
    @functools.wraps(solid2.difference)
    @_concrete_impl
    @_arrayfree
    def difference(a, b):
        return a - b

    @implements(shapes.translate)
    @staticmethod
    @functools.wraps(solid2.translate)
    @_concrete_impl
    @_arrayfree
    def translate(obj, vec):
        return obj.translate(vec)

    @implements(shapes.rotate)
    @staticmethod
    @functools.wraps(solid2.rotate)
    @_concrete_impl
    @_arrayfree
    def rotate(obj, rot):
        return obj.rotate(rot.as_euler("xyz", degrees=True).tolist())

    @implements(shapes.scale)
    @staticmethod
    @functools.wraps(solid2.scale)
    @_concrete_impl
    @_arrayfree
    def scale(obj, vec):
        return obj.scale(vec)

    @implements(shapes.decompose)
    @staticmethod
    def decompose(x, *, max_parts: int = 8):
        # ``decompose`` only affects collision emission; meshing renders ``x``.
        return x


class DecomposeToMeshes(ObjectInterpretation):
    """Rewrite ``decompose(x)`` into a union of ``mesh`` terms, one per COACD part.

    The MuJoCo compiler evaluates a component's collision shape under this
    handler once, and the resulting term feeds both the inertia and the
    geoms, so a shape is rendered and decomposed a single time per compile.
    The hulls are closed, so their integrals are exact even when ``x`` is an
    open scan, and each one collides as itself, so a nonconvex shape keeps
    its concavity instead of collapsing to its convex hull.

    :param name: Prefix for the rendered mesh files.
    """

    def __init__(self, name: str):
        self.name = name
        self._counter = itertools.count()

    @implements(shapes.decompose)
    def decompose(self, x: shapes.Shape, *, max_parts: int = 8) -> shapes.Shape:
        name = f"{self.name}_decompose{next(self._counter)}"
        parts = render_convex_parts(x, name, max_parts=max_parts)
        return shapes.union(*(shapes.mesh(part) for part in parts))


def render_convex_parts(x: shapes.Shape, name: str, *, max_parts: int) -> list[Mesh]:
    """Render ``x`` through OpenSCAD and split the mesh into convex parts with COACD.

    :param x: The shape to decompose; every op in it needs an OpenSCAD handler.
    :param name: Prefix of the rendered scad and STL files under ``build/scad``.
    :param max_parts: Convex part budget handed to COACD.
    """
    with handler(ShapeToOpenSCAD()):
        model = evaluate(x)  # type: ignore[arg-type]
    assert isinstance(model, OpenSCADObject)
    stl = solid2_to_mesh(model, name)
    return decompose_mesh_to_convex_parts(stl, max_parts=max_parts)


def solid2_to_mesh(
    model: OpenSCADObject,
    name: str,
    *,
    path: pathlib.Path = pathlib.Path("build/scad"),
    fs: float = 0.005,
    fa: float = 1,
    fn: int = 0,
) -> pathlib.Path:
    """Render an OpenSCAD object to a binary STL file.

    :param fs: OpenSCAD ``$fs``, the largest chord a curved surface facet may
        span, in model units. Model units are metres, so the default is a
        5 mm chord; OpenSCAD's own default of 2 would floor every cylinder
        and sphere at its 5-fragment minimum.
    :param fa: OpenSCAD ``$fa``, the largest angle one fragment may subtend.
    :param fn: OpenSCAD ``$fn``, a fixed fragment count overriding ``fs`` and
        ``fa`` when nonzero.
    """
    assert isinstance(model, OpenSCADObject)

    solid2.set_global_fs(fs)
    solid2.set_global_fa(fa)
    solid2.set_global_fn(fn)

    # convert geometry to mesh through openscad
    path.mkdir(parents=True, exist_ok=True)
    filename_in, filename_out = path / (name + ".scad"), path / (name + ".stl")
    model.save_as_scad(str(filename_in))
    # Callers reuse an existing STL as a cache, so OpenSCAD writes a sibling
    # that is moved in only once complete; an interrupted export leaves no
    # truncated mesh under the final name.
    with tempfile.TemporaryDirectory(dir=path) as scratch:
        partial = pathlib.Path(scratch) / filename_out.name
        subprocess.check_call(
            [
                "openscad",
                "--export-format",
                "binstl",
                "-o",
                partial,
                filename_in,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        partial.replace(filename_out)
    return filename_out

import typing
from dataclasses import dataclass, replace

import effectful.handlers.jax.numpy as jnp
import jax
import numpy as np
from effectful.ops.semantics import evaluate, handler
from effectful.ops.syntax import ObjectInterpretation, implements
from jax.scipy.spatial.transform import Rotation

from robotl.ops import shapes


def _vec3(x: float, y: float, z: float) -> jax.Array:
    return jnp.array([x, y, z])


type FaceName = typing.Literal["-x", "+x", "-y", "+y", "-z", "+z"]


@dataclass
class Face:
    """A planar face defined by an origin and two edge vectors.

    The face is the parallelogram with corners at origin, origin+edge1,
    origin+edge2, and origin+edge1+edge2. edge1 is the horizontal (width)
    direction and edge2 is the vertical (height) direction.

    Winding convention: edge1 and edge2 form a clockwise pair when viewed
    from outside (i.e. from the direction the outward normal points), so the
    outward normal is cross(edge2, edge1), not cross(edge1, edge2).
    """

    origin: jax.Array
    edge1: jax.Array  # horizontal direction, magnitude = width
    edge2: jax.Array  # vertical direction, magnitude = height

    @property
    def normal(self) -> jax.Array:
        """Outward-facing unit normal. CW winding means cross(edge2, edge1) points out."""
        n = jnp.cross(self.edge2, self.edge1)
        return n / jnp.linalg.norm(n)

    @property
    def center(self) -> jax.Array:
        return self.origin + (self.edge1 + self.edge2) / 2

    @property
    def lower_left(self) -> jax.Array:
        return self.origin

    @property
    def lower_right(self) -> jax.Array:
        return self.origin + self.edge1

    @property
    def upper_left(self) -> jax.Array:
        return self.origin + self.edge2

    @property
    def upper_right(self) -> jax.Array:
        return self.origin + self.edge1 + self.edge2

    @property
    def height(self) -> float:
        return jnp.linalg.norm(self.edge2)

    @property
    def width(self) -> float:
        return jnp.linalg.norm(self.edge1)


class ShapeToFace(ObjectInterpretation):
    def __init__(self, face_name: FaceName):
        super().__init__()
        self._face_name = face_name

    @implements(shapes.cube)
    def cube_face(self, dx: float, dy: float, dz: float) -> Face:
        match self._face_name:
            case "-x":
                origin = _vec3(0, 0, 0)
                edge1 = _vec3(0, dy, 0)
                edge2 = _vec3(0, 0, dz)
            case "+x":
                origin = _vec3(dx, 0, 0)
                edge1 = _vec3(0, 0, dz)
                edge2 = _vec3(0, dy, 0)
            case "-y":
                origin = _vec3(0, 0, 0)
                edge1 = _vec3(0, 0, dz)
                edge2 = _vec3(dx, 0, 0)
            case "+y":
                origin = _vec3(0, dy, 0)
                edge1 = _vec3(dx, 0, 0)
                edge2 = _vec3(0, 0, dz)
            case "-z":
                origin = _vec3(0, 0, 0)
                edge1 = _vec3(dx, 0, 0)
                edge2 = _vec3(0, dy, 0)
            case "+z":
                origin = _vec3(0, 0, dz)
                edge1 = _vec3(0, dy, 0)
                edge2 = _vec3(dx, 0, 0)
            case _:
                raise ValueError("Unexpected face name", self._face_name)

        return Face(origin, edge1, edge2)

    @implements(shapes.translate)
    def translate_face(self, s, v: np.typing.ArrayLike) -> Face:
        if not isinstance(s, Face):
            raise ValueError("Expected a Face but got", s)
        return replace(s, origin=s.origin + jnp.asarray(v))

    @implements(shapes.rotate)
    def rotate_face(self, s, r: Rotation):
        if not isinstance(s, Face):
            raise ValueError("Expected a Face but got", s)
        return replace(
            s, origin=r.apply(s.origin), edge1=r.apply(s.edge1), edge2=r.apply(s.edge2)
        )

    @implements(shapes.scale)
    def scale_face(self, s, v: np.typing.ArrayLike) -> Face:
        if not isinstance(s, Face):
            raise ValueError("Expected a Face but got", s)
        v = jnp.asarray(v)
        return replace(s, origin=s.origin * v, edge1=s.edge1 * v, edge2=s.edge2 * v)


def face(shape: shapes.Shape, face_name: FaceName) -> Face:
    result = handler(ShapeToFace(face_name))(evaluate)(shape)  # type: ignore[arg-type]
    assert isinstance(result, Face)
    return result

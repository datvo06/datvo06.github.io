from __future__ import annotations

from pathlib import Path

import coacd
import effectful.handlers.jax.numpy as jnp
import numpy as np
import trimesh

from robotl.internals.utils import Mesh


def as_trimesh(
    mesh_or_path: str | Path | trimesh.Trimesh | trimesh.Scene,
) -> trimesh.Trimesh:
    # ``concatenate``/``load_mesh`` are typed to return the ``Geometry`` base;
    # the ``isinstance`` guard below narrows back to ``Trimesh`` before return.
    mesh: trimesh.Geometry
    if isinstance(mesh_or_path, trimesh.Trimesh):
        mesh = mesh_or_path
    elif isinstance(mesh_or_path, trimesh.Scene):
        mesh = trimesh.util.concatenate(tuple(mesh_or_path.geometry.values()))
    else:
        mesh = trimesh.load_mesh(mesh_or_path, force="mesh")
        # Some trimesh versions ignore force="mesh" for multi-part formats.
        if isinstance(mesh, trimesh.Scene):
            mesh = trimesh.util.concatenate(tuple(mesh.geometry.values()))

    if not isinstance(mesh, trimesh.Trimesh):
        raise TypeError(f"Expected a trimesh.Trimesh, got {type(mesh)!r}")

    mesh = mesh.copy()
    mesh.process(validate=True)
    if len(mesh.faces) == 0:
        raise ValueError("Mesh has no faces after cleanup")
    return mesh


def decompose_mesh_to_convex_parts(
    mesh_or_path: str | Path | trimesh.Trimesh | trimesh.Scene,
    *,
    max_parts: int = 8,
    coacd_kwargs: dict[str, object] | None = None,
) -> list[Mesh]:
    """Decompose a mesh into convex parts with COACD."""

    mesh = as_trimesh(mesh_or_path)
    kwargs = dict(coacd_kwargs or {})
    kwargs["max_convex_hull"] = max_parts  # max_parts always takes precedence
    coacd_mesh = coacd.Mesh(np.asarray(mesh.vertices), np.asarray(mesh.faces))
    parts = coacd.run_coacd(coacd_mesh, **kwargs)
    return [
        Mesh(vertices=jnp.asarray(vertices), faces=jnp.asarray(faces))
        for vertices, faces in parts[:max_parts]  # defensive: COACD may exceed budget
    ]

"""Offscreen rendering (single frames, trajectories, mp4 writing) and image
degradation/encoding for camera-based virtual sensors."""

import dataclasses
import math
import queue
import threading
import weakref
from collections.abc import Callable
from concurrent.futures import Future
from copy import deepcopy
from functools import partial
from pathlib import Path
from typing import cast, final

import jax
import mediapy
import mujoco
import numpy as np
import torch
from effectful.handlers.jax import numpy as jnp
from effectful.ops.syntax import defop
from effectful.ops.types import NotHandled, Term
from mujoco import gl_context

from robotl.ops.coords import Image

from .process import EnvSpec, EnvState
from .types import Camera


def draw_fixed_tendons(
    model: mujoco.MjModel, data: mujoco.MjData, scene: mujoco.MjvScene
) -> None:
    """Add every fixed tendon to ``scene`` through the joints it crosses.

    A fixed tendon couples joint angles and has no path of its own, so each
    joint it crosses is drawn as a point off the joint axis at the tendon's
    moment arm: on the side that shortens it as the joint turns positively
    when the arm is negative, and opposite otherwise. The side is measured
    against the direction from the joint to its body's centre of mass. A body
    that turns about its centre of mass, like a motor spool, uses instead its
    frame axis most orthogonal to the joint's local axis, so the spool's point
    sits on the spool at its radius and turns with it. A cable entering a
    serial chain from outside it, like a flexor from a motor spool, also
    threads every body of that chain it passes on the way in, up to the body
    the chain branches from (a palm carrying several fingers): through each
    body's joint, or its origin when it is welded, so it runs the metacarpal
    from its base rather than jumping to the knuckle. A tendon on one joint is
    drawn as its moment arm from the joint.
    Widths and colours come from ``tendon_width`` and ``tendon_rgba``; a fully
    transparent one is skipped, which is how the compiler leaves a fixed
    tendon that couples joints without being a cable. MuJoCo draws spatial
    tendons itself.
    """

    def lineage(body: int) -> list[int]:
        bodies = [body]
        while bodies[-1] != 0:
            bodies.append(int(model.body_parentid[bodies[-1]]))
        return bodies

    children = np.bincount(model.body_parentid[1:], minlength=model.nbody)

    def entry(body: int) -> np.ndarray:
        if model.body_jntnum[body] > 0:
            return data.xanchor[model.body_jntadr[body]]
        return data.xpos[body]

    for t in range(model.ntendon):
        start, count = model.tendon_adr[t], model.tendon_num[t]
        if (
            model.wrap_type[start] != mujoco.mjtWrap.mjWRAP_JOINT
            or model.tendon_rgba[t][3] == 0
        ):
            continue
        points: list[np.ndarray] = []
        previous: int | None = None
        for w in range(start, start + count):
            joint, arm = int(model.wrap_objid[w]), float(model.wrap_prm[w])
            body = int(model.jnt_bodyid[joint])
            axis, anchor = data.xaxis[joint], data.xanchor[joint]
            side = np.cross(axis, data.xipos[body] - anchor)
            norm = np.linalg.norm(side)
            if norm < 1e-9:  # centre of mass on the axis
                frame = data.xmat[body].reshape(3, 3)
                local = np.argmin(np.abs(model.jnt_axis[joint]))
                side = np.cross(axis, frame[:, local])
                norm = np.linalg.norm(side)
            offset = -arm * side / norm
            if previous is not None:
                visited = set(lineage(previous))
                entered = []
                for ancestor in lineage(body)[1:]:
                    if ancestor in visited or children[ancestor] > 1:
                        break
                    entered.append(ancestor)
                for passed in reversed(entered):
                    point = entry(passed) + offset
                    # A welded body often starts where its parent's joint is.
                    if np.linalg.norm(point - points[-1]) > 1e-9:
                        points.append(point)
            points.append(anchor + offset)
            previous = body
        if count == 1:
            points.insert(0, data.xanchor[int(model.wrap_objid[start])])
        for a, b in zip(points[:-1], points[1:]):
            if scene.ngeom >= scene.maxgeom:
                raise RuntimeError(
                    f"render scene is full ({scene.maxgeom} geoms); "
                    "too many tendon segments to draw"
                )
            geom = scene.geoms[scene.ngeom]
            mujoco.mjv_initGeom(
                geom,
                mujoco.mjtGeom.mjGEOM_CAPSULE,
                np.zeros(3),
                np.zeros(3),
                np.zeros(9),
                model.tendon_rgba[t].astype(np.float32),
            )
            mujoco.mjv_connector(
                geom,
                mujoco.mjtGeom.mjGEOM_CAPSULE,
                float(model.tendon_width[t]),
                a,
                b,
            )
            scene.ngeom += 1


@final
@dataclasses.dataclass(eq=False)
class _Worker:
    # the GL state of one render thread, which it never leaves
    model: mujoco.MjModel
    gl: gl_context.GLContext
    """The ``mujoco.gl_context.GLContext`` (GLFW, EGL, OSMesa or CGL)."""
    con: mujoco.MjrContext
    scene: mujoco.MjvScene
    flags: np.ndarray
    """``scene``'s default render flags, restored before each frame."""
    data: mujoco.MjData

    @classmethod
    def make(cls, model: mujoco.MjModel, gl_model: mujoco.MjModel) -> "_Worker":
        gl = gl_context.GLContext(
            model.vis.global_.offwidth, model.vis.global_.offheight
        )
        gl.make_current()
        con = mujoco.MjrContext(gl_model, mujoco.mjtFontScale.mjFONTSCALE_150)
        mujoco.mjr_setBuffer(mujoco.mjtFramebuffer.mjFB_OFFSCREEN, con)
        scene = mujoco.MjvScene(model, maxgeom=10000)
        return cls(model, gl, con, scene, scene.flags.copy(), mujoco.MjData(model))

    def render(
        self,
        state: tuple[np.ndarray, ...],
        *,
        camera: Camera | int | str | None,
        height: int,
        width: int,
        fast: bool,
        scene_option: mujoco.MjvOption | None,
    ) -> np.ndarray:
        m, d, con = self.model, self.data, self.con
        d.qpos, d.qvel, d.mocap_pos, d.mocap_quat, d.ctrl = state
        mujoco.mj_forward(m, d)
        camera = Camera() if camera is None else camera
        if isinstance(camera, Camera):
            cam = camera.to_mujoco(m)
        else:
            cam = mujoco.MjvCamera()
            cam.type = mujoco.mjtCamera.mjCAMERA_FIXED
            cam.fixedcamid = (
                mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_CAMERA, camera)
                if isinstance(camera, str)
                else camera
            )
            if not 0 <= cam.fixedcamid < m.ncam:
                raise ValueError(f"no camera {camera!r} in the model")
        option = scene_option or mujoco.MjvOption()
        mujoco.mjv_updateScene(
            m, d, option, None, cam, mujoco.mjtCatBit.mjCAT_ALL, self.scene
        )
        if option.flags[mujoco.mjtVisFlag.mjVIS_TENDON]:
            draw_fixed_tendons(m, d, self.scene)
        flags = self.scene.flags
        flags[:] = self.flags  # undo the last request's
        if fast:
            flags[mujoco.mjtRndFlag.mjRND_SHADOW] = 0
            flags[mujoco.mjtRndFlag.mjRND_REFLECTION] = 0
            flags[mujoco.mjtRndFlag.mjRND_SKYBOX] = 0
        s = 1 if fast else 2  # supersampling factor
        h, w = s * height, s * width
        if h > con.offHeight or w > con.offWidth:
            mujoco.mjr_resizeOffscreen(max(w, con.offWidth), max(h, con.offHeight), con)
            mujoco.mjr_setBuffer(mujoco.mjtFramebuffer.mjFB_OFFSCREEN, con)
        rect = mujoco.MjrRect(0, 0, w, h)
        mujoco.mjr_render(rect, self.scene, con)
        out = np.empty([h, w, 3], np.uint8)
        mujoco.mjr_readPixels(out, None, rect, con)
        out = np.flipud(out)  # GL rows run bottom up
        if s > 1:
            out = out.reshape(height, s, width, s, 3).sum((1, 3), dtype=np.uint16)
            out = ((out + s * s // 2) // (s * s)).astype(np.uint8)
        return out

    def free(self) -> None:
        self.con.free()
        self.gl.free()  # type: ignore[attr-defined]


type _Job = tuple[Future[np.ndarray], Callable[[_Worker], np.ndarray]]

# GLFW cannot create contexts concurrently
_creating = threading.Lock()


def _serve(
    jobs: "queue.SimpleQueue[_Job | None]",
    model: mujoco.MjModel,
    gl_model: mujoco.MjModel,
    ready: Future[None],
) -> None:
    # a render thread: make a context, render jobs until told to stop, free the
    # context. Holds no reference to its Renderer, so that can be collected
    try:
        with _creating:
            worker = _Worker.make(model, gl_model)
    except BaseException as e:
        ready.set_exception(e)
        return
    ready.set_result(None)
    try:
        while (job := jobs.get()) is not None:
            future, fn = job
            if future.set_running_or_notify_cancel():
                try:
                    future.set_result(fn(worker))
                except BaseException as e:
                    future.set_exception(e)
    finally:
        worker.free()


def _stop(jobs: "queue.SimpleQueue[_Job | None]", threads: list[threading.Thread]):
    # one stop per thread, queued behind pending jobs; never waits, as gc may
    # run this on a render thread
    for _ in threads:
        jobs.put(None)


@final
@dataclasses.dataclass(eq=False)
class Renderer:
    """Offscreen renderer for one :class:`EnvSpec`, shared by everything that
    renders it.

    Each request picks its own size and quality, so one renderer serves both
    camera sensors and videos, and the spec's runner holds one by default::

        img = env.spec.runner.renderer.render(env.state, Camera(distance=2.0))

        with handler(env.intp()):
            latent = model.latent.get()  # a camera virtual sensor

    A frame is drawn into a corner of a GL context's offscreen buffer, which
    grows when a request outgrows it. Unless ``fast``, a frame is drawn at
    twice the size and averaged down, which antialiases it.

    A GL context belongs to one thread for life -- on macOS ``make_current``
    takes a CGL lock it never releases, so touching the context from anywhere
    else hangs rather than failing. So on the first render, ``workers``
    threads start, each making a context of its own, and frames queue for
    whichever is free. That is what lets a camera sensor be read from inside a
    jax callback (jax dispatches those from its own threads), and spreads a
    batch across the contexts. A renderer never used costs nothing.
    """

    spec: EnvSpec
    workers: int = 4
    """GL contexts a batch is spread across. Each holds its own copy of
    the model's meshes and textures on the GPU."""
    _jobs: "queue.SimpleQueue[_Job | None]" = dataclasses.field(
        default_factory=queue.SimpleQueue, repr=False
    )
    _threads: list[threading.Thread] = dataclasses.field(
        default_factory=list, repr=False
    )
    _closed: bool = dataclasses.field(default=False, repr=False)
    _lock: threading.Lock = dataclasses.field(
        default_factory=threading.Lock, repr=False
    )

    def __post_init__(self) -> None:
        if self.workers < 1:
            raise ValueError("Renderer workers must be positive")
        if self.spec.is_mjx:
            raise ValueError("Renderer requires a CPU MuJoCo spec")

    @classmethod
    def make(cls, spec: EnvSpec, *, workers: int = 4) -> "Renderer":
        """:param spec: The environment to render; must be CPU MuJoCo (the
        renderer cannot consume MJX state).
        :param workers: Positive number of rendering threads.
        :raises ValueError: If ``workers`` is not positive or the spec uses MJX.
        """
        renderer = cls(spec, workers)
        # stop the threads of a renderer dropped unclosed; at exit they are
        # daemons, and the process takes the contexts with it
        weakref.finalize(
            renderer, _stop, renderer._jobs, renderer._threads
        ).atexit = False  # type: ignore[misc]
        return renderer

    def _start(self) -> list[threading.Thread]:
        """The render threads, started on first call."""
        with self._lock:
            if self._closed:
                raise RuntimeError("this Renderer is closed")
            if not self._threads:
                m = cast(mujoco.MjModel, self.spec.mj_model)
                # contexts read the model only when made; without multisampling,
                # as we antialias by supersampling instead, which fast frames skip
                gl_model = deepcopy(m)
                gl_model.vis.quality.offsamples = 0
                for _ in range(self.workers):
                    ready: Future[None] = Future()
                    # a daemon, so an unclosed renderer does not hold up exit
                    thread = threading.Thread(
                        target=_serve,
                        args=(self._jobs, m, gl_model, ready),
                        name="robotl-render",
                        daemon=True,
                    )
                    thread.start()
                    try:
                        ready.result()  # raise here if the context cannot be made
                    except BaseException:
                        _stop(self._jobs, self._threads)
                        self._threads.clear()
                        raise
                    self._threads.append(thread)
            return list(self._threads)

    def render_host(
        self,
        state: EnvState,
        camera: Camera | int | str | None = None,
        *,
        height: int = 480,
        width: int = 640,
        fast: bool = False,
        scene_option: mujoco.MjvOption | None = None,
    ) -> Image:
        """Render a state to a ``[height, width, 3]`` uint8 :class:`Image`.

        A state with leading batch axes renders to ``[*batch, height, width,
        3]``, its frames spread across the workers.

        :param camera: A :class:`Camera`, or the id/name of a camera defined in
            the model; ``None`` is the default free camera.
        :param fast: Skip shadows, reflections, skybox and antialiasing, for
            sensor renders that need speed more than polish.
        :param scene_option: MuJoCo visualization flags, e.g. to draw
            rangefinder rays; ``None`` is the defaults.
        """
        arrays = [np.asarray(x) for x in self._pack(state)]
        render = partial(
            self._render_raw,
            camera=camera,
            height=height,
            width=width,
            fast=fast,
            scene_option=scene_option,
        )
        # a host render is numpy, not a device array; the box takes either
        return Image(render(*arrays))  # type: ignore[arg-type]

    def render(
        self,
        state: EnvState,
        camera: Camera | int | str | None = None,
        *,
        height: int = 480,
        width: int = 640,
        fast: bool = False,
        scene_option: mujoco.MjvOption | None = None,
    ) -> Image:
        """:meth:`render_host`, callable from inside a jax trace.

        The render still runs on the host, but as part of the traced program,
        so the jax around it batches normally and ``vmap`` hands the whole
        batch to one host call, which spreads it across the workers. jax may
        reorder or drop the call and will not deduplicate two identical ones,
        which rendering is fine with; there is no autodiff rule.
        """
        shape = (*state.t.shape, height, width, 3)
        frames = jax.pure_callback(
            partial(
                self._render_raw,
                camera=camera,
                height=height,
                width=width,
                fast=fast,
                scene_option=scene_option,
            ),
            jax.ShapeDtypeStruct(shape, jnp.uint8),
            *self._pack(state),
            vmap_method="broadcast_all",
        )
        return Image(frames)

    def _pack(self, state: EnvState) -> tuple[jax.Array, ...]:
        """The arrays :meth:`_render_raw` takes, with ``state``'s batch axes."""
        layout = self.spec.layout

        def pack(state: EnvState) -> tuple[jax.Array, ...]:
            qpos, qvel = layout.qv.pack(state.qv)
            mocap_pos, mocap_quat = layout.fixed_q.pack(state.fixed_q)
            return qpos, qvel, mocap_pos, mocap_quat, layout.u.pack(state.u)

        for _ in state.t.shape:
            pack = jax.vmap(pack)
        return pack(state)

    def _render_raw(
        self,
        qpos: np.ndarray,
        qvel: np.ndarray,
        mocap_pos: np.ndarray,
        mocap_quat: np.ndarray,
        ctrl: np.ndarray,
        *,
        camera: Camera | int | str | None,
        height: int,
        width: int,
        fast: bool,
        scene_option: mujoco.MjvOption | None,
    ) -> np.ndarray:
        """Render packed states with leading batch axes ``[*batch]`` to
        ``[*batch, height, width, 3]``, spread across the workers."""
        arrays = [np.asarray(x) for x in [qpos, qvel, mocap_pos, mocap_quat, ctrl]]
        batch = arrays[0].shape[:-1]
        n = math.prod(batch)
        states = zip(
            *[x.reshape(n, *x.shape[len(batch) :]) for x in arrays], strict=True
        )
        render = partial(
            _Worker.render,
            camera=camera,
            height=height,
            width=width,
            fast=fast,
            scene_option=scene_option,
        )
        threads = self._start()
        # a render thread waiting on its own queue would hang
        assert threading.current_thread() not in threads
        futures: list[Future[np.ndarray]] = []
        for state in states:
            futures.append(Future())
            self._jobs.put((futures[-1], partial(render, state=state)))
        frames = [f.result() for f in futures]
        return np.stack(frames).reshape(*batch, height, width, 3)

    def close(self) -> None:
        """Stop the render threads, each freeing its GL context; later renders
        raise.

        No render requests may be in flight. Complete pending JAX callbacks
        with :func:`jax.effects_barrier` before closing a traced renderer.
        """
        # idempotent, so __exit__ after an explicit close is fine
        with self._lock:
            self._closed = True
            threads = list(self._threads)
            _stop(self._jobs, threads)
            self._threads.clear()  # in place: the finalizer holds this list
        for thread in threads:
            thread.join()

    def __enter__(self) -> "Renderer":
        return self

    def __exit__(self, *exc) -> None:
        self.close()


@final
class NoRenderer:
    """Stands in for a :class:`Renderer` where nothing can render, e.g. MJX."""

    def render(self, *args, **kwargs) -> Image:
        raise NotImplementedError("this runner cannot render")

    render_host = render


def render_trajectory(
    spec: EnvSpec,
    rollout: EnvState,
    *,
    save_to: str | Path | None = None,
    max_frames: int | None = None,
    height: int = 480,
    width: int = 640,
    camera: Camera = Camera(),
    scene_option: mujoco.MjvOption | None = None,
    fast: bool = False,
) -> jax.Array:
    """Render a trajectory to an array of images through the spec's runner's
    renderer, optionally writing an mp4.

    Tendons are drawn by default, fixed ones by :func:`draw_fixed_tendons`;
    pass a ``scene_option`` with ``mjVIS_TENDON`` off to hide them.

    :param save_to: If given, also write the rendered frames to this path as
        an mp4 (parent directories are created). Off by default — pass a path
        to enable it.
    :param max_frames: If given, subsample to at most this many evenly-spaced
        frames before rendering; ``None`` renders every frame. The video frame
        rate is the sim rate ``1/timestep`` adjusted for the subsample stride.
    """
    [T] = rollout.t.shape

    stride = 1
    if max_frames is not None and T > max_frames:
        stride = -(-T // max_frames)
        rollout = jax.tree.map(lambda x: x[::stride], rollout)

    frames = spec.runner.renderer.render(
        rollout,
        camera,
        height=height,
        width=width,
        fast=fast,
        scene_option=scene_option,
    ).data

    if save_to is not None:
        save_to = Path(save_to)
        save_to.parent.mkdir(parents=True, exist_ok=True)
        fps = 1.0 / (float(spec.dt) * stride)
        mediapy.write_video(str(save_to), np.asarray(frames), fps=fps)

    return frames


# the next three are operations rather than plain functions because each branches
# on ``shape`` or ``ndim``, which effectful does not track statically: handed a
# symbolic image they have to defer instead of run. A stage that is purely
# elementwise needs no operation -- jnp builds the term for it -- which is why
# ``normalize`` below is an ordinary function
@defop
def to_gray(img: Image) -> Image:
    """RGB → luminance ``[H, W]``; pass-through if already single-channel."""
    if isinstance(img, Term):
        raise NotHandled
    x = img.data
    if x.ndim == 3 and x.shape[-1] == 3:
        x = x @ jnp.array([0.299, 0.587, 0.114], dtype=jnp.float32)
    return Image(x)


@defop
def resize(img: Image, size: tuple[int, int]) -> Image:
    """Nearest-neighbour box resize to ``(h, w)`` — no cv2/skimage dependency."""
    if isinstance(img, Term):
        raise NotHandled
    x = jnp.asarray(img.data)
    h, w = x.shape[:2]
    th, tw = size
    ys = np.linspace(0, h, th, endpoint=False).astype(int)
    xs = np.linspace(0, w, tw, endpoint=False).astype(int)
    return Image(x[ys][:, xs])


def _corr1d(x: jax.Array, k: jax.Array, axis: int) -> jax.Array:
    """Correlate *x* with the 1-D kernel *k* along *axis*, reflect boundary."""
    r = k.size // 2
    pad = [(0, 0)] * x.ndim
    pad[axis] = (r, r)
    x = jnp.moveaxis(jnp.pad(x, pad, mode="symmetric"), axis, -1)
    rows = x.reshape(-1, x.shape[-1])
    out = jax.vmap(lambda v: jnp.correlate(v, k, mode="valid"))(rows)
    return jnp.moveaxis(out.reshape(*x.shape[:-1], -1), -1, axis)


@defop
def gauss_blur(img: Image, sigma: float) -> Image:
    """Gaussian optics blur with stddev *sigma* pixels (0 = no-op).

    Separable truncated-kernel correlation matching
    :func:`scipy.ndimage.gaussian_filter` (``truncate=4.0``, reflect boundary).
    """
    if isinstance(img, Term):
        raise NotHandled
    if not sigma:
        return img
    radius = int(4.0 * sigma + 0.5)
    t = jnp.arange(-radius, radius + 1, dtype=jnp.float32)
    k = jnp.exp(-0.5 * (t / sigma) ** 2)
    k = k / k.sum()
    return Image(_corr1d(_corr1d(img.data, k, 0), k, 1))


@defop
def degrade(
    img: Image,
    res: tuple[int, int] = (64, 64),
    blur: float = 0.8,
    read_noise: float = 6.0,
    seed: jax.Array = jax.random.key(0),
) -> Image:
    """Model a cheap real camera: blur → resize to *res* → read noise."""
    if isinstance(img, Term):
        raise NotHandled
    x = resize(gauss_blur(img, blur), res).data
    if read_noise:
        x = x + read_noise * jax.random.normal(seed, x.shape)
    return Image(jnp.clip(x, 0.0, 255.0).astype(jnp.uint8))


def normalize(img: Image) -> Image:
    """Scale to unit L2 norm, so packed residuals act like cosine distances.

    One image at a time: the norm is over every axis, so ``vmap`` this rather
    than hand it a batch, which it cannot tell from a spatial axis.
    """
    x = img.data
    return Image(x / (jnp.linalg.norm(x) + 1e-12))


_DINO = None


def _dino_forward(x: np.ndarray) -> np.ndarray:
    """Torch half of :func:`encode_image`: ``[..., 98, 98, 3]`` in, ``[..., 384]`` out.

    Under ``broadcast_all`` the host call hands this every leading batch axis
    at once, so it flattens them into one torch batch and restores them after.
    """
    global _DINO
    if _DINO is None:
        model = torch.hub.load("facebookresearch/dinov2", "dinov2_vits14")
        model.eval()
        _DINO = model
    model = _DINO
    x = np.asarray(x, dtype=np.float32)
    batch = x.reshape(-1, *x.shape[-3:]).copy()
    t = torch.from_numpy(batch).permute(0, 3, 1, 2).float()
    mean = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
    std = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
    with torch.no_grad():
        cls = model((t - mean) / std)
    return np.asarray(cls.cpu().numpy(), np.float32).reshape(*x.shape[:-3], 384)


@defop
def encode_image(img: Image) -> jax.Array:
    """Encode *img* to a DINOv2 ViT-S/14 CLS latent (384-D), unit-normalized.

    A feature vector rather than an image, so unlike the rest of this module it
    returns a bare array: box it in a
    :class:`~robotl.ops.coords.RawCoordinate` to read it as a sensor.
    """
    if isinstance(img, Term):
        raise NotHandled
    # resize and normalize in jax, so vmap batches them and the host only runs
    # the part that has to: the torch forward, whole batch in one call
    x = resize(img, (98, 98)).data.astype(jnp.float32) / 255.0  # 98 = 7 * 14
    v = jax.pure_callback(
        _dino_forward,
        jax.ShapeDtypeStruct((384,), jnp.float32),  # per example, not per batch
        x,
        vmap_method="broadcast_all",
    )
    return v / (jnp.linalg.norm(v, axis=-1, keepdims=True) + 1e-12)

"""Shared MuJoCo helper utilities for control parameter extraction and indexing."""

import jax
import jax.numpy as jnp
import numpy as np


def extract_control_params(mj_model) -> tuple[jax.Array, jax.Array]:
    """Extract actuator gains and DOF indices from model config.

    Returns:
        k:   Effective position stiffness per actuator (gear × kp), clamped
             away from zero to make gravity-compensation division safe.
        dof: DOF address for each actuator's driven joint.
    """
    k = mj_model.actuator_gainprm[:, 0] * mj_model.actuator_gear[:, 0]
    k = jnp.where(jnp.abs(k) < 1e-8, 1.0, k)
    dof = mj_model.jnt_dofadr[mj_model.actuator_trnid[:, 0]]
    return k, dof


def extract_kv_over_kp(mj_model) -> jax.Array:
    """Return kv/kp per actuator for velocity feedforward."""
    kp = mj_model.actuator_gainprm[:, 0]
    kv = -mj_model.actuator_biasprm[:, 2]
    kv_over_kp = jnp.where(np.abs(kp) > 1e-8, kv / kp, 0.0)
    return kv_over_kp


def actuator_position_limits(mj_model) -> tuple[jax.Array, jax.Array]:
    """Return per-actuator joint position limits as (q_min, q_max)."""
    jmin = jnp.where(mj_model.jnt_limited, mj_model.jnt_range[:, 0], -jnp.inf)
    jmax = jnp.where(mj_model.jnt_limited, mj_model.jnt_range[:, 1], +jnp.inf)
    actuated_joints = mj_model.actuator_trnid[:, 0]
    return jmin[actuated_joints], jmax[actuated_joints]


def actuated_joint_indices(mj_model) -> tuple[list[int], list[int]]:
    """Return qpos and dof indices for all actuated joints."""
    qpos = mj_model.jnt_qposadr[mj_model.actuator_trnid[:, 0]]
    dof = mj_model.jnt_dofadr[mj_model.actuator_trnid[:, 0]]
    return qpos, dof

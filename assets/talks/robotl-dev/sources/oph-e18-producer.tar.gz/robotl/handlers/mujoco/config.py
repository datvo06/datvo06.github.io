"""MuJoCo simulation + solver configuration presets.

Post-compile knobs that describe the SIMULATOR, not the robot. Material
properties that happen to use MuJoCo-specific parameterization (per-geom
``solref`` / ``solimp``) belong with the robot spec; the knobs below are
all global sim/solver settings with no robot-intrinsic meaning.

Apply to a compiled :class:`mujoco.MjModel` via :meth:`MujocoSettings.apply`::

    from robotl.handlers.mujoco.config import MujocoSettings
    MujocoSettings.standard().apply(mj_model)

Modern recommended stack (what ``MujocoSettings.standard()`` returns):

- ``integrator=implicitfast`` — best general choice for contact-rich
  manipulation. Semi-implicit Euler that avoids eulerdamp's instabilities
  at stiff PD gains while still being cheap.
- ``eulerdamp`` disabled via ``disableflags`` — not needed with implicitfast,
  introduces spurious damping that masks control issues.
- ``impratio=1.0`` — balanced tangential vs normal impedance.
- ``iterations=10``, ``ls_iterations=20`` — enough to resolve contacts with
  ``solimp d_min ≥ 0.9`` (rigid surfaces) at ``dt=0.005``.
- ``cone=pyramidal`` — 4-sided friction pyramid (cheap default). Use
  ``MujocoSettings(cone=mjCONE_ELLIPTIC)`` for more accurate friction direction
  at ~1.5× solver cost; recommended when tangential friction direction
  matters a lot (e.g., in-hand rotation where slip orientation controls
  object rotation axis).
- ``noslip_iterations=0`` — no post-solve cleanup. Set to 1–3 to project
  velocities onto the friction cone and reduce tangential drift when
  ``iterations`` alone isn't enough.

**Note on ground truth:** these presets are *internally consistent* (solver
converges, dynamics stay bounded) and *theoretically consistent* (follows
MuJoCo's modern guidance). They are NOT validated against real-robot
hardware. ``MujocoSettings.precise()`` means "slowest and most numerically
converged", not "closest to physical reality"; the sim can be internally
consistent and still wrong about the real hand. Real-robot ground truth
(force-plate or motion-capture comparison) is future work.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass

import mujoco


@dataclass
class MujocoSettings:
    """MuJoCo sim + solver configuration applied post-compile.

    :param dt: ``mjOption.timestep`` — integration step size in seconds.
    :param integrator: ``mjtIntegrator`` value. ``3`` = implicitfast (recommended).
    :param iterations: main solver iterations per step.
    :param ls_iterations: per-iteration line-search iterations.
    :param impratio: ``mjOption.impratio`` — ratio of tangential to normal
        contact impedance. ``1.0`` is balanced; ``0.1`` is the hydrax
        sliding-friendly value (friction 10× stiffer than normal, used
        intentionally for smooth-gradient soft-contact MPC); values > 1
        favor tangential rigidity (sticky contacts, common in manipulation
        where grip > slip is desired).
    :param disable_eulerdamp: set ``mjDSBL_EULERDAMP`` in disableflags.
        Recommended True when using implicitfast.
    :param cone: ``mjtCone`` value. ``0`` = pyramidal (4-sided, fast default),
        ``1`` = elliptic (true cone, ~1.5× slower, more accurate friction
        direction).
    :param noslip_iterations: number of post-solve sub-passes that project
        velocities onto the friction cone to reduce tangential drift. ``0``
        disables; ``1-3`` is typical when needed.
    """

    dt: float = 0.005
    integrator: mujoco.mjtIntegrator = mujoco.mjtIntegrator.mjINT_IMPLICITFAST
    iterations: int = 10
    ls_iterations: int = 20
    impratio: float = 1.0
    disable_eulerdamp: bool = True
    cone: mujoco.mjtCone = mujoco.mjtCone.mjCONE_PYRAMIDAL
    noslip_iterations: int = 0
    # MJX contact-buffer caps. Pass through ``compile_model(...,
    # max_contact_points=cfg.max_contact_points, ...)`` at scene
    # build time; they bake into mjx.Data shapes so changing them
    # busts the JAX persistent cache. ``None`` lets MJX use its
    # ``ngeom²`` worst-case heuristic (large but always safe).
    max_contact_points: int | None = 64
    max_geom_pairs: int | None = 128

    @classmethod
    def standard(cls) -> MujocoSettings:
        """Modern recommended defaults for contact-rich manipulation."""
        return cls()

    @classmethod
    def precise(cls) -> MujocoSettings:
        """Small-dt + tight-solver profile for reference-quality rollouts.

        Slower but maximally converged; useful as a consistency check when
        evaluating whether :meth:`standard` or :meth:`fast` deviates in ways
        that matter for a given task. Not a model of real-robot physics —
        internally consistent only (see module docstring on ground truth).

        Caps are over-allocated (128/256) so contact-buffer truncation is
        never a confounder when investigating physics differences.
        """
        return cls(
            dt=0.001,
            iterations=50,
            ls_iterations=50,
            cone=mujoco.mjtCone.mjCONE_ELLIPTIC,
            noslip_iterations=2,
            max_contact_points=128,
            max_geom_pairs=256,
        )

    @classmethod
    def fast(cls) -> MujocoSettings:
        """Loose solver preset (dt=0.01, iter=4, ls_iter=10, impratio=0.1).

        Matches hydrax's ``leap_rh.xml`` verbatim. Paired with soft-contact
        physics (``LeapHandPhysics.hydrax``) this is what hydrax-style
        gradient-based MPC uses so setpoint-offset signals stay smooth
        across penetration depth. Also useful on its own as a cheap-and-
        cheerful sim for coarse exploration.

        Note: ``impratio=0.1`` is intentional — making friction stiffer than
        normal contact is backwards for most manipulation, but it smooths
        the friction-cone boundary for gradient-based MPC. Don't "fix" it.

        Tight caps (32/64) match the loose solver — willing to drop
        edge-case contacts since the physics is approximate anyway.
        """
        return cls(
            dt=0.01,
            iterations=4,
            ls_iterations=10,
            impratio=0.1,
            max_contact_points=32,
            max_geom_pairs=64,
        )

    def apply(self, mj_model: mujoco.MjModel) -> None:
        """Mutate ``mj_model.opt`` in place to match this config."""
        opt = mj_model.opt
        opt.timestep = self.dt
        opt.integrator = self.integrator
        opt.iterations = self.iterations
        opt.ls_iterations = self.ls_iterations
        opt.impratio = self.impratio
        opt.cone = self.cone
        opt.noslip_iterations = self.noslip_iterations
        if self.disable_eulerdamp:
            opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_EULERDAMP)

    def validate_contacts(self, mj_model: mujoco.MjModel) -> list[str]:
        """Check per-geom ``solref`` timeconst vs ``dt`` for stability.

        MuJoCo's implicit integrators require ``solref[0] ≥ 2·dt`` when
        ``solref`` is given in positive ``(timeconst, damping_ratio)`` form.
        Violating this produces unstable or silently mis-stiffened contact.

        Emits at most **one** aggregate UserWarning per call summarising the
        worst offender and the total count (so a mismatched rig/sim pairing
        doesn't spam the log with hundreds of identical warnings). Returns
        the full per-geom list so callers can inspect details.
        """
        bad: list[tuple[str, float]] = []
        min_tc = 2.0 * self.dt
        for gi in range(mj_model.ngeom):
            if mj_model.geom_contype[gi] == 0 and mj_model.geom_conaffinity[gi] == 0:
                continue
            tc = float(mj_model.geom_solref[gi, 0])
            # Positive form only (negative means direct stiffness/damping).
            if tc > 0 and tc < min_tc:
                name = mj_model.geom(gi).name or f"#{gi}"
                bad.append((name, tc))

        if bad:
            worst_name, worst_tc = min(bad, key=lambda kv: kv[1])
            warnings.warn(
                f"{len(bad)} geom(s) have solref timeconst < 2·dt={min_tc:.4f}s "
                f"(worst: {worst_name!r} at {worst_tc:.4f}s). "
                f"Contact may be unstable or under-stiffened. Pair this rig "
                f"with a MujocoSettings whose dt ≤ {min(tc for _, tc in bad) / 2:.4f}s, "
                f"or relax the rig's solref timeconst.",
                stacklevel=2,
            )
        return [f"{n}: timeconst={tc:.4f}s < {min_tc:.4f}s" for n, tc in bad]

    def describe(self) -> str:
        """One-line human-readable summary."""
        eulerdamp = "off" if self.disable_eulerdamp else "on"
        integrator_name = {
            int(mujoco.mjtIntegrator.mjINT_EULER): "euler",
            int(mujoco.mjtIntegrator.mjINT_RK4): "rk4",
            int(mujoco.mjtIntegrator.mjINT_IMPLICIT): "implicit",
            int(mujoco.mjtIntegrator.mjINT_IMPLICITFAST): "implicitfast",
        }.get(self.integrator, f"#{self.integrator}")
        cone_name = {
            int(mujoco.mjtCone.mjCONE_PYRAMIDAL): "pyramidal",
            int(mujoco.mjtCone.mjCONE_ELLIPTIC): "elliptic",
        }.get(self.cone, f"#{self.cone}")
        caps = (
            f"caps={self.max_contact_points}/{self.max_geom_pairs}"
            if (self.max_contact_points is not None or self.max_geom_pairs is not None)
            else "caps=none"
        )
        return (
            f"MujocoSettings(dt={self.dt}, {integrator_name}, "
            f"iter={self.iterations}, ls_iter={self.ls_iterations}, "
            f"impratio={self.impratio}, cone={cone_name}, "
            f"noslip={self.noslip_iterations}, eulerdamp={eulerdamp}, "
            f"{caps})"
        )

"""MPC benchmark wrapper around :func:`process.run_episode`.

:func:`benchmark_episode` adds progress bar and wall-clock timings.
"""

from __future__ import annotations

import sys
import time

import jax
from tqdm.auto import tqdm

from robotl.handlers.mujoco.process import (
    ControlProcess,
    EnvProcess,
    Episode,
    run_episode,
    step_episode,
)

from .diagnostics import Recorder, default_recorder


def prewarm(env: EnvProcess, control: ControlProcess, record: Recorder) -> float:
    """Ensure JIT by taking two steps."""
    t0 = time.perf_counter()
    for _ in range(2):  # step 1 plans, step 2 coasts — compile both branches
        env, control = step_episode(env, control)
        jax.block_until_ready(record(env, control))
    return time.perf_counter() - t0


def benchmark_episode(
    *,
    env: EnvProcess,
    controller,
    rng,
    length: int,
    label: str = "MPC",
    record: Recorder | None = None,
) -> tuple[Episode, dict]:
    """Wraps :func:`process.run_episode` with a progress bar and wall-clock
    timings. Returns ``(episode, timings)``; ``record`` defaults to
    :func:`default_recorder`."""
    control = ControlProcess.make(controller, env, rng)
    record = record or default_recorder(env.spec)

    if env.is_mjx:
        return _benchmark_mjx(env, control, record, length, label)
    return _benchmark_cpu(env, control, record, length, label)


def _benchmark_mjx(env, control, record, length, label):
    """One ``lax.scan`` over all steps"""
    print(
        f"  {label}: compiling MJX kernel + scanning {length} steps...",
        file=sys.stderr,
        flush=True,
    )
    t0 = time.perf_counter()
    episode = jax.block_until_ready(
        run_episode(env, control, length=length, record=record)
    )
    total_s = time.perf_counter() - t0

    timings = {
        "total_s": total_s,
        "per_step_ms": total_s / length * 1000 if length else float("nan"),
        "compile_s": float("nan"),
    }
    return episode, timings


def _benchmark_cpu(env, control, record, length, label):
    print(f"  {label}: pre-warming JIT...", file=sys.stderr, flush=True)
    compile_s = prewarm(env, control, record)
    print(f"  {label}: pre-warm done in {compile_s:.1f}s", file=sys.stderr, flush=True)

    pbar = tqdm(
        total=length,
        desc=label,
        unit="step",
        file=sys.stderr,
        dynamic_ncols=True,
        mininterval=0.3,
        leave=False,
    )
    pbar.refresh()

    t0 = time.perf_counter()
    episode = run_episode(
        env, control, length=length, record=record.with_progress(pbar), scan=False
    )
    run_s = time.perf_counter() - t0
    pbar.close()

    # The loop is steady-state (pre-warm is timed separately as compile_s).
    timings = {
        "total_s": run_s,
        "per_step_ms": run_s / length * 1000 if length else float("nan"),
        "compile_s": compile_s,
    }
    return episode, timings

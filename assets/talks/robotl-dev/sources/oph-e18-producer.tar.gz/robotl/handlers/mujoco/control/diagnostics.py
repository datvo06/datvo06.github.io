"""Per-step recording for MPC runs.

A :class:`Recorder` bundles what to measure (``channels``), how to summarize
each channel (``reductions``), how to show it live (``postfix``), and display
``units``. Example:

    rec = loss_recorder(spec) | Recorder(
        channels=lambda spec, state: {"tip_speed": jnp.linalg.norm(state.qvel[6:9])},
        reductions={"tip_speed": ("mean", "max")},
    )
"""

from __future__ import annotations

import dataclasses
from collections.abc import Callable

import jax
import jax.numpy as jnp
import mujoco

_REDUCERS = {
    "start": lambda v: v[0],
    "final": lambda v: v[-1],
    "mean": jnp.mean,
    "min": jnp.min,
    "max": jnp.max,
}


# ── Recorder ──────────────────────────────────────────────────────────


@dataclasses.dataclass
class Recorder:
    """What to measure, how to summarize it, how to show it."""

    channels: Callable[..., dict]  # (spec, state) -> dict of per-step values
    reductions: dict = dataclasses.field(default_factory=dict)  # name -> reductions
    postfix: dict = dataclasses.field(default_factory=dict)  # name -> formatter
    units: dict = dataclasses.field(default_factory=dict)  # name -> (scale, label)

    def __call__(self, env, control) -> dict:
        return self.channels(env.spec, env.state)

    def __or__(self, other: Recorder) -> Recorder:
        """Compose two recorders: channel dicts merge, the rest union."""
        return Recorder(
            channels=lambda spec, state: {
                **self.channels(spec, state),
                **other.channels(spec, state),
            },
            reductions={**self.reductions, **other.reductions},
            postfix={**self.postfix, **other.postfix},
            units={**self.units, **other.units},
        )

    def summarize(self, channels: dict) -> dict:
        """Reduce recorded channels to summaries via ``reductions``"""
        out = {}
        for name, reds in self.reductions.items():
            for red in reds:
                out[f"{name}_{red}"] = jax.tree.map(_REDUCERS[red], channels[name])
        return out

    def with_progress(self, pbar):
        """Bind this recorder to a tqdm bar (eager CPU loops only)."""
        loss_sum = 0.0
        steps_done = 0

        def hook(env, control):
            nonlocal loss_sum, steps_done
            ch = self(env, control)
            jax.block_until_ready(ch)
            steps_done += 1
            pbar.update(1)
            post = {k: fmt(ch[k]) for k, fmt in self.postfix.items()}
            if "loss" in ch:  # running episode average alongside the latest loss
                loss_sum += float(ch["loss"])
                post["avg"] = f"{loss_sum / steps_done:.2f}"
            pbar.set_postfix(**post)
            return ch

        return hook


# ── Library recorders ─────────────────────────────────────────────────


def loss_recorder(spec) -> Recorder:
    """Total + per-term loss from the spec's ``Loss`` expressions."""

    def loss(spec, state):
        losses = spec.get_losses(state)
        loss = jnp.stack(list(losses.values())).sum()
        return {"loss": loss, "loss_terms": losses}

    if spec.is_mjx:
        channels = loss
    else:
        fn = jax.jit(lambda state: loss(spec, state))
        channels = lambda spec, state: fn(state)  # noqa: E731
    return Recorder(
        channels=channels,
        reductions={
            "loss": ("start", "final", "mean", "min"),
            "loss_terms": ("mean", "final"),
        },
        postfix={"loss": lambda v: f"{float(v):.2f}"},
    )


def contact_recorder(spec) -> Recorder:
    """Active-contact count + max penetration."""
    scratch = None if spec.is_mjx else mujoco.MjData(spec.mj_model)

    def channels(spec, state):
        d = spec.layout.state_to_data(state, scratch)
        if spec.is_mjx:
            contact = d._impl.contact
            active = contact.dist <= 0
            ncon = jnp.sum(active)
            pen_max = jnp.max(jnp.where(active, -contact.dist, 0.0))
        else:
            ncon = int(d.ncon)
            pen_max = max(0.0, float(-d.contact.dist[:ncon].min())) if ncon > 0 else 0.0
        return {"ncon": ncon, "pen": pen_max}

    return Recorder(
        channels=channels,
        reductions={"pen": ("max", "mean"), "ncon": ("max", "mean")},
        postfix={
            "pen": lambda v: f"{float(v) * 1e3:.1f}mm",
            "ncon": lambda v: f"{float(v):.0f}",
        },
        units={"pen": (1e3, "mm")},
    )


def default_recorder(spec) -> Recorder:
    """The standard benchmark set: loss + contacts."""
    return loss_recorder(spec) | contact_recorder(spec)

"""Inverse Kinematics solver for robotic arms using Jacobian method."""

from dataclasses import dataclass

import mujoco
import numpy as np

from robotl.handlers.mujoco.utils import actuated_joint_indices


@dataclass
class IKResult:
    """Result from IK solver."""

    joint_angles: tuple
    targets: dict  # {body_name: target_position}
    qpos_indices: list
    dof_indices: list


def solve_ik(
    mj_model, targets, initial_guess=None, max_iters=30, tolerance=0.005, verbose=True
):
    """Solve inverse kinematics for one or more target positions.

    :param mj_model: MuJoCo model.
    :param targets: Dict mapping body names to target positions.
    :param initial_guess: Initial joint configuration (default: read from model).
    :param max_iters: Maximum IK iterations.
    :param tolerance: Convergence tolerance in meters.
    :param verbose: Print solution info.
    :return: :class:`IKResult` with joint angles and index mappings.
    """
    if not isinstance(targets, dict):
        raise TypeError(
            f"targets must be dict, got {type(targets).__name__}. "
            f"Example: {{'root_robot_wristFlange': np.array([0.25, 0.0, 0.60])}}"
        )

    qpos_indices, dof_indices = actuated_joint_indices(mj_model)

    # Resolve body names to IDs
    body_targets = {}  # body_id -> target_pos
    for body_name, target_pos in targets.items():
        body_id = mujoco.mj_name2id(mj_model, mujoco.mjtObj.mjOBJ_BODY, body_name)
        body_targets[body_id] = target_pos

    # Get initial guess
    if initial_guess is None:
        mj_data = mujoco.MjData(mj_model)
        mujoco.mj_forward(mj_model, mj_data)
        initial_guess = np.array([mj_data.qpos[idx] for idx in qpos_indices])
        if np.allclose(initial_guess, 0.0):
            # Generic non-singular seed that scales to arbitrary actuator counts.
            # Keep the old 3-DoF preference for the first three joints.
            initial_guess = np.zeros(len(qpos_indices), dtype=np.float64)
            if len(initial_guess) >= 2:
                initial_guess[1] = 0.8
            if len(initial_guess) >= 3:
                initial_guess[2] = 0.6

    # Solve IK
    joint_angles = _solve_ik_jacobian(
        mj_model,
        body_targets,
        qpos_indices,
        dof_indices,
        initial_guess,
        max_iters,
        tolerance,
    )

    # Align to actuator order
    joint_angles, qpos_indices, dof_indices = _align_to_actuator_order(
        mj_model, joint_angles, qpos_indices, dof_indices
    )

    if verbose:
        angles_str = ", ".join(f"{a:.3f}" for a in joint_angles)
        print(f"   IK solution: [{angles_str}] rad")
        for body_name, target_pos in targets.items():
            if len(targets) > 1:
                print(f"   Target '{body_name}':")
            body_id = mujoco.mj_name2id(mj_model, mujoco.mjtObj.mjOBJ_BODY, body_name)
            _verify_solution(mj_model, qpos_indices, joint_angles, body_id, target_pos)

    return IKResult(
        joint_angles=tuple(map(float, joint_angles)),
        targets=targets,
        qpos_indices=list(qpos_indices),
        dof_indices=list(dof_indices),
    )


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================


def _align_to_actuator_order(mj_model, joint_angles, qpos_indices, dof_indices):
    """Reorder indices and angles to match actuator order."""
    if mj_model.na != len(dof_indices) or mj_model.na == 0:
        return joint_angles, qpos_indices, dof_indices

    try:
        joint_to_ik = {
            mj_model.dof_jntid[dof_idx]: ik_idx
            for ik_idx, dof_idx in enumerate(dof_indices)
        }
        act_order = [
            joint_to_ik[mj_model.actuator(i).trnid[0]] for i in range(mj_model.na)
        ]
        return (
            joint_angles[act_order],
            [qpos_indices[i] for i in act_order],
            [dof_indices[i] for i in act_order],
        )
    except (KeyError, IndexError):
        return joint_angles, qpos_indices, dof_indices


def _verify_solution(mj_model, qpos_indices, joint_angles, body_id, target_pos):
    """Verify IK solution by forward kinematics."""
    verify_data = mujoco.MjData(mj_model)
    for i, qpos_idx in enumerate(qpos_indices):
        verify_data.qpos[qpos_idx] = joint_angles[i]
    mujoco.mj_forward(mj_model, verify_data)

    achieved_pos = verify_data.xpos[body_id]
    error = np.linalg.norm(achieved_pos - target_pos)
    print(f"   IK error: {error * 1000:.2f} mm {'✅' if error < 0.01 else '⚠️'}")
    return error


def _solve_ik_jacobian(
    mj_model,
    target_body_dict,
    qpos_indices,
    dof_indices,
    initial_q,
    max_iters=15,
    tolerance=0.01,
    damping=0.1,
    step_size=0.5,
):
    """Solve IK using damped least squares Jacobian method.

    :param mj_model: MuJoCo model.
    :param target_body_dict: Dict mapping body_id -> target_pos.
    :param qpos_indices: Qpos indices for actuated joints.
    :param dof_indices: DOF indices for actuated joints.
    :param initial_q: Initial joint configuration.
    :param max_iters: Maximum iterations.
    :param tolerance: Convergence tolerance in meters.
    :param damping: Damping factor for pseudoinverse.
    :param step_size: Step size for updates, 0-1.
    :return: Joint angles as numpy array.
    """
    n_targets = len(target_body_dict)
    ik_data = mujoco.MjData(mj_model)

    # Set initial configuration
    for i, qpos_idx in enumerate(qpos_indices):
        ik_data.qpos[qpos_idx] = initial_q[i]

    # IK iterations
    for iteration in range(max_iters):
        mujoco.mj_forward(mj_model, ik_data)

        # Stack error vectors and Jacobians for all targets
        error_vecs = []
        jacobians = []

        for body_id, target_pos in target_body_dict.items():
            current_pos = ik_data.xpos[body_id]
            error_vec = np.array(target_pos) - current_pos
            error_vecs.append(error_vec)

            # Compute Jacobian
            jacp = np.zeros((3, mj_model.nv))
            jacr = np.zeros((3, mj_model.nv))
            mujoco.mj_jac(mj_model, ik_data, jacp, jacr, current_pos, body_id)
            jacobians.append(jacp[:, dof_indices])

        # Stack for multi-target
        error_vec_stacked = np.concatenate(error_vecs)
        jacobian_stacked = np.vstack(jacobians)

        # Check convergence
        if max(np.linalg.norm(ev) for ev in error_vecs) < tolerance:
            break

        # Damped least squares
        jjt = jacobian_stacked @ jacobian_stacked.T + (damping**2) * np.eye(
            3 * n_targets
        )
        delta_q = jacobian_stacked.T @ np.linalg.solve(jjt, error_vec_stacked)

        # Update joints with step size and clamping
        for i, dq in enumerate(delta_q):
            ik_data.qpos[qpos_indices[i]] += step_size * dq
            ik_data.qpos[qpos_indices[i]] = np.clip(
                ik_data.qpos[qpos_indices[i]], -3.14, 3.14
            )

    return np.array([ik_data.qpos[idx] for idx in qpos_indices])

"""Matplotlib diagnostic plots for MPC runs."""

from __future__ import annotations

import math
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np

# ── Loss / contact plots ──────────────────────────────────────────────


def plot_channels(
    channels: dict,
    keys: list[str] | None = None,
    units: dict | None = None,
    title: str = "",
    save_to: Path | None = None,
):
    """Plot recorded channels"""
    import matplotlib.pyplot as plt

    keys = list(channels) if keys is None else keys
    units = units or {}
    fig, axes = plt.subplots(
        len(keys),
        1,
        figsize=(6.5, 2.2 * len(keys)),
        constrained_layout=True,
        sharex=True,
        squeeze=False,
    )
    for ax, name in zip(axes.ravel(), keys):
        ch = channels[name]
        scale, unit = units.get(name, (1.0, ""))
        if isinstance(ch, dict):
            for k, v in ch.items():
                ax.plot(np.asarray(v) * scale, lw=1.0, alpha=0.85, label=f"{name}_{k}")
        else:
            v = np.asarray(ch) * scale
            ax.plot(v, lw=1.2, color="black")
            ax.axhline(
                float(v.mean()),
                color="C3",
                lw=1.0,
                ls="--",
                label=f"mean = {float(v.mean()):.3f}",
            )
        ax.legend(fontsize=8, loc="upper right")
        ax.set_title(f"{name} ({unit})" if unit else name)
        ax.grid(alpha=0.3)
    axes.ravel()[-1].set_xlabel("step")
    if title:
        fig.suptitle(title, fontsize=10)
    if save_to is not None:
        fig.savefig(save_to, dpi=120)
    return fig


# ── Per-round MPC diagnostic ──────────────────────────────────────────


def plot_mpc_samples(
    trace,
    mj_model,
    *,
    label: str = "",
    n_dense: int = 200,
    save_to: Path | None = None,
):
    """Plot an :meth:`MPCController.plan` trace: the candidate population per
    round, one subplot per actuator."""
    import matplotlib.pyplot as plt

    ctrl_lo = mj_model.actuator_ctrlrange[:, 0]
    ctrl_hi = mj_model.actuator_ctrlrange[:, 1]
    horizon = float(trace[0]["mean"].spline.t[-1])
    t_dense = jnp.linspace(0, horizon, n_dense)
    t_np = np.array(t_dense)

    # ── densely evaluate each round's recorded splines ──────────────
    round_data = []
    for r in trace:
        pos_pop, _ = jax.vmap(lambda sp: sp(t_dense))(r["population"].spline)
        pos_pop = jnp.clip(pos_pop, ctrl_lo, ctrl_hi)
        pos_mean_r, _ = r["mean"].spline(t_dense)
        pos_mean_r = jnp.clip(pos_mean_r, ctrl_lo, ctrl_hi)
        round_data.append(
            (np.array(pos_pop), np.array(r["losses"]), np.array(pos_mean_r))
        )

    # ── one subplot per actuator, near-square grid ──────────────────
    nu = round_data[0][0].shape[2]
    act_names = [mj_model.actuator(i).name or f"act_{i}" for i in range(nu)]
    n_cols = math.ceil(math.sqrt(nu))
    n_rows = math.ceil(nu / n_cols)

    round_colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b"]

    fig, axes = plt.subplots(
        n_rows,
        n_cols,
        figsize=(3 * n_cols, 2.2 * n_rows),
        sharex=True,
        layout="constrained",
        squeeze=False,
        dpi=120,
    )
    suptitle = (
        f"{label}  PD-target samples — {len(trace)} rounds × "
        f"{round_data[0][0].shape[0]} candidates"
    )
    fig.suptitle(suptitle, fontsize=10)
    axes_flat = axes.ravel()

    for dd in range(nu):
        ax = axes_flat[dd]
        for r, (pos_pop, losses_r, pos_mean_r) in enumerate(round_data):
            color = round_colors[r % len(round_colors)]
            l_norm = (losses_r - losses_r.min()) / max(
                1e-8, losses_r.max() - losses_r.min()
            )
            for k in range(pos_pop.shape[0]):
                alpha = 0.05 + 0.25 * (1 - l_norm[k])
                ax.plot(t_np, pos_pop[k, :, dd], color=color, alpha=alpha, lw=0.4)
            ax.plot(
                t_np,
                pos_mean_r[:, dd],
                color=color,
                lw=2,
                label=f"R{r}" if dd == 0 else None,
            )
        lo_val, hi_val = float(ctrl_lo[dd]), float(ctrl_hi[dd])
        ax.axhline(lo_val, color="red", ls="--", lw=0.8, alpha=0.5)
        ax.axhline(hi_val, color="red", ls="--", lw=0.8, alpha=0.5)
        ax.grid(alpha=0.2)
        ax.set_title(f"{act_names[dd]}\n[{lo_val:.2f}, {hi_val:.2f}]", fontsize=8)
        ax.set_xlabel("t (s)", fontsize=7)

    # Hide unused cells in the grid.
    for j in range(nu, len(axes_flat)):
        axes_flat[j].set_visible(False)

    axes_flat[0].legend(fontsize=7, loc="upper right")
    if save_to is not None:
        fig.savefig(save_to, dpi=120)
    return fig

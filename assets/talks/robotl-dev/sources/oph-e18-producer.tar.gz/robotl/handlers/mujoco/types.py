import dataclasses

import jax
import jax.numpy as jnp
import mujoco

from robotl.ops.coords import (
    Coordinate,
    CoordinateTangent,
    Pose,
    ProductCoordinate,
    ProductCoordinateTangent,
    TangentBundle,
    TangentBundleTangent,
)
from robotl.ops.id import Id

type Q = ProductCoordinate[dict[Id, Coordinate]]
type V = ProductCoordinateTangent[dict[Id, CoordinateTangent]]
type QV = TangentBundle[Q, V]
type QVTangent = TangentBundleTangent[V, V]
type FixedQ = ProductCoordinate[dict[Id, Pose]]


@dataclasses.dataclass
class Camera:
    """A viewpoint to render from; ``None`` fields keep MuJoCo's default."""

    lookat: jax.Array | None = None
    distance: float | None = None
    elevation: float | None = None  # in radians
    azimuth: float | None = None  # in radians

    def to_mujoco(self, mj_model):
        camera = mujoco.MjvCamera()
        camera.type = mujoco.mjtCamera.mjCAMERA_FREE
        mujoco.mjv_defaultFreeCamera(mj_model, camera)
        if self.lookat is not None:
            camera.lookat = self.lookat
        if self.distance is not None:
            camera.distance = self.distance
        if self.elevation is not None:
            camera.elevation = self.elevation * 180 / jnp.pi
        if self.azimuth is not None:
            camera.azimuth = self.azimuth * 180 / jnp.pi
        return camera

from collections.abc import Callable
from pathlib import Path

import jax
import jax.random as rax
import mujoco
import mujoco.viewer
import numpy as np
from PIL import Image

from robotl.handlers.jax import solve_init
from robotl.handlers.mujoco.compiler import check_internal_collisions, compile
from robotl.handlers.mujoco.process import EnvSpec
from robotl.handlers.mujoco.render import Renderer
from robotl.handlers.mujoco.rollouts import SequentialRunner
from robotl.ops.syntax import Component


def compile_model(
    model_factory: Callable[[], Component],
    build_path: Path = Path("build/compile_model"),
    rng: jax.Array = rax.key(1),
    *,
    check: bool = False,
    **kwargs,
):
    model, init = solve_init(model_factory)
    mj_model, context = compile(model, init, build_path=build_path, rng=rng, **kwargs)
    if check:
        check_internal_collisions(mj_model)
    return model, context, mj_model


def view_model(model_factory: Callable[[], Component], **kwargs):
    """
    Launches the interactive MuJoCo viewer.

    Note: On macOS, use the '[' and ']' keys in the viewer window to switch
    to the 'cinematic' camera for a matching view of the renders.
    """
    _, _, mj_model = compile_model(
        model_factory, build_path=Path("build/view_model"), **kwargs
    )
    mujoco.viewer.launch(mj_model)


def render_model(
    model_factory: Callable[[], Component],
    save_path: Path | None = None,
    width: int | None = None,
    height: int | None = None,
    camera: str = "cinematic",
    **kwargs,
):
    """Renders a cinematic snapshot using defaults baked into the XML."""
    model, context, mj_model = compile_model(
        model_factory, build_path=Path("build/render_model"), **kwargs
    )
    spec = EnvSpec.make(
        model,
        context,
        mj_model,
        runner=SequentialRunner.make,
    )

    # Use XML-baked resolution if not overridden
    width = width or mj_model.vis.global_.offwidth or 1280
    height = height or mj_model.vis.global_.offheight or 1024

    with Renderer.make(spec, workers=1) as renderer:
        state = spec.init(rax.key(0))
        pixels = renderer.render_host(state, camera, height=height, width=width).data

    if save_path:
        save_path = Path(save_path).absolute()
        save_path.parent.mkdir(parents=True, exist_ok=True)
        Image.fromarray(np.asarray(pixels)).save(save_path)

    return pixels

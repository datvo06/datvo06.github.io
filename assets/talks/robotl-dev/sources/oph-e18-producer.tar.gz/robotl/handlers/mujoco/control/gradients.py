"""Derivative estimators over model rollouts, and the Gauss-Newton /
Levenberg-Marquardt step built from them.

The rollouts run in C (MuJoCo, threadpooled) behind host calls, which JAX cannot
differentiate, so every derivative here is *estimated*:

* :func:`sweep_grad` -- central finite differences, ``2P`` rollouts.
* :func:`adjoint_grad` -- one rollout plus per-step ``mjd_transitionFD``
  Jacobians and a backward pass.
* :func:`stage_jacobian` -- per-timestep Jacobian, by the same FD sweep or by
  the bundled zeroth-order (randomized-smoothing) estimator.

:func:`gn_hessian`, :func:`lm_deltas` and :func:`lm_update` turn a stage
Jacobian into a damped Gauss-Newton step; the caller scores the candidates by
rolling them out, so the line search is simulation-based rather than the usual
predicted-vs-actual reduction ratio.

NOTE some of these were originally implemented in 64-bit numpy, and have since been
ported to 32-bit jax.  if we encounter numerical issues, we may have to move more
computations inside the ``jax.pure_callback`` wrapped FD code in ``Runner``.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

import effectful.handlers.jax.numpy as jnp
import jax
import jax.random as rax

from robotl.handlers.mujoco.process import Action, EnvProcess, EnvSpec, EnvState

from .plans import Plan

if TYPE_CHECKING:  # planners imports this module, so keep the edge one-way
    from .planners import (
        GaussNewtonPlanner,
        GaussNewtonState,
        GradientPlanner,
        HybridPlanner,
        PlannerState,
        SamplingState,
    )

# Levenberg-Marquardt ladder constants (classic values; not worth exposing).
LAM_UP, LAM_DOWN, LAM_MIN, LAM_MAX = 10.0, 0.5, 1e-6, 1e8


def fd_perturbations(x0: jax.Array, eps: float) -> jax.Array:
    """``+eps`` rows then ``-eps`` rows, one pair per coordinate ``[2P, ...]``."""
    flat = x0.reshape(-1)
    pert = eps * jnp.eye(flat.shape[0])  # [P, P]
    return jnp.concatenate([flat[None] + pert, flat[None] - pert]).reshape(
        -1, *x0.shape
    )


def rollout_candidates(
    env: EnvProcess,
    mean: Plan,
    time_grid: jax.Array,
    candidates: jax.Array,
    rollout: Callable[[EnvSpec, EnvState, Action], EnvState],
    plan_spec: EnvSpec | None = None,
) -> EnvState:
    """Roll out candidate decision-variable arrays ``[B, 2, n_knots, nu]`` open-loop.
    Candidates are built through the plan's own :meth:`Plan.with_params`
    (feasibility-clipped); an FD perturbation that leaves the box just yields a
    sign-correct, at-worst-halved gradient there — fine for the inner loop. With
    ``plan_spec`` set, rolls out on that softened planning model instead of
    ``env``'s own spec."""
    spec = env.spec if plan_spec is None else plan_spec
    plans = jax.vmap(lambda c: mean.with_params(c, spec))(candidates)
    u = jax.vmap(lambda plan: plan(time_grid))(plans)
    return rollout(spec, env.state, spec.layout.u.unpack(u))


def sweep_grad(
    planner: GradientPlanner,
    state: PlannerState,
    env: EnvProcess,
    params0: jax.Array,
) -> jax.Array:
    """Knot gradient by central finite differences: ``2P`` threaded rollouts."""
    candidates = fd_perturbations(params0, planner.eps)  # [2P, 2, n_knots, nu]
    rollouts = rollout_candidates(
        env, state.mean, state.time_grid, candidates, planner.rollout
    )
    losses = planner.loss(env.spec, rollouts)
    p = params0.size
    return ((losses[:p] - losses[p:]) / (2 * planner.eps)).reshape(params0.shape)


def adjoint_grad(
    planner: GradientPlanner,
    state: PlannerState,
    env: EnvProcess,
    params0: jax.Array,
) -> jax.Array:
    """Knot gradient by the adjoint method: one rollout with per-step
    ``mjd_transitionFD`` Jacobians, a backward pass ``ρ_t = c_t + A_{t+1}ᵀρ_{t+1}``,
    and the spline VJP. Propagates loss dependence through ``y`` (sensordata)
    and the full ``qv`` bundle, by differentiating the stage loss w.r.t. a
    state tangent ``[dq; dv]`` applied at zero via the bundle shift
    ``qv + delta`` (``q ⊕ Exp(dq)`` retraction, additive ``dv``) — the
    same basis as the ``mjd_transitionFD`` Jacobians. CPU path only."""
    u, u_vjp = jax.vjp(
        lambda th: state.mean.with_params(th, env.spec)(state.time_grid), params0
    )
    rollout, A, B, C, D = env.spec.runner.rollout_with_jacobians(env.spec, env.state, u)
    T, _ = u.shape
    nv = env.spec.mj_model.nv
    layout = env.spec.layout
    sens = jax.vmap(layout.y.pack)(rollout.y)

    # stage_loss is essentially differentiated wrt state, however the state lives on a
    # group manifold and its tangent space is lower-dimensional than the primal
    # representation (case in point, rotation vectors vs quaternions).
    # For vector spaces, `grad(lambda x: f(x))(x) == grad(lambda dx: f(x + dx))(0)`,
    # which extends to our Lie group if we interpret `x + dx` as a retraction.
    def stage_loss(dx, sens, x):
        dqv = layout.qv_tangent.unpack(dx)
        y = layout.y.unpack(sens)
        return env.spec.get_loss(x.replace(qv=x.qv + dqv, y=y))

    g_x, g_sens = jax.vmap(jax.grad(stage_loss, argnums=(0, 1)))(
        jnp.zeros((T, 2 * nv)), sens, rollout
    )
    c_x = g_x / T
    g_sens = g_sens / T
    # Stage ``t`` splits across the step: the sensor term is a function of
    # ``(x_t, u_t)`` (mj_step evaluates sensors pre-step), the state term of
    # ``x_{t+1}``. In tangent coordinates [2nv]:
    c_sens = jnp.einsum("tsx,ts->tx", C, g_sens)

    # rho is dL/dx_{t+1} over stages > t
    def backward(rho, stage):
        c_x, c_sens, g_sens, A, B, D = stage
        post = c_x + rho
        return c_sens + A.T @ post, B.T @ post + D.T @ g_sens

    _, gu = jax.lax.scan(
        backward, jnp.zeros(2 * nv), (c_x, c_sens, g_sens, A, B, D), reverse=True
    )
    return u_vjp(gu.astype(u.dtype))[0]


def stage_jacobian(
    planner: GaussNewtonPlanner | HybridPlanner,
    state: GaussNewtonState | SamplingState,
    params0: jax.Array,
    env: EnvProcess,
) -> tuple[jax.Array, jax.Array]:
    """Base stage costs ``ell0`` ``[T]`` and stage-loss Jacobian ``[P, T]``,
    from the central-FD sweep or the bundled zeroth-order estimator."""
    p = params0.size
    if planner.grad_mode == "bundle":
        key = rax.fold_in(state.rng, 0)
        Z = rax.normal(key, (planner.bundle_samples, p)) * planner.bundle_sigma
        cand = jnp.concatenate(
            [params0.reshape(-1)[None], params0.reshape(-1)[None] + Z]
        ).reshape(-1, *params0.shape)
        stage = planner.stage_losses(state, cand, env)  # [1+M, T]
        ell0 = stage[0]
        dstage = stage[1:] - ell0[None]  # [M, T]
        jac = (Z / planner.bundle_sigma**2).T @ dstage / planner.bundle_samples
        return ell0, jac
    candidates = jnp.concatenate(
        [params0[None], fd_perturbations(params0, planner.eps)]
    )
    stage = planner.stage_losses(state, candidates, env)
    return stage[0], (stage[1 : 1 + p] - stage[1 + p :]) / (2 * planner.eps)


def gn_hessian(
    jac: jax.Array, ell0: jax.Array, loss_floor: float
) -> tuple[jax.Array, jax.Array, jax.Array]:
    """Gradient, generalized Gauss-Newton Hessian and base loss from a stage
    Jacobian. Treating each stage cost as a residual ``r_t = √ℓ_t`` gives
    ``H = (1/2T) Σ_t ∇ℓ_t∇ℓ_tᵀ / max(ℓ_t, loss_floor)``, which is PSD."""
    w = 1.0 / (2.0 * jnp.maximum(ell0, loss_floor))  # [T]
    grad = jac.mean(axis=1)  # ∇L = mean_t ∇ℓ_t
    hess = (jac * w[None, :]) @ jac.T / ell0.shape[0]
    return grad, hess, ell0.mean()


def lm_deltas(
    hess: jax.Array, grad: jax.Array, lam: jax.Array, max_trials: int
) -> jax.Array:
    """Levenberg-Marquardt steps ``-(H + λI)⁻¹∇L`` over the λ ladder
    ``λ·LAM_UP^k``, batched: ``[max_trials, P]``."""
    eye = jnp.eye(grad.shape[0])
    ladder = lam * LAM_UP ** jnp.arange(max_trials)
    return jax.vmap(lambda step: -jax.numpy.linalg.solve(hess + step * eye, grad))(
        ladder
    )


def lm_update(
    lam: jax.Array, idx: jax.Array, accepted: jax.Array, max_trials: int
) -> jax.Array:
    """Next damping: on an accepted step take the rung that worked and relax
    toward Newton, else grow past the whole ladder."""
    lam = jnp.where(accepted, lam * LAM_UP**idx * LAM_DOWN, lam * LAM_UP**max_trials)
    return jnp.clip(lam, LAM_MIN, LAM_MAX)

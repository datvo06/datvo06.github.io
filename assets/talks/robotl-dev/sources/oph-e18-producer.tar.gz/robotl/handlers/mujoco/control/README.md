# Control

Control algorithms for MuJoCo envs: sampling-based MPC + IK.

## Layout

- `mpc.py` — `MPCController` / `MPCSettings` / `MPCState`,
  `RatedMPCController`, and the `compute_contact_penalty` helper.
- `plans.py` — action-trajectory parameterizations (`CSplinePlan`, colored
  noise) sampled by the controller.
- `ik_solver.py` — inverse-kinematics solver (`solve_ik`).

## Usage

```python
from robotl.handlers.mujoco.control import MPCController, MPCSettings

controller = MPCController(MPCSettings(horizon=1.0, batch_size=64, rounds=4))
state = controller.init(rng, env)  # -> MPCState
# One control step: optimizes the plan and sets the env control as a side effect.
state = controller(state, env)
```

Drive a full episode with ``ControlProcess`` + ``run_episode`` (see the tests
and ``docs/source/control_demo.ipynb``).

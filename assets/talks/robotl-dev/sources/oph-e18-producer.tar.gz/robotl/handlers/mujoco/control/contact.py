"""Compliant-contact planning model.

A planner that optimizes through contact benefits from a *smoothed* contact
model: stiff unilateral contact gives a gradient that is zero before touch and
discontinuous at touch. Softening the contact — springier constraints and a
force field that reaches out before geoms touch — smooths that landscape, so the
plan is found on the soft model and then applied on the real (stiff) episode.
This is the analytic counterpart of the bundled zeroth-order Jacobian, which
smooths contact by sampling instead.
"""

import copy

import mujoco
import numpy as np

from robotl.handlers.mujoco.mappings import Layout
from robotl.handlers.mujoco.process import EnvSpec


def _free_body_geoms(m: mujoco.MjModel) -> np.ndarray:
    """Geom indices of the free-floating object(s) — the manipuland, not the
    hand — so a contact margin can be applied to the object alone."""
    free = m.jnt_bodyid[m.jnt_type == mujoco.mjtJoint.mjJNT_FREE]
    return np.where(np.isin(m.geom_bodyid, free))[0]


def soften_contact(
    spec: EnvSpec,
    solref_scale: float = 5.0,
    margin: float = 0.0,
    margin_object_only: bool = True,
) -> EnvSpec:
    """A compliant copy of ``spec`` for planning rollouts. Contact springs are
    ``solref_scale`` times softer (longer ``solref`` time constant), and — if
    ``margin > 0`` — contact activates within ``margin`` metres of touching
    (force-at-a-distance, so pre-contact perturbations carry a gradient). By
    default the margin is applied only to the free-floating object's geoms, so
    manipulator self-contacts are unaffected (a global margin makes fingers feel
    each other at a distance and thrash). Dimensions are unchanged, so the live
    state and the task loss transfer directly."""
    m = copy.deepcopy(spec.mj_model)
    tc_floor = 2.1 * m.opt.timestep  # solref time constant stays stable
    m.geom_solref[:, 0] = np.maximum(m.geom_solref[:, 0] * solref_scale, tc_floor)
    if m.npair:
        m.pair_solref[:, 0] = np.maximum(m.pair_solref[:, 0] * solref_scale, tc_floor)
    if margin > 0:
        geoms = _free_body_geoms(m) if margin_object_only else slice(None)
        m.geom_margin[geoms] = np.maximum(m.geom_margin[geoms], margin)
    return spec.replace(layout=Layout.make(m, spec.context))

"""Runners — simulators for planning.

A :class:`Runner` advances :class:`EnvState`s under given controls, either
open-loop over a control sequence (:meth:`~Runner.rollout`) or one step at a
time (:meth:`~Runner.step`, for closed-loop use). It runs raw ``mj_step`` /
``mujoco.rollout`` (bypassing :class:`ControlProcess`) and sits deliberately
outside the :class:`Episode` taxonomy, returning bare :class:`EnvState` stacks.

The backends — :class:`SequentialRunner`, :class:`ThreadedRunner`,
:class:`JaxableThreadedRunner` and :class:`MjxRunner` — share one batching rule.
:func:`openloop_rollouts` defaults to the spec's own; planners take any runner's
:meth:`~Runner.rollout` as their ``rollout`` executor. Only the
:class:`MjxRunner` and :class:`JaxableThreadedRunner` are
usable inside a jax trace.
"""

import abc
import dataclasses
import threading
from collections.abc import Callable
from functools import partial, wraps
from multiprocessing import cpu_count
from typing import ClassVar, cast, final

import effectful.handlers.jax.numpy as jnp
import jax
import mujoco
import mujoco.rollout
import numpy as np
from jax.custom_batching import custom_vmap
from jax.experimental import io_callback
from mujoco import mjx

from robotl.handlers.mujoco.compiler import FIDELITY_PARAMS
from robotl.internals.utils import deepstack, maybe_enable_x64
from robotl.ops.syntax import fidelity

from .process import (
    Action,
    EnvSpec,
    EnvState,
)
from .render import NoRenderer, Renderer


def _traced(*inputs: jax.Array) -> bool:
    """Whether a host callback on ``inputs`` would be staged into a trace.

    JAX caches an eagerly dispatched callback for the process, keyed on the
    callback, which would keep its rollout pool and spec alive; concrete
    inputs call the host directly instead.
    """
    return any(isinstance(x, jax.core.Tracer) for x in inputs)


@jax.jit
def _broadcast_batch(state: EnvState, u: jax.Array) -> tuple[EnvState, jax.Array]:
    if state.t.ndim == 0:
        state = jax.tree.map(lambda x: x[None], state)
    if u.ndim == 2:
        u = u[None]
    [B] = np.broadcast_shapes(state.t.shape[:1], u.shape[:1])
    _, T, U = u.shape
    u = jnp.broadcast_to(u, [B, T, U])
    state = jax.tree.map(lambda x: jnp.broadcast_to(x, [B, *x.shape[1:]]), state)
    return state, u


@partial(jax.jit, static_argnames=["axis"])
def _squeeze[T](tree: T, axis: int) -> T:
    return jax.tree.map(lambda x: jnp.squeeze(x, axis=axis), tree)


def _canonicalize_batch[F: Callable](rollout: F) -> F:
    # pack u, broadcast state/u to a common batch size, check the wrapped
    # rollout returned the promised [B, T], and drop B again if neither was batched
    @wraps(rollout)
    def wrapper(
        self, spec: EnvSpec, state: EnvState, action: Action, length: int | None = None
    ) -> EnvState:
        u = spec.layout.pack_controls(action, length)
        batched = state.t.ndim == 1 or u.ndim == 3
        state, u = _broadcast_batch(state, u)
        B, T, _ = u.shape
        rollouts = rollout(self, spec, state, u)
        assert rollouts.t.shape[:2] == (B, T), rollouts.t.shape
        assert all(x.shape[:2] == (B, T) for x in jax.tree.leaves(rollouts.y))
        if not batched:
            rollouts = _squeeze(rollouts, axis=0)
        return rollouts

    return cast(F, wrapper)


@dataclasses.dataclass(eq=False)
class Runner(abc.ABC):
    """Simulator advancing :class:`EnvState`s under given controls."""

    renderer: Renderer | NoRenderer = dataclasses.field(kw_only=True)
    """Handles :func:`~robotl.handlers.mujoco.process.render_camera` for the
    spec holding this runner."""

    jaxable: ClassVar[bool] = False

    @abc.abstractmethod
    def rollout(
        self, spec: EnvSpec, state: EnvState, u: Action, length: int | None = None
    ) -> EnvState:
        """Roll out open-loop control ``u`` (leaves ``[B?, T]``) starting from
        given state. ``length`` is required only if ``u`` is empty (no
        actuators), and otherwise checked against ``T``.

        Either ``state`` or ``u`` can have a leading batch axis, or both or
        neither. Batched inputs are broadcast to a single common batch axis;
        if neither is batched, neither is the result."""
        ...

    def step(self, spec: EnvSpec, state: EnvState, u: Action) -> EnvState:
        # control values are scalar per actuator, so leaves are [B?]
        u_batched = any(jnp.ndim(x) for x in jax.tree.leaves(u))
        rollouts = self.rollout(
            spec, state, jax.tree.map(lambda x: x[..., None], u), length=1
        )
        # rollout returns [B?, T]; the time axis follows the batch axis if any
        axis = 1 if state.t.ndim == 1 or u_batched else 0
        return _squeeze(rollouts, axis=axis)

    def forward(self, spec: EnvSpec, state: EnvState) -> EnvState:
        # recompute sensordata using rollouts, exploiting the fact that sensordata lags behind
        next_state = self.step(spec, state, state.u)
        return state.replace(y=next_state.y)

    def rollout_with_jacobians(
        self, spec: EnvSpec, state: EnvState, u: jax.Array, fd_eps: float = 1e-6
    ) -> tuple[EnvState, jax.Array, jax.Array, jax.Array, jax.Array]:
        """Nominal open-loop rollout of unbatched ``state`` under ``u`` ``[T, nu]``
        with per-step transition Jacobians from ``mujoco.mjd_transitionFD``.
        With ``x_{t+1} = f(x_t, u_t)``: ``A[t] = ∂x_{t+1}/∂x_t`` ``[2nv, 2nv]``,
        ``B[t] = ∂x_{t+1}/∂u_t`` ``[2nv, nu]``, ``C[t] = ∂s_t/∂x_t``
        ``[nsensordata, 2nv]`` and ``D[t] = ∂s_t/∂u_t``, where ``s_t`` is the
        sensordata carried by the post-step ``states[t]`` — ``mj_step``
        evaluates sensors during the *pre-step* forward, so ``s_t`` is a
        function of ``(x_t, u_t)``. Returns ``(states, A, B, C, D)``. CPU
        MuJoCo only; stateless actuators (``na == 0``).

        The state tangent is ``[dq; dv]``, both halves in the layout's flat
        tangent basis (:meth:`VLayout.pack`, MuJoCo dof order): ``dq`` is the
        right perturbation ``q ⊕ Exp(dq)`` per ``mj_integratePos`` — matching
        :meth:`Coordinate.__add__` — and ``dv`` is a plain velocity offset.
        Sensor rows follow the :meth:`YLayout.pack` layout."""
        m = spec.mj_model
        assert not spec.is_mjx and m.na == 0
        T, nu = u.shape
        nq, nx, ns = m.nq, 2 * m.nv, m.nsensordata
        dtype = jax.dtypes.canonicalize_dtype(np.float64)
        qpos, qvel = spec.layout.qv.pack(state.qv)
        mocap_pos, mocap_quat = spec.layout.fixed_q.pack(state.fixed_q)

        def call_host(t, qpos, qvel, mocap_pos, mocap_quat, u):
            d = mujoco.MjData(m)
            d.time, d.qpos, d.qvel = t, qpos, qvel
            d.mocap_pos, d.mocap_quat = mocap_pos, mocap_quat
            mujoco.mj_forward(m, d)
            fp, y = np.empty((T, 1 + nq + m.nv)), np.empty((T, ns))
            A, B = np.empty((T, nx, nx)), np.empty((T, nx, nu))
            C, D = np.empty((T, ns, nx)), np.empty((T, ns, nu))
            for i in range(T):
                d.ctrl = u[i]
                mujoco.mjd_transitionFD(m, d, fd_eps, 1, A[i], B[i], C[i], D[i])
                mujoco.mj_step(m, d)
                fp[i] = np.concatenate([[d.time], d.qpos, d.qvel])
                y[i] = d.sensordata
            return tuple(x.astype(dtype) for x in [fp, y, A, B, C, D])

        shapes = [[T, 1 + nq + m.nv], [T, ns], [T, nx, nx], [T, nx, nu]]
        shapes += [[T, ns, nx], [T, ns, nu]]
        fp, y, A, B, C, D = jax.pure_callback(
            call_host,
            tuple(jax.ShapeDtypeStruct(shape, dtype) for shape in shapes),
            state.t,
            qpos,
            qvel,
            mocap_pos,
            mocap_quat,
            u,
            vmap_method="sequential",
        )
        states = jax.vmap(
            lambda fp, y, u: EnvState(
                t=fp[0],
                qv=spec.layout.qv.unpack(fp[1 : 1 + nq], fp[1 + nq :]),
                fixed_q=state.fixed_q,
                y=spec.layout.y.unpack(y),
                u=spec.layout.u.unpack(u),
                rng=state.rng,
            )
        )(fp, y, u)
        return states, A, B, C, D


@final
class SequentialRunner(Runner):
    @classmethod
    def make(cls, spec: EnvSpec, renderer: Renderer | None = None):
        if renderer is None:
            renderer = Renderer.make(spec)  # free until it renders
        return cls(renderer=renderer)

    @_canonicalize_batch
    def rollout(self, spec, state, u):
        u = np.asarray(u)
        B, T, _ = u.shape

        def do_rollout(state, u):
            m, d = spec.mj_model, spec.layout.state_to_data(state)
            rollout = []
            for t in range(T):
                d.ctrl = u[t]
                mujoco.mj_step(m, d)
                rollout.append(spec.layout.state_from_data(d, rng=state.rng))
            return deepstack(rollout)

        return deepstack(
            [do_rollout(jax.tree.map(lambda x: x[b], state), u[b]) for b in range(B)]
        )


@final
@dataclasses.dataclass(eq=False)
class MjxRunner(Runner):
    # mujoco cannot render mjx state
    renderer: Renderer | NoRenderer = dataclasses.field(
        default_factory=NoRenderer, kw_only=True
    )
    jaxable = True

    @_canonicalize_batch
    def rollout(self, spec, state, u):
        def one_rollout(state, u):
            def fn(md, u_t):
                md = mjx.step(spec.mj_model, md.replace(ctrl=u_t.astype(md.ctrl.dtype)))
                return md, spec.layout.state_from_data(md, rng=state.rng)

            _, states = jax.lax.scan(fn, spec.layout.state_to_data(state), u)
            return states

        with maybe_enable_x64(FIDELITY_PARAMS[fidelity()]["x64"]):
            return jax.vmap(one_rollout)(state, u)


@final
@dataclasses.dataclass(eq=False)
class _MjRollout:
    manager: mujoco.rollout.Rollout
    scratch: mujoco.MjData | list[mujoco.MjData]
    # XLA runs independent host calls concurrently, and they share the scratch
    lock: threading.Lock = dataclasses.field(default_factory=threading.Lock)

    @classmethod
    def make(cls, spec: EnvSpec, nthread: int) -> "_MjRollout":
        assert not spec.is_mjx
        manager = mujoco.rollout.Rollout(nthread=nthread)  # nthread=0 runs inline
        if manager.nthread == 0:
            scratch = mujoco.MjData(spec.mj_model)
        else:
            scratch = [mujoco.MjData(spec.mj_model) for _ in range(nthread)]
        return cls(manager, scratch)

    def forward(self, spec: EnvSpec, state: EnvState, *, jaxable: bool) -> EnvState:
        """Refresh native sensor readings without integrating physics.

        :param spec: Native model and state layout.
        :param state: Unbatched or batched state, including saved controls.
        :param jaxable: Dispatch through a JAX callback when true.
        :return: The supplied state with only its sensor readings replaced.
        """
        assert spec.mj_model.na == 0
        batched = state.t.ndim == 1
        action = jax.tree.map(lambda x: x[..., None], state.u)
        u = spec.layout.pack_controls(action, 1)
        batch, u = _broadcast_batch(state, u)
        B = u.shape[0]
        fp, control, mocap_pos, mocap_quat = spec.layout.pack_rollout(batch, u)
        dtype = jax.dtypes.canonicalize_dtype(np.float64)
        control_spec = (
            mujoco.mjtState.mjSTATE_CTRL
            | mujoco.mjtState.mjSTATE_MOCAP_POS
            | mujoco.mjtState.mjSTATE_MOCAP_QUAT
        )

        def call_host(fp, control):
            fp, control = np.asarray(fp), np.asarray(control)
            batch_shape = fp.shape[:-1]
            assert control.shape[:-2] == batch_shape
            assert np.all(np.isfinite(fp))
            flat_fp = fp.reshape([-1, fp.shape[-1]])
            flat_control = control.reshape([len(flat_fp), control.shape[-1]])
            readings = np.empty([len(flat_fp), spec.mj_model.nsensordata])
            with self.lock:
                data = (
                    self.scratch[0] if isinstance(self.scratch, list) else self.scratch
                )
                for index, (physics, action) in enumerate(
                    zip(flat_fp, flat_control, strict=True)
                ):
                    # Reset solver/history state so each reading depends only
                    # on its supplied EnvState, not another pool dispatch.
                    mujoco.mj_resetData(spec.mj_model, data)
                    mujoco.mj_setState(
                        spec.mj_model,
                        data,
                        physics,
                        mujoco.mjtState.mjSTATE_FULLPHYSICS,
                    )
                    mujoco.mj_setState(spec.mj_model, data, action, control_spec)
                    mujoco.mj_forward(spec.mj_model, data)
                    readings[index] = data.sensordata
            return readings.reshape([*batch_shape, spec.mj_model.nsensordata]).astype(
                dtype
            )

        if jaxable and _traced(fp, control):
            readings = jax.pure_callback(
                call_host,
                jax.ShapeDtypeStruct([B, spec.mj_model.nsensordata], dtype),
                fp,
                control,
                vmap_method="broadcast_all",
            )
        else:
            readings = call_host(fp, control)
        refreshed = spec.layout.unpack_rollout(
            fp[:, None],
            readings[:, None],
            u,
            batch.rng,
            mocap_pos,
            mocap_quat,
        )
        refreshed = _squeeze(refreshed, axis=1)
        if not batched:
            refreshed = _squeeze(refreshed, axis=0)
        return state.replace(y=refreshed.y)

    def rollout(
        self,
        spec: EnvSpec,
        state: EnvState,
        u: jax.Array,
        jaxable: bool,
        on_work: Callable[[int, int], None] | None = None,
    ) -> EnvState:
        assert spec.mj_model.na == 0  # stateful actuators require tracking mj_data.act
        B, T, _ = u.shape
        dtype = jax.dtypes.canonicalize_dtype(np.float64)
        fp0, control, mocap_pos, mocap_quat = spec.layout.pack_rollout(state, u)
        control_spec = (
            mujoco.mjtState.mjSTATE_CTRL
            | mujoco.mjtState.mjSTATE_MOCAP_POS
            | mujoco.mjtState.mjSTATE_MOCAP_QUAT
        )

        def call_host(fp0, control):
            """Call out to mujoco.rollout to do the work"""
            fp0, control = np.asarray(fp0), np.asarray(control)
            assert np.all(np.isfinite(fp0))
            # an outer vmap adds leading axes; flatten them into the rollout batch
            batch_shape = fp0.shape[:-1]
            assert control.shape[:-2] == batch_shape, (fp0.shape, control.shape)
            B = int(np.prod(batch_shape))
            with self.lock:
                if on_work is not None:
                    on_work(B, T)
                fp, sensordata = self.manager.rollout(
                    model=spec.mj_model,
                    data=self.scratch,
                    initial_state=fp0.reshape([B, fp0.shape[-1]]),
                    control=control.reshape([B, *control.shape[-2:]]),
                    control_spec=control_spec,
                )
            fp = fp.reshape([*batch_shape, *fp.shape[1:]])
            sensordata = sensordata.reshape([*batch_shape, *sensordata.shape[1:]])
            # mujoco allocates its outputs float64; jax runs float32 unless x64
            return fp.astype(dtype), sensordata.astype(dtype)

        traced = _traced(fp0, control)
        if jaxable and traced and on_work is not None:

            @custom_vmap
            def dispatch(fp0, control):
                batch_shape = fp0.shape[:-1]
                return io_callback(
                    call_host,
                    (
                        jax.ShapeDtypeStruct((*batch_shape, T, fp0.shape[-1]), dtype),
                        jax.ShapeDtypeStruct(
                            (*batch_shape, T, spec.mj_model.nsensordata), dtype
                        ),
                    ),
                    fp0,
                    control,
                    ordered=False,
                )

            @dispatch.def_vmap
            def dispatch_batch(size, in_batched, fp0, control):
                if not in_batched[0]:
                    fp0 = jnp.broadcast_to(fp0, (size, *fp0.shape))
                if not in_batched[1]:
                    control = jnp.broadcast_to(control, (size, *control.shape))
                return dispatch(fp0, control), (True, True)

            fp, sensordata = dispatch(fp0, control)
        elif jaxable and traced:
            fp, sensordata = jax.pure_callback(
                call_host,
                (
                    jax.ShapeDtypeStruct([B, T, fp0.shape[-1]], dtype),
                    jax.ShapeDtypeStruct([B, T, spec.mj_model.nsensordata], dtype),
                ),
                fp0,
                control,
                # an outer vmap becomes a single host call over the whole batch
                vmap_method="broadcast_all",
            )
        else:
            fp, sensordata = call_host(fp0, control)
        assert fp.shape == (B, T, fp0.shape[-1])
        assert sensordata.shape == (B, T, spec.mj_model.nsensordata)

        return spec.layout.unpack_rollout(
            fp, sensordata, u, state.rng, mocap_pos, mocap_quat
        )


@final
@dataclasses.dataclass(eq=False)
class ThreadedRunner(Runner):
    pool: _MjRollout

    @classmethod
    def make(cls, spec: EnvSpec, nthread: int = cpu_count()):
        return cls(_MjRollout.make(spec, nthread), renderer=Renderer.make(spec))

    @_canonicalize_batch
    def rollout(self, spec, state, u):
        return self.pool.rollout(spec, state, u, jaxable=False)

    def forward(self, spec: EnvSpec, state: EnvState) -> EnvState:
        return self.pool.forward(spec, state, jaxable=False)


@final
@dataclasses.dataclass(eq=False)
class JaxableThreadedRunner(Runner):
    """Native runner usable in JAX traces.

    :param on_work: Optional host hook called with flattened batch size and
        horizon length, under the pool lock before each native dispatch. Raising
        from the hook refuses that dispatch. The hook runs during execution,
        not tracing, and is not used by an unhooked runner sharing this pool.
    """

    pool: _MjRollout
    on_work: Callable[[int, int], None] | None = None
    jaxable = True

    @classmethod
    def make(
        cls,
        spec: EnvSpec,
        nthread: int = cpu_count(),
        renderer: Renderer | None = None,
    ):
        if renderer is None:
            renderer = Renderer.make(spec)  # free until it renders
        return cls(_MjRollout.make(spec, nthread), renderer=renderer)

    @_canonicalize_batch
    def rollout(self, spec, state, u):
        return self.pool.rollout(spec, state, u, jaxable=True, on_work=self.on_work)

    def forward(self, spec: EnvSpec, state: EnvState) -> EnvState:
        return self.pool.forward(spec, state, jaxable=True)


Threadpool = JaxableThreadedRunner
"""Alias kept so existing ``Threadpool`` call sites keep working. Jaxable,
since planners trace their rollouts under ``lax.cond``."""


def openloop_rollouts(
    spec: EnvSpec,
    state: EnvState,
    u: Action,
    threadpool: Runner | None = None,
    length: int | None = None,
) -> EnvState:
    """Roll out ``u`` from ``state`` with ``threadpool``, defaulting to
    ``spec.runner``. See :meth:`Runner.rollout` for the batching contract.
    """
    runner = spec.runner if threadpool is None else threadpool
    return runner.rollout(spec, state, u, length=length)


@jax.jit
def default_batched_loss_fn(spec: EnvSpec, rollouts: EnvState):
    @jax.vmap
    @jax.vmap
    def fn(state):
        return spec.get_loss(state)

    return fn(rollouts).mean(axis=1)  # average over time


@jax.jit
def batched_stage_loss_fn(spec: EnvSpec, rollouts: EnvState) -> jax.Array:
    """Per-``(batch, timestep)`` total task loss, shape ``[B, T]``. Jitted so
    the effectful loss evaluation is traced once, not per call."""
    return jax.vmap(jax.vmap(spec.get_loss))(rollouts)

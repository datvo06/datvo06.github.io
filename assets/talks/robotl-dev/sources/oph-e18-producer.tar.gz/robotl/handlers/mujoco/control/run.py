"""Single MPC run: any example env × any of the planners.

``--env`` takes either a registered builder (``cube_spinning``) or the name of
any ``robotl.examples`` module exposing a zero-arg ``factory()`` with a task
loss — e.g. ``--env bottleneck`` — compiled and framed generically, no per-env
code::

    python -m robotl.handlers.mujoco.control.run --env bottleneck --method mppi

Runs the env selected by ``--env`` under a receding-horizon
:class:`~robotl.handlers.mujoco.control.mpc.MPCController` and saves a video, a
run-summary figure, and a metrics JSON to an auto-numbered
``output/NNN-<env>-<method>/`` directory. The planner is selected by
``--method``:

* ``mppi``     — :class:`SamplingPlanner` (the notebook's MPPI config).
* ``gradient`` — :class:`GradientPlanner` (finite-diff + Adam).
* ``gn``       — :class:`GaussNewtonPlanner` (finite-diff + Levenberg-Marquardt).

Everything downstream of building the controller (rollout, diagnostics, render)
is env- and planner-agnostic. The three standard cube-spinning runs (5 s)::

    python -m robotl.handlers.mujoco.control.run --method mppi
    python -m robotl.handlers.mujoco.control.run --method gradient
    python -m robotl.handlers.mujoco.control.run --method gn

The finite-difference planners (``gradient`` / ``gn``) cost ``~4·n_knots·nu``
rollouts per step, so start with a short ``--duration`` and a coarse
``--knot-interval`` before scaling up. Long runs belong in the background.
"""

from __future__ import annotations

import argparse
import importlib
import json
from collections.abc import Callable
from functools import partial
from pathlib import Path
from typing import Any

import jax.numpy as jnp
import jax.random as rax
import numpy as np
import optax

from robotl.examples.cube_spinning import CompiledEnv, build_cube_spinning
from robotl.handlers.mujoco import compile_model
from robotl.handlers.mujoco.config import MujocoSettings
from robotl.handlers.mujoco.control import plots
from robotl.handlers.mujoco.control.contact import soften_contact
from robotl.handlers.mujoco.control.diagnostics import default_recorder
from robotl.handlers.mujoco.control.gradients import adjoint_grad, sweep_grad
from robotl.handlers.mujoco.control.mpc import MPCController
from robotl.handlers.mujoco.control.planners import (
    GaussNewtonPlanner,
    GradientPlanner,
    HybridPlanner,
    Planner,
    SamplingPlanner,
)
from robotl.handlers.mujoco.control.plans import CSplinePlan
from robotl.handlers.mujoco.control.runner import benchmark_episode
from robotl.handlers.mujoco.process import EnvProcess
from robotl.handlers.mujoco.render import Camera, render_trajectory
from robotl.handlers.mujoco.rollouts import Threadpool
from robotl.internals.utils import rscope

# Registered builders for envs that need bespoke setup (collisions, physics,
# contact caps) beyond a plain compile. Anything else resolves generically from
# ``robotl.examples`` — see :func:`resolve_env`.
ENVS: dict[str, Callable[[], CompiledEnv]] = {
    "cube_spinning": build_cube_spinning,
}


def resolve_env(name: str) -> CompiledEnv:
    """A :class:`CompiledEnv` for any example. Registered builders win; otherwise
    ``robotl.examples.<name>``'s zero-arg ``factory()`` is compiled under the
    standard solver preset."""
    if name in ENVS:
        return ENVS[name]()
    factory = importlib.import_module(f"robotl.examples.{name}").factory
    model, context, mj_model = compile_model(factory)
    sim_config = MujocoSettings.standard()
    sim_config.apply(mj_model)
    return CompiledEnv(model, context, mj_model, sim_config)


def resolve_camera(name: str, mj_model) -> Camera:
    """The tuned cube view for cube_spinning, else MuJoCo's auto-framing (unset
    fields make ``to_mujoco`` frame from ``mj_model.stat``)."""
    if name == "cube_spinning":
        return Camera(
            lookat=jnp.array([0.0, 0.0, 0.35]),
            elevation=-0.4,
            azimuth=0.5,
            distance=0.6,
        )
    return Camera()


# Per-method rounds/knot-interval defaults, sized for roughly equal compute
# per planning event: mppi does rounds×batch rollouts (4×64 = 256); the FD
# planners do rounds×2P rollouts (P = 2·n_knots·nu), so one round over a
# 5-knot spline gives 320 — within 25% of mppi.
METHOD_DEFAULTS = {
    "mppi": {"rounds": 4, "knot_interval": 0.125},
    "gradient": {"rounds": 1, "knot_interval": 0.25},
    "gn": {"rounds": 1, "knot_interval": 0.25},
    "hybrid": {"rounds": 4, "knot_interval": 0.125},
}

# method -> one-line description of the planner's important knobs (line 3 of
# the startup banner).
CONTROL_DESC: dict[str, Callable[[Any], str]] = {
    "mppi": lambda p: (
        f"batch={p.batch_size}  sigma0={p.sigma0}  sigma_slope={p.sigma_slope}  "
        f"noise_color={p.noise_color}  decay={p.decay}  temp={p.temperature}  "
        f"carry_n={p.carry_n}"
    ),
    "gradient": lambda p: f"grad={p.grad_fn.__name__}  eps={p.eps}",
    "gn": lambda p: (
        f"grad={p.grad_mode}  bundle_sigma={p.bundle_sigma}  lam0={p.lam0}  "
        f"ladder={p.max_trials}"
    ),
    "hybrid": lambda p: (
        f"batch={p.batch_size}  inject_n={p.inject_n}  bundle_sigma={p.bundle_sigma}  "
        f"temp={p.temperature}  decay={p.decay}"
    ),
}

# method -> planner builder; construction is uniform, only the planner differs.
PLANNERS: dict[str, Callable[[argparse.Namespace, Threadpool, float], Planner]] = {
    "mppi": lambda args, tp, replan: SamplingPlanner(
        horizon=args.horizon,
        rounds=args.rounds,
        replan_interval=replan,
        batch_size=args.batch,
        plan_init=partial(CSplinePlan.make, knot_interval=args.knot_interval),
        sigma0=0.1,
        sigma_slope=1.0,
        noise_color=2.5,
        rollout=tp.rollout,
    ),
    "gradient": lambda args, tp, replan: GradientPlanner(
        horizon=args.horizon,
        rounds=args.rounds,
        replan_interval=replan,
        plan_init=partial(CSplinePlan.make, knot_interval=args.knot_interval),
        opt=optax.adam(args.lr),
        grad_fn={"sweep": sweep_grad, "adjoint": adjoint_grad}[args.grad],
        rollout=tp.rollout,
    ),
    "gn": lambda args, tp, replan: GaussNewtonPlanner(
        horizon=args.horizon,
        rounds=args.rounds,
        replan_interval=replan,
        plan_init=partial(CSplinePlan.make, knot_interval=args.knot_interval),
        lam0=args.lam0,
        grad_mode=args.grad_mode,
        bundle_sigma=args.bundle_sigma,
        accept=args.accept,
        rollout=tp.rollout,
    ),
    "hybrid": lambda args, tp, replan: HybridPlanner(
        horizon=args.horizon,
        rounds=args.rounds,
        replan_interval=replan,
        batch_size=args.batch,
        plan_init=partial(CSplinePlan.make, knot_interval=args.knot_interval),
        sigma0=0.1,
        sigma_slope=1.0,
        noise_color=2.5,
        inject_n=args.inject_n,
        bundle_sigma=args.bundle_sigma,
        bundle_samples=args.bundle_samples,
        grad_mode=args.grad_mode,
        lam0=args.lam0,
        rollout=tp.rollout,
    ),
}


def build_controller(
    method: str, threadpool, args, replan_interval: float = 0.0, plan_spec=None
) -> MPCController:
    """Build the receding-horizon controller: a planner from the registry, wrapped
    by the (planner-agnostic) driver. ``plan_spec`` softens the planner's rollout
    model (compliant contact) while the episode keeps the real one."""
    planner = PLANNERS[method](args, threadpool, replan_interval)
    planner.plan_spec = plan_spec
    return MPCController(planner)


def auto_output_dir(label: str) -> Path:
    """Next ``output/NNN-<label>/`` (auto-incremented, matching the run layout)."""
    base = Path("output")
    base.mkdir(exist_ok=True)
    nums = [
        int(p.name.split("-", 1)[0])
        for p in base.glob("[0-9]*-*")
        if p.name.split("-", 1)[0].isdigit()
    ]
    out = base / f"{max(nums, default=0) + 1:03d}-{label}"
    out.mkdir()
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument(
        "--env",
        default="cube_spinning",
        help="registered builder (cube_spinning) or any robotl.examples.<name> "
        "exposing a zero-arg factory() with a loss (e.g. bottleneck)",
    )
    ap.add_argument("--method", choices=tuple(PLANNERS), required=True)
    ap.add_argument("--duration", type=float, default=5.0, help="episode seconds")
    ap.add_argument("--horizon", type=float, default=1.0, help="planning horizon (s)")
    ap.add_argument("--rounds", type=int, default=None, help="planner steps per tick")
    ap.add_argument("--batch", type=int, default=64, help="mppi population size")
    ap.add_argument("--lr", type=float, default=0.05, help="gradient Adam step size")
    ap.add_argument(
        "--grad",
        choices=("sweep", "adjoint"),
        default="sweep",
        help="gradient source: central-diff sweep or mjd_transitionFD adjoint",
    )
    ap.add_argument("--lam0", type=float, default=1e-3, help="gn initial LM damping")
    ap.add_argument(
        "--grad-mode",
        choices=("fd", "bundle"),
        default="fd",
        help="gn stage-loss Jacobian: central-FD or zeroth-order bundle",
    )
    ap.add_argument(
        "--accept",
        choices=("soft", "stiff"),
        default="soft",
        help="gn LM line search scored on the soft plan_spec or the true stiff model",
    )
    ap.add_argument(
        "--inject-n",
        type=int,
        default=4,
        help="hybrid: bundle-GN descent candidates injected into the MPPI population",
    )
    ap.add_argument(
        "--bundle-samples",
        type=int,
        default=128,
        help="gn/hybrid: perturbation count of the bundled Jacobian",
    )
    ap.add_argument(
        "--bundle-sigma", type=float, default=0.1, help="gn bundle smoothing std (rad)"
    )
    ap.add_argument(
        "--soft-solref",
        type=float,
        default=1.0,
        help="soften the PLANNING contact springs by this factor (1 = off); episode stays stiff",
    )
    ap.add_argument(
        "--soft-margin",
        type=float,
        default=0.0,
        help="planning contact force-at-a-distance margin (m); episode stays stiff",
    )
    ap.add_argument(
        "--knot-interval", type=float, default=None, help="spline knot spacing (s)"
    )
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument(
        "--output", type=Path, default=None, help="output dir (default auto)"
    )
    args = ap.parse_args()
    for k, v in METHOD_DEFAULTS[args.method].items():
        if getattr(args, k) is None:
            setattr(args, k, v)

    rng = rax.key(args.seed)
    ce = resolve_env(args.env)
    env0 = EnvProcess.make(
        ce.model, ce.context, ce.mj_model, rng=rscope(rng, "env"), use_mjx=False
    )
    losses = env0.spec.get_losses(env0.state)
    threadpool = Threadpool.make(env0.spec)
    plan_spec = None
    if args.soft_solref != 1.0 or args.soft_margin != 0.0:
        plan_spec = soften_contact(env0.spec, args.soft_solref, args.soft_margin)
    controller = build_controller(
        args.method,
        threadpool,
        args,
        replan_interval=2 * ce.mj_model.opt.timestep,
        plan_spec=plan_spec,
    )

    sim_desc: str = ce.sim_config.describe()  # type: ignore[attr-defined]
    m = ce.mj_model
    length = int(args.duration / m.opt.timestep)
    label = f"{args.env}-{args.method}"
    print(f"[{label}] {sim_desc}")
    print(
        f"[{label}] env: nu={m.nu}  nq={m.nq}  nv={m.nv}  "
        f"nbody={m.nbody}  ngeom={m.ngeom}"
    )
    total = sum(float(v) for v in losses.values())
    print(f"[{label}] loss: {len(losses)} term(s), initial total={total:.4f}")
    for name, val in losses.items():
        print(f"[{label}]   {name} = {float(val):.4f}")
    print(
        f"[{label}] control: duration={args.duration}s ({length} steps)  "
        f"horizon={args.horizon}s  rounds={args.rounds}  "
        f"knot_interval={args.knot_interval}s  "
        f"replan={2 * m.opt.timestep}s  "
        + CONTROL_DESC[args.method](controller.planner)
    )
    recorder = default_recorder(env0.spec)
    episode, timings = benchmark_episode(
        env=env0,
        controller=controller,
        rng=rscope(rng, "ctrl"),
        length=length,
        label=label,
        record=recorder,
    )
    states, channels = episode.states, episode.channels

    out = args.output or auto_output_dir(label)
    camera = resolve_camera(args.env, ce.mj_model)
    render_trajectory(env0.spec, states, save_to=out / "rollout.mp4", camera=camera)
    np.savez(out / "diagnostics.npz", **episode.to_npz_dict(env0.spec))
    summary = recorder.summarize(channels)
    plots.plot_channels(
        channels,
        units=recorder.units,
        title=f"{args.env} {args.method} ({sim_desc})",
        save_to=out / "summary.png",
    )
    (out / "metrics.json").write_text(
        json.dumps(
            {
                "env": args.env,
                "method": args.method,
                "config": {**vars(args), "output": str(out)},
                "summary": summary,
                "timings": timings,
            },
            indent=2,
            default=str,
        )
    )
    print(
        f"[{label}] loss_mean={summary['loss_mean']:.3f} "
        f"min={summary['loss_min']:.3f} final={summary['loss_final']:.3f}  "
        f"pen_max={summary['pen_max'] * 1e3:.2f}mm  "
        f"{timings.get('per_step_ms', 0):.0f}ms/step  ->  {out}"
    )


if __name__ == "__main__":
    main()

import argparse
import logging
import sys
from pathlib import Path

import jax
import mujoco
import mujoco.viewer

import robotl.examples
from robotl.handlers.jax import solve_init
from robotl.handlers.mujoco.compiler import compile

logger = logging.getLogger(__name__)


def compile_example(
    example_name,
    output_dir,
    is_outermost,
    seed,
    launch_viewer=False,
):
    """Create and compile the specified robot model to XML in the output directory."""
    logger.info(f"Creating {example_name} model...")

    # Get the example class
    example_class = getattr(robotl.examples, example_name, None)
    if example_class is None:
        available = ", ".join(
            v.__name__ for v in robotl.examples.__dict__.values() if callable(v)
        )
        logger.error(f"Example '{example_name}' not found.")
        logger.info(f"Available examples: {available}")
        return

    logger.info("Converting to MuJoCo format...")
    model, init = solve_init(example_class)
    mj_model, _ = compile(
        model,
        init,
        build_path=Path(output_dir),
        is_outermost=is_outermost,
        rng=jax.random.key(seed),
    )

    if launch_viewer:
        logger.info(f"Launching MuJoCo viewer for {example_name}...")
        mujoco.viewer.launch(mj_model)

    logger.info(f"Generated XML file: {output_dir}/model.xml")


def main():
    """Main function with command line argument parsing."""
    parser = argparse.ArgumentParser(
        description="Compile robot models to XML files.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "directory",
        help="Output directory path to save XML files and assets",
        type=str,
    )
    parser.add_argument(
        "--example",
        "-e",
        help="Name of the robot example to compile (default: compile all examples)",
        default=None,
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Set the logging level (default: INFO)",
    )
    parser.add_argument(
        "--viewer",
        "-v",
        action="store_true",
        help="Launch MuJoCo viewer after compilation",
    )
    parser.add_argument(
        "--includable",
        help="Compile for inclusion in other models (omits automatic freejoints)",
        action="store_true",
    )
    parser.add_argument(
        "--seed",
        type=int,
        help="Random seed for initialization",
        default=13,
    )

    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(levelname)s: %(message)s",
        stream=sys.stderr,
        force=True,  # Force reconfiguration if already configured
    )
    logger.setLevel(getattr(logging, args.log_level))

    compile_example(
        args.example,
        args.directory,
        is_outermost=not args.includable,
        launch_viewer=args.viewer,
        seed=args.seed,
    )


if __name__ == "__main__":
    main()

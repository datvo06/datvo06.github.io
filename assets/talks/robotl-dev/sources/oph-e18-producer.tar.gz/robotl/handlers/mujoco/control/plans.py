from typing import Protocol, Self

import effectful.handlers.jax.numpy as jnp
import jax
import jax.random as rax
import numpy as np
from flax import struct

from robotl.handlers.mujoco.process import EnvProcess, EnvSpec
from robotl.internals.utils import CSpline
from robotl.ops import actuators, joints


class Plan(Protocol):
    def __call__(self, t: jax.typing.ArrayLike) -> jax.Array: ...

    def shift(self, dt: float) -> Self: ...

    def params(self) -> jax.Array: ...

    def with_params(self, params: jax.Array, spec: EnvSpec) -> Self: ...


def initial_knots(
    env: EnvProcess, horizon: float, knot_interval: float
) -> tuple[jax.Array, jax.Array]:
    """Knot times over ``[0, horizon)`` at ``knot_interval`` spacing and the constant
    initial knot values; shapes ``[n_knots]``, ``[n_knots, nu]``.

    Position servos start at their geared actuator length; other controls
    start at the current command.
    """
    horizon_steps = max(1, int(round(horizon / env.spec.dt)))
    knot_di = max(1, int(round(knot_interval / env.spec.dt)))
    knot_i = list(range(0, horizon_steps, knot_di))
    if knot_i[-1] != horizon_steps - 1:
        knot_i.append(horizon_steps - 1)
    knot_t = jnp.asarray(knot_i) * env.spec.dt
    data = env.spec.layout.state_to_data(env.state)
    q0 = jnp.asarray(data.ctrl)
    for info in env.spec.context.actuators.values():
        if isinstance(info.object, actuators.Position):
            q0 = q0.at[info.idx].set(data.actuator_length[info.idx])
    knot_x = jnp.broadcast_to(q0, [len(knot_i), env.spec.mj_model.nu])
    return knot_t, knot_x


class DensePlan(struct.PyTreeNode, Plan):
    x: jax.Array
    dt: jax.Array = struct.field(pytree_node=False)

    @classmethod
    def make(cls, env: EnvProcess, horizon: float, knot_interval: float = 0.25) -> Self:
        knot_t, knot_x = initial_knots(env, horizon, knot_interval)
        return cls(knot_x, knot_t[1] - knot_t[0])

    def __call__(self, t):
        i = jnp.floor(t / self.dt).astype(int)
        return self.x.at[i].get(mode="clip")

    def shift(self, dt):
        di = jnp.floor(dt / self.dt).astype(int)
        return self.replace(x=jnp.roll(self.x, -di, axis=0))

    def params(self) -> jax.Array:
        return self.x

    def with_params(self, params: jax.Array, spec: EnvSpec) -> Self:
        return self.replace(x=params)


class ZeroOrderHoldPlan(struct.PyTreeNode, Plan):
    t: jax.Array
    x: jax.Array

    @classmethod
    def make(cls, env: EnvProcess, horizon: float, knot_interval: float = 0.25) -> Self:
        return cls(*initial_knots(env, horizon, knot_interval))

    def __call__(self, t):
        assert self.t.ndim == 1
        assert self.x.ndim == 2
        order = jnp.argsort(self.t)

        @jax.vmap
        def fn(t):
            ia = jnp.searchsorted(self.t, t, sorter=order, method="compare_all") - 1
            ia = jnp.clip(ia, 0, self.x.shape[0] - 1)
            return self.x[ia]

        x = fn(jnp.ravel(t))
        return x.reshape([*jnp.shape(t), self.x.shape[1]])

    def shift(self, dt):
        # move expired time points to the end
        t = jnp.where(self.t >= dt, self.t - dt, jnp.max(self.t))
        return self.replace(t=t, x=self(t))

    def params(self) -> jax.Array:
        return self.x

    def with_params(self, params: jax.Array, spec: EnvSpec) -> Self:
        return self.replace(x=params)


class LinearSplinePlan(struct.PyTreeNode, Plan):
    t: jax.Array
    x: jax.Array

    @classmethod
    def make(cls, env: EnvProcess, horizon: float, knot_interval: float = 0.25) -> Self:
        return cls(*initial_knots(env, horizon, knot_interval))

    def __call__(self, t):
        assert self.t.ndim == 1
        assert self.x.ndim == 2
        assert self.t.shape[0] == self.x.shape[0]
        t_shape = jnp.shape(t)
        order = jnp.argsort(self.t)
        x = jax.vmap(
            lambda x: jnp.interp(jnp.ravel(t), self.t[order], x[order]),
            in_axes=1,
            out_axes=1,
        )(self.x)
        return x.reshape([*t_shape, self.x.shape[1]])

    def shift(self, dt):
        # move expired time points to the end
        t = jnp.where(self.t >= dt, self.t - dt, jnp.max(self.t))
        return self.replace(t=t, x=self(t))

    def params(self) -> jax.Array:
        return self.x

    def with_params(self, params: jax.Array, spec: EnvSpec) -> Self:
        return self.replace(x=params)


def control_limits(spec: EnvSpec) -> tuple[tuple[float, ...], tuple[float, ...]]:
    """Feasible commands in each actuator's control units, with unlimited ends infinite.

    Scalar joint position servos also respect geared physical joint stops.
    Force, velocity and tendon controls retain their native command limits.
    """
    model = spec.mj_model
    ranges = np.asarray(model.actuator_ctrlrange)
    lower = np.where(np.asarray(model.actuator_ctrllimited), ranges[:, 0], -np.inf)
    upper = np.where(np.asarray(model.actuator_ctrllimited), ranges[:, 1], np.inf)
    joint_ranges = np.asarray(model.jnt_range)
    joint_limited = np.asarray(model.jnt_limited)
    gears = np.asarray(model.actuator_gear)
    for info in spec.context.actuators.values():
        actuator = info.object
        if isinstance(actuator, actuators.Position) and isinstance(
            actuator.target, (joints.Hinge, joints.Slide)
        ):
            joint = spec.context.joints[actuator.target.id].idx
            if joint_limited[joint]:
                stops = joint_ranges[joint] * gears[info.idx, 0]
                lower[info.idx] = max(lower[info.idx], stops.min())
                upper[info.idx] = min(upper[info.idx], stops.max())
    if np.any(lower > upper):
        raise ValueError(
            "Position actuator control range does not intersect its joint stops: "
            f"{np.flatnonzero(lower > upper).tolist()}"
        )
    return tuple(map(float, lower)), tuple(map(float, upper))


def _actuator_span(q_min: jax.Array, q_max: jax.Array) -> jax.Array:
    """Per-actuator command range span; unit span for unlimited controls."""
    finite = jnp.isfinite(q_min) & jnp.isfinite(q_max)
    return jnp.where(finite, jnp.maximum(q_max - q_min, 1e-6), 1.0)


def knot_sigma(
    spec: EnvSpec, knot_t: jax.Array, sigma0: float, sigma_slope: float
) -> jax.Array:
    """Per-knot, per-actuator absolute σ from a linear schedule over ``knot_t``,
    shape ``[n_knots, n_act]``. ``sigma0``/``sigma_slope`` are dimensionless: a
    value of ``1`` means ±3σ spans each actuator's finite command range (unit span
    for unlimited controls)."""
    span = _actuator_span(*map(jnp.asarray, control_limits(spec)))
    return (sigma0 + knot_t[:, None] * sigma_slope) * span[None, :] / 6


def colored_noise(key: jax.Array, shape: tuple, noise_color: float) -> jax.Array:
    """Gaussian noise with power spectrum ``1/f^noise_color`` along axis 0.

    ``noise_color=0`` is plain white noise; ``>0`` produces temporally
    correlated noise along axis 0, independent across the remaining axes. The
    DC component (``f=0``) is zeroed so the colored noise has zero mean, and
    the result is renormalised to unit std along axis 0 so ``noise_color``
    controls the *shape* of the spectrum without leaking into the marginal
    variance.

    iCEM (Pinneri et al. 2020) uses ``noise_color ≈ 2.5`` for robotics.
    """
    if noise_color == 0.0:
        return rax.normal(key, shape)
    n = shape[0]
    white = rax.normal(key, shape)
    # ``jnp`` here is effectful's shim, which doesn't proxy ``fft``; call the
    # real ``jax.numpy.fft`` directly.
    fft = jax.numpy.fft.rfft(white, axis=0)
    freqs = jax.numpy.fft.rfftfreq(n)
    # Zero DC contribution; scale remaining bins by f^{-noise_color/2}.
    weight = jnp.where(freqs == 0, 0.0, freqs ** (-noise_color / 2))
    weight = weight.reshape((-1,) + (1,) * (len(shape) - 1))
    colored = jax.numpy.fft.irfft(fft * weight, n=n, axis=0)
    std = jnp.std(colored, axis=0, keepdims=True)
    return colored / jnp.maximum(std, 1e-8)


class CSplinePlan(struct.PyTreeNode, Plan):
    spline: CSpline
    bounds: tuple[tuple[float, ...], tuple[float, ...]] = struct.field(
        pytree_node=False
    )

    @classmethod
    def make(cls, env: EnvProcess, horizon: float, knot_interval: float = 0.25) -> Self:
        """Constant current position target or command, with knots at ``knot_interval``."""
        knot_t, knot_x = initial_knots(env, horizon, knot_interval)
        return cls(
            CSpline(knot_t, knot_x, jnp.zeros_like(knot_x)), control_limits(env.spec)
        )

    def __call__(self, t):
        q, _ = self.spline(t)
        return jnp.clip(q, *map(jnp.asarray, self.bounds))

    def shift(self, dt):
        return self.replace(spline=self.spline.shift(dt))

    def params(self) -> jax.Array:
        """Decision variables ``[2, n_knots, nu]``: knot positions and scaled
        tangents ``v·Δt``, both in actuator command units."""
        dt = self.spline.t[1] - self.spline.t[0]
        return jnp.stack([self.spline.x, self.spline.v * dt])

    def clip_params(self, params: jax.Array, spec: EnvSpec) -> jax.Array:
        """Project ``[..., 2, n_knots, nu]`` decision matrices onto the feasible
        box: knot commands clipped to control limits, tangents clamped by
        the remaining margin over half a sim timestep. Evaluated commands
        are also bounded between knots; unlimited controls pass through.
        """
        q_min, q_max = map(jnp.asarray, self.bounds)
        x = jnp.clip(params[..., 0, :, :], q_min, q_max)
        margin = jnp.maximum(0, jnp.minimum(q_max - x, x - q_min))
        dt = self.spline.t[1] - self.spline.t[0]
        bound = margin * dt / (spec.dt / 2.0)
        v = jnp.clip(params[..., 1, :, :], -bound, bound)
        return jnp.stack([x, v], axis=-3)

    def with_params(self, params: jax.Array, spec: EnvSpec) -> Self:
        """Build a plan of this type from decision variables ``[2, n_knots, nu]``
        (see :meth:`params`), automatically projected onto the feasible set by
        :meth:`clip_params`; evaluated commands obey the same bounds.
        """
        clipped = self.clip_params(params, spec)
        dt = self.spline.t[1] - self.spline.t[0]
        return self.replace(
            spline=CSpline(self.spline.t, clipped[0], clipped[1] / dt),
        )

from collections.abc import Callable

import effectful.handlers.jax.numpy as jnp
import jax

from robotl.examples.hinge import HingeJoint
from robotl.internals.utils import rv_solve
from robotl.ops import joints, shapes
from robotl.ops.losses import Equalize
from robotl.ops.syntax import (
    Component,
    Inertia,
    Origin,
    Port,
    Pose,
    defcomponent,
    time,
)


@defcomponent
def MassiveCylinder(self, d: float, h: float, mass: float) -> None:
    """Cylinder with explicit mass specification."""
    self.d = d
    self.h = h
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, h]))
    self.shape = shapes.cylinder(r=d / 2, h=h)
    # Add inertia for mass (cylinder: Ixx=Iyy=m*(3r^2+h^2)/12, Izz=mr^2/2)
    r = d / 2
    ixx = mass * (3 * r**2 + h**2) / 12
    izz = mass * r**2 / 2
    self.inertia = Inertia(
        mass=mass,
        pose=Pose(pos=jnp.array([0, 0, h / 2])),
        diag=jnp.array([ixx, ixx, izz]),
    )


@defcomponent
def Arm(
    self,
    link1L=0.400,
    link2L=0.400,
    linkDia=0.025,
    kp=50.0,
    kv=5.0,
    damping=2.0,
):
    """Three-link robotic arm with Waist, Shoulder, and Elbow joints.

    This configuration (3 DOFs) allows the tip to reach any position (x,y,z)
    within its workspace volume.

    Args:
        kp: Position actuator gain (N·m/rad).
        kv: Velocity feedback gain for the actuator (N·m·s/rad).
        damping: Passive joint damping (N·m·s/rad) applied to all joints.
                 Reduces oscillation without affecting the steady-state position.
    """
    from robotl.examples.simple_cad import Cylinder

    # Links with mass
    self.link1 = MassiveCylinder(d=linkDia, h=link1L, mass=0.5)
    self.link2 = MassiveCylinder(d=linkDia, h=link2L, mass=0.4)

    # 3-DOF: Waist (Z-axis), Shoulder (X-axis), Elbow (X-axis)
    self.waist = HingeJoint(axis=jnp.array([0, 0, 1]), kp=kp, kv=kv, damping=damping)
    self.shoulder = HingeJoint(axis=jnp.array([1, 0, 0]), kp=kp, kv=kv, damping=damping)
    self.elbow = HingeJoint(axis=jnp.array([1, 0, 0]), kp=kp, kv=kv, damping=damping)
    self.wristFlange = Cylinder(d=0.032, h=0.005)

    self.base = self.place(Port())
    self.tip = self.wristFlange.tip

    self._welds = [
        joints.Weld(self.base, self.waist.base),
        joints.Weld(self.waist.tip, self.shoulder.base),
        joints.Weld(self.shoulder.tip, self.link1.base),
        joints.Weld(self.link1.tip, self.elbow.base),
        joints.Weld(self.elbow.tip, self.link2.base),
        joints.Weld(self.link2.tip, self.wristFlange.base),
    ]


@defcomponent
def PathStroke(self, path, times, r=0.01):
    segments = []
    xs = list(map(path, times))
    for x1, x2 in zip(xs[:-1], xs[1:]):
        dx = x2 - x1
        length = jnp.linalg.norm(dx)
        segments.append(
            shapes.transform(
                shapes.capsule(r=r, h=length),
                Pose(pos=x1, rv=rv_solve(jnp.array([0, 0, 1]), dx / length)),
            )
        )
    self.shape = shapes.union(*segments)
    self.base = self.place(Port())
    self.disable_collision = True


@defcomponent
def EndEffector(self):
    self.shape = shapes.sphere(0.01)
    self.base = self.place(Port())


@defcomponent
def PathTracingEnv(
    self, robot: Component, path: Callable[[float], jax.Array] | None = None
):
    """
    Trace a path in 3D space.

    - Description & evaluation metrics
        - The robot needs to trace a path as defined by the reward.

    - Success criteria
        - Minimize L2 distance from the current path point
    """
    self.base = self.place(Port(), Pose(pos=[0, 0, 0.05]))
    self.ee = EndEffector()
    self.robot = robot
    if path is None:
        # figure-8 curve on the horizontal plane centered above the robot
        path = lambda t: jnp.array([0.2 * jnp.cos(t), 0.2 * jnp.sin(2 * t), 0.6])
    self.loss = Equalize(self.ee.pos, path(time()))
    self.path_stroke = PathStroke(path, jnp.linspace(0, 2 * jnp.pi))
    self._welds = [
        joints.Weld(Origin.base, self.base),
        joints.Weld(self.base, self.robot.base),
        joints.Weld(self.robot.tip, self.ee.base),
        joints.Weld(self.base, self.path_stroke.base),
    ]


if __name__ == "__main__":
    from robotl.handlers.mujoco import view_model

    view_model(lambda: PathTracingEnv(Arm()))

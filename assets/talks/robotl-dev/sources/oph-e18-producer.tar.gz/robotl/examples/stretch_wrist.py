"""Source-derived Stretch RE1 Dex Wrist with geometry-independent motor drives.

Pass the published ``stretch_description_RE1V0_tool_stretch_dex_wrist.urdf``
from https://github.com/hello-robot/stretch_urdf. Geometry, joint frames and
inertias come from that description; the removable gripper is excluded.
The tip is its attachment frame on the roll output.

The motor approximation is voltage-limited position control, not identified
Stretch firmware. In particular, the real pitch current-based mode and its
2.5 A limit are not reproduced. Do not treat this as a calibrated controller.
Yaw's external 2.4 reduction and the pitch current limit come from
https://github.com/hello-robot/stretch_body/blob/master/body/stretch_body/robot_params_RE1V0.py.
Motor assignments are specified at https://dev-docs.hello-robot.com/hardware_user_guide/
and https://dev-docs.hello-robot.com/images/dex_wrist_specification.png.
"""

import argparse
import json
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Self

import mujoco
import numpy as np
from effectful.ops.types import Term
from PIL import Image
from scipy.spatial.transform import Rotation

from robotl.examples.based import Based
from robotl.examples.dynamixel import DynamixelDrive, DynamixelModel
from robotl.handlers.mujoco import compile_model
from robotl.ops import actuators as actuator_ops
from robotl.ops import joints as joint_ops
from robotl.ops import shapes
from robotl.ops.syntax import (
    Component,
    Inertia,
    Material,
    Port,
    Pose,
    assert_transform,
    disable_pair_collisions,
    frame,
)
from robotl.ops.units import Volt, volt

STRETCH_RE1_URDF = (
    Path(__file__).parents[2]
    / "assets/stretch_re1/stretch_description_RE1V0_tool_stretch_dex_wrist.urdf"
)
"""Pinned URDF in the source checkout; these assets are not installed package data."""

STRETCH_FLANGE_COLLISION_INSET = 0.001
"""Pinned roll collision proxy's inset from its visual tool flange, in metres."""

# Assumed output-coordinate gain in N m/rad; not a firmware register value.
_WRIST_KP = 10.0


def required(root: ET.Element, query: str, source: Path) -> ET.Element:
    """Read an obligatory URDF element with source-file error context."""
    element = root.find(query)
    if element is None:
        raise ValueError(f"{source}: missing {query}")
    return element


def origin(element: ET.Element) -> Pose:
    """Read the published SI pose, including noncommuting URDF RPY rotations."""
    return Pose(
        pos=np.fromstring(element.attrib["xyz"], sep=" "),
        quat=Rotation.from_euler(
            "xyz", np.fromstring(element.attrib["rpy"], sep=" ")
        ).as_quat(scalar_first=True),
    )


@dataclass(eq=False, kw_only=True)
class WristLink(Component):
    """A published link with explicit inertial properties and attachment ports."""

    base: Port
    attachments: dict[str, Port]
    shape: shapes.Shape
    vshape: shapes.Shape | None
    inertia: Inertia
    material: Material

    @classmethod
    def make(
        cls,
        link: ET.Element,
        outgoing: list[ET.Element],
        source: Path,
        *,
        use_meshes: bool,
    ) -> Self:
        """Construct one link directly from its URDF, without inferred density."""

        def mesh(kind: str) -> shapes.Shape:
            mesh = required(link, f"{kind}/geometry/mesh", source)
            return shapes.transform(
                shapes.scale(
                    shapes.external_mesh(str(source.parent / mesh.attrib["filename"])),
                    np.fromstring(mesh.get("scale", "1 1 1"), sep=" "),
                ),
                origin(required(link, f"{kind}/origin", source)),
            )

        tensor = required(link, "inertial/inertia", source).attrib
        with frame() as pose:
            base = Port()
            attachments = {joint.attrib["name"]: Port() for joint in outgoing}
            component = cls(
                pose=pose,
                base=base,
                attachments=attachments,
                shape=mesh("collision"),
                vshape=mesh("visual") if use_meshes else None,
                inertia=Inertia(
                    mass=float(required(link, "inertial/mass", source).attrib["value"]),
                    diag=[float(tensor[key]) for key in ("ixx", "iyy", "izz")],
                    offdiag=[float(tensor[key]) for key in ("ixy", "ixz", "iyz")],
                    pose=origin(required(link, "inertial/origin", source)),
                ),
                material=Material(
                    color=np.fromstring(
                        required(link, "visual/material/color", source).attrib["rgba"],
                        sep=" ",
                    )
                ),
            )
            assert_transform(component, base)
            for joint in outgoing:
                assert_transform(
                    component,
                    attachments[joint.attrib["name"]],
                    origin(required(joint, "origin", source)),
                )
        return component


@dataclass(eq=False, kw_only=True)
class StretchDexWrist(Component):
    """Published yaw, pitch and roll assembly, without the removable gripper.

    ``DynamixelDrive`` adds forces to the existing joint outputs, not additional
    motor bodies. The URDF inertias already include the motor assembly masses.

    :param excludes: Unhandled collision markers retained for compiler traversal,
        following :class:`OpenParametricHand`.
    """

    base: Port
    tip: Port
    links: dict[str, WristLink]
    joints: list[joint_ops.Hinge]
    actuators: list[actuator_ops.Position]
    welds: list[joint_ops.Weld]
    excludes: tuple[Term | None, ...]

    @classmethod
    def make(
        cls,
        urdf: Path,
        *,
        supply: Volt = volt(12),
        use_meshes: bool = True,
        command_ranges: tuple[tuple[float, float], ...] | None = None,
    ) -> Self:
        """Load the RE1 Dex chain and apply documented motor operating points.

        :param use_meshes: Attach visual CAD overlays. Disabling them preserves
            the source collision geometry, inertias and motor drives.
        :param command_ranges: Mounted-tool target limits in yaw, pitch, roll order.
            ``None`` retains published joint travel; physical stops never change.
        """
        source = urdf.resolve()
        root = ET.parse(source).getroot()
        joint_names = (
            "joint_wrist_yaw",
            "joint_wrist_yaw_bottom",
            "joint_wrist_pitch",
            "joint_wrist_roll",
            "joint_straight_gripper",
        )
        edges = [
            required(root, f"joint[@name='{name}']", source) for name in joint_names
        ]
        link_names = (
            "link_arm_l0",
            "link_wrist_yaw",
            "link_wrist_yaw_bottom",
            "link_wrist_pitch",
            "link_wrist_roll",
        )
        drives: dict[str, tuple[DynamixelModel, float]] = {
            "joint_wrist_yaw": ("XL430-W250", 2.4),
            "joint_wrist_pitch": ("XM540-W270", 1.0),
            "joint_wrist_roll": ("XM430-W350", 1.0),
        }
        with frame() as pose:
            links = {
                name: WristLink.make(
                    required(root, f"link[@name='{name}']", source),
                    [
                        edge
                        for edge in edges
                        if required(edge, "parent", source).attrib["link"] == name
                    ],
                    source,
                    use_meshes=use_meshes,
                )
                for name in link_names
            }
            base = Port()
            welds = [joint_ops.Weld(base, links["link_arm_l0"].base)]
            hinges = []
            servos = []
            for edge in edges[:-1]:
                name = edge.attrib["name"]
                fixed = links[
                    required(edge, "parent", source).attrib["link"]
                ].attachments[name]
                moving = links[required(edge, "child", source).attrib["link"]].base
                if edge.attrib["type"] == "fixed":
                    welds.append(joint_ops.Weld(fixed, moving))
                else:
                    motor, reduction = drives[name]
                    limit = required(edge, "limit", source).attrib
                    hinge, servo = DynamixelDrive.at_voltage(motor, supply).hinge(
                        fixed,
                        moving,
                        axis=np.fromstring(
                            required(edge, "axis", source).attrib["xyz"], sep=" "
                        ),
                        rot_range=(float(limit["lower"]), float(limit["upper"])),
                        reduction=reduction,
                        kp=_WRIST_KP,
                    )
                    hinges.append(hinge)
                    servos.append(servo)
            if command_ranges is not None:
                for servo, limits in zip(servos, command_ranges, strict=True):
                    servo.ctrlrange = limits
            assembly = cls(
                pose=pose,
                base=base,
                tip=links["link_wrist_roll"].attachments["joint_straight_gripper"],
                links=links,
                joints=hinges,
                actuators=servos,
                welds=welds,
                excludes=tuple(
                    disable_pair_collisions(links[first], links[second])
                    for first, second in (
                        # Published Dex SRDF, restricted to the imported links:
                        # https://github.com/hello-robot/stretch_ros2/blob/3cf63ed1033eec8c3f1ed74ea1f422f9630f4089/stretch_moveit2/config/stretch_description_dex.srdf
                        ("link_arm_l0", "link_wrist_yaw"),
                        ("link_arm_l0", "link_wrist_pitch"),
                        ("link_arm_l0", "link_wrist_roll"),
                        ("link_wrist_yaw", "link_wrist_pitch"),
                        ("link_wrist_yaw", "link_wrist_yaw_bottom"),
                        ("link_wrist_yaw", "link_wrist_roll"),
                        ("link_wrist_pitch", "link_wrist_roll"),
                        ("link_wrist_pitch", "link_wrist_yaw_bottom"),
                        # Yaw-bottom is welded to yaw in the source URDF.
                        # These two pairs lift the arm/yaw and yaw/roll policy
                        # through that rigid group; they are not SRDF rows.
                        ("link_arm_l0", "link_wrist_yaw_bottom"),
                        ("link_wrist_yaw_bottom", "link_wrist_roll"),
                    )
                ),
            )
            assert_transform(assembly, base)
        return assembly


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--urdf", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--no-visual-meshes",
        action="store_true",
        help="Render source collision geometry without optional CAD overlays.",
    )
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    assembly, context, model = compile_model(
        lambda: Based.make(
            StretchDexWrist.make(args.urdf, use_meshes=not args.no_visual_meshes)
        ),
        build_path=args.output,
    )
    model.opt.timestep = 0.005
    model.opt.integrator = mujoco.mjtIntegrator.mjINT_IMPLICITFAST
    data = mujoco.MjData(model)
    controls = [context.actuators[actuator.id].idx for actuator in assembly.c.actuators]
    for step in range(400):
        data.ctrl[controls] = 0.2 * np.sin(step * model.opt.timestep)
        mujoco.mj_step(model, data)
    camera = mujoco.MjvCamera()
    camera.lookat[:] = [0.04, -0.04, 0]
    camera.distance = 0.5
    camera.azimuth = 135
    camera.elevation = -20
    options = mujoco.MjvOption()
    options.geomgroup[3] = 0
    with mujoco.Renderer(model, height=800, width=1000) as renderer:
        renderer.update_scene(data, camera=camera, scene_option=options)
        Image.fromarray(renderer.render()).save(
            args.output / "stretch-wrist-motion.png"
        )
    print(
        json.dumps(
            {
                "controls": model.nu,
                "qpos": data.qpos.tolist(),
                "warnings": [int(w.number) for w in data.warning],
            }
        )
    )


if __name__ == "__main__":
    main()

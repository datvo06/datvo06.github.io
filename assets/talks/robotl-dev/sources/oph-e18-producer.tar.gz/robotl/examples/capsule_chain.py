import effectful.handlers.jax.numpy as jnp

from robotl.examples.based import Based
from robotl.examples.link import Link
from robotl.handlers.mujoco import view_model
from robotl.ops import actuators, joints, sensors
from robotl.ops.syntax import Port, defcomponent

X, Z = jnp.eye(3)[0], jnp.eye(3)[2]


def make_hinge_actuator(joint):
    return actuators.Position(joint, kp=10), actuators.Velocity(joint)


@defcomponent
def RotorLink(self, length, radius=0.05):
    self.link = Link(length, radius)
    self.base = self.link.base
    self.tip = self.place(Port())
    self.joint = joints.Hinge(self.link.tip, self.tip, axis=Z, damping=1)
    self.actuator = make_hinge_actuator(self.joint)
    self.sensor = sensors.Position(self.joint)


@defcomponent
def Chain(self, n, length=0.5, radius=0.05):
    # links interleaved with coaxial rotators to get a useful arm
    self.links = [RotorLink(length, radius) for i in range(n)]
    self.joints = [
        joints.Hinge(a.tip, b.base, axis=X, damping=1)
        for a, b in zip(self.links[:-1], self.links[1:])
    ]
    self.actuators = [make_hinge_actuator(j) for j in self.joints]
    self.sensors = [sensors.Position(j) for j in self.joints]

    self.base = self.place(Port())
    self._weld_base = joints.Weld(self.base, self.links[0].base)
    self.tip = self.links[-1].tip


if __name__ == "__main__":
    view_model(lambda: Based.make(Chain(5)))

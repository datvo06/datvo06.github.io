import typing
from dataclasses import dataclass
from typing import Self, runtime_checkable

from robotl.ops import joints
from robotl.ops.syntax import (
    Component,
    ComponentProtocol,
    Origin,
    Port,
    assert_transform,
    frame,
)


@runtime_checkable
class HasBase(ComponentProtocol, typing.Protocol):
    """A component exposing a ``base`` port."""

    base: Port


@runtime_checkable
class HasTip(ComponentProtocol, typing.Protocol):
    """A component exposing a ``tip`` port."""

    tip: Port


@runtime_checkable
class HasBaseAndTip(HasBase, HasTip, typing.Protocol):
    """A component exposing both ``base`` and ``tip`` ports."""


@dataclass(eq=False, kw_only=True)
class Based(Component):
    """Anchors a component to the world by welding its base to ``Origin``.

    :param c: The anchored component.
    :param base: Own port carrying the ``Origin`` weld; without it this
        component would form an isolated island and be freejointed.
    :param welds: ``Origin.base`` -> ``base`` -> ``c.base``.
    """

    c: HasBase
    base: Port
    welds: tuple[joints.Weld, joints.Weld]

    @classmethod
    def make(cls, c: HasBase) -> Self:
        with frame() as pose:
            base = Port()
            based = cls(
                pose=pose,
                c=c,
                base=base,
                welds=(
                    joints.Weld(Origin.base, base),
                    joints.Weld(base, c.base),
                ),
            )
            assert_transform(based, base)
        return based

import effectful.handlers.jax.numpy as jnp

from robotl.examples.based import Based
from robotl.handlers.mujoco import view_model
from robotl.ops import joints, shapes
from robotl.ops.syntax import Port, Pose, defcomponent


@defcomponent
def Support(self, width=0.150, height=0.050):
    self.shape = shapes.centered_cube(width, 0.1, height)
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(rv=jnp.pi * jnp.array([1, 0, 0])))


@defcomponent
def PendulumArm(self, length=3.000, thickness=0.020):
    self.shape = shapes.cylinder(r=thickness, h=length)
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, length]))


@defcomponent
def OscillatingMass(self, mass_size=0.080):
    self.shape = shapes.sphere(mass_size)
    self.base = self.place(Port())


@defcomponent
def Pendulum(self):
    """Simple pendulum physics example with support, arm, and oscillating mass.

    Demonstrates creating a mechanical pendulum system with runtime constraints
    for physics simulation and dynamic motion analysis.
    """
    self.support = Support()
    self.arm = PendulumArm(length=0.250)
    self.mass = OscillatingMass()
    self.base = self.place(Port())
    self._weld_support = joints.Weld(self.base, self.support.base)
    self.joint = joints.Hinge(
        self.support.tip, self.arm.base, axis=jnp.array([1, 0, 0])
    )
    self._weld_mass = joints.Weld(self.arm.tip, self.mass.base)


if __name__ == "__main__":
    view_model(lambda: Based.make(Pendulum()))

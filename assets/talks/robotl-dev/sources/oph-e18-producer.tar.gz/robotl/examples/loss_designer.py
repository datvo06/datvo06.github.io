"""Replay and validate planning loss factories."""

from collections.abc import Callable
from copy import copy
from typing import Annotated

import effectful.handlers.jax.numpy as jnp  # noqa: F401  Used by synthesized code.
import jax
import pydantic
from effectful.ops.syntax import defop
from effectful.ops.types import NotHandled

from robotl.handlers.mujoco.process import EnvProcess
from robotl.ops.losses import (  # noqa: F401  Used by synthesized code.
    Equalize,
    KeepAbove,
    KeepBelow,
    Loss,
    Maximize,
    Minimize,
    Nullify,
)
from robotl.ops.syntax import LegacyComponent
from robotl.ops.syntax import (
    time as sim_time,  # noqa: F401  Used by synthesized code.
)

LossFn = Callable[[LegacyComponent], dict[str, Loss]]
"""A factory for a root component's named planning losses.

The returned mapping replaces ``env.losses``. Losses defined by other
components or attributes still contribute through ``EnvSpec.get_losses``.
"""


def set_losses(env: LegacyComponent, loss_fn: LossFn) -> LegacyComponent:
    """Replace the root's named losses before creating scoring traces."""
    env.losses = pydantic.TypeAdapter(
        dict[str, pydantic.InstanceOf[Loss]]
    ).validate_python(loss_fn(env))
    return env


@defop
def probe_env() -> EnvProcess:
    """Provide the compiled environment used to check a loss factory."""
    raise NotHandled


def _check_losses(factory: LossFn) -> LossFn:
    env = probe_env()
    base = pydantic.TypeAdapter(pydantic.InstanceOf[LegacyComponent]).validate_python(
        env.spec.model
    )
    previous = copy(base.attributes.get("losses"))
    try:
        set_losses(base, factory)
        jax.make_jaxpr(env.spec.get_loss)(env.state)
    finally:
        if previous is None:
            base.attributes.pop("losses", None)
        else:
            base.losses = previous
    return factory


CheckedLossFn = Annotated[LossFn, pydantic.AfterValidator(_check_losses)]

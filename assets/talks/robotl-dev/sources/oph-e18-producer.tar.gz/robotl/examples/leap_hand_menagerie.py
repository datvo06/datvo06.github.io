"""LEAP-hand menagerie: a parameterized family of LEAP-hand morphologies.

A directly parameterized variant of :mod:`robotl.examples.leap_hand`.
Same component chain, same joint axes (``-Z``), same coordinate conventions —
segment lengths, per-end cross-sectional widths, palm layout, finger count,
and palm base shape are all tunable. Palm shapes :class:`RectangularPalm`,
:class:`CircularPalm`, and :class:`TriangularPalm` give a small zoo of base
layouts, assembled into a hand by :func:`ParameterizedLeapHand`.

Primary use: morphology search via :class:`LeapHandConfig`.

CLI usage::

    python -m robotl.examples.leap_hand_menagerie --help
    python -m robotl.examples.leap_hand_menagerie --n-fingers 5
    python -m robotl.examples.leap_hand_menagerie --n-fingers 4 --palm-shape circular
    python -m robotl.examples.leap_hand_menagerie --n-fingers 3 --palm-shape triangular
    python -m robotl.examples.leap_hand_menagerie \\
        --finger-prox 1.2 0.8 0.6 --finger-mid 1.0 1.0 0.5
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from enum import StrEnum
from importlib import resources
from typing import ClassVar, TypedDict

import effectful.handlers.jax.numpy as jnp
import jax
import mujoco
from pydantic import BaseModel, model_validator

from robotl.examples.based import Based
from robotl.examples.hand_collision import (
    CUBE_BIT,
    FLOOR_BIT,
    PALM_BIT,
    apply_contact_response,
    assign_collision_masks,
    digit_masks,
    surface_masks,
)
from robotl.handlers.mujoco import view_model
from robotl.ops import actuators, joints, sensors, shapes
from robotl.ops.coords import Rotation
from robotl.ops.shapes import Shape, transform, translate
from robotl.ops.syntax import Component, Material, Port, Pose, defcomponent

# Menagerie mujoco_menagerie/leap_hand OBJ asset paths. Used as opt-in
# visual overlays when :attr:`LeapHandConfig.use_meshes` is set.
_MESH_FILES = [
    "palm_right.obj",
    "base.obj",
    "proximal.obj",
    "medial.obj",
    "distal.obj",
    "tip.obj",
    "thumb_base.obj",
    "thumb_proximal.obj",
    "thumb_distal.obj",
    "thumb_tip.obj",
]
_meshes = {
    name.split(".")[0]: str(
        resources.files("robotl").parent.joinpath("assets", "leap_hand", name)  # type: ignore
    )
    for name in _MESH_FILES
}

# Materials registered by the MuJoCo compiler (:func:`compile`).
# ``leap_mesh_body`` is a matte-black plastic at rgba≈0.38 with mild
# specular; ``leap_mesh_tip`` is the white silicone pad. We assign these
# by name via ``Material(name=...)`` so each mesh picks up proper shininess
# and reflectance rather than emitting as a flat rgba geom.
_BODY = "leap_mesh_body"
_WHITE = "leap_mesh_tip"


def _set_vmesh(comp, key: str, pos, quat, material: str = _BODY) -> None:
    """Attach a Menagerie LEAP visual mesh to ``comp`` as its ``vshape``.

    Sets ``comp.vshape`` to the transformed external mesh and ``comp.material``
    to the named compiler-registered material. The parametric collision
    ``shape`` is hidden behind this visual overlay by the compiler.

    :param key: Asset key from :data:`_meshes` (without ``.obj``).
    :param pos: Offset in the parent body's frame, metres.
    :param quat: Rotation in the parent body's frame (scalar-first).
    :param material: Compiler-registered material name. ``_BODY``
        (default) is matte black, ``_WHITE`` for silicone fingertips.
    """
    comp.vshape = shapes.transform(
        shapes.external_mesh(_meshes[key]), Pose(pos=list(pos), quat=list(quat))
    )
    comp.material = Material(name=material)


Z = jnp.array([0, 0, 1])

# Stock XC330-M288-T at 5 V and 550 mA. kp is from LEAP_Hand_Sim;
# kv estimates damping from the stall/free-speed line. Sources and the
# searchable current limit are in robotl.examples.leap_hand_space.
_KP = 3.0
_KV = 0.93 / (81 * 2 * math.pi / 60)
_FORCE = 0.93 / 1.80 * 0.550


@dataclass(frozen=True)
class Actuation:
    """Digit servo gains in N m/rad and N m s/rad, with a torque cap in N m."""

    kp: float = _KP
    kv: float = _KV
    force: float = _FORCE


class _JointKwargs(TypedDict):
    """Shared dissipative settings splatted into every finger joint."""

    damping: float
    armature: float
    frictionloss: float


jkwargs: _JointKwargs = dict(damping=0.05, armature=0.01, frictionloss=0.001)


def mjcube(rx, ry, rz):
    return shapes.centered_cube(2 * rx, 2 * ry, 2 * rz)


# ---------------------------------------------------------------------------
# Palm shape
# ---------------------------------------------------------------------------


class PalmShape(StrEnum):
    RECTANGULAR = "rectangular"  # fingers in a line; box palm (LEAP default)
    CIRCULAR = "circular"  # fingers in an arc; disc palm
    TRIANGULAR = "triangular"  # fingers at triangle vertices; triangular-prism palm


# ---------------------------------------------------------------------------
# Per-segment dimensions
# ---------------------------------------------------------------------------


@dataclass
class SegmentDims:
    """Resolved dimensions for one bone: length and both end widths."""

    length: float = 1.0
    base_width: float = 1.0
    tip_width: float = 1.0


class DigitDims(BaseModel):
    """Dimensions for a chain of n bone segments.

    ``widths`` has **n + 1** entries — one cross-sectional scale per joint
    boundary (palm → segment 0 tip/segment 1 base → … → fingertip).
    ``lengths`` has **n** entries — one length scale per bone.

    Because adjacent bones share the same joint boundary, the constraint
    ``tip_width[i] == base_width[i+1]`` is satisfied by construction: both
    read from ``widths[i+1]``.

    Example (4-bone finger, tapering from wide palm to narrow tip)::

        DigitDims(widths=[1.0, 0.9, 0.8, 0.6, 0.4], lengths=[1.0]*4)
    """

    widths: list[float]  # n+1 values; widths[i] and widths[i+1] bracket bone i
    lengths: list[float]  # n values

    @model_validator(mode="after")
    def _check_sizes(self) -> DigitDims:
        if len(self.widths) != len(self.lengths) + 1:
            raise ValueError(
                f"widths must have len(lengths)+1 entries; "
                f"got {len(self.widths)} widths and {len(self.lengths)} lengths"
            )
        return self

    def segment(self, i: int) -> SegmentDims:
        """Return resolved :class:`SegmentDims` for bone *i* (0-indexed)."""
        return SegmentDims(
            length=self.lengths[i],
            base_width=self.widths[i],
            tip_width=self.widths[i + 1],
        )

    @classmethod
    def default(cls, n: int = 4) -> DigitDims:
        """All-ones default (n bones at LEAP geometry)."""
        return cls(widths=[1.0] * (n + 1), lengths=[1.0] * n)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


@dataclass
class LeapHandConfig:
    """Tunable morphology parameters for :func:`ParameterizedLeapHand`.

    Defaults reproduce the original LEAP hand (all scales = 1.0).
    """

    # Number of fingers on the palm; thumb is always present.
    n_fingers: int = 3

    # Palm base shape — controls both palm body geometry and mount arrangement.
    palm_shape: PalmShape = PalmShape.RECTANGULAR

    # Radius of the palm disc (CIRCULAR only), in metres.
    palm_radius: float = 0.07

    # Side length of the equilateral-triangle palm (TRIANGULAR only), in metres.
    palm_triangle_side: float = 0.18

    # Hinge joints per finger: int (same for all) or list[int] (per-finger).
    # Range 1-3. Default 3 = original 4-segment LEAP.
    n_finger_joints: int | list[int] = 3

    # Hinge joints for thumb (1-3). Default 3.
    n_thumb_joints: int = 3

    # Finger dims: single DigitDims (shared) or list[DigitDims] (per-finger).
    # Each DigitDims must match the corresponding n_finger_joints.
    finger_dims: DigitDims | list[DigitDims] = field(
        default_factory=lambda: DigitDims.default(4)
    )

    # Thumb dims.
    thumb_dims: DigitDims = field(default_factory=lambda: DigitDims.default(4))

    # Servo gains and torque cap of each finger's joints, including its palm
    # hinge: one Actuation (shared) or list[Actuation] (per-finger).
    finger_actuation: Actuation | list[Actuation] = field(default_factory=Actuation)

    # Servo gains and torque cap of the thumb's joints.
    thumb_actuation: Actuation = field(default_factory=Actuation)

    # Additional spread factor on finger mount spacing (1.0 = default LEAP spacing).
    finger_spacing: float = 1.0

    # Scale factor on the thumb's lateral (x-axis) offset (1.0 = default ~69 mm).
    thumb_lateral: float = 1.0

    # Attach real-hardware OBJ meshes from mujoco_menagerie/leap_hand as
    # visual-only overlays on each body. Collision physics is unchanged — the
    # parametric ``_leap_box`` shapes still drive contact. Meshes align with
    # default dims; when you tweak ``finger_dims`` they will look increasingly
    # misaligned since the mesh does not scale with the parametric knobs.
    # Default on because "use the real LEAP look" is almost always what you
    # want; opt out with ``use_meshes=False`` if you need faster rendering
    # or are running morphology sweeps where dims deviate from the default.
    use_meshes: bool = True

    # Approximate max cross-section of one LEAP finger base segment at scale 1.0.
    _FINGER_BASE_CROSS: ClassVar[float] = 0.04  # metres

    def __post_init__(self):
        # Normalize and validate n_finger_joints.
        if isinstance(self.n_finger_joints, int):
            self.n_finger_joints = [self.n_finger_joints] * self.n_fingers
        for nj in self.n_finger_joints:
            if not (1 <= nj <= 5):
                raise ValueError(f"n_finger_joints must be 1-3, got {nj}")
        if not (1 <= self.n_thumb_joints <= 5):
            raise ValueError(f"n_thumb_joints must be 1-3, got {self.n_thumb_joints}")

        # Normalize finger_dims to a per-finger list.
        if isinstance(self.finger_dims, DigitDims):
            shared = self.finger_dims
            self.finger_dims = []
            for nj in self.n_finger_joints:
                n_seg = nj + 1
                if len(shared.lengths) == n_seg:
                    self.finger_dims.append(shared)
                else:
                    self.finger_dims.append(DigitDims.default(n_seg))
        # If already a list, auto-adjust each entry.
        for idx, nj in enumerate(self.n_finger_joints):
            n_seg = nj + 1
            if len(self.finger_dims[idx].lengths) != n_seg:
                self.finger_dims[idx] = DigitDims.default(n_seg)

        # Auto-adjust thumb dims.
        n_tseg = self.n_thumb_joints + 1
        if len(self.thumb_dims.lengths) != n_tseg:
            self.thumb_dims = DigitDims.default(n_tseg)

        # Normalize finger_actuation to a per-finger list.
        if isinstance(self.finger_actuation, Actuation):
            self.finger_actuation = [self.finger_actuation] * self.n_fingers
        if len(self.finger_actuation) != self.n_fingers:
            raise ValueError(
                f"finger_actuation has {len(self.finger_actuation)} entries "
                f"for {self.n_fingers} fingers"
            )

        # Triangular: edge-midpoint spacing = side / 2; must exceed finger width.
        if self.palm_shape == PalmShape.TRIANGULAR:
            base_w = max(d.widths[0] for d in self.finger_dims)
            min_side = 2 * self._FINGER_BASE_CROSS * base_w
            if self.palm_triangle_side < min_side:
                raise ValueError(
                    f"palm_triangle_side={self.palm_triangle_side:.3f}m is too small "
                    f"for finger base width scale {base_w:.2f}; "
                    f"minimum side ≈ {min_side:.3f}m"
                )
        # Circular: chord between adjacent mounts must exceed finger width.
        if self.palm_shape == PalmShape.CIRCULAR and self.n_fingers > 1:
            base_w = max(d.widths[0] for d in self.finger_dims)
            chord = 2 * self.palm_radius * math.sin(math.pi / self.n_fingers)
            min_chord = self._FINGER_BASE_CROSS * base_w
            if chord < min_chord:
                min_r = min_chord / (2 * math.sin(math.pi / self.n_fingers))
                raise ValueError(
                    f"Circular palm: chord between adjacent mounts = {chord * 1e3:.1f}mm "
                    f"is too small for finger base width scale {base_w:.2f}; "
                    f"increase palm_radius to ≥ {min_r:.3f}m"
                )
        # Rectangular: pitch must exceed finger width.
        if self.palm_shape == PalmShape.RECTANGULAR:
            base_w = max(d.widths[0] for d in self.finger_dims)
            pitch = _LEAP_FINGER_PITCH * self.finger_spacing
            min_pitch = self._FINGER_BASE_CROSS * base_w
            if self.n_fingers > 1 and pitch < min_pitch:
                raise ValueError(
                    f"Finger pitch={pitch * 1e3:.1f}mm (spacing={self.finger_spacing}) "
                    f"is too small for finger base width scale {base_w:.2f}; "
                    f"minimum pitch ≈ {min_pitch * 1e3:.1f}mm"
                )


# ---------------------------------------------------------------------------
# LEAP-faithful parameterized geometry
#
# _leap_box reproduces the exact multi-box L-shaped assemblies from
# leap_hand.py but with two independent scale axes:
#
#   length     — scales all box *positions* (stretches/compresses the bone)
#   base_width — cross-section scale at the proximal end of the bone
#   tip_width  — cross-section scale at the distal end
#
# The width applied to each box is linearly interpolated by projecting its
# centre onto the bone axis, so the assembly tapers smoothly while preserving
# the L-shaped topology for manufacturing.
# ---------------------------------------------------------------------------


def _leap_box(
    half_dims: list[float],
    center: list[float],
    tip_pos: list[float],  # bone tip offset at unit scale (metres)
    length: float,
    base_width: float,
    tip_width: float,
) -> Shape:
    """One box from a LEAP segment, with scaled position and tapered width.

    Position components along the bone axis scale by ``length``;
    perpendicular components scale by the local ``width``.
    Box dimensions scale by ``width``.
    """
    half = jnp.array(half_dims)
    c = jnp.array(center)
    tp = jnp.array(tip_pos)
    bone_len_sq = tp @ tp
    if bone_len_sq > 1e-10:
        alpha = jnp.clip((c @ tp) / bone_len_sq, 0.0, 1.0)
    else:
        alpha = jnp.array(0.5)
    w = base_width * (1 - alpha) + tip_width * alpha
    if bone_len_sq > 1e-10:
        par = tp * (c @ tp) / bone_len_sq
        pos = par * length + (c - par) * w
    else:
        pos = c * w
    rx, ry, rz = half * w
    return translate(mjcube(rx, ry, rz), pos)


# ---------------------------------------------------------------------------
# Finger segments  (exact LEAP multi-box geometry, parameterized)
# ---------------------------------------------------------------------------


@defcomponent
def ParameterizedFingerBaseSegment(
    self,
    length: float = 1.0,
    base_width: float = 1.0,
    tip_width: float = 1.0,
    use_meshes: bool = False,
):
    tp = [-0.0122, 0.0381, 0.0145]
    s, bw, tw = length, base_width, tip_width
    self.shape = shapes.union(
        _leap_box([0.01, 0.003, 0.017], [0, 0.018, 0.0147], tp, s, bw, tw),
        _leap_box([0.014, 0.02, 0.01], [-0.027, 0.042, 0.015], tp, s, bw, tw),
        _leap_box([0.017, 0.003, 0.01], [-0.0262, 0.02, 0.0146], tp, s, bw, tw),
        _leap_box([0.01, 0.012, 0.004], [-0.0295, 0.035, 0.029], tp, s, bw, tw),
        _leap_box([0.007, 0.01, 0.002], [0, 0.005, 0.03], tp, s, bw, tw),
        _leap_box([0.007, 0.01, 0.002], [0, 0.005, -0.001], tp, s, bw, tw),
    )
    if use_meshes:
        _set_vmesh(self, "base", (0.0084, 0.0077, 0.01465), (1, 0, 0, 0))
    self.base = self.place(Port())
    self.tip = self.place(
        Port(),
        Pose(pos=[-0.0122 * s, 0.0381 * s, 0.0145 * s], quat=[1, -1, -1, 1]),
    )


@defcomponent
def ParameterizedFingerProximalSegment(
    self,
    length: float = 1.0,
    base_width: float = 1.0,
    tip_width: float = 1.0,
    use_meshes: bool = False,
):
    tp = [0.015, 0.0143, -0.013]
    s, bw, tw = length, base_width, tip_width
    self.shape = _leap_box(
        [0.017, 0.013, 0.011], [0.0075, -0.0002, -0.011], tp, s, bw, tw
    )
    if use_meshes:
        _set_vmesh(
            self,
            "proximal",
            (0.0096, 0.0002, 0.0007),
            (0.500003, -0.5, -0.5, -0.499997),
        )
    self.base = self.place(Port())
    self.tip = self.place(
        Port(),
        Pose(pos=[0.015 * s, 0.0143 * s, -0.013 * s], quat=[1, 1, -1, 1]),
    )


@defcomponent
def ParameterizedFingerMiddleSegment(
    self,
    length: float = 1.0,
    base_width: float = 1.0,
    tip_width: float = 1.0,
    use_meshes: bool = False,
):
    tp = [0.0, -0.0361, 0.0002]
    s, bw, tw = length, base_width, tip_width
    self.shape = shapes.union(
        _leap_box([0.008, 0.003, 0.013], [0, -0.02, 0.015], tp, s, bw, tw),
        _leap_box([0.01, 0.002, 0.017], [0, -0.016, 0.015], tp, s, bw, tw),
        _leap_box([0.007, 0.01, 0.002], [0, -0.0045, 0.03], tp, s, bw, tw),
        _leap_box([0.007, 0.01, 0.002], [0, -0.0045, 0.0], tp, s, bw, tw),
        _leap_box([0.017, 0.011, 0.013], [0.0075, -0.035, 0.015], tp, s, bw, tw),
    )
    if use_meshes:
        _set_vmesh(self, "medial", (0.0211, -0.0084, 0.0097), (0, -1, 0, 0))
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0.0, -0.0361 * s, 0.0002 * s]))


@defcomponent
def ParameterizedFingerDistalSegment(
    self,
    length: float = 1.0,
    base_width: float = 1.0,
    tip_width: float = 1.0,
    use_meshes: bool = False,
):
    # tip at base (same as original LEAP); give axis a notional direction for alpha
    tp = [0.0, -0.025, 0.015]
    s, bw, tw = length, base_width, tip_width
    self.shape = shapes.union(
        _leap_box([0.01, 0.003, 0.015], [0, -0.017, 0.015], tp, s, bw, tw),
        _leap_box([0.007, 0.011, 0.002], [0, -0.006, 0.03], tp, s, bw, tw),
        _leap_box([0.007, 0.011, 0.002], [0, -0.006, -0.001], tp, s, bw, tw),
    )
    if use_meshes:
        _set_vmesh(self, "distal", (0.0132, -0.0061, 0.0144), (0, 1, 0, 0))
    self.base = self.place(Port())
    self.tip = self.place(Port())


# ---------------------------------------------------------------------------
# Thumb segments  (exact LEAP multi-box geometry, parameterized)
# ---------------------------------------------------------------------------


@defcomponent
def ParameterizedThumbMetacarpalSegment(
    self,
    length: float = 1.0,
    base_width: float = 1.0,
    tip_width: float = 1.0,
    use_meshes: bool = False,
):
    tp = [0.0, 0.0143, -0.013]
    s, bw, tw = length, base_width, tip_width
    self.shape = _leap_box(
        [0.017, 0.013, 0.011], [-0.0075, -0.0002, -0.011], tp, s, bw, tw
    )
    if use_meshes:
        # Menagerie reuses the finger ``proximal`` mesh for th_mp.
        _set_vmesh(
            self,
            "proximal",
            (-0.0053, 0.0003, 0.00078),
            (0.500003, -0.5, -0.5, -0.499997),
        )
    self.base = self.place(Port())
    self.tip = self.place(
        Port(),
        Pose(pos=[0.0, 0.0143 * s, -0.013 * s], quat=[1, 1, -1, 1]),
    )


@defcomponent
def ParameterizedThumbBaseSegment(
    self,
    length: float = 1.0,
    base_width: float = 1.0,
    tip_width: float = 1.0,
    use_meshes: bool = False,
):
    tp = [0.0, 0.0145, -0.017]
    s, bw, tw = length, base_width, tip_width
    self.shape = shapes.union(
        _leap_box([0.009, 0.0165, 0.002], [0, 0, -0.0015], tp, s, bw, tw),
        _leap_box([0.007, 0.002, 0.01], [0, -0.015, -0.013], tp, s, bw, tw),
        _leap_box([0.007, 0.002, 0.01], [0, 0.015, -0.013], tp, s, bw, tw),
    )
    if use_meshes:
        _set_vmesh(
            self,
            "thumb_base",
            (0.01196, 0.0, -0.0158),
            (0.707109, 0.707105, 0, 0),
        )
    self.base = self.place(Port())
    self.tip = self.place(
        Port(),
        Pose(pos=[0.0, 0.0145 * s, -0.017 * s], quat=[1, -1, 0, 0]),
    )


@defcomponent
def ParameterizedThumbProximalSegment(
    self,
    length: float = 1.0,
    base_width: float = 1.0,
    tip_width: float = 1.0,
    use_meshes: bool = False,
):
    tp = [0.0, 0.0466, 0.0002]
    s, bw, tw = length, base_width, tip_width
    self.shape = shapes.union(
        _leap_box([0.01, 0.02, 0.012], [0, 0.0105, -0.014], tp, s, bw, tw),
        _leap_box([0.01, 0.002, 0.016], [0, 0.031, -0.015], tp, s, bw, tw),
        _leap_box([0.007, 0.01, 0.002], [0, 0.042, 0.001], tp, s, bw, tw),
        _leap_box([0.007, 0.01, 0.002], [0, 0.042, -0.029], tp, s, bw, tw),
        _leap_box([0.005, 0.012, 0.009], [-0.0135, 0.0175, -0.011656], tp, s, bw, tw),
    )
    if use_meshes:
        _set_vmesh(self, "thumb_proximal", (0.0439, 0.0579, -0.0086), (1, 0, 0, 0))
    self.base = self.place(Port())
    self.tip = self.place(
        Port(),
        Pose(pos=[0.0, 0.0466 * s, 0.0002 * s], quat=[0, 0, 0, 1]),
    )


@defcomponent
def ParameterizedThumbDistalSegment(
    self,
    length: float = 1.0,
    base_width: float = 1.0,
    tip_width: float = 1.0,
    use_meshes: bool = False,
):
    tp = [0.015, -0.0175, -0.0115]  # notional axis for alpha interpolation
    s, bw, tw = length, base_width, tip_width
    self.shape = shapes.union(
        _leap_box([0.01, 0.018, 0.012], [0, -0.0085, -0.015], tp, s, bw, tw),
        _leap_box([0.01, 0.002, 0.015], [0, -0.029, -0.014], tp, s, bw, tw),
        _leap_box([0.004, 0.012, 0.009], [0.015, -0.0175, -0.0115], tp, s, bw, tw),
    )
    if use_meshes:
        _set_vmesh(self, "thumb_distal", (0.0625, 0.0784, 0.0489), (1, 0, 0, 0))
    self.base = self.place(Port())
    self.tip = self.place(Port())


# ---------------------------------------------------------------------------
# Fingertip / thumb-tip  (capsule collision geoms, matching hydrax)
#
# Hydrax (`hydrax/models/cube/leap_rh.xml` `tip` class) uses a capsule of
# r=12mm, half-length=8mm at pos=(0,-0.03,0.015) rotated π/2 about +X.
# Capsule-vs-box contact is well-conditioned in MuJoCo; the previous
# external-mesh fingertip produced unstable mesh-mesh contact and let
# the cube and adjacent fingers interpenetrate.
#
# The fingertip body is welded to the distal segment's `tip` Port (default
# Pose), so its frame coincides with the distal segment body. Hydrax's
# capsule placement therefore applies directly.
# ---------------------------------------------------------------------------

_TIP_R = 0.012  # fingertip cap radius (m)
_TIP_H = 0.016  # cylinder length between caps (m)
_TIP_POS = [0.0, -0.030, 0.015]  # offset to where the visible tip sits
_THUMB_TIP_POS = [0.0, -0.040, -0.015]


@defcomponent
def ParameterizedFingerTip(self, width: float = 1.0, use_meshes: bool = False):
    w = width
    rv = jnp.pi / 2 * jnp.array([1.0, 0.0, 0.0])  # axis along -y after rotation
    self.shape = transform(
        shapes.capsule(r=_TIP_R * w, h=_TIP_H * w),
        Pose(pos=jnp.array(_TIP_POS) * w, rv=rv),
    )
    self.friction = 0.7
    if use_meshes:
        # Menagerie tip class attaches the mesh at identity inside the
        # distal body; our fingertip body is welded identity to distal,
        # so identity offset reproduces the Menagerie placement.
        _set_vmesh(self, "tip", (0, 0, 0), (1, 0, 0, 0), _WHITE)
    self.base = self.place(Port())


@defcomponent
def ParameterizedThumbTip(self, width: float = 1.0, use_meshes: bool = False):
    w = width
    rv = jnp.pi / 2 * jnp.array([1.0, 0.0, 0.0])
    self.shape = transform(
        shapes.capsule(r=_TIP_R * w, h=_TIP_H * w),
        Pose(pos=jnp.array(_THUMB_TIP_POS) * w, rv=rv),
    )
    if use_meshes:
        _set_vmesh(self, "thumb_tip", (0, 0, 0), (1, 0, 0, 0), _WHITE)
    self.friction = 0.7
    self.base = self.place(Port())


# ---------------------------------------------------------------------------
# Finger & Thumb assemblies
# ---------------------------------------------------------------------------


# Ordered segment constructors and joint ranges for fingers and thumbs.
# n_joints selects how many to use (1-3 for fingers, 1-3 for thumbs).

# Segment constructors and joint ranges, extended beyond 4 by repeating
# middle segments.  This allows up to 6 segments (5 joints) per digit.
_FINGER_SEGMENTS = [
    ParameterizedFingerBaseSegment,
    ParameterizedFingerProximalSegment,
    ParameterizedFingerMiddleSegment,
    ParameterizedFingerDistalSegment,
    ParameterizedFingerMiddleSegment,  # extra: reuse middle
    ParameterizedFingerDistalSegment,  # extra: reuse distal
]
_FINGER_RANGES = [
    (-1.047, 1.047),
    (-0.506, 1.885),
    (-0.366, 2.042),
    (-0.506, 1.885),  # extra: reuse proximal range
    (-0.366, 2.042),  # extra: reuse middle range
]

_THUMB_SEGMENTS = [
    ParameterizedThumbMetacarpalSegment,
    ParameterizedThumbBaseSegment,
    ParameterizedThumbProximalSegment,
    ParameterizedThumbDistalSegment,
    ParameterizedThumbProximalSegment,  # extra
    ParameterizedThumbDistalSegment,  # extra
]
_THUMB_RANGES = [
    (-0.349, 2.094),
    (-0.47, 2.443),
    (-1.34, 1.88),
    (-0.47, 2.443),  # extra
    (-1.34, 1.88),  # extra
]


@defcomponent
def ParameterizedFinger(
    self,
    dims: DigitDims | None = None,
    n_joints: int = 3,
    use_meshes: bool = False,
    actuation: Actuation | None = None,
):
    """Variable-length finger chain with 1-5 hinge joints.

    ``n_joints`` controls the number of inter-segment hinges (default 3 =
    original 4-segment LEAP finger).  The chain always starts with the base
    segment and uses the first ``n_joints`` segment pairs.  A fingertip mesh
    is welded to the last segment.

    ``dims`` must have ``n_joints + 1`` lengths and ``n_joints + 2`` widths.
    When ``use_meshes`` is set, the Menagerie ``base``/``proximal``/
    ``medial``/``distal``/``tip`` OBJs are attached as visual overlays.
    ``actuation`` sets the gains and torque cap of every joint's servo;
    the default is the stock hand's.
    """
    n_seg = n_joints + 1
    d = dims or DigitDims.default(n_seg)
    a = actuation or Actuation()

    seg_ctors = _FINGER_SEGMENTS[:n_seg]
    segments = []
    for i, ctor in enumerate(seg_ctors):
        s = d.segment(i)
        segments.append(
            ctor(
                length=s.length,
                base_width=s.base_width,
                tip_width=s.tip_width,
                use_meshes=use_meshes,
            )
        )

    # Disable collision on base segment to avoid palm-finger penetration
    segments[0].disable_collision = True

    for i, seg in enumerate(segments):
        setattr(self, f"seg{i}", seg)

    self.ft = ParameterizedFingerTip(width=d.widths[-1], use_meshes=use_meshes)

    self.base = self.place(Port())
    self._weld_base = joints.Weld(self.base, segments[0].base)
    self.joints = [
        joints.Hinge(
            segments[i].tip,
            segments[i + 1].base,
            axis=-Z,
            range=_FINGER_RANGES[i],
            **jkwargs,  # type: ignore
        )
        for i in range(n_joints)
    ]
    self._weld_tip = joints.Weld(segments[-1].tip, self.ft.base)
    self.tip = self.ft.base

    self.actuators = [
        actuators.Position(
            j, ctrlrange=j.range, kp=a.kp, kv=a.kv, forcerange=(-a.force, a.force)
        )
        for j in self.joints
    ]
    self.sensors = [sensors.Position(j) for j in self.joints]


@defcomponent
def ParameterizedThumb(
    self,
    dims: DigitDims | None = None,
    n_joints: int = 3,
    use_meshes: bool = False,
    actuation: Actuation | None = None,
):
    """Variable-length thumb chain with 1-5 hinge joints.

    ``actuation`` is as in :func:`ParameterizedFinger`.
    """
    n_seg = n_joints + 1
    d = dims or DigitDims.default(n_seg)
    a = actuation or Actuation()

    seg_ctors = _THUMB_SEGMENTS[:n_seg]
    segments = []
    for i, ctor in enumerate(seg_ctors):
        s = d.segment(i)
        segments.append(
            ctor(
                length=s.length,
                base_width=s.base_width,
                tip_width=s.tip_width,
                use_meshes=use_meshes,
            )
        )

    # Disable collision on base segment to avoid palm-thumb penetration
    segments[0].disable_collision = True

    for i, seg in enumerate(segments):
        setattr(self, f"seg{i}", seg)

    self.tt = ParameterizedThumbTip(width=d.widths[-1], use_meshes=use_meshes)

    self.base = self.place(Port())
    self._weld_base = joints.Weld(self.base, segments[0].base)
    self.joints = [
        joints.Hinge(
            segments[i].tip,
            segments[i + 1].base,
            axis=-Z,
            range=_THUMB_RANGES[i],
            **jkwargs,  # type: ignore
        )
        for i in range(n_joints)
    ]
    self._weld_tip = joints.Weld(segments[-1].tip, self.tt.base)
    self.tip = self.tt.base

    self.actuators = [
        actuators.Position(
            j, ctrlrange=j.range, kp=a.kp, kv=a.kv, forcerange=(-a.force, a.force)
        )
        for j in self.joints
    ]
    self.sensors = [sensors.Position(j) for j in self.joints]


# ---------------------------------------------------------------------------
# Palm mount-position helpers
# ---------------------------------------------------------------------------

# LEAP reference measurements (metres, palm frame)
_LEAP_FINGER_PITCH = 0.0454  # distance between adjacent finger mounts (45.4 mm)
_LEAP_FINGER_Y0 = 0.023  # y of first (top) finger in LEAP 3-finger config
_LEAP_THUMB_X = -0.0693
_PALM_THICKNESS = 0.023
_FINGER_BOX_HY = 0.013  # palm-column half-y per finger slot


def _rect_finger_ys(n: int, pitch: float) -> list[float]:
    """Evenly spaced y-coordinates starting from the LEAP first-finger Y position."""
    return [_LEAP_FINGER_Y0 - i * pitch for i in range(n)]


_X = jnp.array([1.0, 0.0, 0.0])
_LEAP_FINGER_ROT = Rotation(quat=[1, 1, 1, -1])


def _inward_mount_rot(y: float, z: float) -> Rotation:
    """Rotation so the finger extends in +x and curls inward toward the centroid.

    Pre-rotates the default LEAP finger orientation by -φ around x, where
    φ = atan2(y, z) is the mount's angular position on the palm face.
    """
    r = math.hypot(y, z)
    if r < 1e-9:
        return _LEAP_FINGER_ROT
    phi = math.atan2(y, z)
    return Rotation(rv=-phi * _X) @ _LEAP_FINGER_ROT


# ---------------------------------------------------------------------------
# Palm components — one per shape
# ---------------------------------------------------------------------------


@defcomponent
def RectangularPalm(
    self,
    n_fingers: int = 3,
    finger_spacing: float = 1.0,
    thumb_lateral: float = 1.0,
    use_meshes: bool = False,
):
    pitch = _LEAP_FINGER_PITCH * finger_spacing
    ys = _rect_finger_ys(n_fingers, pitch)
    y_top = ys[0]
    y_bot = ys[-1]
    y_center = (y_top + y_bot) / 2
    half_span = abs(y_top - y_bot) / 2 + _FINGER_BOX_HY

    column_boxes = [
        translate(
            mjcube(0.011, _FINGER_BOX_HY, 0.017), [-0.009, y - _FINGER_BOX_HY, -0.011]
        )
        for y in ys
    ]
    front_plate = translate(mjcube(0.01, half_span, 0.015), [-0.03, y_center, -0.003])
    back_plate = translate(mjcube(0.012, half_span, 0.023), [-0.048, y_center, -0.0115])
    thumb_angled = transform(
        mjcube(0.029, 0.01, 0.023),
        Pose(pos=[-0.066, -0.078, -0.0115], quat=[0.989016, 0, 0, -0.147806]),
    )
    thumb_block = translate(mjcube(0.022, 0.026, 0.023), [-0.078, -0.053, -0.0115])
    thumb_pin = translate(mjcube(0.002, 0.018, 0.017), [-0.098, -0.009, -0.006])
    thumb_top = translate(mjcube(0.022, 0.028, 0.002), [-0.078, -0.003, 0.010])

    self.shape = shapes.union(
        *column_boxes,
        front_plate,
        back_plate,
        thumb_angled,
        thumb_block,
        thumb_pin,
        thumb_top,
    )
    if use_meshes:
        _set_vmesh(self, "palm_right", (-0.02, 0.02575, -0.0347), (1, 0, 0, 0))
    self.base = self.place(Port())
    self.finger_mounts = [
        self.place(Port(), Pose(pos=[-0.007, y, -0.0187], quat=[1, 1, 1, -1]))
        for y in ys
    ]
    self.thumb_mount = self.place(
        Port(),
        Pose(pos=[_LEAP_THUMB_X * thumb_lateral, -0.0012, -0.0216], quat=[1, 0, 1, 0]),
    )


@defcomponent
def CircularPalm(
    self,
    n_fingers: int = 3,
    palm_radius: float = 0.07,
):
    t = _PALM_THICKNESS
    r = palm_radius + 0.008
    s2 = math.sqrt(0.5)
    # One disc, 8 mm past the ring the finger mounts sit on. A square slab
    # used to wrap it, which put the mounts at one edge midpoint and two
    # corners and weighed in as a second geom. Cylinders compile to meshes
    # (``EXPORT_CYLINDER`` in the compiler), so this palm is a mesh geom.
    self.shape = transform(
        shapes.cylinder(r=r, h=t),
        Pose(pos=[-0.007 - t / 2, 0, 0], quat=[s2, 0, s2, 0]),
    )

    angles = [2 * math.pi * i / n_fingers for i in range(n_fingers)]
    self.base = self.place(Port())
    self.finger_mounts = [
        self.place(
            Port(),
            Pose(
                pos=[-0.007, palm_radius * math.sin(a), palm_radius * math.cos(a)],
                rot=_inward_mount_rot(
                    palm_radius * math.sin(a), palm_radius * math.cos(a)
                ),
            ),
        )
        for a in angles
    ]


@defcomponent
def TriangularPalm(
    self,
    n_fingers: int = 3,
    palm_triangle_side: float = 0.18,
):
    side = palm_triangle_side
    h = side * math.sqrt(3) / 2
    bx = 0.014  # palm depth (x half-extent)
    n_slices = 4
    z_bot = -h / 3
    z_top = 2 * h / 3
    dz = h / n_slices

    slices = []
    for i in range(n_slices):
        z_c = z_bot + dz * (i + 0.5)
        half_y = side / 2 * (z_top - z_c) / h
        slices.append(translate(mjcube(bx, half_y, dz / 2), [-0.007, 0.0, z_c]))

    # (y, z) positions: edge midpoints first, then vertices
    tri_pts = [
        (-side / 4, h / 6),
        (side / 4, h / 6),
        (0.0, -h / 3),
        (0.0, h * 2 / 3),
        (-side / 2, -h / 3),
        (side / 2, -h / 3),
    ]
    if n_fingers > len(tri_pts):
        raise ValueError(
            f"Triangular palm supports at most {len(tri_pts)} fingers, got {n_fingers}"
        )

    col_boxes = [
        translate(
            mjcube(0.011, _FINGER_BOX_HY, _FINGER_BOX_HY),
            [-0.009, y - _FINGER_BOX_HY, z],
        )
        for y, z in tri_pts[:n_fingers]
    ]

    self.shape = shapes.union(*slices, *col_boxes)
    self.base = self.place(Port())
    self.finger_mounts = [
        self.place(
            Port(),
            Pose(pos=[-0.007, y, z], rot=_inward_mount_rot(y, z)),
        )
        for y, z in tri_pts[:n_fingers]
    ]


# ---------------------------------------------------------------------------
# Full assembly
# ---------------------------------------------------------------------------


@defcomponent
def ParameterizedLeapHand(self, config: LeapHandConfig | None = None):
    """LEAP hand with fully tunable morphology.

    Exposes:
      - ``base``       — palm weld port
      - ``tip``        — middle (or first) finger's fingertip
      - ``fingertips`` — all digit tips [finger_0, …, thumb]
    """
    cfg = config or LeapHandConfig()

    # Match the original LeapHand's base/origin convention so that
    # CubeSpinningEnv (which welds robot.base) positions us correctly.
    Y = jnp.array([0, 1, 0])
    Z = jnp.array([0, 0, 1])
    leap_offset = (
        Pose(rv=jnp.pi / 2 * Y)
        @ Pose(rv=-jnp.pi / 2 * Z)
        @ Pose(pos=[0.03, 0.01, -0.1])
    )
    if cfg.palm_shape in (PalmShape.CIRCULAR, PalmShape.TRIANGULAR):
        # Non-rect palms face sideways without correction. Ry(-90°) applied
        # AFTER leap_offset rotates the hand so palms face upward, matching
        # the visual convention. CubeSpinningEnv welds to hand.base, so the
        # cube placement adjusts automatically with the rotated base.
        self.base = self.place(Port(), Pose(rv=-jnp.pi / 2 * Y) @ leap_offset)
    else:
        self.base = self.place(Port(), leap_offset)
    self.origin = self.place(Port())

    if cfg.palm_shape == PalmShape.CIRCULAR:
        self.palm = CircularPalm(
            n_fingers=cfg.n_fingers,
            palm_radius=cfg.palm_radius,
        )
    elif cfg.palm_shape == PalmShape.TRIANGULAR:
        self.palm = TriangularPalm(
            n_fingers=cfg.n_fingers,
            palm_triangle_side=cfg.palm_triangle_side,
        )
    else:
        # Only the rectangular palm currently has a matching Menagerie mesh
        # (``palm_right.obj``). For the circular and triangular palms we
        # intentionally skip mesh decoration.
        self.palm = RectangularPalm(
            n_fingers=cfg.n_fingers,
            finger_spacing=cfg.finger_spacing,
            thumb_lateral=cfg.thumb_lateral,
            use_meshes=cfg.use_meshes,
        )
    self._weld_palm = joints.Weld(self.origin, self.palm.base)

    finger_joints = cfg.n_finger_joints  # always list after __post_init__
    finger_dims_list = cfg.finger_dims  # always list after __post_init__
    finger_actuation = cfg.finger_actuation  # always list after __post_init__
    assert isinstance(finger_joints, list)
    assert isinstance(finger_dims_list, list)
    assert isinstance(finger_actuation, list)
    self.fingers = [
        ParameterizedFinger(
            dims=finger_dims_list[i],
            n_joints=finger_joints[i],
            use_meshes=cfg.use_meshes,
            actuation=finger_actuation[i],
        )
        for i in range(cfg.n_fingers)
    ]

    has_thumb = cfg.palm_shape == PalmShape.RECTANGULAR
    if has_thumb:
        self.thumb = ParameterizedThumb(
            dims=cfg.thumb_dims,
            n_joints=cfg.n_thumb_joints,
            use_meshes=cfg.use_meshes,
            actuation=cfg.thumb_actuation,
        )

    digits = self.fingers + ([self.thumb] if has_thumb else [])
    digit_mounts = self.palm.finger_mounts + (
        [self.palm.thumb_mount] if has_thumb else []
    )
    digit_ranges = cfg.n_fingers * [(-0.314, 2.23)] + (
        [(-0.349, 2.094)] if has_thumb else []
    )
    digit_actuation = finger_actuation + ([cfg.thumb_actuation] if has_thumb else [])

    self.joints = [
        joints.Hinge(mount, digit.base, axis=-Z, range=rng, **jkwargs)  # type: ignore
        for mount, digit, rng in zip(digit_mounts, digits, digit_ranges)
    ]
    self.actuators = [
        actuators.Position(
            j, ctrlrange=j.range, kp=a.kp, kv=a.kv, forcerange=(-a.force, a.force)
        )
        for j, a in zip(self.joints, digit_actuation)
    ]
    self.sensors = [sensors.Position(j) for j in self.joints]

    self.fingertips = [f.tip for f in self.fingers] + (
        [self.thumb.tip] if has_thumb else []
    )
    self.tip = self.fingertips[min(1, cfg.n_fingers - 1)]

    def _set_friction(c: Component):
        if hasattr(c, "shape") and not hasattr(c, "friction"):
            setattr(c, "friction", 0.2)
        for _, child in jax.tree.leaves_with_path(getattr(c, "attributes", {})):
            if isinstance(child, Component):
                _set_friction(child)

    _set_friction(self)


# ---------------------------------------------------------------------------
# MuJoCo post-compile setup
# ---------------------------------------------------------------------------
#
# RoboTL's Component model can't express MuJoCo contact-solver params
# (solref/solimp/margin), collision bitmasks, or per-geom two-tone paint, so
# these are patched onto the compiled mj_model here. PD gains, force limits,
# joint damping/armature, and sliding friction ARE baked into the morphology
# above. The cube is the task env's concern — see
# :func:`robotl.examples.cube_spinning.patch_cube`. The contact response
# constants and the mask engine live in
# :mod:`robotl.examples.hand_collision`, shared with the other mounted hands.


def setup_hand_collisions(mj_model) -> str:
    """Assign the LEAP hand's collision groups (``contype``/``conaffinity``).

    Sole owner of the collision bitmasks. Beyond enabling the physical
    contacts, it drops two categories of wasted pair-checks that would
    otherwise dominate MJX collision cost:

    * Intra-digit pairs — ``fingers_0_seg1`` vs ``fingers_0_seg3`` etc.
      Adjacent parent/child pairs are already auto-filtered by MuJoCo's
      ``filterparent`` flag; non-adjacent segments of the same finger
      are not, even though they cannot meaningfully collide in a
      rigid-body LEAP hand.
    * Mount-plate pairs — ``seg0`` of each finger is the motor-mount
      body at the knuckle. It is fixed against the palm and its
      "collision" surfaces are inside the mechanism, so any contact it
      generates is non-physical.

    After this call:

    * fingers **do** collide with other fingers, with the palm, with
      the cube, and with the floor;
    * segments of the **same** finger do **not** collide with each
      other or with that finger's fingertip capsule;
    * ``seg0`` (finger mounts) and palm-mesh visuals do not collide.

    Bitmask layout (one bit per collision group):

    ========  =====================================================
    bit 0     cube
    bit 1     floor
    bit 2     palm (structural primitives only)
    bit 3..N  per-digit (``fingers_0``, ``fingers_1``, …, ``thumb``)
    ========  =====================================================

    Pair semantics: two geoms collide iff
    ``(A.contype & B.conaffinity) != 0`` OR
    ``(B.contype & A.conaffinity) != 0``. Each digit uses a single-bit
    ``contype`` and a multi-bit ``conaffinity`` excluding its own bit,
    so same-digit pairs zero out.

    Pair with :func:`apply_hand_physics` (which sets the material contact
    response on the collision-active geoms). Returns a short summary string.
    """
    # Enumerate digits in a stable order so bit assignments are
    # reproducible. Prefix is the regex-captured digit name
    # (``fingers_0``, ``fingers_1``, ``fingers_2``, ``thumb``).
    digits: list[str] = []
    for bi in range(mj_model.nbody):
        body_name = mj_model.body(bi).name
        m = re.search(r"(fingers_\d+|thumb)", body_name)
        if m and m.group(1) not in digits:
            digits.append(m.group(1))
    digit_bit = {d: 1 << (3 + i) for i, d in enumerate(digits)}
    all_digit_bits = sum(digit_bit.values())

    def classify(geom: int) -> tuple[str, tuple[int, int]]:
        body = mj_model.body(int(mj_model.geom_bodyid[geom])).name
        gtype = int(mj_model.geom_type[geom])

        if "cube" in body:
            return "cube", surface_masks(CUBE_BIT, all_digit_bits)
        if gtype == int(mujoco.mjtGeom.mjGEOM_PLANE):
            return "floor", surface_masks(FLOOR_BIT, all_digit_bits)
        if "palm" in body:
            if gtype == int(mujoco.mjtGeom.mjGEOM_MESH):
                return "off", (0, 0)
            return "palm", surface_masks(PALM_BIT, all_digit_bits)
        m = re.search(r"(fingers_\d+|thumb)", body)
        if m is None:
            return "off", (0, 0)
        digit = m.group(1)
        seg = re.search(rf"{digit}_seg(\d+)", body)
        if seg is not None and int(seg.group(1)) == 0:
            # The motor-mount body at the knuckle: fixed against the palm,
            # its surfaces inside the mechanism.
            return "mount", (0, 0)
        if "_ft" in body or "_tt" in body:
            return "tip", digit_masks(digit_bit[digit], all_digit_bits)
        if seg is not None:
            return "seg", digit_masks(digit_bit[digit], all_digit_bits)
        return "off", (0, 0)

    summary = assign_collision_masks(mj_model, "hand collision filter", classify)
    return f"{summary}, {len(digits)} digits (within-digit + mounts disabled)"


def apply_hand_physics(mj_model) -> str:
    """Patch the compiled model with the hand's MuJoCo-only contact settings.

    Sets what the RoboTL Component model can't express: per-geom solref/solimp,
    palm collision margin, fingertip friction (incl. torsional/rolling), and
    the two-tone paint (white silicone tips + connector caps, black bodies).
    Operates on the hand + floor geoms; the cube is patched separately by
    :func:`robotl.examples.cube_spinning.patch_cube`. Run *after*
    :func:`setup_hand_collisions` — it scopes to collision-active geoms.

    Returns a short summary string.
    """
    tips: set[int] = set()
    palms: set[int] = set()
    for gi in range(mj_model.ngeom):
        body_name = mj_model.body(int(mj_model.geom_bodyid[gi])).name
        gname = mj_model.geom(gi).name
        if (
            "_ft" in body_name
            or "_tt" in body_name
            or any(k in gname for k in ("ft", "tt"))
        ):
            tips.add(gi)
        if "palm" in body_name and mj_model.geom_type[gi] != int(
            mujoco.mjtGeom.mjGEOM_MESH
        ):
            palms.add(gi)
    summary = apply_contact_response(mj_model, tips, palms)

    # ── Paint: white silicone tips + thin connector caps, black bodies ──
    # Each parametric segment emits multiple boxes; bulky ones are the
    # structural body, flat/thin ones are joint caps / mount plates. We
    # split them with a dimensional heuristic (min/max half-extent < 0.25
    # reads as "thin cap" → white). Visual-mesh overlays (group 1) keep
    # their own colour.
    _BLACK = [0.18, 0.18, 0.18, 1.0]
    _WHITE = [0.96, 0.96, 0.96, 1.0]
    _CAP_RATIO = 0.25
    for gi in range(mj_model.ngeom):
        if int(mj_model.geom_group[gi]) == 1:
            continue
        body_name = mj_model.body(int(mj_model.geom_bodyid[gi])).name
        if "_ft" in body_name or "_tt" in body_name:
            mj_model.geom_rgba[gi] = _WHITE
        elif "palm" in body_name or "fingers_" in body_name or "thumb" in body_name:
            size = mj_model.geom_size[gi]
            max_dim, min_dim = float(max(size)), float(min(size))
            ratio = min_dim / max_dim if max_dim > 0 else 1.0
            mj_model.geom_rgba[gi] = _WHITE if ratio < _CAP_RATIO else _BLACK

    return summary


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="View a parameterized LEAP hand in the MuJoCo viewer.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # Palm layout
    parser.add_argument(
        "--n-fingers",
        type=int,
        default=3,
        help="Number of fingers (thumb always present).",
    )
    parser.add_argument(
        "--palm-shape",
        choices=[s.value for s in PalmShape],
        default="rectangular",
        help="Palm base shape: rectangular / circular / triangular.",
    )
    parser.add_argument(
        "--palm-radius",
        type=float,
        default=0.045,
        help="Palm disc radius in metres (circular only).",
    )
    parser.add_argument(
        "--palm-triangle-side",
        type=float,
        default=0.08,
        help="Triangle side length in metres (triangular only).",
    )
    parser.add_argument(
        "--finger-spacing",
        type=float,
        default=1.0,
        help="Stretch factor on finger-mount spacing.",
    )
    parser.add_argument(
        "--thumb-lateral",
        type=float,
        default=1.0,
        help="Scale on the thumb's lateral offset.",
    )

    # Joint count
    parser.add_argument(
        "--n-finger-joints",
        type=int,
        default=3,
        help="Hinge joints per finger (1-5). Fewer = simpler finger.",
    )
    parser.add_argument(
        "--n-thumb-joints",
        type=int,
        default=3,
        help="Hinge joints for the thumb (1-5).",
    )

    args = parser.parse_args()

    cfg = LeapHandConfig(
        n_fingers=args.n_fingers,
        palm_shape=PalmShape(args.palm_shape),
        palm_radius=args.palm_radius,
        palm_triangle_side=args.palm_triangle_side,
        finger_spacing=args.finger_spacing,
        thumb_lateral=args.thumb_lateral,
        n_finger_joints=args.n_finger_joints,
        n_thumb_joints=args.n_thumb_joints,
    )

    view_model(lambda: Based.make(ParameterizedLeapHand(config=cfg)))

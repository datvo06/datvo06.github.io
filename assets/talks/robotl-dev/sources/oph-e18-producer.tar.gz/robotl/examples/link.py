from robotl.ops import shapes
from robotl.ops.syntax import Port, Pose, defcomponent


@defcomponent
def Link(self, length, radius):
    self.shape = shapes.capsule(r=radius, h=length)
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, length]))

"""YCB objects as components with measured mass and material.

Download an object with ``scripts/download_ycb.py``, then put it in a scene::

    obj = YCBObject(name="048_hammer", mesh_path=mesh_path)

Collision goes through convex parts built at construction, COACD hulls of
each rigid part carried as :func:`robotl.ops.shapes.mesh` terms, and the true
scan renders over them. Each part's density is its share of the measured mass
in :data:`OBJECT_CONFIGS` over the volume of those hulls, the same volume the
compiler integrates, so the compiled inertia lands on the measured mass. The
hammer constructs as a wood handle with a metal head welded to it; envs
choose their own subset of objects.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path

import numpy as np
import unxt
from effectful.ops.semantics import evaluate, handler

from robotl.handlers.cad.decomposition import as_trimesh
from robotl.handlers.cad.openscad import (
    ShapeToOpenSCAD,
    render_convex_parts,
    solid2_to_mesh,
)
from robotl.ops import joints, shapes
from robotl.ops.syntax import Material, Port, defcomponent
from robotl.ops.units import kg

# Bulk materials of YCB objects. Wood and steel carry nominal densities for
# the mass split of two-part tools; the per-object density derived from the
# measured mass takes precedence.
CERAMIC = Material(friction=0.4, color=[0.95, 0.93, 0.88, 1.0])
PLASTIC = Material(friction=0.5, color=[0.90, 0.78, 0.20, 1.0])
METAL = Material(density=7850.0, friction=0.3, color=[0.55, 0.56, 0.60, 1.0])
WOOD = Material(density=700.0, friction=0.5, color=[0.72, 0.52, 0.28, 1.0])
RUBBER = Material(friction=0.9, color=[0.75, 0.85, 0.15, 1.0])
CARDBOARD = Material(friction=0.5, color=[0.82, 0.68, 0.42, 1.0])


@dataclass(frozen=True)
class ObjectConfig:
    """Physical properties of a YCB object for simulation.

    :param name: YCB object id
    :param object_rv: Rotation vector of the natural resting orientation
    :param mass: Measured mass, from the YCB digital-scale data
    :param material: Bulk material
    """

    name: str
    object_rv: list
    mass: unxt.AbstractQuantity
    material: Material


# Mass values from the YCB dataset (digital scale, +-1g). All objects use
# object_rv=[0,0,0]: YCB meshes are already in natural resting orientation
# (tools lying flat, bottles upright, etc.).
OBJECT_CONFIGS: dict[str, ObjectConfig] = {
    # Upright containers
    "002_master_chef_can": ObjectConfig(
        "002_master_chef_can", [0, 0, 0], kg(0.414), METAL
    ),
    "003_cracker_box": ObjectConfig("003_cracker_box", [0, 0, 0], kg(0.411), CARDBOARD),
    "004_sugar_box": ObjectConfig("004_sugar_box", [0, 0, 0], kg(0.514), CARDBOARD),
    "005_tomato_soup_can": ObjectConfig(
        "005_tomato_soup_can", [0, 0, 0], kg(0.349), METAL
    ),
    "006_mustard_bottle": ObjectConfig(
        "006_mustard_bottle", [0, 0, 0], kg(0.603), PLASTIC
    ),
    "007_tuna_fish_can": ObjectConfig("007_tuna_fish_can", [0, 0, 0], kg(0.171), METAL),
    "008_pudding_box": ObjectConfig("008_pudding_box", [0, 0, 0], kg(0.187), CARDBOARD),
    "009_gelatin_box": ObjectConfig("009_gelatin_box", [0, 0, 0], kg(0.097), CARDBOARD),
    "010_potted_meat_can": ObjectConfig(
        "010_potted_meat_can", [0, 0, 0], kg(0.370), METAL
    ),
    "019_pitcher_base": ObjectConfig("019_pitcher_base", [0, 0, 0], kg(0.178), PLASTIC),
    "024_bowl": ObjectConfig("024_bowl", [0, 0, 0], kg(0.147), CERAMIC),
    "025_mug": ObjectConfig("025_mug", [0, 0, 0], kg(0.118), CERAMIC),
    # Flat tools (already lying flat in canonical frame)
    "035_power_drill": ObjectConfig("035_power_drill", [0, 0, 0], kg(0.895), PLASTIC),
    "036_wood_block": ObjectConfig("036_wood_block", [0, 0, 0], kg(0.729), WOOD),
    "040_large_marker": ObjectConfig("040_large_marker", [0, 0, 0], kg(0.016), PLASTIC),
    "042_adjustable_wrench": ObjectConfig(
        "042_adjustable_wrench", [0, 0, 0], kg(0.252), METAL
    ),
    "043_phillips_screwdriver": ObjectConfig(
        "043_phillips_screwdriver", [0, 0, 0], kg(0.097), PLASTIC
    ),
    "044_flat_screwdriver": ObjectConfig(
        "044_flat_screwdriver", [0, 0, 0], kg(0.098), PLASTIC
    ),
    "048_hammer": ObjectConfig("048_hammer", [0, 0, 0], kg(0.665), WOOD),
    # Ball-like objects
    "013_apple": ObjectConfig("013_apple", [0, 0, 0], kg(0.068), PLASTIC),
    "056_tennis_ball": ObjectConfig("056_tennis_ball", [0, 0, 0], kg(0.058), RUBBER),
}

#: Scan-frame y coordinate where the 048_hammer metal head begins; the handle
#: lies below. Read off the scan's vertex profile along its long axis.
HAMMER_HEAD_MIN_Y = 0.03

#: Half-space clip cubes are this large; bigger than any YCB scan.
_CLIP_SPAN = 1.0


@defcomponent
def YCBObjectPart(self, collision_shape, visual_shape, part_material):
    """One rigid part of a YCB object; welds to the object's first part."""
    self.shape = collision_shape
    if visual_shape is not None:
        self.vshape = visual_shape
    self.material = part_material
    self.base = self.place(Port())


@defcomponent
def YCBObject(
    self,
    name: str,
    mesh_path: str | Path,
    max_parts: int | None = 6,
    show_true_mesh: bool = True,
):
    """Free-floating YCB object with measured mass and material.

    Collision is a union of up to ``max_parts`` COACD convex hulls per rigid
    part, built here at construction and carried as
    :func:`robotl.ops.shapes.mesh` terms, or the raw mesh colliding as its
    convex hull when ``max_parts`` is ``None``. The hammer constructs as a
    wood handle with a metal head welded to it, split at
    :data:`HAMMER_HEAD_MIN_Y`; the measured mass splits across parts by
    nominal density and volume. Each part's density is its mass share over
    the volume the compiler's inertia integral covers: the hulls, overlaps
    double counted on both sides alike, or the scan itself when ``max_parts``
    is ``None``. An open scan has no volume to integrate directly and is
    refused without ``max_parts``. With ``show_true_mesh`` the true scan
    renders over the collision parts.

    Construction keeps ``parts_info`` as (label, part mesh, mass) per rigid
    part for analysis, such as building a matching collision proxy.
    """
    cfg = OBJECT_CONFIGS[name]
    # OpenSCAD resolves import() relative to the generated .scad file, so a
    # relative mesh path would break the render; absolutize it here.
    mesh_path = Path(mesh_path).resolve()
    base = shapes.external_mesh(str(mesh_path))
    mesh = as_trimesh(str(mesh_path))

    # Rigid parts as (label, material, clip region); None means the whole
    # scan. Part shapes go through the ordinary CAD pipeline, so the metric
    # meshes match the simulated geometry.
    regions: list[tuple[str, Material, shapes.Shape | None]]
    if name == "048_hammer" and max_parts is not None:
        clip = shapes.centered_cube(_CLIP_SPAN, _CLIP_SPAN, _CLIP_SPAN)
        below = shapes.translate(clip, [0.0, HAMMER_HEAD_MIN_Y - _CLIP_SPAN / 2, 0.0])
        above = shapes.translate(clip, [0.0, HAMMER_HEAD_MIN_Y + _CLIP_SPAN / 2, 0.0])
        regions = [("handle", WOOD, below), ("head", METAL, above)]
    else:
        regions = [("body", cfg.material, None)]

    entries = []
    for label, mat, region in regions:
        if region is None:
            entries.append((label, mat, base, mesh))
        else:
            part_shape = shapes.intersection(base, region)
            with handler(ShapeToOpenSCAD()):
                scad = evaluate(part_shape)
            part_mesh = as_trimesh(solid2_to_mesh(scad, f"{name}_{label}"))
            entries.append((label, mat, part_shape, part_mesh))

    # Measured mass splits by nominal density and volume; non-watertight
    # scans have no reliable volume, so those weigh by their convex hull.
    weights = np.array(
        [
            (mat.density or 1.0)
            * abs(float(m.volume if m.is_watertight else m.convex_hull.volume))
            for _, mat, _, m in entries
        ]
    )
    masses = [cfg.mass * float(w / weights.sum()) for w in weights]

    self.parts_info = [
        (label, part_mesh, mass)
        for (label, _, _, part_mesh), mass in zip(entries, masses)
    ]

    part_specs = []
    for (label, mat, part_shape, part_mesh), mass in zip(entries, masses):
        if max_parts is not None:
            # Decomposed once, here; the hulls collide and are integrated as
            # they are, so the density divides exactly the volume the
            # compiler integrates.
            parts = render_convex_parts(
                part_shape, f"{name}_{label}", max_parts=max_parts
            )
            hulls = [shapes.mesh(p) for p in parts]
            collision = hulls[0] if len(hulls) == 1 else shapes.union(*hulls)
            vol = sum(abs(float(p.to_trimesh().volume)) for p in parts)
        elif part_mesh.is_watertight:
            collision = part_shape
            vol = abs(float(part_mesh.volume))
        else:
            raise ValueError(
                f"{name} {label}: the scan is not watertight, so its inertia "
                "cannot be integrated directly; pass max_parts to decompose it."
            )
        part_specs.append(
            (
                collision,
                part_shape if show_true_mesh else None,
                replace(mat, density=float(mass.to("kg").value) / vol),
            )
        )

    collision, vshape, part_material = part_specs[0]
    self.shape = collision
    if vshape is not None:
        self.vshape = vshape
    self.material = part_material
    self.base = self.place(Port())
    for i, (s, vs, m) in enumerate(part_specs[1:]):
        part = YCBObjectPart(collision_shape=s, visual_shape=vs, part_material=m)
        setattr(self, f"part{i}", part)
        setattr(self, f"_weld_part{i}", joints.Weld(self.base, part.base))

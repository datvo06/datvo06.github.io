import effectful.handlers.jax.numpy as jnp

from robotl.examples.based import Based
from robotl.handlers.mujoco import view_model
from robotl.ops import joints, shapes
from robotl.ops.syntax import Port, Pose, defcomponent


@defcomponent
def Seat(self, width=0.400, depth=0.400, thickness=0.050):
    self.shape = shapes.cube(width, depth, thickness)

    self.backmount = self.place(Port(), Pose(pos=[0, depth, thickness]))
    self.legmounts = [
        self.place(
            Port(),
            Pose(pos=[x * width, y * depth, 0], rv=jnp.pi * jnp.array([0, 1, 0])),
        )
        for x in [0, 1]
        for y in [0, 1]
    ]


@defcomponent
def Leg(self, length=0.450, radius=0.040):
    self.shape = shapes.cylinder(r=radius, h=length)
    self.base = self.place(Port())


@defcomponent
def ChairBack(self, width=0.400, length=0.350, thickness=0.030):
    self.shape = shapes.cube(width, thickness, length)
    self.base = self.place(Port())


@defcomponent
def Chair(self):
    """Chair furniture example with seat, legs, and backrest.

    Demonstrates creating furniture components using boxes and cylinders,
    with port-based connections for assembly of seat, legs, and backrest.
    """
    self.seat = Seat()
    self.legs = [Leg() for _ in range(4)]
    self.back = ChairBack()
    self._welds = [
        joints.Weld(mount, leg.base)
        for leg, mount in zip(self.legs, self.seat.legmounts)
    ]
    self._weld_back = joints.Weld(self.seat.backmount, self.back.base)
    self.base = self.place(Port())
    self._weld_base = joints.Weld(self.base, self.back.base)


if __name__ == "__main__":
    view_model(lambda: Based.make(Chair()))

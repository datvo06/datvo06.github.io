import effectful.handlers.jax.numpy as jnp

from robotl.examples.based import Based
from robotl.handlers.mujoco import view_model
from robotl.ops import joints, shapes
from robotl.ops.syntax import Port, Pose, defcomponent


@defcomponent
def Support(self, width=0.150, height=0.040):
    self.shape = shapes.centered_cube(width, 0.080, height)
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(rv=jnp.pi * jnp.array([1, 0, 0])))


@defcomponent
def Arm(self, length=0.220, radius=0.010):
    self.shape = shapes.cylinder(r=radius, h=length)
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, length]))


@defcomponent
def Bob(self, r=0.020):
    self.shape = shapes.sphere(r)
    self.base = self.place(Port())


@defcomponent
def TriplePendulum(self):
    """Triple pendulum chain with three arms and bobs."""
    self.support = Support()
    self.arm1 = Arm(length=0.250)
    self.arm2 = Arm(length=0.220)
    self.arm3 = Arm(length=0.200)
    self.bob1 = Bob()
    self.bob2 = Bob()
    self.bob3 = Bob()

    self.base = self.place(Port())
    self._weld_support = joints.Weld(self.base, self.support.base)

    self.j1 = joints.Hinge(self.support.tip, self.arm1.base, axis=jnp.array([1, 0, 0]))
    self.j2 = joints.Hinge(self.arm1.tip, self.arm2.base, axis=jnp.array([1, 0, 0]))
    self.j3 = joints.Hinge(self.arm2.tip, self.arm3.base, axis=jnp.array([1, 0, 0]))

    self.k1 = joints.Weld(self.arm1.tip, self.bob1.base)
    self.k2 = joints.Weld(self.arm2.tip, self.bob2.base)
    self.k3 = joints.Weld(self.arm3.tip, self.bob3.base)


if __name__ == "__main__":
    view_model(lambda: Based.make(TriplePendulum()))

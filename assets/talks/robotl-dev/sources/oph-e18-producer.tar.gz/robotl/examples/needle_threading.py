import effectful.handlers.jax.numpy as jnp

from robotl.examples.capsule_chain import Chain
from robotl.examples.shadow_hand import ShadowHand
from robotl.handlers.mujoco import view_model
from robotl.internals.utils import Colors
from robotl.ops import joints, shapes
from robotl.ops.losses import Equalize, Nullify
from robotl.ops.syntax import (
    Component,
    Origin,
    Port,
    Pose,
    assert_transform,
    defcomponent,
)


@defcomponent
def Thread(self, length=0.2, radius=0.01):
    self.shape = shapes.capsule(r=radius, h=length)
    self.center = self.place(Port(), Pose(pos=[0, 0, length / 2]))


@defcomponent
def Needle(self, length=0.1, radius=0.01):
    width = 2 * radius
    eye_length = length / 4
    eye_width = radius
    self.shape = shapes.union(
        shapes.decompose(
            shapes.difference(
                shapes.centered_cube(width, width, eye_length),
                shapes.centered_cube(eye_width, width, eye_length * 3 / 4),
            )
        ),
        shapes.translate(
            shapes.centered_cube(width, width, length - eye_length),
            [0, 0, length / 2],
        ),
    )
    self.tip = self.place(Port(), Pose(pos=[0, 0, length - eye_length / 2]))
    self.hole = self.place(Port())


@defcomponent
def NeedleThreadingEnv(
    self,
    robot: Component,
    hole_height=0.3,
    needle_length=0.5,
    needle_radius=0.03,
    thread_radius=0.01,
    thread_len=0.2,
):
    """Insert a thread into a needle.

    - Description & evaluation metrics
        - The robot needs to pick up the thread and insert it into the hole as shown in the below figure
        - The reward function rewards the red end being close to the red hole, and the needle being perpendicular to the hole

    - Success criteria (thresholds may be changed later)
        - The robot needs to thread the needle within 10 seconds
        - L2 distance from the needle’s end to the goal position < 10% needle length
    """
    self.shape = shapes.translate(shapes.plane(), [0, 0, -0.35])

    self.base = self.place(Port())
    self._weld_origin = joints.Weld(Origin.base, self.base)

    self.needle = Needle(length=needle_length, radius=needle_radius)
    self._weld_needle = joints.Weld(
        self.base,
        self.needle.hole,
        Pose(pos=[0, 0.3, hole_height], rv=-jnp.pi / 4 * jnp.array([0, 1, 0])),
    )

    self.thread = Thread(length=thread_len, radius=thread_radius)
    assert_transform(
        self,
        self.thread,
        Pose(pos=[0.3, 0, thread_len], rv=jnp.pi / 4 * jnp.array([0, 1, 0])),
    )

    self.needle.color = Colors.orange
    self.thread.color = Colors.blue

    self.arm = Chain(n=4, length=0.3, radius=0.03)
    self._weld_arm = joints.Weld(self.base, self.arm.base)

    self.robot = robot
    self._weld_robot = joints.Weld(self.arm.tip, self.robot.base)

    self.losses = dict(
        pos=Equalize(self.thread.pos, self.needle.hole.pos),
        vel=Nullify(self.thread.linvel),
    )


if __name__ == "__main__":
    view_model(lambda: NeedleThreadingEnv(ShadowHand()))

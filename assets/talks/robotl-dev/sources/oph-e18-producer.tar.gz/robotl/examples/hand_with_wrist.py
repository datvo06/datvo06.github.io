import math
from dataclasses import dataclass
from pathlib import Path
from typing import Self

from effectful.handlers.jax import numpy as jnp
from effectful.ops.types import Term

from robotl.examples.link import Link
from robotl.examples.open_parametric_hand import OpenParametricHand
from robotl.examples.stretch_wrist import StretchDexWrist
from robotl.ops import actuators, joints, shapes
from robotl.ops.syntax import (
    Component,
    Material,
    Port,
    Pose,
    assert_transform,
    defcomponent,
    disable_pair_collisions,
    frame,
)

X, Y, Z = jnp.eye(3)

OPH_STRETCH_COMMAND_RANGES = ((-0.35, 0.35), (-0.25, 0.15), (-0.35, 0.35))
"""Sampled collision-clear target envelope for the stock mounted OPH, in radians."""

OPH_FLANGE_SEAT = (0.0, -0.010, 0.0)
"""Printed bracket's seating patch in the wrist tool frame, in metres."""

OPH_THUMB_POCKET_DEPTH = 0.002
OPH_ROUTED_THUMB_POCKET_DEPTH = 0.0045
# Depths are in metres; the 4.5 mm pocket clears the printed spatial thumb guides.

OPH_PALM_SEAT = 0.0155
"""Stock OPH palm's back face along the palm port's +y, in metres."""


@defcomponent
def HandWithWrist(
    self, hand: Component, size=0.02, *, radius: float | None = None, kp=1.0, kv=0.0
):
    """Mount a hand on two hinges with independent link length and radius.

    :param size: Wrist link length and distance between its attachment ports.
    :param radius: Capsule radius; ``None`` uses ``size``.
        Changing it changes wrist mass and inertia, not ports or hinge anchors.
    :param kp: Position gain for both wrist actuators.
    :param kv: Velocity gain for both wrist actuators.
    """
    self.base = self.place(Port())
    self.wrist = Link(size, size if radius is None else radius)
    self.hand = hand
    self.joints = [
        joints.Hinge(
            self.base,
            self.wrist.base,
            axis=Y,
            damping=0.1,
            range=(-jnp.pi / 4, jnp.pi / 4),
        ),
        joints.Hinge(
            self.wrist.tip,
            self.hand.base,
            axis=X,
            damping=0.1,
            range=(-jnp.pi / 4, jnp.pi / 4),
        ),
    ]
    self.actuators = [actuators.Position(j, kp=kp, kv=kv) for j in self.joints]
    self.fingertips = self.hand.fingertips
    self.tip = self.hand.tip


@defcomponent
def OphWristMount(
    self,
    palm_height: float = 0.0755,
    n_motors: int = 2,
    thumb_pocket_depth: float = OPH_THUMB_POCKET_DEPTH,
    palm_seat: float = OPH_PALM_SEAT,
):
    """Printed prototype bracket for the stock OPH palm and mixer housings.

    Dimensions and PLA density are design assumptions, not published Stretch
    hardware. The lower plate seats on the tool flange; the offset column and
    upper plate provide continuous palm support with a recessed thumb pocket.
    Connected lower shelves support the motor housings with a 12 mm backset,
    leaving spool planes free.

    :param palm_height: Palm reference height above the flange, in metres.
    :param thumb_pocket_depth: Pocket depth below the upper plate surface,
        in metres. Spatial thumb routing needs room for its printed guides.
    :param palm_seat: Depth of the palm's back face below the palm port, in
        metres; the upper plate top sits there so the palm seats on it. The
        motor shelves stay put, since housings weld to the palm port.
    """
    self.base = self.place(Port())
    self.palm = self.place(
        Port(), Pose(pos=[0, 0, palm_height], rv=[-math.pi / 2, 0, 0])
    )
    self.shape = shapes.union(
        shapes.translate(
            shapes.centered_cube(0.006, 0.008, 0.005),
            [*OPH_FLANGE_SEAT[:2], 0.0025],
        ),
        shapes.translate(
            shapes.centered_cube(0.006, 0.008, palm_height - palm_seat - 0.010),
            [*OPH_FLANGE_SEAT[:2], (palm_height - palm_seat) / 2],
        ),
        shapes.translate(
            shapes.centered_cube(0.053, 0.105, 0.005),
            [0.0185, -0.0375, palm_height - palm_seat - 0.0025],
        ),
        shapes.translate(
            shapes.centered_cube(0.037, 0.020, 0.005),
            [0.0265, 0.025, palm_height - palm_seat - 0.0025],
        ),
        shapes.translate(
            shapes.centered_cube(0.016, 0.020, 0.003),
            [0, 0.025, palm_height - palm_seat - 0.0015 - thumb_pocket_depth],
        ),
        *(
            shapes.translate(
                shapes.centered_cube(0.065, 0.036, 0.005),
                [-0.0295, y, palm_height - 0.0395],
            )
            for y in (-0.026 - i * 0.06 for i in range(n_motors))
        ),
        shapes.translate(
            shapes.centered_cube(0.006, 0.036 + (n_motors - 1) * 0.06, 0.005),
            [0, -0.026 - (n_motors - 1) * 0.03, palm_height - 0.0395],
        ),
    )
    self.material = Material(density=1240, color=jnp.array([0.25, 0.3, 0.35, 1]))


@dataclass(eq=False, kw_only=True)
class StretchHandWithWrist(Component):
    """Tendon-driven OPH on the source-derived Stretch wrist and printed mount.

    The neutral hand axes match ``HandWithWrist`` so the cube environment's
    existing OPH palm-up world mounting convention applies unchanged. Wrist
    link inertias and motor drives remain owned by ``StretchDexWrist``.
    Command travel uses an assembly-specific target envelope;
    the bare wrist's published physical joint stops remain unchanged.
    """

    base: Port
    wrist: StretchDexWrist
    mount: Component
    hand: OpenParametricHand
    welds: tuple[joints.Weld, ...]
    excludes: tuple[Term | None, ...]

    @property
    def fingertips(self) -> tuple[Port, ...]:
        return self.hand.fingertips

    @property
    def tip(self) -> Port:
        return self.hand.tip

    @property
    def joints(self) -> list[joints.Hinge]:
        return self.wrist.joints

    @property
    def actuators(self) -> list[actuators.Position]:
        return self.wrist.actuators

    @classmethod
    def make(
        cls,
        hand: OpenParametricHand,
        urdf: Path,
        *,
        use_meshes: bool = False,
        palm_height: float = 0.0755,
        command_ranges: tuple[tuple[float, float], ...] = OPH_STRETCH_COMMAND_RANGES,
    ) -> Self:
        """Attach the palm directly to the bracket without adding actuators.

        :param command_ranges: Assembly target envelope in yaw, pitch, roll
            order, in radians. Co-design admission checks source joint stops
            and sampled hand/mount clearance across this envelope.
        """
        with frame() as pose:
            base = Port()
            wrist = StretchDexWrist.make(
                urdf, use_meshes=use_meshes, command_ranges=command_ranges
            )
            mount = OphWristMount(
                palm_height=palm_height,
                n_motors=len(hand.motors),
                thumb_pocket_depth=(
                    OPH_ROUTED_THUMB_POCKET_DEPTH
                    if hand.routing_guides
                    else OPH_THUMB_POCKET_DEPTH
                ),
                # A thumb moved onto a strut no longer thickens the plate, so
                # the bracket follows the palm's back face rather than the stock one.
                palm_seat=hand.palm.back_face,
            )
            assembly = cls(
                pose=pose,
                base=base,
                wrist=wrist,
                mount=mount,
                hand=hand,
                welds=(
                    joints.Weld(base, wrist.base, Pose(rv=[math.pi / 2, 0, 0])),
                    joints.Weld(wrist.tip, mount.base),
                    joints.Weld(mount.palm, hand.palm.base),
                ),
                excludes=(
                    disable_pair_collisions(mount, wrist.links["link_wrist_roll"]),
                    disable_pair_collisions(mount, hand.palm),
                ),
            )
            assert_transform(assembly, base)
        return assembly

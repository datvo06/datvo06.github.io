"""The Open Parametric Hand's own OpenSCAD source, for printed-bone overlays.

The source (`kg398/100_fingers <https://github.com/kg398/100_fingers>`_) is
GPL-3.0, so it is not vendored: ``scripts/download_oph.py`` fetches it at
:data:`OPH_COMMIT` into :data:`OPH_SOURCES`, and
:func:`~robotl.examples.open_parametric_hand.printed_bone` renders bones
from it.
"""

import ast
import functools
import re
from importlib import resources
from pathlib import Path

import solid2

OPH_COMMIT = "b9331f1bfc2ff918645d164db07af007f612305d"
"""Upstream commit ``scripts/download_oph.py`` fetches."""

OPH_SOURCES = (
    Path(
        str(resources.files("robotl").parent.joinpath("assets", "open_parametric_hand"))  # type: ignore
    )
    / OPH_COMMIT[:12]
)
"""Downloaded OPH sources, one directory per commit so a bumped
:data:`OPH_COMMIT` never renders stale ones; generated bone meshes go in its
``meshes``."""

_CONFIG_TABLES = (
    "dof4_config",
    "dof4_thumb_config",
    "dof3_config",
    "dof3_thumb_config",
    "dof2_config",
    "dof2_thumb_config",
)
"""``digits.scad`` ``bone_configs`` tables, indexed by OPH finger type."""


def source(name: str) -> Path:
    """A downloaded OPH source file."""
    path = OPH_SOURCES / name
    if not path.exists():
        raise FileNotFoundError(
            f"{path} is missing; run scripts/download_oph.py to fetch the OPH source"
        )
    return path


@functools.cache
def bone_configs() -> tuple[tuple[tuple[int, ...], ...], ...]:
    """The ``bone_configs`` tables, read from their literals in ``digits.scad``."""
    text = re.sub(r"//[^\n]*", "", source("digits.scad").read_text())
    tables = []
    for name in _CONFIG_TABLES:
        match = re.search(rf"^{name}\s*=\s*(\[.*?\]);", text, re.MULTILINE | re.DOTALL)
        if match is None:
            raise ValueError(f"digits.scad defines no {name}")
        tables.append(tuple(tuple(row) for row in ast.literal_eval(match[1])))
    return tuple(tables)


@functools.cache
def primitives():
    """``primitives.scad`` as solid2 callables, ``modular_bone`` among them."""
    return solid2.import_scad(str(source("primitives.scad")))

import effectful.handlers.jax.numpy as jnp
import jax.numpy as jp

from robotl.examples.capsule_chain import Chain
from robotl.examples.shadow_hand import ShadowHand
from robotl.handlers.mujoco import view_model
from robotl.internals.utils import Colors
from robotl.ops import joints, sensors, shapes
from robotl.ops.coords import Angle
from robotl.ops.losses import Equalize
from robotl.ops.syntax import (
    Component,
    Origin,
    Port,
    Pose,
    defcomponent,
)


@defcomponent
def Handle(self, length=1e-1, radius=1e-2):
    # use boxes to create "cylinder" with hexagonal cross section
    n = 6
    a = jp.pi * 2 / n
    x = radius * jp.cos(a / 2)
    y = radius * jp.sin(a / 2)
    self.shape = shapes.union(
        *(
            shapes.transform(
                shapes.centered_cube(2 * x, 2 * y, length),
                Pose(rv=a * i * jnp.array([0, 0, 1])),
            )
            for i in range(n // 2)
        )
    )
    self.base = self.place(Port(), Pose(pos=[0, 0, -length / 2]))
    self.tip = self.place(Port(), Pose(pos=[0, 0, length / 2]))


@defcomponent
def ScrewTurningEnv(
    self,
    robot: Component,
    handle_len=0.20,
    handle_radius=0.02,
    torque_threshold=10,
):
    """Turn a screwdriver handle.

    The robot should grasp the handle and turn it 90 degrees clockwise.  This requires
    more than `torque_threshold` torque.
    """
    self.shape = shapes.plane()

    self.base = self.place(Port())
    self._weld_origin = joints.Weld(Origin.base, self.base)

    self.arm = Chain(n=4, length=0.3, radius=0.03)
    self._weld_arm = joints.Weld(self.base, self.arm.base, Pose(pos=[0, 0, 0.011]))

    self.robot = robot
    self._weld_robot = joints.Weld(self.arm.tip, self.robot.base)

    self.handle = Handle(length=handle_len, radius=handle_radius)
    self.handle.color = Colors.blue
    self.handle_port = self.place(
        Port(), Pose(pos=[0.5, 0, 0.3], rv=jnp.pi / 2 * jnp.array([1, 0, 0]))
    )
    self.hinge = joints.Hinge(
        self.handle_port,
        self.handle.base,
        axis=jnp.array([0, 0, 1]),
        frictionloss=torque_threshold,
    )
    self.angle = sensors.Position(self.hinge)

    self.loss = Equalize(self.angle.get(), Angle(jnp.pi / 2))


if __name__ == "__main__":
    view_model(lambda: ScrewTurningEnv(ShadowHand()))

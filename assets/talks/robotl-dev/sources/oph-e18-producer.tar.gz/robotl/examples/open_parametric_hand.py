"""Motor-driven Open Parametric Hand approximation.

Based on the `100_fingers` project by Gilday et al. (2025):
  https://github.com/kg398/100_fingers
  Gilday, K., Sirithunge, C., Iida, F., & Hughes, J. (2025).
  Embodied manipulation with past and future morphologies through an open
  parametric hand design. Science Robotics, 10(102), eads6437.

Design pattern
--------------
:class:`Bone`, :class:`Digit`, :class:`Palm`, and
:class:`OpenParametricHand` are pure-data ``@dataclass`` components with
``make`` classmethod constructors, following the ``DHChain`` conventions:
construction runs under ``with frame() as pose:`` and registers port edges
with ``assert_transform``. :class:`Bone`, :class:`Digit`, and the hand
expose ``base``/``tip`` ports (:class:`~robotl.examples.based.HasBaseAndTip`),
so they compose with any base/tip linkage (e.g. ``DHChain``).

Two XL430-W250-T motors drive compliant tendon mixers by default; XM430-W210
and W350 are selectable same-envelope hardware alternatives. The motor reference
is the music-playing parametric hand (doi:10.3389/frobt.2024.1463744,
section 2.4); routing follows the grasp-oriented double pulley in the OPH
paper (arxiv:2410.18633, section 4.6), not the music-playing synergies.
Hinges and constant tendon moment arms approximate rolling joints and
nonlinear routing. Spring stiffnesses are paper-derived; passive damping,
pretension (zero), mixer packaging, and servo gains are not calibrated.
The constant-moment-arm distal flexor and extensor are parallel constraints:
together with the intermediate flexor they leave one three-hinge flexion
mode without spring restoring stiffness. Passive joint mechanics are not a
validated model of the printed rolling-flexure hand.

Opt-in spatial transmissions replace constant moment arms with native cable
paths over the represented uniform drums and printed guide prototypes. These
paths are tension-only; guide friction and pretension remain uncalibrated.
"""

import hashlib
import math
import re
from collections import Counter
from collections.abc import Iterator, Mapping, Sequence
from enum import IntEnum, unique
from typing import Literal, NamedTuple, Self

import effectful.handlers.jax.numpy as jnp
import jax
import mujoco
import numpy as np
import pydantic.dataclasses
import unxt
from effectful.ops.types import Term
from flax import struct
from jax.scipy.spatial.transform import Rotation
from pydantic import (
    ConfigDict,
    NonNegativeInt,
    TypeAdapter,
    validate_call,
)

from robotl.examples import oph_printed
from robotl.examples.based import Based
from robotl.examples.dynamixel import X430, X430Model, mixer_track_heights
from robotl.examples.hand_collision import (
    CUBE_BIT,
    FLOOR_BIT,
    PALM_BIT,
    apply_contact_response,
    assign_collision_masks,
    digit_masks,
    surface_masks,
)
from robotl.handlers.cad.openscad import solid2_to_mesh
from robotl.handlers.mujoco import view_model
from robotl.internals.utils import Colors
from robotl.ops import joints, shapes, tendons
from robotl.ops.syntax import (
    Component,
    LegacyComponent,
    Material,
    Port,
    Pose,
    assert_transform,
    defcomponent,
    disable_pair_collisions,
    frame,
)
from robotl.ops.units import (
    Mm,
    MmOrOff,
    PlacementDeg,
    PlacementMm,
    Unit,
    Volt,
    deg,
    mm,
    volt,
)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------
@unique
class FingerType(IntEnum):
    """Finger-type enum (matching 100_fingers/OpenSCAD/parameters.scad)."""

    FOUR_DOF = 0
    FOUR_DOF_THUMB = 1
    THREE_DOF = 2
    THREE_DOF_THUMB = 3
    TWO_DOF = 4
    TWO_DOF_THUMB = 5


@unique
class JointType(IntEnum):
    """Joint-type enum for bone configuration."""

    BASE = 0  # flat base
    HINGE = 1  # 1-DOF cylindrical
    BALL = 2  # 2-DOF spherical
    TIP = 3  # fingertip (with nail)


# ---------------------------------------------------------------------------
# Parameter dataclasses
# ---------------------------------------------------------------------------
@struct.dataclass
class LigParams:
    """Ligament dimensions (mm)."""

    width: MmOrOff = mm(0.0)
    thickness: MmOrOff = mm(0.0)


@struct.dataclass
class PulleyParams:
    """Flexor-pulley dimensions (mm)."""

    length: MmOrOff = mm(0.0)
    thickness: MmOrOff = mm(0.0)
    radius: MmOrOff = mm(0.0)


class BoneLengths(NamedTuple):
    """Bone lengths for one digit (mm), matching the phalanx order."""

    metacarpal: Mm
    proximal: Mm
    intermediate: Mm
    distal: Mm


class JointTaper(NamedTuple):
    """Taper factors at each of the 5 joint boundaries (base -> tip)."""

    base: Unit
    mcp: Unit
    pip: Unit
    dip: Unit
    tip: Unit


class FingerScalars(NamedTuple):
    """One scalar per finger, in anatomical order."""

    index: Mm  # type: ignore[assignment]  # pyright: ignore[reportIncompatibleVariableOverride] - shadows tuple.index
    middle: Mm
    ring: Mm
    pinky: Mm


class ThumbScalars(NamedTuple):
    """One scalar per thumb."""

    inner: Mm
    outer: Mm


@struct.dataclass
class JointEnd:
    """Geometry of one end (proximal or distal) of a bone, in mm quantities."""

    diameter: Mm
    width: Mm
    joint_type: JointType = struct.field(pytree_node=False, default=JointType.BASE)


@struct.dataclass
class DigitParams:
    """Parameters for a single digit (finger or thumb), in mm."""

    bone_lengths: BoneLengths
    joint_diameters: list[Mm]  # n+1 values (one per joint boundary)
    joint_widths: list[Mm]  # n+1 values
    joint_configs: list[tuple[JointType, JointType]] = struct.field(pytree_node=False)
    lig: LigParams
    pulley: PulleyParams
    finger_type: FingerType = struct.field(pytree_node=False)


@struct.dataclass
class HandParams:
    """Default parameters from ``100_fingers/OpenSCAD/parameters.scad``.

    Raw dimensions are in **millimetres** and **degrees**.  Derived per-digit
    arrays (joint diameters and widths after taper) are exposed as
    ``@property`` methods so they stay in sync when any base value changes.
    """

    # -- Digit types -------------------------------------------------------
    type_finger: list[FingerType] = struct.field(
        pytree_node=False,
        default_factory=lambda: [FingerType.FOUR_DOF] * 4,
    )
    type_thumb: list[FingerType] = struct.field(
        pytree_node=False,
        default_factory=lambda: [FingerType.FOUR_DOF_THUMB] * 2,
    )

    # -- Bone lengths (mm), one per digit ------------------------------------
    bone_lengths_finger: list[BoneLengths] = struct.field(
        default_factory=lambda: [
            BoneLengths(mm(80), mm(38), mm(20), mm(20)),
            BoneLengths(mm(82), mm(41), mm(20.5), mm(20.5)),
            BoneLengths(mm(79), mm(38), mm(19), mm(19)),
            BoneLengths(mm(74), mm(35), mm(17), mm(17)),
        ],
    )
    bone_lengths_thumb: list[BoneLengths] = struct.field(
        default_factory=lambda: [
            BoneLengths(mm(25), mm(35), mm(25), mm(25)),
            BoneLengths(mm(25), mm(35), mm(25), mm(25)),
        ],
    )

    # -- Joint diameters: base value per digit + taper factors (n+1) -------
    base_jd_finger: FingerScalars = FingerScalars(
        index=mm(12.5),
        middle=mm(14),
        ring=mm(12.5),
        pinky=mm(11),
    )
    base_jd_thumb: ThumbScalars = ThumbScalars(inner=mm(16.0), outer=mm(16.0))
    jd_factors: JointTaper = JointTaper(
        base=0.7,
        mcp=1.0,
        pip=0.6,
        dip=0.5,
        tip=0.4,
    )

    # -- Joint widths: base value per digit + taper factors (n+1) ----------
    base_w_finger: FingerScalars = FingerScalars(
        index=mm(15.0),
        middle=mm(16.0),
        ring=mm(15.0),
        pinky=mm(13.0),
    )
    base_w_thumb: ThumbScalars = ThumbScalars(inner=mm(20.0), outer=mm(20.0))
    w_factors: JointTaper = JointTaper(
        base=0.7,
        mcp=1.0,
        pip=0.8,
        dip=0.7,
        tip=0.7,
    )

    # -- Ligament params -----------------------------------------------------
    lig_finger: LigParams = LigParams(mm(2.5), mm(0.6))
    lig_thumb: LigParams = LigParams(mm(2.5), mm(0.6))

    # -- Pulley params -------------------------------------------------------
    pulley_finger: PulleyParams = PulleyParams(mm(5.0), mm(1.5), mm(1.0))
    pulley_thumb: PulleyParams = PulleyParams(mm(5.0), mm(2.2), mm(1.0))

    # -- Digit placement: origins in mm, angles in degrees -------------------
    origins_finger: PlacementMm = struct.field(
        default_factory=lambda: mm(
            jnp.array(
                [
                    [0.0, 1.5, 0.0],
                    [0.0, 0.0, -12.0],
                    [0.0, 1.0, -24.0],
                    [0.0, 3.5, -34.0],
                ]
            )
        ),
    )
    angles_finger: PlacementDeg = struct.field(
        default_factory=lambda: deg(
            jnp.array(
                [
                    [0.0, -10.0, 0.0],
                    [0.0, 3.0, 0.0],
                    [0.0, 16.0, 0.0],
                    [0.0, 30.0, 0.0],
                ]
            )
        ),
    )
    origins_thumb: PlacementMm = struct.field(
        default_factory=lambda: mm(
            jnp.array(
                [
                    [-3.0, 5.5, 15.0],
                    [-3.0, 5.5, -45.0],
                ]
            )
        ),
    )
    angles_thumb: PlacementDeg = struct.field(
        default_factory=lambda: deg(
            jnp.array(
                [
                    [0.0, -100.0, 0.0],
                    [0.0, 100.0, 0.0],
                ]
            )
        ),
    )

    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    @classmethod
    def validated(cls, **kwargs) -> Self:
        """Authoring seam: construct with every constraint checked."""
        return TypeAdapter(cls).validate_python(kwargs)

    def finger(self, index: int) -> DigitParams:
        """Return :class:`DigitParams` for finger *index*."""
        ft = self.type_finger[index]
        base_jd = self.base_jd_finger[index]
        base_w = self.base_w_finger[index]
        return DigitParams(
            bone_lengths=self.bone_lengths_finger[index],
            joint_diameters=[base_jd * f for f in self.jd_factors],
            joint_widths=[base_w * f for f in self.w_factors],
            joint_configs=DOF4_JOINTS[: N_BONES[ft]],
            lig=self.lig_finger,
            pulley=self.pulley_finger,
            finger_type=ft,
        )

    def thumb(self, index: int) -> DigitParams:
        """Return :class:`DigitParams` for thumb *index*."""
        ft = self.type_thumb[index]
        base_jd = self.base_jd_thumb[index]
        base_w = self.base_w_thumb[index]
        return DigitParams(
            bone_lengths=self.bone_lengths_thumb[index],
            joint_diameters=[base_jd * f for f in self.jd_factors],
            joint_widths=[base_w * f for f in self.w_factors],
            joint_configs=DOF4_JOINTS[: N_BONES[ft]],
            lig=self.lig_thumb,
            pulley=self.pulley_thumb,
            finger_type=ft,
        )


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
DOF4_JOINTS: list[tuple[JointType, JointType]] = [
    (JointType.BASE, JointType.BALL),  # metacarpal, fixed; 2-DOF MCP ball
    (JointType.BALL, JointType.HINGE),  # proximal phalanx
    (JointType.HINGE, JointType.HINGE),  # intermediate phalanx
    (JointType.HINGE, JointType.TIP),  # distal phalanx
]

N_BONES: dict[FingerType, int] = {
    FingerType.FOUR_DOF: 4,
    FingerType.FOUR_DOF_THUMB: 4,
    FingerType.THREE_DOF: 3,
    FingerType.THREE_DOF_THUMB: 3,
    FingerType.TWO_DOF: 2,
    FingerType.TWO_DOF_THUMB: 2,
}

# Ry(pi/2): maps local +Z (bone direction) to +X (outward from palm).
# The OpenSCAD "print angle" only affects living-hinge offsets and is
# not needed for joint-based simulation.
_BASE_ROT = Pose(rv=[0.0, jnp.pi / 2.0, 0.0])

_MOUNT_CLEARANCE = 0.05
"""Distance from the base port to the palm plate along the outward axis, in
metres. The base port is the hand's mounting face: a wrist that mounts at
the base sits this far behind the palm, clear of the plate and of the
metacarpal roots, the same convention as ``ParameterizedLeapHand``'s
``leap_offset``."""


# ---------------------------------------------------------------------------
# Bone: single anatomical bone segment
# ---------------------------------------------------------------------------
@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class Bone(Component):
    """Anatomical bone with tapered body, joint knobs, ligaments, and pulleys.

    Pure-data dataclass: every field is populated by :meth:`make`.

    :param shape: Union of tapered body, joint knobs, and optional
        ligament strips and flexor-pulley channel.
    :param base: Port at the bone's proximal end.
    :param tip: Port at the bone's distal end.
    :param vshape: Visual-only overlay drawn in place of ``shape``.
    """

    shape: shapes.Shape
    base: Port
    tip: Port
    flexor_guides: tuple[Port, ...] = ()
    extensor_guides: tuple[Port, ...] = ()
    lateral_anchors: tuple[Port, ...] = ()
    vshape: shapes.Shape | None = None

    @classmethod
    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def make(
        cls,
        length: unxt.AbstractQuantity,
        prox: JointEnd,
        dist: JointEnd,
        lig: LigParams | None = None,
        pulley: PulleyParams | None = None,
        routed: bool = False,
        lateral: bool = False,
        guide_end: float = 0.6,
        vshape: shapes.Shape | None = None,
    ) -> Self:
        """Build a :class:`Bone` from its end geometries.

        Dimensions arrive as quantities and are converted to metres here,
        at the geometry boundary.

        The body is a tapered shape (wider at proximal, narrower at distal).
        Joint knobs are spheres (2-DOF) or cylinders (1-DOF) at each end.
        Distal tip type gets a flat nail cap.

        Ligaments are thin flexible strips on each side of the bone bridging
        from the proximal joint outward; they provide passive joint stability.

        Pulleys are small guide channels on the palmar (flexor) side of the
        bone that keep tendons close to the bone surface through joint
        articulation.

        :param length: Bone length along local Z.
        :param prox: Geometry of the proximal end.
        :param dist: Geometry of the distal end.
        :param lig: Ligament dimensions; omitted when ``None``.
        :param pulley: Flexor-pulley dimensions; omitted when ``None``.
        :param vshape: Visual-only overlay in the bone frame, in metres.
        """
        length_m = float(length.to("m").value)
        pd, dd = float(prox.diameter.to("m").value), float(dist.diameter.to("m").value)
        pwf, dwf = float(prox.width.to("m").value), float(dist.width.to("m").value)
        with frame() as pose:
            pr, dr = pd / 2.0, dd / 2.0
            pw, dw = pwf / 2.0, dwf / 2.0

            # --- Tapered body: two overlapping cuboids spanning joint to joint ---
            body_prox = shapes.translate(
                shapes.centered_cube(pd, pwf, length_m * 0.6),
                [0, 0, length_m * 0.3],
            )
            body_dist = shapes.translate(
                shapes.centered_cube(dd, dwf, length_m * 0.6),
                [0, 0, length_m * 0.7],
            )
            body = shapes.union(body_prox, body_dist)

            # --- Proximal joint knob ---
            if prox.joint_type == JointType.BALL:
                knob_prox = shapes.sphere(pr)
            elif prox.joint_type == JointType.HINGE:
                knob_prox = shapes.translate(
                    shapes.cylinder(r=pr, h=pwf),
                    [0, -pw, 0],
                )
            else:  # JointType.BASE — flat, no extra geometry
                knob_prox = shapes.cube(pd, pwf, 0.01)
                knob_prox = shapes.translate(knob_prox, [-pr, -pw, 0])

            # --- Distal joint knob ---
            if dist.joint_type == JointType.TIP:
                nail = shapes.centered_cube(dd * 1.2, dwf, dd * 0.3)
                nail = shapes.translate(nail, [0, 0, length_m])
                knob_dist = shapes.union(
                    shapes.translate(shapes.sphere(dr), [0, 0, length_m]),
                    nail,
                )
            elif dist.joint_type == JointType.BALL:
                knob_dist = shapes.translate(shapes.sphere(dr), [0, 0, length_m])
            elif dist.joint_type == JointType.HINGE:
                knob_dist = shapes.translate(
                    shapes.cylinder(r=dr, h=dwf),
                    [0, -dw, length_m],
                )
            else:
                knob_dist = shapes.translate(
                    shapes.sphere(dr * 0.5),
                    [0, 0, length_m],
                )

            parts = [body, knob_prox, knob_dist]

            # --- Ligaments: thin strips on ±Y sides of the proximal joint ---
            lig_w = float(lig.width.to("m").value) if lig else 0.0
            lig_t = float(lig.thickness.to("m").value) if lig else 0.0
            if lig_w > 0 and lig_t > 0 and prox.joint_type != JointType.BASE:
                lig_length = pd * 2.0
                for side in (+1.0, -1.0):
                    strip = shapes.centered_cube(lig_t, lig_w, lig_length)
                    strip = shapes.translate(
                        strip,
                        [
                            pd / 2.0,
                            side * (pw - lig_w / 2.0),
                            -lig_length / 4.0,
                        ],
                    )
                    parts.append(strip)

            # --- Flexor pulley: guide channel on the palmar (+X) side ---
            pu_l = float(pulley.length.to("m").value) if pulley else 0.0
            pu_t = float(pulley.thickness.to("m").value) if pulley else 0.0
            pu_r = float(pulley.radius.to("m").value) if pulley else 0.0
            if pu_l > 0 and pu_t > 0 and pu_r > 0:
                p_outer_r = pu_r + pu_t
                channel = shapes.cylinder(r=p_outer_r, h=pu_l)
                mid_z = length_m / 2.0 - pu_l / 2.0
                channel = shapes.translate(
                    channel,
                    [pd / 2.0, -pu_l / 2.0, mid_z],
                )
                parts.append(channel)

            base = Port()
            tip = Port()
            flexor_guides: tuple[Port, ...] = ()
            extensor_guides: tuple[Port, ...] = ()
            lateral_anchors: tuple[Port, ...] = ()
            routing_positions: list[tuple[Port, list[float]]] = []
            if routed:
                clearance = max(pd, dd, pwf, dwf) / 2 + 0.002
                flexor_guides = (Port(), Port())
                extensor_guides = (Port(), Port())
                lateral_anchors = (Port(), Port()) if lateral else ()
                for sign, ports in ((-1, flexor_guides), (1, extensor_guides)):
                    for port, z in zip(
                        ports, (0.2 * length_m, guide_end * length_m), strict=True
                    ):
                        position = [0, sign * clearance, z]
                        routing_positions.append((port, position))
                        # An open printed eye: two cheeks anchored to the bone
                        # and a cap, with no solid at the cable centreline.
                        root = sign * min(pwf, dwf) / 2
                        height = clearance + 0.0015 - abs(root)
                        parts.extend(
                            shapes.translate(
                                shapes.centered_cube(0.001, height, 0.004),
                                [x, sign * (abs(root) + height / 2), z],
                            )
                            for x in (-0.00125, 0.00125)
                        )
                        parts.append(
                            shapes.translate(
                                shapes.centered_cube(0.0035, 0.001, 0.004),
                                [0, sign * (clearance + 0.00125), z],
                            )
                        )
                for sign, port in zip((-1, 1), lateral_anchors):
                    position = [sign * (max(pd, dd) / 2 + 0.001), 0, 0.2 * length_m]
                    routing_positions.append((port, position))
                    parts.append(
                        shapes.translate(
                            shapes.centered_cube(0.004, 0.004, 0.004),
                            position,
                        )
                    )
            bone = cls(
                pose=pose,
                shape=shapes.union(*parts),
                base=base,
                tip=tip,
                flexor_guides=flexor_guides,
                extensor_guides=extensor_guides,
                lateral_anchors=lateral_anchors,
                vshape=vshape,
            )
            assert_transform(bone, base)
            assert_transform(bone, tip, Pose(pos=[0, 0, length_m]))
            for port, position in routing_positions:
                assert_transform(bone, port, Pose(pos=position))
        return bone


# ---------------------------------------------------------------------------
# Printed bones: the OPH's own parts as visual overlays
# ---------------------------------------------------------------------------
# Config entries that are not part of one moving bone: 8 is the ligament
# bridging to the next bone, 11 the print-jig hole.
_PRINT_ONLY = (8, 11)

# OPH bones lie along +x with the dorsal face at y = 0, the palmar face at
# y = diameter and the width along z; RoboTL bones lie along +z, flex about +x
# and face palmar toward -y.
_OPH_TO_BONE = np.array([[0.0, 0.0, 1.0], [0.0, -1.0, 0.0], [1.0, 0.0, 0.0]])

# Millimetre model units: 0.4 mm chords, as fine as the print itself.
_PRINT_FS, _PRINT_FA = 0.4, 6.0


def printed_bone(dp: DigitParams, level: int) -> shapes.Shape:
    """The printed OPH bone ``level`` of digit ``dp``, in its RoboTL bone frame.

    The OPH's own ``modular_bone`` renders the bone with the same parameters,
    in the OPH frame and in millimetres, cached under
    :data:`~robotl.examples.oph_printed.OPH_SOURCES`. The OPH rolling contact
    points sit at mid-height of each joint, ``(0, d0/2)`` and
    ``(length, d1/2)``; they land on the RoboTL base and tip ports, so the
    taper's slight tilt is rotated out.

    :param dp: The digit's parameters.
    :param level: Bone index from the metacarpal.
    """

    def mm_values(*values: unxt.AbstractQuantity) -> list[float]:
        return [float(v.to("mm").value) for v in values]

    config = [
        0 if i in _PRINT_ONLY else value
        for i, value in enumerate(oph_printed.bone_configs()[dp.finger_type][level])
    ]
    (length,) = mm_values(dp.bone_lengths[level])
    diameters = mm_values(*dp.joint_diameters[level : level + 2])
    widths = mm_values(*dp.joint_widths[level : level + 2])
    ligament = mm_values(dp.lig.width, dp.lig.thickness)
    # The OPH ``p`` triple, in the order of ``parameters.scad``.
    pulley = mm_values(dp.pulley.length, dp.pulley.thickness, dp.pulley.radius)

    arguments = (config, length, diameters, widths, ligament, pulley)
    key = repr((arguments, _PRINT_FS, _PRINT_FA)).encode()
    name = "bone-" + hashlib.sha256(key).hexdigest()[:16]
    meshes = oph_printed.OPH_SOURCES / "meshes"
    stl = meshes / f"{name}.stl"
    if not stl.exists():
        bone = oph_printed.primitives().modular_bone(*arguments, ang=0)
        solid2_to_mesh(bone, name, path=meshes, fs=_PRINT_FS, fa=_PRINT_FA)

    tilt = math.atan2((diameters[1] - diameters[0]) / 2, length)
    untilt = np.array(
        [
            [math.cos(tilt), math.sin(tilt), 0.0],
            [-math.sin(tilt), math.cos(tilt), 0.0],
            [0.0, 0.0, 1.0],
        ]
    )
    centred = shapes.translate(
        shapes.external_mesh(str(stl)), [0, -diameters[0] / 2, 0]
    )
    metres = shapes.scale(centred, [1e-3, 1e-3, 1e-3])
    return shapes.rotate(metres, Rotation.from_matrix(_OPH_TO_BONE @ untilt))


# ---------------------------------------------------------------------------
# Digit: passive chain of Bones
# ---------------------------------------------------------------------------
@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class Digit(Component):
    """Anatomical digit: chain of :class:`Bone` s connected by hinges.

    Pure-data dataclass: every field is populated by :meth:`make`.

    :param bones: Bones from metacarpal to distal phalanx.
    :param base: Port at the digit's base, welded to the first bone.
    :param tip: Alias to the last bone's tip port.
    :param hinges: Inter-bone flexion hinges (length ``len(bones) - 1``).
    :param abduction: MCP abduction hinge; with ``hinges[0]`` it makes the
        MCP a 2-DOF ball between the fixed metacarpal and the proximal
        phalanx, as in the OPH source (``dof4_config`` in ``digits.scad``).
    :param weld_base: Weld holding ``base`` -> ``bones[0].base``.
    :param excludes: Unhandled ``disable_pair_collisions`` terms (the op is
        typed ``None``); the compiler walks these to emit exclusions.
    """

    bones: tuple[Bone, ...]
    base: Port
    tip: Port
    hinges: tuple[joints.Hinge, ...]
    abduction: joints.Hinge
    weld_base: joints.Weld
    excludes: tuple[Term | None, ...]

    @classmethod
    def make(
        cls,
        dp: DigitParams,
        *,
        routed: bool = False,
        thumb: bool = False,
        printed: bool = False,
    ) -> Self:
        """Build a :class:`Digit` from a single-digit parameter bundle.

        :param dp: Digit parameters, in mm quantities.
        :param printed: Draw each bone as its printed OPH part.
        """

        with frame() as pose:
            bones = tuple(
                Bone.make(
                    length=dp.bone_lengths[i],
                    prox=JointEnd(
                        dp.joint_diameters[i],
                        dp.joint_widths[i],
                        dp.joint_configs[i][0],
                    ),
                    dist=JointEnd(
                        dp.joint_diameters[i + 1],
                        dp.joint_widths[i + 1],
                        dp.joint_configs[i][1],
                    ),
                    lig=dp.lig,
                    pulley=dp.pulley,
                    routed=routed,
                    lateral=routed and i == 1,
                    guide_end=0.7 if i == 0 and not thumb else 0.6,
                    vshape=printed_bone(dp, i) if printed else None,
                )
                for i in range(len(dp.joint_configs))
            )

            # Distal phalanx overlaps the proximal phalanx's joint sphere at
            # qpos=0.
            excludes = (
                (disable_pair_collisions(bones[-1], bones[1]),)
                if len(bones) >= 4
                else ()
            )

            base = Port()
            weld_base = joints.Weld(base, bones[0].base)
            # Declared before the flexion hinges so abduction comes first.
            abduction = joints.Hinge(
                bones[0].tip,
                bones[1].base,
                axis=jnp.array([0.0, 1.0, 0.0]),
                range=(-1.2, 1.2),
                damping=0.01,
            )
            hinges = tuple(
                joints.Hinge(
                    parent.tip,
                    child.base,
                    axis=jnp.array([1.0, 0.0, 0.0]),
                    range=(-1.2, 1.2),
                    damping=0.01,
                )
                for parent, child in zip(bones[:-1], bones[1:])
            )
            digit = cls(
                pose=pose,
                bones=bones,
                base=base,
                tip=bones[-1].tip,
                hinges=hinges,
                abduction=abduction,
                weld_base=weld_base,
                excludes=excludes,
            )
            assert_transform(digit, base)
        return digit


_DIGIT_COLORS = (Colors.blue, Colors.orange, Colors.green, Colors.red, Colors.purple)
"""Cable hues in finger-then-thumb order; they repeat past five digits."""


def _cable(
    hinges: tuple[joints.Hinge, ...],
    moment_arms: tuple[float, ...],
    stiffness: float,
    color: tuple[float, float, float, float],
) -> tendons.FixedTendon:
    """A tension-only spring with constant moment arms, in metres.

    All OPH hinges and mixer joints travel less than one revolution. The
    lower deadband endpoint covers that travel with room for limit overshoot.
    It is drawn 1.5 mm across, wider than the OPH bill of materials' 0.2 mm
    braided line, so each cable stays legible in a whole-hand render.
    """
    return tendons.FixedTendon(
        joints=hinges,
        gear_ratios=moment_arms,
        stiffness=stiffness,
        rest_length=(-math.tau * sum(abs(arm) for arm in moment_arms), 0.0),
        width=0.00075,
        color=color,
    )


# ---------------------------------------------------------------------------
# Palm — computes its own geometry from HandParams
# ---------------------------------------------------------------------------
_THUMB_REACH = 0.025
"""How far beyond the finger origins, per axis in metres, the palm plate
extends toward a thumb; a thumb farther out is carried on a strut instead,
since a larger plate would shift off its wrist mount."""

_THUMB_PROUD = 0.0025
"""How far a thumb root may stand proud of the finger roots through the palm
thickness, in metres, and still enlarge the plate; the stock thumb stands
2 mm proud, and the plate face it sets is the one the wrist bracket seats."""

_STRUT_WIDTH = 0.012
"""Square cross-section of a printed thumb strut, in metres."""


def _thumb_strut(lo: jax.Array, hi: jax.Array, port: jax.Array) -> shapes.Shape:
    """Printed bars from the palm plate ``[lo, hi]`` to a thumb ``port``.

    The bars leave the plate at mid-thickness sideways across the finger row
    (z), run beside the fingers (x), then step through the palm thickness (y)
    to the port, so they clear the finger roots and the thumb's own bones.
    """
    corners = [jnp.clip(port, lo, hi).at[1].set((lo[1] + hi[1]) / 2)]
    for axis in (2, 0, 1):
        corners.append(corners[-1].at[axis].set(port[axis]))
    half = _STRUT_WIDTH / 2
    return shapes.union(
        *(
            shapes.translate(
                shapes.cube(*(jnp.abs(b - a) + 2 * half).tolist()),
                (jnp.minimum(a, b) - half).tolist(),
            )
            for a, b in zip(corners[:-1], corners[1:])
            if float(jnp.linalg.norm(b - a)) > 0
        )
    )


@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class Palm(Component):
    """Palm plate that derives size, digit poses, and ports from params.

    Pure-data dataclass: every field is populated by :meth:`make`.

    :param shape: Palm plate cuboid covering the finger origins and reaching
        toward each thumb by at most :data:`_THUMB_REACH`, plus a printed strut
        to each thumb mounted farther out.
    :param base: Port at the palm's local frame origin.
    :param finger_ports: One port per finger, splayed per the params.
    :param thumb_ports: One port per thumb.
    :param params: The hand parameters :meth:`make` built this palm from, so
        its geometry can be rebuilt and checked against later edits.
    :param back_face: The plate's back face along the palm's +y, in metres;
        a mount seats here, never on a strut that leaves the plate.
    """

    shape: shapes.Shape
    base: Port
    finger_ports: tuple[Port, ...]
    thumb_ports: tuple[Port, ...]
    params: HandParams
    back_face: float
    cable_anchors: tuple[tuple[Port, Port], ...] = ()

    @classmethod
    def make(
        cls,
        params: HandParams,
        n_fingers: int,
        n_thumbs: int,
        routed: bool = False,
    ) -> Self:
        """Build a :class:`Palm` from hand parameters.

        :param params: Hand parameters, in mm and degree quantities.
        :param n_fingers: Number of finger ports (capped by the params).
        :param n_thumbs: Number of thumb ports (capped by the params).
        """
        origins_f = jnp.asarray(params.origins_finger.to("m").value)
        origins_t = jnp.asarray(params.origins_thumb.to("m").value)
        angles_f = jnp.asarray(params.angles_finger.to("rad").value)
        angles_t = jnp.asarray(params.angles_thumb.to("rad").value)
        n_f = min(n_fingers, origins_f.shape[0])
        n_t = min(n_thumbs, origins_t.shape[0])

        with frame() as pose:
            # Compute digit poses (splay + base rotation + unit scaling)
            finger_poses = [
                Pose(pos=origins_f[i], rv=angles_f[i]) @ _BASE_ROT for i in range(n_f)
            ]
            thumb_poses = [
                Pose(pos=origins_t[i], rv=angles_t[i]) @ _BASE_ROT for i in range(n_t)
            ]

            # The plate covers the fingers and each thumb, but reaches toward a
            # thumb at most _THUMB_REACH beyond the fingers, so it keeps its
            # wrist-mount footprint; a thumb farther out gets a strut below.
            covered, far_thumbs = [], []
            # Reach spans the palm plane (x along the fingers, z across them);
            # through the plate's thickness (y) only a thumb barely proud of
            # the fingers, as the stock one is, still widens the plate.
            in_plane = jnp.array([_THUMB_REACH, _THUMB_PROUD, _THUMB_REACH])
            for origin in origins_t[:n_t]:
                if n_f:
                    reach = jnp.clip(
                        origin,
                        origins_f[:n_f].min(axis=0) - in_plane,
                        origins_f[:n_f].max(axis=0) + in_plane,
                    )
                    if not jnp.allclose(reach, origin):
                        far_thumbs.append(origin)
                    covered.append(reach)
                else:
                    covered.append(origin)
            if n_f + n_t > 0:
                xyz = jnp.concatenate([origins_f[:n_f], *(o[None] for o in covered)])
                pad = 0.020
                dxyz = jnp.maximum(
                    xyz.max(axis=0) - xyz.min(axis=0) + pad,
                    jnp.array([0.020, 0.020, 0.040]),
                )
                center = (xyz.min(axis=0) + xyz.max(axis=0)) / 2
            else:
                dxyz = jnp.array([0.020, 0.060, 0.080])
                center = jnp.zeros(3)

            shape = shapes.translate(
                shapes.centered_cube(*dxyz.tolist()),
                center.tolist(),
            )
            lo, hi = center - dxyz / 2, center + dxyz / 2
            for origin in far_thumbs:
                # The plate's padding already holds a thumb just past the reach.
                if not jnp.all((origin >= lo) & (origin <= hi)):
                    shape = shapes.union(shape, _thumb_strut(lo, hi, origin))

            base = Port()
            fports = tuple(Port() for _ in finger_poses)
            tports = tuple(Port() for _ in thumb_poses)
            cable_anchors = (
                tuple((Port(), Port()) for _ in (*finger_poses, *thumb_poses))
                if routed
                else ()
            )
            anchor_poses = []
            if routed:
                for digit_pose, ports in zip(
                    (*finger_poses, *thumb_poses), cable_anchors, strict=True
                ):
                    for sign, port in zip((-1, 1), ports, strict=True):
                        anchor_pose = digit_pose @ Pose(pos=[sign * 0.012, 0, -0.012])
                        anchor_poses.append((port, anchor_pose))
                        # Printed root anchor bosses share the palm body.
                        shape = shapes.union(
                            shape,
                            shapes.transform(
                                shapes.union(
                                    *(
                                        shapes.translate(
                                            shapes.centered_cube(0.001, 0.006, 0.006),
                                            [x, 0, 0],
                                        )
                                        for x in (-0.0025, 0.0025)
                                    ),
                                    *(
                                        shapes.translate(
                                            shapes.centered_cube(0.004, 0.001, 0.006),
                                            [0, y, 0],
                                        )
                                        for y in (-0.0025, 0.0025)
                                    ),
                                ),
                                anchor_pose,
                            ),
                            shapes.transform(
                                shapes.union(
                                    shapes.translate(
                                        shapes.centered_cube(0.018, 0.004, 0.004),
                                        [sign * 0.006, 0.004, -0.012],
                                    ),
                                    shapes.translate(
                                        shapes.centered_cube(0.004, 0.004, 0.016),
                                        [0, 0.004, -0.006],
                                    ),
                                ),
                                digit_pose,
                            ),
                        )
            palm = cls(
                pose=pose,
                shape=shape,
                base=base,
                finger_ports=fports,
                thumb_ports=tports,
                params=params,
                back_face=float(center[1] + dxyz[1] / 2),
                cable_anchors=cable_anchors,
            )
            assert_transform(palm, base)
            for port, digit_pose in zip(fports, finger_poses):
                assert_transform(palm, port, digit_pose)
            for port, digit_pose in zip(tports, thumb_poses):
                assert_transform(palm, port, digit_pose)
            for port, anchor_pose in anchor_poses:
                assert_transform(palm, port, anchor_pose)
        return palm


# ---------------------------------------------------------------------------
# OpenParametricHand — full assembly
# ---------------------------------------------------------------------------
@defcomponent
def MixerCableGuide(self, radius: float, n_tracks: int) -> None:
    """Printed stator bracket and ideal frictionless exit eyes.

    The bracket seats on the casing outside the drum. Tracks use its 6 mm width;
    the side site selects the wrapping branch and is not a physical guide.
    Both casing-seated feet support the exit bridge. The rear brace stays on
    the left to clear the palm and digit roots.
    """
    self.base = self.place(Port())
    self.side = self.place(Port(), Pose(pos=[-2 * radius, 0, 0.003]))
    self.eyes = tuple(
        self.place(Port(), Pose(pos=[0, 2 * radius, z]))
        for z in mixer_track_heights(n_tracks)
    )
    self.shape = shapes.union(
        *(
            shapes.translate(
                shapes.centered_cube(radius + 0.006 - 0.01425, 0.004, 0.002),
                [sign * (radius + 0.006 + 0.01425) / 2, 0, -0.002],
            )
            for sign in (-1, 1)
        ),
        *(
            shapes.translate(
                shapes.centered_cube(0.004, 0.004, 0.005),
                [x, 0, -0.0005],
            )
            for x in (-radius - 0.004, radius + 0.004)
        ),
        shapes.translate(
            shapes.centered_cube(radius + 0.006, 0.008, 0.002),
            [-(radius + 0.006) / 2, -radius - 0.005, 0.001],
        ),
        *(
            shapes.translate(
                shapes.centered_cube(0.004, length, 0.002),
                [x, center, 0.001],
            )
            for x, length, center in (
                (-radius - 0.004, 3 * radius + 0.007, radius / 2 - 0.0015),
                (radius + 0.004, 2 * radius + 0.004, radius),
            )
        ),
        shapes.translate(
            shapes.centered_cube(2 * radius + 0.012, 0.004, 0.002),
            [0, 2 * radius, -0.002],
        ),
        *(
            shapes.translate(
                shapes.centered_cube(0.004, 0.004, 0.005),
                [x, 2 * radius, -0.0005],
            )
            for x in (-radius - 0.004, radius + 0.004)
        ),
        *(
            shapes.translate(
                shapes.centered_cube(0.001, 0.004, 0.008), [x, 2 * radius, 0.003]
            )
            for x in (-0.0015, 0.0015)
        ),
        shapes.translate(
            shapes.centered_cube(0.004, 0.004, 0.001), [0, 2 * radius, 0.0065]
        ),
    )
    self.material = Material(density=1240, color=jnp.array([0.3, 0.5, 0.4, 1]))


type CableRole = Literal["flexor", "intermediate", "splay_pos", "splay_neg"]
"""A digit cable a motor can drive: the distal flexor, the intermediate
flexor (every joint but the distal), or the cable on either side of the MCP
abduction hinge, named by the direction it turns that hinge when pulled."""


class CableDrive(NamedTuple):
    """One digit cable driven by one motor.

    :param digit: Digit index, fingers then thumbs.
    :param role: Which of the digit's cables.
    :param motor: Motor index: 0 and 1 are the OPH mixers; each higher index
        adds a motor.
    """

    digit: NonNegativeInt
    role: CableRole
    motor: NonNegativeInt


# A cable pulls its joint toward the negative of its coefficient, so the
# positive splay cable carries a negative arm on the abduction hinge.
_SPLAY_SIGN: dict[CableRole, float] = {"splay_pos": -1.0, "splay_neg": 1.0}


@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class OpenParametricHand(Component):
    """Open parametric hand assembled from a palm and hinge-mounted digits.

    Pure-data dataclass: every field is populated by :meth:`make`; pass a
    :class:`HandParams` to override the stock ``parameters.scad`` anatomy.

    :param base: Port at the hand's local frame origin.
    :param tip: Alias to the first digit's tip (the hand's reference
        fingertip).
    :param fingertips: One tip port per digit, fingers then thumbs. This is
        the grip-point interface the grasp losses and the cube placement
        walk; :class:`~robotl.examples.hand_with_wrist.HandWithWrist`
        forwards it when the hand is mounted on a wrist.
    :param palm: Palm plate carrying the digit mount ports.
    :param weld_palm: Weld holding ``base`` -> ``palm.base``.
    :param fingers: Finger digits, one per palm finger port.
    :param thumbs: Thumb digits, one per palm thumb port.
    :param digit_welds: Each digit's metacarpal fixed at its palm port.
    :param motors: Intermediate/opposition mixer, then distal-flexor mixer.
    :param motor_welds: Mixer housings attached behind the palm.
    :param tendons: Active series-elastic cables and passive antagonist cables.
    :param excludes: Unhandled ``disable_pair_collisions`` terms (the op is
        typed ``None``); the compiler walks these to emit exclusions.
    """

    base: Port
    tip: Port
    fingertips: tuple[Port, ...]
    palm: Palm
    weld_palm: joints.Weld
    fingers: tuple[Digit, ...]
    thumbs: tuple[Digit, ...]
    digit_welds: tuple[joints.Weld, ...]
    motors: tuple[X430, ...]
    motor_welds: tuple[joints.Weld, ...]
    tendons: tuple[tendons.FixedTendon | tendons.SpatialTendon, ...]
    excludes: tuple[Term | None, ...]
    routing_guides: tuple[LegacyComponent, ...] = ()
    routing_welds: tuple[joints.Weld, ...] = ()

    @classmethod
    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def make(
        cls,
        params: HandParams | None = None,
        n_fingers: int = 4,
        n_thumbs: int = 1,
        *,
        motor_model: X430Model | tuple[X430Model, ...] = "XL430-W250",
        motor_supply: Volt = volt(11.1),
        motor_backset: MmOrOff = mm(0),
        independent_fingers: tuple[NonNegativeInt, ...] = (),
        drives: tuple[CableDrive, ...] = (),
        spatial_transmission: bool = False,
        printed: bool = False,
    ) -> Self:
        """Build an :class:`OpenParametricHand`.

        :param params: Hand anatomy; stock ``parameters.scad`` values when
            ``None``.
        :param n_fingers: Number of fingers.
        :param n_thumbs: Number of thumbs.
        :param motor_model: One same-envelope X430 model for every motor, or
            one per motor in motor-index order.
        :param motor_supply: Both motor supplies; defaults to the XL430 ROBOTIS
            recommended 11.1 V, not a reported voltage from the OPH paper.
        :param motor_backset: Additional housing displacement behind the palm.
            Fixed-mode moment arms are unchanged. Spatial-mode reference cuts
            follow the assembled route at the new mounting position.
        :param independent_fingers: Finger indices whose distal-flexor cables
            use separate motors. The first two motors retain their mixer roles;
            additional motors follow this index order. Shorthand for
            ``flexor`` drives on motors 2, 3 and so on.
        :param drives: Motor for each listed digit cable, over the stock OPH
            wiring: every distal flexor on mixer 1; the index and thumb
            intermediate flexors and the thumb's two splay cables on mixer 0;
            every other intermediate and splay cable a passive spring. A
            driven cable keeps its OPH moment arms and takes the active cable
            stiffness; driving a passive one replaces its spring. Motors are
            numbered from 0 without gaps, and each must drive a cable.
            Fixed-tendon mode only.
        :param spatial_transmission: Prototype geometric, tension-only routing
            using the represented uniform drum radius. Printed guide geometry
            is approximate; guide friction and spring pretension are uncalibrated.
            Fairleads are frictionless, cables do not collide with arbitrary
            solids, and printed-support compliance is not modeled.
        :param printed: Draw each bone as its printed OPH part; see
            :mod:`robotl.examples.oph_printed`. Visual only.
        """
        backset = motor_backset
        p = params or HandParams()

        with frame() as pose:
            base = Port()
            palm = Palm.make(
                params=p,
                n_fingers=n_fingers,
                n_thumbs=n_thumbs,
                routed=spatial_transmission,
            )
            # A thumb index would otherwise move that thumb's flexor.
            if any(i >= len(palm.finger_ports) for i in independent_fingers):
                raise ValueError("independent_fingers must name existing fingers")
            weld_palm = joints.Weld(
                base, palm.base, Pose(pos=[_MOUNT_CLEARANCE, 0.0, 0.0])
            )

            fingers = []
            thumbs = []
            digit_welds = []
            excludes: list[Term | None] = []

            # --- Fingers ---
            for i, fport in enumerate(palm.finger_ports):
                digit = Digit.make(
                    dp=p.finger(i), routed=spatial_transmission, printed=printed
                )
                # The fixed metacarpal overlaps the palm.
                excludes.append(disable_pair_collisions(palm, digit.bones[0]))
                digit_welds.append(joints.Weld(fport, digit.base))
                fingers.append(digit)

            # --- Thumbs ---
            for i, tport in enumerate(palm.thumb_ports):
                digit = Digit.make(
                    dp=p.thumb(i),
                    routed=spatial_transmission,
                    thumb=True,
                    printed=printed,
                )
                # Metacarpal sits inside the palm; on top of that the thumb's
                # MCP abduction swings the proximal phalanx through the palm
                # geometry.
                excludes.append(disable_pair_collisions(palm, digit.bones[0]))
                if len(digit.bones) >= 2:
                    excludes.append(disable_pair_collisions(palm, digit.bones[1]))
                digit_welds.append(joints.Weld(tport, digit.base))
                thumbs.append(digit)

            # Adjacent fingers' metacarpals and proximal phalanges sit close
            # enough at rest that their tapered cuboid bodies overlap; exclude
            # the pairs.
            for a, b in zip(fingers[:-1], fingers[1:]):
                excludes.extend(
                    disable_pair_collisions(a.bones[k], b.bones[k])
                    for k in (0, 1)
                    if k < len(a.bones) and k < len(b.bones)
                )

            digits = (*fingers, *thumbs)
            if not digits:
                raise ValueError("OpenParametricHand needs at least one digit")
            if drives and spatial_transmission:
                raise ValueError("cable drives apply to fixed-tendon hands only")
            # Stock OPH wiring, then the independent fingers, then the drives.
            assignment: dict[tuple[int, CableRole], int] = {
                (i, "flexor"): FLEXOR_MIXER_INDEX for i in range(len(digits))
            }
            for i, digit in enumerate(digits):
                is_thumb = i >= len(fingers)
                if digit.hinges[:-1] and (is_thumb or i == 0):
                    assignment[i, "intermediate"] = 0
                if is_thumb:
                    assignment[i, "splay_pos"] = 0
                    assignment[i, "splay_neg"] = 0
            requested = (
                *(
                    CableDrive(i, "flexor", SHARED_MIXER_COUNT + k)
                    for k, i in enumerate(independent_fingers)
                ),
                *drives,
            )
            if len({(d.digit, d.role) for d in requested}) != len(requested):
                raise ValueError("each digit cable takes at most one drive")
            for drive in requested:
                if drive.digit >= len(digits):
                    raise ValueError(f"no digit {drive.digit} to drive")
                if drive.role == "intermediate" and not digits[drive.digit].hinges[:-1]:
                    raise ValueError(f"digit {drive.digit} has no intermediate flexor")
                assignment[drive.digit, drive.role] = drive.motor
            motor_count = max(SHARED_MIXER_COUNT, max(assignment.values()) + 1)
            idle = set(range(motor_count)) - set(assignment.values())
            if idle:
                raise ValueError(f"motors {sorted(idle)} drive no cable")
            digit_params = [
                *(p.finger(i) for i in range(len(fingers))),
                *(p.thumb(i) for i in range(len(thumbs))),
            ]
            mixer_radii = [
                float(dp.joint_diameters[1].to("m").value)
                * (
                    (18.3, 19.4, 18.3, 16.0)[i] / (12.5, 14, 12.5, 11)[i]
                    if i < len(fingers)
                    else 21 / 16
                )
                for i, dp in enumerate(digit_params)
            ]
            spool_radius = max(mixer_radii)
            cables_per_motor = Counter(assignment.values())
            track_counts = tuple(cables_per_motor[m] for m in range(motor_count))
            motor_models = (
                (motor_model,) * len(track_counts)
                if isinstance(motor_model, str)
                else motor_model
            )
            if len(motor_models) != len(track_counts):
                raise ValueError(
                    f"motor_model names {len(motor_models)} motors; "
                    f"the hand has {len(track_counts)}"
                )
            motors = tuple(
                X430.make(
                    model=model,
                    supply=motor_supply,
                    spool_radius=mm(spool_radius * 1000),
                    rot_range=(0.0, math.pi / 2),
                    cable_tracks=tracks if spatial_transmission else 0,
                )
                for model, tracks in zip(motor_models, track_counts, strict=True)
            )
            motor_welds = tuple(
                joints.Weld(
                    base,
                    motor.base,
                    Pose(
                        pos=[
                            _MOUNT_CLEARANCE
                            - spool_radius
                            - 0.01
                            - float(backset.to("m").value),
                            0.02,
                            -0.025 - i * 0.06,
                        ]
                    ),
                )
                for i, motor in enumerate(motors)
            )

            cables: list[tendons.FixedTendon | tendons.SpatialTendon] = []
            if not spatial_transmission:
                for i, (digit, dp, mixer_radius) in enumerate(
                    zip(digits, digit_params, mixer_radii)
                ):
                    is_thumb = i >= len(fingers)
                    arms = tuple(
                        float(d.to("m").value) / 2
                        for d in dp.joint_diameters[1 : len(digit.bones)]
                    )
                    # The OPH source mounts the abduction pulleys on the sides
                    # of the MCP ball, at half its joint width.
                    base_arm = float(dp.joint_widths[1].to("m").value) / 2
                    # Motor-driven cables in the digit's hue, springs paled
                    # toward white.
                    driven = _DIGIT_COLORS[i % len(_DIGIT_COLORS)]
                    red, green, blue, alpha = driven
                    passive = ((red + 1) / 2, (green + 1) / 2, (blue + 1) / 2, alpha)

                    def pull(
                        role: CableRole,
                        hinges: tuple[joints.Hinge, ...],
                        moment_arms: tuple[float, ...],
                        spring: float,
                    ) -> tendons.FixedTendon:
                        """The cable on its assigned motor, else a passive spring."""
                        motor = assignment.get((i, role))
                        if motor is None:
                            return _cable(hinges, moment_arms, spring, passive)
                        return _cable(
                            (motors[motor].hinge, *hinges),
                            (mixer_radius, *moment_arms),
                            870.0,
                            driven,
                        )

                    cables.append(
                        pull("flexor", digit.hinges, tuple(-a for a in arms), 870.0)
                    )
                    cables.append(_cable(digit.hinges, arms, 320.0, passive))
                    if digit.hinges[:-1]:
                        cables.append(
                            pull(
                                "intermediate",
                                digit.hinges[:-1],
                                tuple(-a for a in arms[:-1]),
                                320.0,
                            )
                        )
                    cables.extend(
                        pull(role, (digit.abduction,), (sign * base_arm,), 110.0)
                        for role, sign in _SPLAY_SIGN.items()
                    )
                    if is_thumb:
                        cables.append(
                            _cable(
                                (digit.abduction,),
                                (-base_arm,),
                                320.0,
                                passive,
                            )
                        )

            routing_guides: tuple[LegacyComponent, ...] = ()
            routing_welds: tuple[joints.Weld, ...] = ()
            if spatial_transmission:
                routed_cables, routing_guides, routing_welds = _spatial_cables(
                    digits,
                    len(fingers),
                    palm,
                    motors,
                    dict(
                        zip(
                            independent_fingers,
                            range(SHARED_MIXER_COUNT, len(motors)),
                            strict=True,
                        )
                    ),
                    spool_radius,
                )
                cables.extend(routed_cables)
            hand = cls(
                pose=pose,
                base=base,
                tip=digits[0].tip,
                fingertips=tuple(d.tip for d in digits),
                palm=palm,
                weld_palm=weld_palm,
                fingers=tuple(fingers),
                thumbs=tuple(thumbs),
                digit_welds=tuple(digit_welds),
                motors=motors,
                motor_welds=motor_welds,
                tendons=tuple(cables),
                excludes=tuple(excludes),
                routing_guides=routing_guides,
                routing_welds=routing_welds,
            )
            assert_transform(hand, base)
        return hand


FLEXOR_MIXER_INDEX = 1
SHARED_MIXER_COUNT = 2

type SpatialCableRole = Literal[
    "flexor",
    "extensor",
    "intermediate-active",
    "intermediate-passive",
    "lateral-active",
    "lateral-passive",
    "antagonist",
]


class SpatialCableRoute(NamedTuple):
    """Component-owned cable path and elastic intent before drum attachment."""

    role: SpatialCableRole
    path: tuple[Port, ...]
    digit_index: int
    hinges: tuple[joints.Hinge, ...]
    sign: float
    stiffness: float
    color: tuple[float, float, float]

    def motor_index(self, independent: Mapping[int, int]) -> int | None:
        """Resolve the mixer or selected finger motor for this route.

        :param independent: Finger index to additional motor index.
        """
        if self.role == "flexor":
            return independent.get(self.digit_index, FLEXOR_MIXER_INDEX)
        if self.role in ("intermediate-active", "lateral-active"):
            return 0
        return None


def spatial_cable_routes(
    digits: tuple[Digit, ...], n_fingers: int, palm: Palm
) -> Iterator[SpatialCableRoute]:
    """Derive each anatomical cable role from its components' actual ports.

    :param digits: Finger digits followed by thumb digits.
    :param n_fingers: Number of finger digits before the thumbs.
    :param palm: Palm carrying the lateral root anchors.
    """
    for i, digit in enumerate(digits):
        yield SpatialCableRoute(
            "flexor",
            tuple(p for bone in digit.bones for p in bone.flexor_guides),
            i,
            digit.hinges,
            -1.0,
            870,
            (1, 0.1, 0.1),
        )
        yield SpatialCableRoute(
            "extensor",
            tuple(p for bone in digit.bones for p in bone.extensor_guides),
            i,
            digit.hinges,
            1.0,
            320,
            (0.1, 0.5, 1),
        )
        if digit.hinges[:-1]:
            active = i == 0 or i >= n_fingers
            yield SpatialCableRoute(
                "intermediate-active" if active else "intermediate-passive",
                tuple(p for bone in digit.bones[:-1] for p in bone.flexor_guides),
                i,
                digit.hinges[:-1],
                -1.0,
                870 if active else 320,
                (1, 0.1, 0.1) if active else (0.2, 0.8, 0.7),
            )
        for root, anchor in zip(
            palm.cable_anchors[i], digit.bones[1].lateral_anchors, strict=True
        ):
            thumb = i >= n_fingers
            yield SpatialCableRoute(
                "lateral-active" if thumb else "lateral-passive",
                (root, anchor),
                i,
                (),
                0.0,
                870 if thumb else 110,
                (1, 0.1, 0.1) if thumb else (0.7, 0.7, 0.2),
            )
        if i >= n_fingers:
            yield SpatialCableRoute(
                "antagonist",
                (palm.cable_anchors[i][1], digit.bones[1].lateral_anchors[1]),
                i,
                (),
                0.0,
                320,
                (0.1, 0.5, 1),
            )


def _spatial_cables(
    digits: tuple[Digit, ...],
    n_fingers: int,
    palm: Palm,
    motors: tuple[X430, ...],
    independent: Mapping[int, int],
    radius: float,
) -> tuple[
    list[tendons.SpatialTendon], tuple[LegacyComponent, ...], tuple[joints.Weld, ...]
]:
    """Assemble cable load paths; all motor commands still act on real shafts."""
    cables = []
    active: list[tuple[X430, SpatialCableRoute]] = []
    for route in spatial_cable_routes(digits, n_fingers, palm):
        if (motor_index := route.motor_index(independent)) is not None:
            active.append((motors[motor_index], route))
        else:
            cables.append(
                tendons.SpatialTendon(
                    path=route.path,
                    stiffness=route.stiffness,
                    slack_length=0,
                    width=0.00025,
                    color=(*route.color, 1),
                )
            )
    guides, welds = [], []
    for motor in motors:
        routes = [route for source, route in active if source is motor]
        guide = MixerCableGuide(radius, len(routes))
        guides.append(guide)
        welds.append(joints.Weld(motor.output_mount, guide.base))
        for anchor, eye, route in zip(
            motor.spool.cable_anchors, guide.eyes, routes, strict=True
        ):
            cables.append(
                tendons.SpatialTendon(
                    path=(
                        anchor,
                        tendons.TendonWrap.make(motor.spool, guide.side),
                        eye,
                        *route.path,
                    ),
                    stiffness=route.stiffness,
                    slack_length=0,
                    width=0.00025,
                    color=(*route.color, 1),
                )
            )
    return cables, tuple(guides), tuple(welds)


def _digit_prefixes(mj_model: mujoco.MjModel, pattern: str) -> list[str]:
    """The digit prefixes (``fingers_0``, ``thumbs_1``, ...) a body name
    pattern matches, in a stable body order."""
    found: list[str] = []
    for body in range(mj_model.nbody):
        m = re.search(pattern, mj_model.body(body).name)
        if m and m.group(0) not in found:
            found.append(m.group(0))
    return found


def setup_oph_collisions(mj_model: mujoco.MjModel, geoms: Sequence[int]) -> str:
    """Assign the open parametric hand's collision groups
    (``contype``/``conaffinity``).

    The shared engine owns the bit layout and pair semantics (bit 0 the
    cube, bit 1 the floor, bit 2 the palm, bits 3.. one per digit; MuJoCo
    accepts a pair when either geom's ``contype`` intersects the other's
    ``conaffinity``, and a digit leaves its own bit out of its
    ``conaffinity``, so same-digit pairs zero out). Intrinsic overlaps
    (metacarpal in the palm, adjacent metacarpals, the distal phalanx at the
    tip joint) are compiler excludes on the component and stay excluded
    under any masks.

    Pair with :func:`apply_oph_physics`, which sets the material contact
    response on the collision-active geoms. Returns a short summary string.

    :param geoms: Graph-owned hand geometry and the selected cube/floor surfaces.
        Wrist, mounting hardware and other scene objects retain their masks.
    """
    digits = _digit_prefixes(mj_model, r"(fingers|thumbs)_\d+")
    digit_bit = {d: 1 << (3 + i) for i, d in enumerate(digits)}
    all_digit_bits = sum(digit_bit.values())

    def classify(geom: int) -> tuple[str, tuple[int, int]]:
        if not (mj_model.geom_contype[geom] or mj_model.geom_conaffinity[geom]):
            return "disabled", (0, 0)
        body = mj_model.body(int(mj_model.geom_bodyid[geom])).name
        gtype = int(mj_model.geom_type[geom])
        if "cube" in body:
            return "cube", surface_masks(CUBE_BIT, all_digit_bits)
        if gtype == int(mujoco.mjtGeom.mjGEOM_PLANE):
            return "floor", surface_masks(FLOOR_BIT, all_digit_bits)
        if "palm" in body:
            if gtype == int(mujoco.mjtGeom.mjGEOM_MESH):
                return "off", (0, 0)
            return "palm", surface_masks(PALM_BIT, all_digit_bits)
        m = re.search(r"(fingers|thumbs)_\d+", body)
        if m is None:
            return "off", (0, 0)
        return "digit", digit_masks(digit_bit[m.group(0)], all_digit_bits)

    summary = assign_collision_masks(
        mj_model, "oph collision filter", classify, geoms=geoms
    )
    return f"{summary}, {len(digits)} digits (within-digit disabled)"


def _tip_bodies(mj_model: mujoco.MjModel) -> set[int]:
    """The body ids of each digit's distal bone, the fingertip surface."""
    top: dict[str, tuple[int, int]] = {}
    for body in range(mj_model.nbody):
        m = re.search(r"(fingers|thumbs)_\d+_bones_(\d+)", mj_model.body(body).name)
        if m is None:
            continue
        digit, index = m.group(0).rsplit("_bones_", 1), int(m.group(2))
        known = top.get(digit[0])
        if known is None or index > known[1]:
            top[digit[0]] = (body, index)
    return {body for body, _ in top.values()}


def apply_oph_physics(mj_model: mujoco.MjModel, geoms: Sequence[int]) -> str:
    """Patch the compiled model with the hand's MuJoCo-only contact settings.

    The shared engine's contact response, scoped to this family: the
    fingertip surface is each digit's distal bone, and the palm plate is the
    palm body's non-mesh geoms. The two-tone paint loop is a menagerie
    cosmetic and the OPH skips it. Run *after* :func:`setup_oph_collisions`,
    which owns the hand masks.

    :param geoms: Graph-owned hand geometry; other materials remain unchanged.
    """
    tip_bodies = _tip_bodies(mj_model)
    tips: set[int] = set()
    palms: set[int] = set()
    for geom in geoms:
        body = mj_model.body(int(mj_model.geom_bodyid[geom])).name
        if int(mj_model.geom_bodyid[geom]) in tip_bodies:
            tips.add(geom)
        if "palm" in body and mj_model.geom_type[geom] != int(
            mujoco.mjtGeom.mjGEOM_MESH
        ):
            palms.add(geom)
    return apply_contact_response(mj_model, tips, palms, geoms=geoms)


if __name__ == "__main__":
    view_model(lambda: Based.make(OpenParametricHand.make()))

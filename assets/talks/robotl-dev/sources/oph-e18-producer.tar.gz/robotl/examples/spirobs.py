"""SpiRobs: logarithmic spiral-shaped cable-driven robots.

After Wang, Freris and Wei, "SpiRobs: Logarithmic Spiral-shaped Robots for
Versatile Grasping Across Scales", Device, 2024.

The body is a logarithmic spiral discretized at a fixed angular step. Because
the discretization is uniform in the angular domain, adjacent units differ by a
constant ratio, so one unit design scales down the whole chain and the uncurled
body is a cone. Units are joined by hinges carrying the elastic layer that
restores the body to straight, and cables running the length of the body curl
it when a motor pulls them. A body is described by :class:`SpiRobParams`,
which checks the ranges the design is known to work in, and built by the
``make`` classmethod of :class:`SpiRob` or :class:`SpiRob3`.
"""

import math
from dataclasses import dataclass
from typing import Self

import effectful.handlers.jax.numpy as jnp
import pydantic
import unxt
from effectful.ops.types import Term
from pydantic import ConfigDict, TypeAdapter

from robotl.examples.based import Based
from robotl.handlers.mujoco import view_model
from robotl.handlers.mujoco.config import MujocoSettings
from robotl.internals.utils import Polygon
from robotl.ops import actuators, joints, shapes, tendons
from robotl.ops.joints import JointSpring
from robotl.ops.syntax import (
    Component,
    Material,
    Port,
    Pose,
    assert_transform,
    enable_pair_collisions,
    frame,
)
from robotl.ops.units import Deg, Mm, N, Unit, deg, mm, newton

# The cables bend the body about +Y, so the spiral curls in the XZ plane.
Y = jnp.array([0.0, 1.0, 0.0])
X = jnp.array([1.0, 0.0, 0.0])

# The printed body is hard against itself, and the distal units are nearly
# massless: with MuJoCo's inertia-scaled default contact they could not stop
# anything, so the impedance is pinned near rigid.
_BODY_MATERIAL = Material(solimp=(0.98, 0.999, 2e-4), solref=(0.004, 1.0))


def settings() -> MujocoSettings:
    """Simulation settings the body's packing behaviour needs.

    The short timestep matches the near-rigid contact of the body material.
    """
    return MujocoSettings(dt=0.001)


def solve_growth(width_root: float, width_tip: float, length: float) -> float:
    """Growth rate ``b`` of the spiral a body of these proportions unrolls to.

    Inverts the paper's relation between the body's length and the widths at
    its two ends,

    ``L = sqrt(b^2 + 1) / b * (width_root - width_tip) / 2 * (e^(2 pi b) + 1) / (e^(2 pi b) - 1)``

    by bisection, which is monotone in ``b`` over the range that matters.
    """
    if width_root <= width_tip:
        raise ValueError("width_root must exceed width_tip")
    if length <= 0:
        raise ValueError("length must be positive")

    def excess(b: float) -> float:
        eb = math.exp(2.0 * math.pi * b)
        ratio = (eb + 1.0) / (eb - 1.0)
        return (
            math.sqrt(1.0 + b * b) / b * (width_root - width_tip) * 0.5 * ratio - length
        )

    low, high = 1e-6, 5.0
    while excess(high) > 0:
        high *= 2.0
        if high > 1e6:
            raise ValueError("no spiral matches these proportions")
    for _ in range(80):
        mid = 0.5 * (low + high)
        low, high = (mid, high) if excess(mid) > 0 else (low, mid)
    return 0.5 * (low + high)


def unit_profile(b: float, delta_theta: float, p: float = 0.5) -> Polygon:
    """Half of one unit's outline, unrolled, as (axial, lateral) rows.

    A unit is the quadrilateral between the spiral and the central spiral over
    one step, mirrored across the central spiral. Unrolling it puts the central
    spiral on the axis, so the returned points run from the base corner out to
    the widest edge and back to the tip corner, and the mirror is the same
    points with the lateral coordinate negated.

    Sizes are relative to the spiral's ``a``, so a unit scales by
    ``exp(b * delta_theta)`` from the one before it. The spiral grows away
    from the tip, so within a unit the larger end faces the base; that
    orientation is what makes consecutive scaled units continuous, each
    unit's long base flank tapering down to meet the next smaller unit.

    :param b: Growth rate of the spiral.
    :param delta_theta: Discretization step.
    :param p: Where the central spiral sits between a turn and the next. The
        paper's midpoint is ``0.5``.
    """
    c = p + (1.0 - p) * math.exp(2.0 * math.pi * b)
    r0, r1 = 1.0, math.exp(b * delta_theta)
    # The spiral edge and the central-spiral edge, in the plane.
    outer = [(r0, 0.0), (r1 * math.cos(delta_theta), r1 * math.sin(delta_theta))]
    inner = [
        (c * r0, 0.0),
        (c * r1 * math.cos(delta_theta), c * r1 * math.sin(delta_theta)),
    ]
    # Unroll: put the central-spiral edge on the axis, starting at the origin.
    dx, dy = inner[1][0] - inner[0][0], inner[1][1] - inner[0][1]
    angle = -math.atan2(dy, dx)
    cos_a, sin_a = math.cos(angle), math.sin(angle)

    def place(pt: tuple[float, float]) -> tuple[float, float]:
        x, y = pt[0] - inner[0][0], pt[1] - inner[0][1]
        return (x * cos_a - y * sin_a, x * sin_a + y * cos_a)

    unrolled = [place(inner[0]), place(outer[0]), place(outer[1]), place(inner[1])]
    # The unrolled quadrilateral runs from the smaller (theta = 0) end to
    # the larger; flip it so the larger end is the base at the origin.
    length = unrolled[-1][0]
    return Polygon(jnp.asarray([(length - x, y) for x, y in reversed(unrolled)]))


@dataclass(frozen=True)
class SpiRobParams:
    """A SpiRob body, within the ranges the design is known to work in.

    Defaults are the paper's grasping prototype: 24 units tapering from 60 mm
    at the root to 5.5 mm at the tip. Constructing checks every range;
    :meth:`validated` additionally checks that dimensioned fields arrive as
    quantities of the right dimension (see :mod:`robotl.ops.units`).

    The ranges are the authors' own: their published design tool bounds the
    spiral's growth rate, scale, discretization and total wrap, its simulator
    bounds the elastic constants, and the paper's prototypes sit inside all of
    them. The force bound is this module's calibration of the cable control;
    see :attr:`max_stable_pull`.

    :param n_units: Units in the chain, base to tip.
    :param base_width: Width of the body at the root.
    :param tip_width: Width at the tip. With ``base_width`` and ``n_units``
        this is the taper, and so the spiral the body unrolls from.
    :param depth_frac: Extent of a planar body across the curling plane, per
        unit width. A revolved body has no depth to choose.
    :param delta_theta: Discretization step, and so the angle one joint closes
        by when the body is fully curled.
    :param stiffness: Elastic layer at the root, as a spring on every joint in
        newton metres per radian, restoring the body to straight when the
        cables relax. A joint's spring falls off as the square of the taper
        down the chain and its damping as the taper, which is how the authors'
        own generator scales them.
    :param damping: Damping at the root joint, in newton metre seconds per
        radian.
    :param cable_frac: Where the cables sit as a fraction of the half width.
        This is the moment arm the motors pull on.
    :param flat_frac: Where a spatial body's three cut flats sit, as a
        fraction of the radius. The paper's arm is revolved and then cut to
        re-shape: flat between the cables, full radius at the cables' lobes.
        A planar body has no flats to place.
    :param gap_frac: How much of a unit's length is cut from each of its
        points, which is the clearance to its neighbours in the straight body.
    :param max_pull: Largest force a cable motor may pull with. Cables push
        nothing, so a motor's control range is one sided.
    """

    n_units: int = 24
    base_width: Mm = mm(60)
    tip_width: Mm = mm(5.5)
    depth_frac: Unit = 0.6
    delta_theta: Deg = deg(30)
    stiffness: float = 0.04
    damping: float = 0.02
    cable_frac: Unit = 0.8
    flat_frac: Unit = 0.85
    gap_frac: float = 0.06
    max_pull: N = newton(0.3)

    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    @classmethod
    def validated(cls, **kwargs) -> Self:
        """Authoring seam: construct with every constraint checked."""
        return TypeAdapter(cls).validate_python(kwargs)

    @property
    def taper_ratio(self) -> float:
        """Size ratio of a unit to the one before it, fixed by the taper."""
        tip = float(self.tip_width.to("mm").value)
        base = float(self.base_width.to("mm").value)
        return (tip / base) ** (1.0 / (self.n_units - 1))

    @property
    def growth_rate(self) -> float:
        """Growth rate ``b`` of the spiral the body unrolls from."""
        return -math.log(self.taper_ratio) / float(self.delta_theta.to("rad").value)

    @property
    def max_stable_pull(self) -> unxt.AbstractQuantity:
        """Largest steady pull the packed body can hold, as a force.

        At full curl every packed joint rests on its contact stop, where the
        root spring holds a torque of ``stiffness * delta_theta``. A cable
        pulling harder than that torque over its root moment arm is no longer
        curling anything: it crushes the packed body through its own stops,
        which the solver resolves badly. The default body measures stable at
        0.9 times this bound and unstable at 1.6.
        """
        torque = unxt.Quantity(jnp.asarray(self.stiffness), "N m") * float(
            self.delta_theta.to("rad").value
        )
        arm = self.cable_frac * self.base_width / 2.0
        return (torque / arm).to("N")

    def __post_init__(self):
        if self.n_units < 2:
            raise ValueError(
                f"a body is a chain of at least 2 units, got {self.n_units}"
            )
        base = float(self.base_width.to("mm").value)
        tip = float(self.tip_width.to("mm").value)
        if tip >= base:
            raise ValueError(
                f"the body must taper: tip_width {self.tip_width} is not "
                f"smaller than base_width {self.base_width}"
            )
        step = float(self.delta_theta.to("deg").value)
        if not 1.0 <= step <= 60.0:
            raise ValueError(
                f"delta_theta {step:.3g} deg is outside [1, 60] deg, the "
                "authors' design tool range"
            )
        b = self.growth_rate
        if not 0.01 <= b <= 0.35:
            raise ValueError(
                f"these proportions unroll to a spiral of growth rate {b:.3g}, "
                "outside [0.01, 0.35], the authors' design tool range; bring "
                "the widths closer or spread the taper over more units"
            )
        wrap = self.n_units * float(self.delta_theta.to("rad").value)
        if not math.pi <= wrap <= 12.0 * math.pi:
            raise ValueError(
                f"fully curled, the body wraps {wrap / math.pi:.3g} pi, "
                "outside [1, 12] pi, the authors' design tool range"
            )
        profile = unit_profile(b, float(self.delta_theta.to("rad").value))
        scale = base / (2.0 * float(profile.points[:, 1].max()))
        if not 0.1 <= scale <= 100.0:
            raise ValueError(
                f"the spiral's scale comes to {scale:.3g} mm, outside "
                "[0.1, 100] mm, the authors' design tool range"
            )
        if not 0.0 < self.stiffness <= 100.0:
            raise ValueError(
                f"stiffness {self.stiffness} is outside (0, 100], the "
                "authors' simulator range"
            )
        if not 0.0 <= self.damping <= 100.0:
            raise ValueError(
                f"damping {self.damping} is outside [0, 100], the authors' "
                "simulator range"
            )
        if not 0.03 <= self.gap_frac <= 0.10:
            raise ValueError(
                f"gap_frac {self.gap_frac} is outside [0.03, 0.1], the range "
                "where the trimmed mesh stays sound and first contact stays "
                "within a degree of the design stop"
            )
        pull = float(self.max_pull.to("N").value)
        limit = float(self.max_stable_pull.to("N").value)
        if pull > limit:
            raise ValueError(
                f"max_pull {pull:.3g} N exceeds max_stable_pull {limit:.3g} N; "
                "a stronger pull overpowers the root spring at full curl and "
                "drives the packed body through its own contact stops"
            )


@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class SpiRobUnit(Component):
    """One unit of the planar body, the shape the spiral discretization gives it.

    Pure-data dataclass: every field is populated by :meth:`make`.

    :param shape: The unit's prism, axial along local +Z.
    :param material: Near-rigid contact of the printed body.
    :param base: Port at the proximal pivot.
    :param tip: Port at the distal pivot.
    :param cable_left: Cable routing port on the -X side.
    :param cable_right: Cable routing port on the +X side.
    """

    shape: shapes.Shape
    material: Material
    base: Port
    tip: Port
    cable_left: Port
    cable_right: Port

    @classmethod
    def make(
        cls,
        profile: Polygon,
        scale: float,
        depth: float,
        cable_frac: float,
        gap_frac: float,
    ) -> Self:
        """Build one unit at ``scale``.

        The unit tapers to a point at each end along its axis, which is what
        leaves its neighbours room to rotate: they close on each other when
        the body packs into the spiral, and the angle they close is the
        discretization step. The points themselves are cut back by
        ``gap_frac`` so that closing brings two faces together instead of two
        pivot vertices.

        :param profile: Half the outline from :func:`unit_profile`.
        :param scale: Size of this unit, as the spiral's radius where it sits.
        :param depth: Extent across the curling plane.
        :param cable_frac: Where the cables sit as a fraction of the half
            width. This is the moment arm the motors pull on.
        :param gap_frac: How much of the unit's length to cut from each point.
        """
        with frame() as pose:
            half = Polygon(profile.points * scale)
            mirror = (half.points[1:-1] * jnp.asarray([1.0, -1.0]))[::-1]
            outline = Polygon(jnp.concatenate([half.points, mirror]))
            length = float(half.points[-1, 0])  # tip pivot; flanks may overhang
            width = 2 * float(half.points[:, 1].max())
            gap = gap_frac * length
            thickness = depth * scale
            # Cut the points back: the flanks keep their direction, so a unit
            # still has exactly one discretization step of clearance, but
            # neighbours close face on face instead of vertex on vertex,
            # which is a contact a solver can resolve.
            body = shapes.intersection(
                shapes.translate(
                    shapes.extrude(outline, thickness),
                    [0.0, 0.0, -thickness / 2],
                ),
                shapes.translate(
                    shapes.centered_cube(length - 2 * gap, 2 * width, 2 * thickness),
                    [length / 2, 0.0, 0.0],
                ),
            )
            # The outline is drawn axial-along-x, wide-along-y, thick-along-z.
            # Cycle those onto the body frame: axial along +Z, width across
            # the curling plane on X so the cables have a moment arm about the
            # hinge, thickness on Y.
            cycle = Pose(
                rv=(-2 * math.pi / 3) * jnp.array([1.0, 1.0, 1.0]) / math.sqrt(3)
            )
            unit = cls(
                pose=pose,
                shape=shapes.transform(body, cycle),
                material=_BODY_MATERIAL,
                base=Port(),
                tip=Port(),
                cable_left=Port(),
                cable_right=Port(),
            )
            assert_transform(unit, unit.base)
            assert_transform(unit, unit.tip, Pose(pos=[0.0, 0.0, length]))
            offset = cable_frac * width / 2
            assert_transform(
                unit, unit.cable_left, Pose(pos=[-offset, 0.0, length / 2])
            )
            assert_transform(
                unit, unit.cable_right, Pose(pos=[+offset, 0.0, length / 2])
            )
        return unit


@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class SpiRob(Component):
    """A two-cable planar SpiRob.

    Pure-data dataclass: every field is populated by :meth:`make`.

    :param units: Units in the chain, base to tip.
    :param base: Port the root unit is welded to.
    :param tip: Alias to the last unit's tip port.
    :param hinges: Sprung hinge per pair of neighbouring units.
    :param contacts: Unhandled ``enable_pair_collisions`` terms, one per
        pair of neighbouring units; the compiler walks these to emit the
        contacts MuJoCo's parent filter would otherwise drop.
    :param weld_base: Weld holding ``base`` to the root unit.
    :param cable_left: Cable down the -X side of the body.
    :param cable_right: Cable down the +X side.
    :param motor_left: Pulls ``cable_left``.
    :param motor_right: Pulls ``cable_right``.
    """

    units: tuple[SpiRobUnit, ...]
    base: Port
    tip: Port
    hinges: tuple[joints.Hinge, ...]
    contacts: tuple[Term | None, ...]
    weld_base: joints.Weld
    cable_left: tendons.SpatialTendon
    cable_right: tendons.SpatialTendon
    motor_left: actuators.Force
    motor_right: actuators.Force

    @classmethod
    def make(cls, params: SpiRobParams = SpiRobParams()) -> Self:
        """Build the body :class:`SpiRobParams` describes.

        The taper fixes the spiral, the spiral fixes the shape of a unit, and
        the length follows, so the body is one shape repeated at a geometric
        sequence of sizes, joined by sprung hinges and curled by a cable down
        each side. Neighbours closing on each other is what stops the curl,
        the same way the printed body does it, so each neighbouring pair is
        declared as colliding past MuJoCo's parent filter.
        """
        delta_theta = float(params.delta_theta.to("rad").value)
        ratio = params.taper_ratio
        profile = unit_profile(params.growth_rate, delta_theta)
        unit_width = 2 * float(profile.points[:, 1].max())
        # `taper` is how far down the chain a unit sits, and scales the
        # elastic layer; `scales` carries the size in metres and only shapes
        # the geometry.
        taper = [ratio**i for i in range(params.n_units)]
        base_width = float(params.base_width.to("m").value)
        scales = [(base_width / unit_width) * t for t in taper]
        max_pull = float(params.max_pull.to("N").value)

        with frame() as pose:
            units = tuple(
                SpiRobUnit.make(
                    profile=profile,
                    scale=s,
                    depth=params.depth_frac,
                    cable_frac=params.cable_frac,
                    gap_frac=params.gap_frac,
                )
                for s in scales
            )
            base = Port()
            hinges = tuple(
                joints.Hinge(
                    units[i].tip,
                    units[i + 1].base,
                    axis=Y,
                    damping=params.damping * taper[i],
                    spring=JointSpring(
                        stiffness=params.stiffness * taper[i] ** 2, rest=0.0
                    ),
                )
                for i in range(params.n_units - 1)
            )
            # Neighbouring units are parent and child, whose contacts MuJoCo
            # filters by default; each declared pair restores exactly their
            # touching, which is what stops the curl.
            contacts = tuple(
                enable_pair_collisions(units[i], units[i + 1])
                for i in range(params.n_units - 1)
            )
            cable_left = tendons.SpatialTendon(
                path=[u.cable_left for u in units], width=0.0015
            )
            cable_right = tendons.SpatialTendon(
                path=[u.cable_right for u in units], width=0.0015
            )
            robot = cls(
                pose=pose,
                units=units,
                base=base,
                tip=units[-1].tip,
                hinges=hinges,
                contacts=contacts,
                weld_base=joints.Weld(base, units[0].base),
                cable_left=cable_left,
                cable_right=cable_right,
                motor_left=actuators.Force(cable_left, ctrlrange=(-max_pull, 0.0)),
                motor_right=actuators.Force(cable_right, ctrlrange=(-max_pull, 0.0)),
            )
            assert_transform(robot, base)
        return robot


def _flats(d: float, span: float) -> list[shapes.Shape]:
    """Three half-space slabs whose faces sit ``d`` from the +Z axis.

    The faces' outward normals point between the cables, at 60, 180 and 300
    degrees: intersecting with them is the paper's cut to re-shape, keeping
    the revolved body's full radius at the cables' lobes and cutting it
    flat between them.

    :param d: Distance of each face from the axis.
    :param span: Largest extent of the geometry being cut, so each slab
        reaches past the axis to cover all of it.
    """
    side = 2.0 * (d + span)
    return [
        shapes.transform(
            shapes.centered_cube(side, side, side),
            Pose(
                pos=[
                    (d - side / 2) * math.cos(a),
                    (d - side / 2) * math.sin(a),
                    0.0,
                ],
                rv=[0.0, 0.0, a],
            ),
        )
        for a in (math.pi / 3, math.pi, 5 * math.pi / 3)
    ]


def _clipped(outline: Polygon, cut: float, keep_high: bool) -> Polygon:
    """The closed outline clipped to one side of a first-coordinate plane."""
    points = [(float(x), float(y)) for x, y in outline.points]
    out: list[tuple[float, float]] = []
    for (x0, y0), (x1, y1) in zip(points, points[1:] + points[:1]):
        if (x0 >= cut) == keep_high:
            out.append((x0, y0))
        if (x0 >= cut) != (x1 >= cut):
            t = (cut - x0) / (x1 - x0)
            out.append((cut, y0 + t * (y1 - y0)))
    return Polygon(jnp.asarray(out))


@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class SpiRobKnuckle(Component):
    """The pivot between two units of a spatial SpiRob, drawn as their points.

    Three cables bend the body in any direction, which takes two axes, so a
    junction is a hinge into the knuckle and a hinge out of it. Its shape
    restores exactly what the units' solver cut removed: the lower unit's
    tip point and the upper unit's base point, meeting at the pivot they
    share, so the body keeps the printed chain's silhouette of units
    joined at their points. The restored points do not collide, because the
    elastic layer at the pivot bends rather than stops; what stops the curl
    is the units' own faces touching, and they sit two links apart so no
    contact filter hides that.

    :param shape: The two cut-off points meeting at the pivot.
    :param base: Port the pitch hinge acts on.
    :param tip: Port the yaw hinge acts on.
    """

    shape: shapes.Shape
    base: Port
    tip: Port

    @classmethod
    def make(
        cls,
        below: Polygon,
        above: Polygon,
        flat_below: float,
        flat_above: float,
    ) -> Self:
        """Build the two cut-off points as revolved meridian outlines.

        :param below: Meridian outline of the piece under the pivot, as
            (radial, axial) rows with the pivot at the origin.
        :param above: Meridian outline of the piece over the pivot.
        :param flat_below: Distance of the piece's three cut flats from the
            axis, continuing its unit's own flats.
        :param flat_above: The same for the piece over the pivot.
        """

        def piece(outline: Polygon, flat: float) -> shapes.Shape:
            span = 4.0 * float(jnp.abs(outline.points).max())
            return shapes.intersection(shapes.revolve(outline), *_flats(flat, span))

        with frame() as pose:
            knuckle = cls(
                pose=pose,
                shape=shapes.union(piece(below, flat_below), piece(above, flat_above)),
                disable_collision=True,
                base=Port(),
                tip=Port(),
            )
            assert_transform(knuckle, knuckle.base)
            assert_transform(knuckle, knuckle.tip)
        return knuckle


@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class SpiRobUnit3(Component):
    """One unit of a spatial body, the same outline revolved instead of mirrored.

    Pure-data dataclass: every field is populated by :meth:`make`.

    :param shape: The revolved unit, axial along local +Z.
    :param material: Near-rigid contact of the printed body.
    :param base: Port at the proximal pivot.
    :param tip: Port at the distal pivot.
    :param cables: Cable routing ports, 120 degrees apart around the
        section, one per channel at the middle of its bore. A via-point
        tendon passes through geometry freely, so ports at the bore mouths
        would let the crossing chord cross the pivot at full curl and
        reverse the cable's moment arm, where the printed channel's walls
        hold the real cable out; the mid-bore chord keeps the moment arm on
        the cable's side of every pivot.
    """

    shape: shapes.Shape
    material: Material
    base: Port
    tip: Port
    cables: tuple[Port, Port, Port]

    @classmethod
    def make(
        cls,
        profile: Polygon,
        scale: float,
        cable_frac: float,
        flat_frac: float,
        gap_frac: float,
    ) -> Self:
        """Build one unit at ``scale``, rotated and then cut to re-shape.

        The paper's construction: the half profile is the meridian outline,
        revolved about the unit's axis, so the surface is what the planar
        unit's flanks sweep and neighbours close on each other at the same
        angle whichever way the body bends. The revolved body is then cut:
        the points are cut back by a coaxial cylinder, the same slab cut as
        the planar unit's; three flats are cut between the cables; and the
        cable channels are bored through the lobes that remain at full
        radius. A mesh collides as its convex hull, so the bores stay
        visual and the cables run inside them.

        :param profile: Half the outline from :func:`unit_profile`.
        :param scale: Size of this unit, as the spiral's radius where it sits.
        :param cable_frac: Where the cables sit as a fraction of the radius.
        :param flat_frac: Where the flats sit as a fraction of the radius.
        :param gap_frac: How much of the unit's length to cut from each point.
        """
        with frame() as pose:
            half = Polygon(profile.points * scale)
            length = float(half.points[-1, 0])  # tip pivot; flanks may overhang
            radius = float(half.points[:, 1].max())
            gap = gap_frac * length
            offset = cable_frac * radius
            body = shapes.intersection(
                shapes.revolve(Polygon(half.points[:, ::-1])),
                shapes.translate(
                    shapes.cylinder(r=2 * radius, h=length - 2 * gap),
                    [0.0, 0.0, gap],
                ),
                *_flats(flat_frac * radius, 4.0 * (length + radius)),
            )
            channels = shapes.union(
                *(
                    shapes.translate(
                        shapes.cylinder(r=0.07 * radius, h=3.0 * length),
                        [offset * math.cos(a), offset * math.sin(a), -length],
                    )
                    for a in (0.0, 2 * math.pi / 3, 4 * math.pi / 3)
                )
            )
            unit = cls(
                pose=pose,
                shape=shapes.difference(body, channels),
                material=_BODY_MATERIAL,
                base=Port(),
                tip=Port(),
                cables=(Port(), Port(), Port()),
            )
            assert_transform(unit, unit.base)
            assert_transform(unit, unit.tip, Pose(pos=[0.0, 0.0, length]))
            for port, a in zip(unit.cables, (0.0, 2 * math.pi / 3, 4 * math.pi / 3)):
                assert_transform(
                    unit,
                    port,
                    Pose(pos=[offset * math.cos(a), offset * math.sin(a), length / 2]),
                )
        return unit


@pydantic.dataclasses.dataclass(
    eq=False, kw_only=True, config=ConfigDict(arbitrary_types_allowed=True)
)
class SpiRob3(Component):
    """A three-cable spatial SpiRob.

    Pure-data dataclass: every field is populated by :meth:`make`.

    :param units: Units in the chain, base to tip.
    :param knuckles: Pivot between each pair of neighbouring units.
    :param base: Port the root unit is welded to.
    :param tip: Alias to the last unit's tip port.
    :param pitch_hinges: Sprung hinge from each unit into its knuckle.
    :param yaw_hinges: Sprung hinge from each knuckle into the next unit.
    :param weld_base: Weld holding ``base`` to the root unit.
    :param cables: Three cables spaced evenly around the section.
    :param motors: One per cable.
    """

    units: tuple[SpiRobUnit3, ...]
    knuckles: tuple[SpiRobKnuckle, ...]
    base: Port
    tip: Port
    pitch_hinges: tuple[joints.Hinge, ...]
    yaw_hinges: tuple[joints.Hinge, ...]
    weld_base: joints.Weld
    cables: tuple[tendons.SpatialTendon, ...]
    motors: tuple[actuators.Force, ...]

    @classmethod
    def make(
        cls,
        params: SpiRobParams = SpiRobParams(
            n_units=42, base_width=mm(120), tip_width=mm(5)
        ),
    ) -> Self:
        """Build the body :class:`SpiRobParams` describes, rotated then cut.

        Defaults are the paper's metre-long arm: the same spiral as the planar
        body over 42 units, but the section is revolved instead of mirrored,
        and three cables spaced evenly around it bend the body in any
        direction.

        A junction is a pitch hinge and a yaw hinge in series rather than a
        ball, because a spring needs a rest value and MuJoCo rests a ball
        spring at a quaternion. Sequential axes are not isotropic: the cables
        sit 120 degrees apart but bend the body along bearings nearer 0 and
        plus or minus 132 degrees. The directions stay distinct and symmetric,
        which is what the three-cable strategy needs, but a ball joint would
        place them evenly.
        """
        delta_theta = float(params.delta_theta.to("rad").value)
        ratio = params.taper_ratio
        profile = unit_profile(params.growth_rate, delta_theta)
        unit_width = 2 * float(profile.points[:, 1].max())
        taper = [ratio**i for i in range(params.n_units)]
        base_width = float(params.base_width.to("m").value)
        scales = [(base_width / unit_width) * t for t in taper]
        max_pull = float(params.max_pull.to("N").value)

        length_rel = float(profile.points[-1, 0])
        radius_rel = float(profile.points[:, 1].max())
        gap_rel = params.gap_frac * length_rel
        # The pieces the units' slab cut removes, in (radial, axial) with
        # the pivot at the origin; each knuckle wears them back. The cut
        # plane sits at 1.2 times the gap so the pieces reach into their
        # units and no coincident faces flicker where they meet the cuts.
        tip_shift = jnp.asarray([length_rel, 0.0])
        tip_piece = Polygon(
            (_clipped(profile, length_rel - 1.2 * gap_rel, True).points - tip_shift)[
                :, ::-1
            ]
        )
        base_piece = Polygon(_clipped(profile, 1.2 * gap_rel, False).points[:, ::-1])

        with frame() as pose:
            units = tuple(
                SpiRobUnit3.make(
                    profile=profile,
                    scale=s,
                    cable_frac=params.cable_frac,
                    flat_frac=params.flat_frac,
                    gap_frac=params.gap_frac,
                )
                for s in scales
            )
            knuckles = tuple(
                SpiRobKnuckle.make(
                    below=Polygon(tip_piece.points * scales[i]),
                    above=Polygon(base_piece.points * scales[i + 1]),
                    flat_below=params.flat_frac * radius_rel * scales[i],
                    flat_above=params.flat_frac * radius_rel * scales[i + 1],
                )
                for i in range(params.n_units - 1)
            )
            base = Port()
            # Two axes per junction: pitch into the knuckle, yaw out of it.
            pitch_hinges = tuple(
                joints.Hinge(
                    units[i].tip,
                    knuckles[i].base,
                    axis=Y,
                    damping=params.damping * taper[i],
                    spring=JointSpring(
                        stiffness=params.stiffness * taper[i] ** 2, rest=0.0
                    ),
                )
                for i in range(params.n_units - 1)
            )
            yaw_hinges = tuple(
                joints.Hinge(
                    knuckles[i].tip,
                    units[i + 1].base,
                    axis=X,
                    damping=params.damping * taper[i],
                    spring=JointSpring(
                        stiffness=params.stiffness * taper[i] ** 2, rest=0.0
                    ),
                )
                for i in range(params.n_units - 1)
            )
            cables = tuple(
                tendons.SpatialTendon(path=[u.cables[k] for u in units], width=0.002)
                for k in range(3)
            )
            robot = cls(
                pose=pose,
                units=units,
                knuckles=knuckles,
                base=base,
                tip=units[-1].tip,
                pitch_hinges=pitch_hinges,
                yaw_hinges=yaw_hinges,
                weld_base=joints.Weld(base, units[0].base),
                cables=cables,
                motors=tuple(
                    actuators.Force(cable, ctrlrange=(-max_pull, 0.0))
                    for cable in cables
                ),
            )
            assert_transform(robot, base)
        return robot


if __name__ == "__main__":
    view_model(lambda: Based.make(SpiRob.make()))

import effectful.handlers.jax.numpy as jnp

from robotl.examples.based import HasBaseAndTip
from robotl.ops import joints, shapes
from robotl.ops.losses import Equalize
from robotl.ops.syntax import Origin, Port, defcomponent


@defcomponent
def Rectangle(self, distance, thickness, length):
    self.base = self.place(Port())
    self.shape = shapes.union(
        *(
            shapes.translate(
                shapes.centered_cube(thickness, thickness, length),
                [dx, distance / 2, dz],
            )
            for dx, dz in [
                [-length / 2, 0],
                [length / 2, 0],
                [0, -length / 2],
                [0, length / 2],
            ]
        )
    )


@defcomponent
def EndEffector(self):
    self.base = self.place(Port())
    self.shape = shapes.sphere(0.01)


@defcomponent
def PassThroughEnv(
    self,
    robot: HasBaseAndTip,
    distance: float = 1.0,
    thickness: float = 1e-2,
    length: float = 0.5,
):
    """
    Pass robot through a rectangle.

    - Description & evaluation metrics
        - The robot needs to trace a pass through a rectangle and reach specified distance.

    - Success criteria
        - Minimize L2 distance to the distance point
    """
    self.base = self.place(Port())
    self._weld_origin = joints.Weld(Origin.base, self.base)
    self.rectangle = self.place(
        Rectangle(distance=distance, thickness=thickness, length=length)
    )
    self._weld_rectangle = joints.Weld(self.base, self.rectangle.base)

    self.ee = EndEffector()
    self.robot = robot
    self._weld_robot = joints.Weld(self.base, robot.base)
    self._weld_ee = joints.Weld(self.robot.tip, self.ee.base)

    self.loss = Equalize(self.ee.pos, jnp.array([0, distance, 0]))

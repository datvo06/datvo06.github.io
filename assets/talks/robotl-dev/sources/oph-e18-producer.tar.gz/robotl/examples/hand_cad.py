import effectful.handlers.jax.numpy as jnp
from jax.scipy.spatial.transform import Rotation
from solid2.core.object_base import OpenSCADObject

import robotl.ops.joints as joints
from robotl.examples.based import Based
from robotl.handlers.mujoco import view_model
from robotl.ops.shapes import (
    centered_cube,
    cylinder,
    difference,
    intersection,
    rotate,
    sphere,
    translate,
    union,
)
from robotl.ops.syntax import Port, Pose, defcomponent


@defcomponent
def DummyRotatedComponent(self, component: OpenSCADObject):
    # Used to help with automated modification and make the Linter Happy
    self.base = self.place(Port())
    rotation = Rotation.from_euler("xyz", jnp.array([45, 90, 0]) / 180 * jnp.pi)
    self.shape = rotate(component, rotation)


@defcomponent
def DummyDifferencedComponent(
    self, component1: OpenSCADObject, component2: OpenSCADObject
):
    # Used to help with automated modification and make the Linter Happy
    self.base = self.place(Port())
    self.shape = difference(component1, component2)


@defcomponent
def DummyIntersectionComponent(
    self, component1: OpenSCADObject, component2: OpenSCADObject
):
    # Used to help with automated modification and make the Linter Happy
    self.base = self.place(Port())
    self.shape = intersection(component1, component2)


@defcomponent
def FingerTip(self, radius: float = 5, height: float = 10):
    self.shape = union(
        cylinder(r=radius, h=height),
        translate(sphere(radius), [0, 0, height]),
    )
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, height]))


@defcomponent
def FingerMiddleKnuckle(self, radius: float = 5, height: float = 10):
    self.shape = cylinder(r=radius, h=height)
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, height]))


@defcomponent
def FingerRoot(self, radius: float = 5, height: float = 10):
    self.shape = cylinder(r=radius, h=height)
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, height]))


@defcomponent
def ThumbRoot(self, base_radius: float = 10, radius: float = 5, height: float = 10):
    self.shape = cylinder(r=base_radius, r2=radius, h=height)
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, height]))


@defcomponent
def ThumpTop(self, radius: float = 5, height: float = 10, spacing: float = 2):
    self.base = self.place(Port())
    self.thumb_knuckle = FingerMiddleKnuckle(radius=radius, height=height)
    self.thumb_tip = FingerTip(radius=radius, height=height)
    self._weld_knuckle = joints.Weld(self.base, self.thumb_knuckle.base)
    self._weld_tip = joints.Weld(
        self.thumb_knuckle.tip, self.thumb_tip.base, Pose(pos=[0, 0, spacing])
    )


@defcomponent
def Thumb(self, radius: float = 5, height: float = 10, spacing: float = 2):
    self.base = self.place(Port())
    self.root = ThumbRoot(base_radius=radius * 1.2, radius=radius, height=height)
    self._weld_root = joints.Weld(self.base, self.root.base)
    self.top = ThumpTop(radius=radius, height=height, spacing=spacing)
    self._weld_top = joints.Weld(
        self.root.tip,
        self.top.base,
        Pose(pos=[0, 0, spacing], rv=jnp.pi / 4 * jnp.array([0, 1, 0])),
    )


@defcomponent
def Finger(self, radius: float = 5, height: float = 10, spacing: float = 2):
    self.base = self.place(Port())
    self.root = FingerRoot(radius=radius, height=height)
    self.middle = FingerMiddleKnuckle(radius=radius, height=height)
    self.finger_tip = FingerTip(radius=radius, height=height)
    self._weld_root = joints.Weld(self.base, self.root.base)
    self._weld_middle = joints.Weld(
        self.root.tip, self.middle.base, Pose(pos=[0, 0, spacing])
    )
    self._weld_finger_tip = joints.Weld(
        self.middle.tip, self.finger_tip.base, Pose(pos=[0, 0, spacing])
    )


@defcomponent
def Palm(self, width: float = 10, height: float = 10, depth: float = 10):
    self.base = self.place(Port())
    self.shape = centered_cube(width, height, depth)


@defcomponent
def Hand(
    self,
    radius: float = 5,
    height: float = 10,
    spacing: float = 2,
    horizontal_spacing: float = 2,
    **kwargs,
):
    """Complete robotic hand with palm, fingers, and thumb using CAD operations.

    Comprehensive CAD example showing complex assembly with local coordinate
    transformations, and varied finger geometries including a full palm
    structure and articulated thumb.
    """
    self.base = self.place(Port())
    self.fingers = []

    dx = 2 * radius + horizontal_spacing
    middle_idx = 1
    self._welds = []
    for i in range(3):
        finger_height = height * 1.2 if i == middle_idx else height
        finger = Finger(radius=radius, height=finger_height, spacing=spacing)
        self.fingers.append(finger)
        x = (i - middle_idx) * dx
        self._welds.append(joints.Weld(self.base, finger.base, Pose(pos=[x, 0, 0])))

    # The pinky is shorter
    self.pinky = Finger(radius=radius, height=height * 0.8, spacing=spacing)
    self._weld_pinky = joints.Weld(
        self.base, self.pinky.base, Pose(pos=[-2 * dx, 0, 0])
    )

    self.thumb = Thumb(radius=radius * 1.2, height=height * 0.8, spacing=spacing)
    self._weld_thumb = joints.Weld(
        self.base,
        self.thumb.base,
        Pose(
            pos=jnp.array([2 * (2 * radius), 0, -3 * radius]),
            rv=Rotation.from_euler(
                "ZXY", jnp.pi * jnp.array([1, -0.5, -0.25])
            ).as_rotvec(),
        ),
    )

    self.palm = Palm(
        width=dx * 4,
        height=height * 3,
        depth=radius * 2,
    )
    self._weld_palm = joints.Weld(
        self.base,
        self.palm.base,
        Pose(
            pos=[-2 * horizontal_spacing, 0, -height * 3 / 2],
            rv=jnp.pi / 2 * jnp.array([1, 0, 0]),
        ),
    )


if __name__ == "__main__":
    view_model(lambda: Based.make(Hand()))

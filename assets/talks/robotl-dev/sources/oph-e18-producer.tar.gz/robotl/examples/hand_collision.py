"""Shared collision masks and contact response for hands mounted in a scene.

The menagerie LEAP hand and the open parametric hand classify their own
compiled geoms and delegate here: this module owns the bit layout (cube,
floor, palm, one bit per digit), the mask filter (MuJoCo accepts a pair
when either geom's ``contype`` intersects the other's ``conaffinity``), and
the material contact response, so a second family cannot drift a second
copy of any of them.
"""

from collections.abc import Callable, Iterable

import mujoco

CUBE_BIT = 1
FLOOR_BIT = 2
PALM_BIT = 4

# Hand contact response, mirroring hydrax leap_rh.xml. Sliding friction is
# also set on the morphology; torsional/rolling + solref/solimp can't be, and
# we set them explicitly rather than trust compiler defaults (which can drift).
SOLREF = (0.02, 1.0)
SOLIMP = (0.9, 0.95, 0.001)
GEOM_FRICTION = (0.2, 0.005, 0.0001)
FINGERTIP_FRICTION = (0.7, 0.05, 0.0002)
PALM_MARGIN = 0.005


def surface_masks(bit: int, all_digit_bits: int) -> tuple[int, int]:
    """A cube, floor or palm geom's masks: every surface but its own bit."""
    others = (CUBE_BIT | FLOOR_BIT | PALM_BIT) & ~bit
    return (bit, others | all_digit_bits)


def digit_masks(bit: int, all_digit_bits: int) -> tuple[int, int]:
    """A digit geom's masks: every surface and digit but its own digit."""
    return (bit, CUBE_BIT | FLOOR_BIT | PALM_BIT | (all_digit_bits & ~bit))


def assign_collision_masks(
    mj_model: mujoco.MjModel,
    label: str,
    classify: Callable[[int], tuple[str, tuple[int, int]]],
    *,
    geoms: Iterable[int] | None = None,
) -> str:
    """Apply the classifier's (category, masks) to every geom and return the
    summary line. ``geoms`` limits ownership without changing other components'
    masks; the classifier owns enable/disable policy.
    """
    counts: dict[str, int] = {}
    for geom in range(mj_model.ngeom) if geoms is None else geoms:
        if int(mj_model.geom_group[geom]) == 1:
            continue
        category, masks = classify(geom)
        mj_model.geom_contype[geom], mj_model.geom_conaffinity[geom] = masks
        counts[category] = counts.get(category, 0) + 1
    enabled = sum(
        1
        for g in range(mj_model.ngeom)
        if mj_model.geom_contype[g] or mj_model.geom_conaffinity[g]
    )
    summary = " ".join(f"{k}={v}" for k, v in sorted(counts.items()))
    return f"{label}: {summary} | {enabled}/{mj_model.ngeom} geoms collision-enabled"


def apply_contact_response(
    mj_model: mujoco.MjModel,
    tips: set[int],
    palms: set[int],
    *,
    geoms: Iterable[int] | None = None,
) -> str:
    """The hand's MuJoCo-only contact response on the collision-active
    geoms: per-geom solref/solimp and the friction floor, the palm margin on
    the palm geoms, and the fingertip friction on the tip geoms. The cube is
    patched separately by ``patch_cube``.
    """
    for geom in range(mj_model.ngeom) if geoms is None else geoms:
        if mj_model.geom_contype[geom] == 0 and mj_model.geom_conaffinity[geom] == 0:
            continue
        body = mj_model.body(int(mj_model.geom_bodyid[geom])).name
        if "cube" in body:
            continue
        mj_model.geom_solref[geom] = SOLREF
        mj_model.geom_solimp[geom, :3] = SOLIMP
        for k in range(3):
            if mj_model.geom_friction[geom, k] <= GEOM_FRICTION[k]:
                mj_model.geom_friction[geom, k] = GEOM_FRICTION[k]
        if geom in palms:
            mj_model.geom_margin[geom] = PALM_MARGIN
        if geom in tips:
            for k in range(3):
                mj_model.geom_friction[geom, k] = FINGERTIP_FRICTION[k]
    return (
        f"hand: solref={list(SOLREF)} solimp={list(SOLIMP)} "
        f"fingertip_friction={list(FINGERTIP_FRICTION)}"
    )

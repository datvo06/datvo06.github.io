from importlib import resources

import effectful.handlers.jax.numpy as jnp

from robotl.handlers.mujoco import view_model
from robotl.ops import actuators, joints, shapes
from robotl.ops.shapes import rotate_quat, scale, translate
from robotl.ops.syntax import Inertia, Port, defcomponent

MESHSCALE = 1 * jnp.ones([3])
from robotl.ops.syntax import Pose

meshes = {
    name: str(
        resources.files("robotl").parent.joinpath(  # type: ignore
            "assets", "SO101", name + ".stl"
        )
    )
    for name in [
        "base_motor_holder_so101_v1",
        "base_so101_v2",
        "motor_holder_so101_base_v1",
        "motor_holder_so101_wrist_v1",
        "moving_jaw_so101_v1",
        "rotation_pitch_so101_v1",
        "sts3215_03a_no_horn_v1",
        "sts3215_03a_v1",
        "under_arm_so101_v1",
        "upper_arm_so101_v1",
        "waveshare_mounting_plate_so101_v2",
        "wrist_roll_follower_so101_v1",
        "wrist_roll_pitch_so101_v2",
    ]
}


@defcomponent
def SO101(self):
    self.inertia = Inertia(
        mass=0.147,
        pose=Pose(
            pos=jnp.array([0.0137179, -5.19711e-05, 0.0334843]),
            quat=jnp.array([0.0, 1.0, 0.0, 0.0]),
        ),
        diag=jnp.full((3,), 1e-6),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["base_motor_holder_so101_v1"]),
                    (0.5, 0.5, 0.5, 0.5),
                ),
                (-0.00636471, -9.94414e-05, -0.0024),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["base_so101_v2"]), (0.5, 0.5, 0.5, 0.5)
                ),
                (-0.00636471, -8.97657e-09, -0.0024),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["sts3215_03a_v1"]),
                    (1.0, -2.85511e-16, -9.64433e-17, 6.12908e-16),
                ),
                (0.0263353, -8.97657e-09, 0.0437),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["waveshare_mounting_plate_so101_v2"]),
                    (0.5, 0.5, 0.5, 0.5),
                ),
                (-0.0309827, -0.000199441, 0.0474),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.shoulder_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.0388353, -8.97657e-09, 0.0624]),
            quat=jnp.array([3.56167e-16, 1.22818e-15, -1.0, -4.14635e-16]),
        ),
    )
    self.shoulder = Shoulder()

    self.shoulder_pan = joints.Hinge(
        self.shoulder_mount,
        self.shoulder.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-1.9198621771937616, 1.9198621771937634),
    )
    self.shoulder_pan_actuator = actuators.Position(
        self.shoulder_pan,
        forcerange=jnp.array([-3.35, 3.35]),
        ctrlrange=jnp.array([-1.91986, 1.91986]),
    )


@defcomponent
def Shoulder(self):
    self.inertia = Inertia(
        mass=0.100006,
        pose=Pose(
            pos=jnp.array([-0.0307604, -1.66727e-05, -0.0252713]),
            quat=jnp.array([0.0, 1.0, 0.0, 0.0]),
        ),
        diag=jnp.full((3,), 1e-6),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["sts3215_03a_v1"]),
                    (0.5, 0.5, 0.5, -0.5),
                ),
                (-0.0303992, 0.000422241, -0.0417),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["sts3215_03a_v1"]),
                    (0.5, 0.5, 0.5, -0.5),
                ),
                (-0.0303992, 0.000422241, -0.0417),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["motor_holder_so101_base_v1"]),
                    (0.5, 0.5, -0.5, 0.5),
                ),
                (-0.0675992, -0.000177759, 0.0158499),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["motor_holder_so101_base_v1"]),
                    (0.5, 0.5, -0.5, 0.5),
                ),
                (-0.0675992, -0.000177759, 0.0158499),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["rotation_pitch_so101_v1"]),
                    (0.707107, -0.707107, -0.0, 8.3163e-34),
                ),
                (0.0122008, 2.22413e-05, 0.0464),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["rotation_pitch_so101_v1"]),
                    (0.707107, -0.707107, -0.0, 8.3163e-34),
                ),
                (0.0122008, 2.22413e-05, 0.0464),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.upper_arm_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([-0.0303992, -0.0182778, -0.0542]),
            quat=jnp.array([0.5, -0.5, -0.5, -0.5]),
        ),
    )
    self.upper_arm = UpperArm()

    self.shoulder_lift = joints.Hinge(
        self.upper_arm_mount,
        self.upper_arm.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-1.7453292519943224, 1.7453292519943366),
    )
    self.shoulder_lift_actuator = actuators.Position(
        self.shoulder_lift,
        forcerange=jnp.array([-3.35, 3.35]),
        ctrlrange=jnp.array([-1.74533, 1.74533]),
    )


@defcomponent
def UpperArm(self):
    self.inertia = Inertia(
        mass=0.103,
        pose=Pose(
            pos=jnp.array([-0.0898471, -0.00838224, 0.0184089]),
            quat=jnp.array([0.0, 1.0, 0.0, 0.0]),
        ),
        diag=jnp.full((3,), 1e-6),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["sts3215_03a_v1"]),
                    (4.56308e-16, -0.707107, 0.707107, -1.37383e-16),
                ),
                (-0.11257, -0.0155, 0.0187),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["sts3215_03a_v1"]),
                    (4.56308e-16, -0.707107, 0.707107, -1.37383e-16),
                ),
                (-0.11257, -0.0155, 0.0187),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["upper_arm_so101_v1"]),
                    (0.0, 1.0, 0.0, 0.0),
                ),
                (-0.065085, 0.012, 0.0182),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["upper_arm_so101_v1"]),
                    (0.0, 1.0, 0.0, 0.0),
                ),
                (-0.065085, 0.012, 0.0182),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.lower_arm_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([-0.11257, -0.028, 1.73763e-16]),
            quat=jnp.array([0.707107, -5.98613e-17, -2.58051e-17, 0.707107]),
        ),
    )
    self.lower_arm = LowerArm()

    self.elbow_flex = joints.Hinge(
        self.lower_arm_mount,
        self.lower_arm.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-1.69, 1.69),
    )
    self.elbow_flex_actuator = actuators.Position(
        self.elbow_flex,
        forcerange=jnp.array([-3.35, 3.35]),
        ctrlrange=jnp.array([-1.69, 1.69]),
    )


@defcomponent
def LowerArm(self):
    self.inertia = Inertia(
        mass=0.104,
        pose=Pose(
            pos=jnp.array([-0.0980701, 0.00324376, 0.0182831]),
            quat=jnp.array([0.0, 1.0, 0.0, 0.0]),
        ),
        diag=jnp.full((3,), 1e-6),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["under_arm_so101_v1"]),
                    (0.0, 1.0, 0.0, 0.0),
                ),
                (-0.0648499, -0.032, 0.0182),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["under_arm_so101_v1"]),
                    (0.0, 1.0, 0.0, 0.0),
                ),
                (-0.0648499, -0.032, 0.0182),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["motor_holder_so101_wrist_v1"]),
                    (3.92687e-16, -1.0, -1.9186e-15, -6.38378e-16),
                ),
                (-0.0648499, -0.032, 0.018),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["motor_holder_so101_wrist_v1"]),
                    (3.92687e-16, -1.0, -1.9186e-15, -6.38378e-16),
                ),
                (-0.0648499, -0.032, 0.018),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["sts3215_03a_v1"]),
                    (7.21645e-16, 1.56949e-15, 1.0, -3.33067e-16),
                ),
                (-0.1224, 0.0052, 0.0187),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["sts3215_03a_v1"]),
                    (7.21645e-16, 1.56949e-15, 1.0, -3.33067e-16),
                ),
                (-0.1224, 0.0052, 0.0187),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.wrist_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([-0.1349, 0.0052, 3.62355e-17]),
            quat=jnp.array([0.707107, 9.58722e-16, -7.51313e-16, -0.707107]),
        ),
    )
    self.wrist = Wrist()

    self.wrist_flex = joints.Hinge(
        self.wrist_mount,
        self.wrist.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-1.6580628494556928, 1.6580627293335335),
    )
    self.wrist_flex_actuator = actuators.Position(
        self.wrist_flex,
        forcerange=jnp.array([-3.35, 3.35]),
        ctrlrange=jnp.array([-1.65806, 1.65806]),
    )


@defcomponent
def Wrist(self):
    self.inertia = Inertia(
        mass=0.079,
        pose=Pose(
            pos=jnp.array([-0.000103312, -0.0386143, 0.0281156]),
            quat=jnp.array([0.0, 1.0, 0.0, 0.0]),
        ),
        diag=jnp.full((3,), 1e-6),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["sts3215_03a_no_horn_v1"]),
                    (0.5, 0.5, 0.5, -0.5),
                ),
                (8.32667e-17, -0.0424, 0.0306),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["sts3215_03a_no_horn_v1"]),
                    (0.5, 0.5, 0.5, -0.5),
                ),
                (8.32667e-17, -0.0424, 0.0306),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wrist_roll_pitch_so101_v2"]),
                    (0.5, -0.5, -0.5, -0.5),
                ),
                (0.0, -0.028, 0.0181),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wrist_roll_pitch_so101_v2"]),
                    (0.5, -0.5, -0.5, -0.5),
                ),
                (0.0, -0.028, 0.0181),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.gripper_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([5.55112e-17, -0.0611, 0.0181]),
            quat=jnp.array([0.0172091, -0.0172091, 0.706897, 0.706897]),
        ),
    )
    self.gripper = Gripper()

    self.wrist_roll = joints.Hinge(
        self.gripper_mount,
        self.gripper.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-2.7438472969992493, 2.841206309382605),
    )
    self.wrist_roll_actuator = actuators.Position(
        self.wrist_roll,
        forcerange=jnp.array([-3.35, 3.35]),
        ctrlrange=jnp.array([-2.74385, 2.84121]),
    )


@defcomponent
def Gripper(self):
    self.inertia = Inertia(
        mass=0.087,
        pose=Pose(
            pos=jnp.array([0.000213627, 0.000245138, -0.025187]),
            quat=jnp.array([0.0, 1.0, 0.0, 0.0]),
        ),
        diag=jnp.full((3,), 1e-6),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["sts3215_03a_v1"]),
                    (0.707107, -0.707107, 1.66015e-15, 6.45094e-15),
                ),
                (0.0077, 0.0001, -0.0234),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["sts3215_03a_v1"]),
                    (0.707107, -0.707107, 1.66015e-15, 6.45094e-15),
                ),
                (0.0077, 0.0001, -0.0234),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wrist_roll_follower_so101_v1"]),
                    (0.0, 1.0, 0.0, 0.0),
                ),
                (8.32667e-17, -0.000218214, 0.000949706),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wrist_roll_follower_so101_v1"]),
                    (0.0, 1.0, 0.0, 0.0),
                ),
                (8.32667e-17, -0.000218214, 0.000949706),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.moving_jaw_so101_v1_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.0202, 0.0188, -0.0234]),
            quat=jnp.array([0.707107, 0.707107, -1.85362e-08, 1.85362e-08]),
        ),
    )
    self.moving_jaw_so101_v1 = MovingJawSo101V1()

    self.gripper = joints.Hinge(
        self.moving_jaw_so101_v1_mount,
        self.moving_jaw_so101_v1.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-0.17453297762778586, 1.7453291995659765),
    )
    self.gripper_actuator = actuators.Position(
        self.gripper,
        forcerange=jnp.array([-3.35, 3.35]),
        ctrlrange=jnp.array([-0.17453, 1.74533]),
    )


@defcomponent
def MovingJawSo101V1(self):
    self.inertia = Inertia(
        mass=0.012,
        pose=Pose(
            pos=jnp.array([-0.00157495, -0.0300244, 0.0192755]),
            quat=jnp.array([0.0, 1.0, 0.0, 0.0]),
        ),
        diag=jnp.full((3,), 1e-6),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["moving_jaw_so101_v1"]),
                    (1.0, -0.0, 3.00524e-16, -2.00834e-17),
                ),
                (-5.55112e-17, -5.55112e-17, 0.0189),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["moving_jaw_so101_v1"]),
                    (1.0, -0.0, 3.00524e-16, -2.00834e-17),
                ),
                (-5.55112e-17, -5.55112e-17, 0.0189),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())


if __name__ == "__main__":
    view_model(SO101)

"""Alternative palm shapes for :func:`robotl.examples.leap_hand.LeapHand`.

The original LEAP hand uses :func:`RectangularPalm` — fingers along one
rail. This module adds two cylindrical palms:

* :func:`CircularPalm` — fingers Dirichlet-sampled on the front
  semicircle, spaced apart by ``non_overlap`` constraints applied at the
  ``LeapHand`` level. Use this when you want flexible finger placement
  around a disc.
* :func:`TriangularPalm` — fingers fixed at three edge midpoints of an
  inscribed equilateral triangle. Use this when you specifically want a
  triangular finger layout (the underlying body is still a cylinder).

Both expose the same ``base`` / ``finger_mounts`` / ``thumb_mount``
contract the :func:`LeapHand` constructor expects.

CLI usage::

    python -m robotl.examples.parameterized_leap_hand --help
    python -m robotl.examples.parameterized_leap_hand --palm-shape circular --n-fingers 4
    python -m robotl.examples.parameterized_leap_hand --palm-shape triangular --tip hook
"""

from __future__ import annotations

import argparse
import logging
import math
import sys
from collections.abc import Sequence
from enum import StrEnum

import effectful.handlers.jax.numpy as jnp
import effectful.handlers.numpyro as dist

from robotl.examples.based import Based
from robotl.examples.dynamixel import POLYCARBONATE
from robotl.examples.leap_hand import (
    NEG_X,
    BallTip,
    CapsuleTip,
    CubeTip,
    CylinderTip,
    HookTip,
    LeapHand,
    RectangularPalm,
)
from robotl.handlers.mujoco import view_model
from robotl.ops import shapes
from robotl.ops.coords import Rotation
from robotl.ops.shapes import transform
from robotl.ops.syntax import Port, Pose, choose, defcomponent

# Inset past the +X disc face so the proximal motor's hinge plate clears
# the palm body.
_FINGER_INSET_M = 0.025

_X_AXIS = jnp.array([1.0, 0.0, 0.0])


class PalmShape(StrEnum):
    RECTANGULAR = "rectangular"
    CIRCULAR = "circular"
    TRIANGULAR = "triangular"


def _build_disc_palm(
    self,
    *,
    n_fingers: int,
    body_radius: float,
    palm_height: float,
    finger_angles,
    thumb_angle: float,
    stochastic: bool,
) -> None:
    """Shared body + port-layout code for the disc-shaped palms.

    Builds a cylinder of radius ``body_radius`` along palm-frame X with the
    wrist port on the -X face. Each finger/thumb mount sits at an angle on
    the +X face rim with the rectangular-palm finger rotation pre-rotated
    by ``-a`` about the disc axis (so all digits point in the same
    direction with their curl planes swung around the rim). ``stochastic``
    controls whether ``LeapHand`` applies ``non_overlap`` between adjacent
    finger motors.
    """
    self.stochastic_finger_positions = stochastic
    self.shape = transform(
        shapes.cylinder(r=body_radius, h=palm_height),
        Pose(rot=Rotation.from_euler("y", 90, degrees=True)),
    )
    self.material = POLYCARBONATE

    self.base = self.place(
        Port(), Pose(pos=jnp.array([-palm_height / 2, 0.0, 0.0]), rot=NEG_X)
    )

    angles = jnp.concatenate([jnp.asarray(finger_angles), jnp.asarray([thumb_angle])])
    n_digits = n_fingers + 1
    finger_x = palm_height / 2 + _FINGER_INSET_M
    positions = jnp.stack(
        [
            jnp.full(n_digits, finger_x),
            body_radius * jnp.sin(angles),
            body_radius * jnp.cos(angles),
        ],
        axis=-1,
    )
    mounts = [
        self.place(
            Port(),
            Pose(pos=positions[i], rot=Rotation(rv=-angles[i] * _X_AXIS) @ NEG_X),
        )
        for i in range(n_digits)
    ]
    self.finger_mounts, self.thumb_mount = mounts[:-1], mounts[-1]


@defcomponent
def CircularPalm(
    self,
    n_fingers: int = 3,
    palm_radius: float = 0.08,
    palm_height: float = 0.046,
    finger_angles: Sequence[float] | None = None,
):
    """Cylindrical palm; fingers Dirichlet-sampled on the front semicircle.

    Body is a short cylinder along palm-frame X. The wrist sits on the -X
    face. Fingers attach on the +X face at angles sampled by the init
    solver from a Dirichlet over ``n_fingers + 1`` gaps that fill the front
    semicircle ``[-π/2, +π/2]``; ``non_overlap`` between adjacent proximal
    motors (applied at the ``LeapHand`` level) pushes the equilibrium
    toward equiangular spacing within that arc. The thumb is anchored at
    the back of the rim (angle π).

    :param finger_angles: fixes the rim angles instead, in radians, one per
        finger. No sampling and no ``non_overlap`` constraint then; keeping
        the mounts apart is the caller's job.

    Use :func:`TriangularPalm` when you want the fingers fixed at exactly
    three edge midpoints rather than sampled.
    """
    if finger_angles is None:
        spread = math.pi
        gaps = choose(dist.Dirichlet(jnp.ones(n_fingers + 1)))
        angles = -spread / 2 + spread * jnp.cumsum(gaps[:-1])
    else:
        assert len(finger_angles) == n_fingers
        angles = jnp.asarray(finger_angles)
    _build_disc_palm(
        self,
        n_fingers=n_fingers,
        body_radius=palm_radius,
        palm_height=palm_height,
        finger_angles=angles,
        thumb_angle=math.pi,
        stochastic=finger_angles is None,
    )


@defcomponent
def TriangularPalm(self, palm_side: float = 0.25, palm_height: float = 0.046):
    """Cylindrical palm with fingers fixed at three triangle edge midpoints.

    Body radius equals the inscribed triangle's apothem. Unlike
    :func:`CircularPalm` this palm is deterministic — the three vertex
    positions are exact, not sampled, so there's no Dirichlet machinery.
    (Tried a soft ``Maximize`` constraint pulling Dirichlet samples toward
    edge-midpoint angles, but NUTS doesn't converge tightly enough at
    realistic weights to keep the fingers from drifting into the thumb.)

    .. note::
       The body is the inscribed cylinder, not a real triangular prism
       — only the finger layout is triangular for now. Tracked in #442.
    """
    # Edge-midpoint angles: bottom (-π/2), upper-right (π/6), upper-left (5π/6).
    finger_angles = jnp.asarray([-math.pi / 2, math.pi / 6, 5 * math.pi / 6])
    apothem = palm_side / (2 * math.sqrt(3))
    _build_disc_palm(
        self,
        n_fingers=3,
        body_radius=apothem,
        palm_height=palm_height,
        finger_angles=finger_angles,
        thumb_angle=math.pi / 2,  # opposite the bottom finger
        stochastic=False,
    )


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


_TIP_FACTORIES = {
    "capsule": CapsuleTip,
    "ball": BallTip,
    "cube": CubeTip,
    "cylinder": CylinderTip,
    "hook": HookTip,
}


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="View a parameterized LEAP hand.")
    p.add_argument(
        "--palm-shape",
        choices=[s.value for s in PalmShape],
        default=PalmShape.RECTANGULAR.value,
    )
    p.add_argument("--n-fingers", type=int, default=3)
    p.add_argument("--palm-width", type=float, default=0.08)
    p.add_argument("--palm-radius", type=float, default=0.08)
    p.add_argument("--palm-side", type=float, default=0.25)
    p.add_argument("--finger-middle-mm", type=float, default=6.0)
    p.add_argument("--finger-lateral-lower-mm", type=float, default=22.0)
    p.add_argument("--finger-lateral-upper-mm", type=float, default=28.6)
    p.add_argument(
        "--tip",
        choices=list(_TIP_FACTORIES),
        default="capsule",
        help="Fingertip shape.",
    )
    return p


def main() -> None:
    log = logging.getLogger("robotl")
    log.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s %(name)s %(levelname)s: %(message)s", datefmt="%H:%M:%S"
        )
    )
    log.addHandler(handler)

    args = _build_parser().parse_args()
    tip_factory = _TIP_FACTORIES[args.tip]
    palm_constructors = {
        PalmShape.RECTANGULAR: lambda: RectangularPalm(
            n_fingers=args.n_fingers, palm_width=args.palm_width
        ),
        PalmShape.CIRCULAR: lambda: CircularPalm(
            n_fingers=args.n_fingers, palm_radius=args.palm_radius
        ),
        PalmShape.TRIANGULAR: lambda: TriangularPalm(palm_side=args.palm_side),
    }

    def factory():
        palm = palm_constructors[PalmShape(args.palm_shape)]()
        n_finger_tips = len(palm.finger_mounts)
        return Based.make(
            LeapHand(
                palm=palm,
                finger_tips=[tip_factory() for _ in range(n_finger_tips)],
                thumb_tip=tip_factory(),
                middle_length_mm=args.finger_middle_mm,
                lateral_lower_mm=args.finger_lateral_lower_mm,
                lateral_upper_mm=args.finger_lateral_upper_mm,
            )
        )

    view_model(factory, debug_ports=True)


if __name__ == "__main__":
    main()

import effectful.handlers.jax.numpy as jnp

from robotl.examples.based import Based
from robotl.handlers.mujoco import view_model
from robotl.ops import actuators, joints, shapes
from robotl.ops.syntax import Port, Pose, defcomponent


@defcomponent
def Fingertip(self, r):
    self.shape = shapes.sphere(r)
    self.base = self.place(Port())


@defcomponent
def Palm(self, r, rz, n):
    self.shape = shapes.cylinder(r=r, h=rz)
    self.base = self.place(Port())

    def make_finger_port(i):
        ai = i / n * 2 * jnp.pi
        rotation = Pose(rv=ai * jnp.array([0, 0, 1]))
        return self.place(Port(), rotation @ Pose(pos=[0, r, rz / 2]))

    self.finger_ports = list(map(make_finger_port, range(n)))


@defcomponent
def Knuckle(self, l, kt):
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, l]))
    self.shape = shapes.capsule(r=kt, h=l)


@defcomponent
def Finger(self, k, l, kt):
    self.knuckles = [Knuckle(l=l, kt=kt) for _ in range(k)]
    self.joints = [
        joints.Hinge(
            a.tip, b.base, axis=jnp.array([1, 0, 0]), damping=0.1, armature=0.1
        )
        for a, b in zip(self.knuckles[:-1], self.knuckles[1:])
    ]
    self.actuators = [actuators.Position(joint) for joint in self.joints]
    self.fingertip = Fingertip(r=kt * 1.2)

    self.base = self.knuckles[0].base
    self._weld_fingertip = joints.Weld(self.knuckles[-1].tip, self.fingertip.base)
    self.tip = self.fingertip.base


@defcomponent
def ComicHand(
    self,
    n=6,  # number of fingers
    r=7e-2,  # palm radius
    k=4,  # number of knuckles
    l=5e-2,  # length per knuckle
    pt=1e-2,  # palm thickness
    kt=1e-2,  # knuckle thickness
):
    self.palm = Palm(r=r, rz=pt, n=n)
    self.fingers = [Finger(k=k, l=l, kt=kt) for _ in range(n)]
    self._welds = [
        joints.Weld(port, finger.base)
        for port, finger in zip(self.palm.finger_ports, self.fingers)
    ]
    self.base = self.place(Port())
    self._weld_palm = joints.Weld(self.base, self.palm.base)
    self.tip = self.fingers[0].tip  # just pick one finger's tip as the hand tip


ReachHighComicHand = ComicHand
PassThroughComicHand = ComicHand

if __name__ == "__main__":
    view_model(lambda: Based.make(ComicHand()))

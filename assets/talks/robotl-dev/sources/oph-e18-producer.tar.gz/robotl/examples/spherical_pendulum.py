from robotl.examples.based import Based
from robotl.handlers.mujoco import view_model
from robotl.ops import joints, shapes
from robotl.ops.syntax import Port, Pose, defcomponent


@defcomponent
def Support(self, width=0.120, height=0.040):
    self.shape = shapes.centered_cube(width, 0.080, height)
    self.base = self.place(Port())
    self.tip = self.place(Port())


@defcomponent
def Bob(self, r=0.030, rod_len=0.250):
    self.shape = shapes.union(
        shapes.cylinder(r=0.006, h=rod_len),
        shapes.translate(shapes.sphere(r), [0, 0, rod_len]),
    )
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, rod_len]))


@defcomponent
def SphericalPendulum(self):
    """Spherical pendulum with a ball joint at the support."""
    self.support = Support()
    self.bob = Bob()
    self.base = self.place(Port())
    self._weld_support = joints.Weld(self.base, self.support.base)
    # Ball joint allows rotation in all directions
    self.joint = joints.Ball(self.support.tip, self.bob.base)


if __name__ == "__main__":
    view_model(lambda: Based.make(SphericalPendulum()))

from importlib import resources

import effectful.handlers.jax.numpy as jnp
from effectful.ops.semantics import handler
from effectful.ops.syntax import deffn, defop
from effectful.ops.types import NotHandled

from robotl.examples.based import Based
from robotl.handlers.mujoco import view_model
from robotl.ops import actuators, joints, shapes
from robotl.ops.shapes import scale, transform, translate
from robotl.ops.syntax import Inertia, Port, Pose, defcomponent

meshes = {
    k: str(resources.files("robotl").parent.joinpath("assets", "shadow_hand", v))  # type: ignore
    for k, v in dict(
        forearm="forearm_collision.stl",
        fingertip="f_distal_pst_214.stl",
        thumbtip="th_distal_pst_190.stl",
    ).items()
}
MESHSCALE = 0.001 * jnp.ones([3])

bigjoint_defaults = dict(
    damping=0.5,
    armature=0.0002,
)

smalljoint_defaults = dict(
    damping=0.05,
    armature=0.0002,
)


def mjbox(*, rx: float = 1, ry: float = 1, rz: float = 1):
    return translate(shapes.cube(2 * rx, 2 * ry, 2 * rz), [-rx, -ry, -rz])


def mjcapsule(*, r: float = 1, rz: float = 1):
    return translate(shapes.capsule(r=r, h=2 * rz), [0, 0, -rz])


def mjcylinder(*, r: float = 1, rz: float = 1):
    return translate(shapes.cylinder(r=r, h=2 * rz), [0, 0, -rz])


@defop
def finger_proximal_height() -> float:
    return 0.02


def ShadowHandShort():
    with handler({finger_proximal_height: deffn(0.01)}):
        return ShadowHand()


def ShadowHandLong():
    with handler({finger_proximal_height: deffn(0.04)}):
        return ShadowHand()


def ShadowHandFree():
    @defop
    def _free_op(*args, **kwargs):
        raise NotHandled

    with handler({finger_proximal_height: _free_op}):
        return ShadowHand()


@defcomponent
def ShadowHand(self):
    self.forearm = ForeArm()
    self.wrist = Wrist()
    self.hand = RightHand()

    self.base = self.place(Port(), Pose(rv=jnp.pi * jnp.array([0, 0, 1])))
    self.origin = self.place(Port())
    self._weld_forearm = joints.Weld(self.origin, self.forearm.base)
    self.fingertips = self.hand.fingertips
    self.tip = self.fingertips[0]  # index fingertip

    self.wrj2 = joints.Hinge(
        self.forearm.tip,
        self.wrist.base,
        axis=jnp.array([0, 1, 0]),
        range=(-0.523599, 0.174533),
        **bigjoint_defaults,
    )
    self.wrj1 = joints.Hinge(
        self.wrist.tip,
        self.hand.base,
        axis=jnp.array([1, 0, 0]),
        range=(-0.698132, 0.488692),
        **bigjoint_defaults,
    )

    self.wrj2a = actuators.Position(
        self.wrj2,
        forcerange=(-10, 10),
        ctrlrange=(-0.523599, 0.174533),
        kp=10,
    )
    self.wrj1a = actuators.Position(
        self.wrj1, forcerange=(-5, 5), ctrlrange=(-0.698132, 0.488692), kp=8
    )


@defcomponent
def ForeArm(self):
    self.inertia = Inertia(
        pose=Pose(pos=jnp.array([0, 0, 0.09]), quat=jnp.array([1, 0, 0, 0])),
        mass=3,
        diag=jnp.array([0.0138, 0.0138, 0.00744]),
    )
    self.shape = scale(shapes.external_mesh(meshes["forearm"]), MESHSCALE)
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, -0.01, 0.21301]))


@defcomponent
def Wrist(self):
    self.inertia = Inertia(
        pose=Pose(pos=jnp.array([0, 0, 0.029]), quat=jnp.array([1, 1, 1, 1])),
        mass=0.1,
        diag=jnp.array([6.4e-5, 4.38e-5, 3.5e-5]),
    )
    self.shape = shapes.union(
        transform(mjcylinder(r=0.0135, rz=0.015), Pose(quat=[1, 1, 1, -1])),
        transform(
            mjcylinder(r=0.011, rz=0.005),
            Pose(pos=[-0.026, 0, 0.034], quat=[1, 0, 1, 0]),
        ),
        transform(
            mjcylinder(r=0.011, rz=0.005),
            Pose(pos=[0.031, 0, 0.034], quat=[1, 0, 1, 0]),
        ),
    )
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, 0.034]))


@defcomponent
def RightHand(self):
    self.palm = Palm()
    self.ff, self.mf, self.rf, self.lf = [Finger() for _ in range(4)]
    self.th = Thumb()
    self.metacarpal = Metacarpal()  # NOTE lf connects through a metacarpal body

    self.joints, self.actuators = dict(), dict()
    for key, mount, finger, axis in [
        ("ffj4", self.palm.ff_mount, self.ff, [0, -1, 0]),
        ("mfj4", self.palm.mf_mount, self.mf, [0, -1, 0]),
        ("rfj4", self.palm.rf_mount, self.rf, [0, 1, 0]),
        ("lfj4", self.metacarpal.tip, self.lf, [0, 1, 0]),
    ]:
        self.joints[key] = joints.Hinge(
            mount,
            finger.base,
            axis=jnp.array(axis),
            range=(-0.349066, 0.349066),
            **smalljoint_defaults,
        )
        self.actuators[key] = actuators.Position(
            self.joints[key],
            forcerange=(-1, 1),
            ctrlrange=(-0.349066, 0.349066),
        )

    self.joints["lfj5"] = joints.Hinge(
        self.palm.lf_mount,
        self.metacarpal.base,
        axis=jnp.array([0.573576, 0, 0.819152]),
        range=(0, 0.785398),
        **smalljoint_defaults,
    )
    self.actuators["lfj5"] = actuators.Position(
        self.joints["lfj5"], forcerange=(-1, 1), ctrlrange=(0, 0.785398)
    )

    self.joints["thj5"] = joints.Hinge(
        self.palm.th_mount,
        self.th.base,
        axis=jnp.array([0, 0, -1]),
        range=(-1.0472, 1.0472),
        **smalljoint_defaults,
    )
    self.actuators["thj5"] = actuators.Position(
        self.joints["thj5"],
        forcerange=(-3, 3),
        ctrlrange=(-1.0472, 1.0472),
        kp=0.4,
    )

    self.base = self.place(Port())
    self._weld_palm = joints.Weld(self.base, self.palm.base)
    self.fingertips = [
        finger.tip for finger in [self.ff, self.mf, self.rf, self.lf, self.th]
    ]


@defcomponent
def Palm(self):
    self.inertia = Inertia(
        pose=Pose(pos=jnp.array([0, 0, 0.035]), quat=jnp.array([1, 0, 0, 1])),
        mass=0.3,
        diag=jnp.array([0.0005287, 0.0003581, 0.000191]),
    )

    self.shape = shapes.union(
        translate(mjbox(rx=0.031, ry=0.0035, rz=0.049), [0.011, 0.0085, 0.038]),
        translate(mjbox(rx=0.018, ry=0.0085, rz=0.049), [-0.002, -0.0035, 0.038]),
        translate(mjbox(rx=0.013, ry=0.0085, rz=0.005), [0.029, -0.0035, 0.082]),
        transform(
            mjbox(rx=0.013, ry=0.007, rz=0.009),
            Pose(
                pos=[0.0265, -0.001, 0.07],
                quat=[0.987241, 0.0990545, 0.0124467, 0.124052],
            ),
        ),
        transform(
            mjbox(rx=0.011, ry=0.0025, rz=0.015),
            Pose(pos=[0.0125, -0.015, 0.004], quat=[0.971338, 0, 0, -0.237703]),
        ),
        translate(mjbox(rx=0.0105, ry=0.0135, rz=0.012), [0.0315, -0.0085, 0.001]),
        translate(mjbox(rx=0.009, ry=0.012, rz=0.002), [0.011, 0, 0.089]),
        translate(mjbox(rx=0.01, ry=0.012, rz=0.02), [-0.03, 0, 0.009]),
    )

    self.base = self.place(Port())
    self.grasp_site = self.place(Port(), Pose(pos=[0, -0.035, 0.09]))
    self.ff_mount = self.place(Port(), Pose(pos=[0.033, 0, 0.095]))
    self.mf_mount = self.place(Port(), Pose(pos=[0.011, 0, 0.099]))
    self.rf_mount = self.place(Port(), Pose(pos=[-0.011, 0, 0.095]))
    self.lf_mount = self.place(Port(), Pose(pos=[-0.033, 0, 0.02071]))
    self.th_mount = self.place(
        Port(),
        Pose(
            pos=[0.034, -0.00858, 0.029],
            quat=[0.92388, 0, 0.382683, 0],
        ),
    )


@defcomponent
def Metacarpal(self):
    self.inertia = Inertia(
        pose=Pose(pos=jnp.array([0, 0, 0.04]), quat=jnp.array([1, 0, 0, 1])),
        mass=0.03,
        diag=jnp.array([1.638e-05, 1.45e-05, 4.272e-06]),
    )
    self.shape = translate(mjbox(rx=0.011, ry=0.012, rz=0.025), [0.002, 0, 0.033])
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, 0.06579]))


@defcomponent
def Finger(self):
    @defcomponent
    def Knuckle(self):
        self.inertia = Inertia(
            pose=Pose(pos=jnp.array([0, 0, 0]), quat=jnp.array([1, 1, -1, 1])),
            mass=0.08,
            diag=jnp.array([3.2e-07, 2.6e-07, 2.6e-07]),
        )
        self.shape = transform(mjcylinder(r=0.005, rz=0.005), Pose(quat=[1, 0, 1, 0]))
        self.base = self.place(Port())
        self.tip = self.place(Port())  # proximal is at same position as knuckle

    @defcomponent
    def Proximal(self):
        self.inertia = Inertia(
            pose=Pose(pos=jnp.array([0, 0, 0.0225]), quat=jnp.array([1, 0, 0, 1])),
            mass=0.03,
            diag=jnp.array([1e-05, 9.8e-06, 1.8e-06]),
        )
        height = finger_proximal_height()
        z_offset = 0.025
        self.shape = translate(mjcapsule(r=0.009, rz=height), (0, 0, z_offset))
        self.base = self.place(Port())
        self.tip = self.place(Port(), Pose(pos=[0, 0, height + z_offset]))

    @defcomponent
    def Middle(self):
        self.inertia = Inertia(
            pose=Pose(pos=jnp.array([0, 0, 0.0125]), quat=jnp.array([1, 0, 0, 1])),
            mass=0.017,
            diag=jnp.array([2.7e-06, 2.6e-06, 8.7e-07]),
        )
        self.shape = shapes.capsule(r=0.009, h=0.025)
        self.base = self.place(Port())
        self.tip = self.place(Port(), Pose(pos=[0, 0, 0.025]))

    @defcomponent
    def Distal(self):
        self.inertia = Inertia(
            pose=Pose(
                pos=jnp.array([0, 0, 0.0130769]),
                quat=jnp.array([1, 0, 0, 1]),
            ),
            mass=0.013,
            diag=jnp.array([1.28092e-06, 1.12092e-06, 5.3e-07]),
        )
        self.shape = scale(shapes.external_mesh(meshes["fingertip"]), MESHSCALE)
        self.base = self.place(Port())
        self.tip = self.place(Port())

    self.knuckle = Knuckle()
    self.proximal = Proximal()
    self.middle = Middle()
    self.distal = Distal()

    self.base = self.place(Port())
    self._weld_knuckle = joints.Weld(self.base, self.knuckle.base)
    self.tip = self.distal.tip

    self.j3 = joints.Hinge(
        self.knuckle.tip,
        self.proximal.base,
        range=(-0.261799, 1.5708),
        axis=jnp.array([1, 0, 0]),
        **smalljoint_defaults,
    )
    self.j2 = joints.Hinge(
        self.proximal.tip,
        self.middle.base,
        range=(0, 1.5708),
        axis=jnp.array([1, 0, 0]),
        **smalljoint_defaults,
    )
    self.j1 = joints.Hinge(
        self.middle.tip,
        self.distal.base,
        range=(0, 1.5708),
        axis=jnp.array([1, 0, 0]),
        **smalljoint_defaults,
    )

    self.a3 = actuators.Position(
        self.j3, forcerange=(-1, 1), ctrlrange=(-0.261799, 1.5708)
    )
    self.a2 = actuators.Position(
        self.j2, forcerange=(-1, 1), ctrlrange=(0, 3.1415), kp=0.5
    )
    self.a1 = actuators.Position(
        self.j1, forcerange=(-1, 1), ctrlrange=(0, 3.1415), kp=0.5
    )


@defcomponent
def Thumb(self):
    @defcomponent
    def Base(self):
        self.inertia = Inertia(
            pose=Pose(pos=jnp.array([0, 0, 0]), quat=jnp.array([1, 0, 0, 0])),
            mass=0.01,
            diag=jnp.array([1.6e-07, 1.6e-07, 1.6e-07]),
        )
        self.shape = shapes.sphere(0.013)
        self.base = self.place(Port())
        self.tip = self.place(Port())

    @defcomponent
    def Proximal(self):
        self.inertia = Inertia(
            pose=Pose(pos=jnp.array([0, 0, 0.019]), quat=jnp.array([1, 0, 0, 0])),
            mass=0.04,
            diag=jnp.array([1.36e-05, 1.36e-05, 3.13e-06]),
        )
        self.shape = translate(mjcapsule(r=0.0105, rz=0.009), [0, 0, 0.02])
        self.base = self.place(Port())
        self.tip = self.place(Port(), Pose(pos=[0, 0, 0.038]))

    @defcomponent
    def Hub(self):
        self.inertia = Inertia(
            pose=Pose(pos=jnp.array([0, 0, 0]), quat=jnp.array([1, 0, 0, 0])),
            mass=0.005,
            diag=jnp.array([1e-06, 1e-06, 3e-07]),
        )
        self.shape = shapes.sphere(0.011)
        self.base = self.place(Port())
        self.tip = self.place(Port())

    @defcomponent
    def Middle(self):
        self.inertia = Inertia(
            pose=Pose(pos=jnp.array([0, 0, 0.016]), quat=jnp.array([1, 0, 0, 0])),
            mass=0.02,
            diag=jnp.array([5.1e-06, 5.1e-06, 1.21e-06]),
        )
        self.shape = shapes.union(
            translate(mjcapsule(r=0.009, rz=0.009), [0, 0, 0.012]),
            translate(shapes.sphere(0.01), [0, 0, 0.03]),
        )
        self.base = self.place(Port())
        self.tip = self.place(Port(), Pose(pos=[0, 0, 0.032], quat=[1, 0, 0, -1]))

    @defcomponent
    def Distal(self):
        self.inertia = Inertia(
            pose=Pose(pos=jnp.array([0, 0, 0.0145588]), quat=jnp.array([1, 0, 0, 1])),
            mass=0.017,
            diag=jnp.array([2.37794e-06, 2.27794e-06, 1e-06]),
        )
        self.shape = scale(shapes.external_mesh(meshes["thumbtip"]), MESHSCALE)
        self.base = self.place(Port())
        self.tip = self.place(Port())

    self.base_component = Base()
    self.proximal = Proximal()
    self.hub = Hub()
    self.middle = Middle()
    self.distal = Distal()

    self.base = self.place(Port())
    self._weld_base = joints.Weld(self.base, self.base_component.base)
    self.tip = self.distal.tip

    self.thj4 = joints.Hinge(
        self.base_component.tip,
        self.proximal.base,
        range=(0, 1.22173),
        axis=jnp.array([1, 0, 0]),
        **smalljoint_defaults,
    )
    self.thj3 = joints.Hinge(
        self.proximal.tip,
        self.hub.base,
        range=(-0.20944, 0.20944),
        axis=jnp.array([1, 0, 0]),
        **smalljoint_defaults,
    )
    self.thj2 = joints.Hinge(
        self.hub.tip,
        self.middle.base,
        range=(-0.698132, 0.698132),
        axis=jnp.array([0, -1, 0]),
        **smalljoint_defaults,
    )
    self.thj1 = joints.Hinge(
        self.middle.tip,
        self.distal.base,
        range=(-0.261799, 1.5708),
        axis=jnp.array([1, 0, 0]),
        **smalljoint_defaults,
    )

    self.thj4a = actuators.Position(
        self.thj4, forcerange=(-2, 2), ctrlrange=(0, 1.22173)
    )
    self.thj3a = actuators.Position(
        self.thj3, forcerange=(-1, 1), ctrlrange=(-0.20944, 0.20944), kp=0.5
    )
    self.thj2a = actuators.Position(
        self.thj2,
        forcerange=(-1, 1),
        ctrlrange=(-0.698132, 0.698132),
        kp=1.5,
    )
    self.thj1a = actuators.Position(
        self.thj1, forcerange=(-1, 1), ctrlrange=(-0.261799, 1.5708)
    )


if __name__ == "__main__":
    view_model(lambda: Based.make(ShadowHand()))

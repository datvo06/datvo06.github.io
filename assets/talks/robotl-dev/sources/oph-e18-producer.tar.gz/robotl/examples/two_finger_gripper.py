import effectful.handlers.jax.numpy as jnp

from robotl.examples.based import Based
from robotl.examples.simple_cad import Box, Cylinder
from robotl.handlers.mujoco import view_model
from robotl.ops import actuators, joints, sensors, shapes, tendons
from robotl.ops.syntax import Port, Pose, defcomponent


@defcomponent
def Link(self, l, r=0.01):
    self.shape = shapes.capsule(r=r, h=l)
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, l]))


@defcomponent
def TwoFingerGripper(
    self,
    flangeD=0.032,
    flangeT=0.005,
    legW=0.008,
    legH=0.004,
    axis=jnp.array([0, 1, 0]),
):
    """Two-finger gripper with symmetric closing motion.

    Advanced gripper example demonstrating hinge constraints, symmetry constraints,
    and coordinated motion between two finger components with a single control DOF.
    """
    # NOTE the fingers collide with each other
    self.base = self.place(Port())

    self.baseFlange = Cylinder(d=flangeD, h=flangeT)
    self._weld_flange = joints.Weld(self.base, self.baseFlange.base)
    self.leg = Box(width=legW, depth=flangeT, height=legH)
    self._weld_leg = joints.Weld(self.baseFlange.tip, self.leg.faces["Z-"])
    self.fingerL = Link(l=0.1, r=0.005)
    self.fingerR = Link(l=0.1, r=0.005)
    legtip = self.leg.faces["Z+"]
    self.joint1 = joints.Hinge(
        legtip,
        self.fingerL.base,
        axis=axis,
        damping=1.0,
        armature=0.02,
        frictionloss=0.01,
    )
    self.joint2 = joints.Hinge(
        legtip,
        self.fingerR.base,
        axis=axis,
        damping=1.0,
        armature=0.02,
        frictionloss=0.01,
    )

    # maintain symmetry between the two fingers via a fixed tendon constraint
    # (q1 + q2 = 0 with opposite axes)
    self.symmetry = tendons.FixedTendon(
        joints=[self.joint1, self.joint2],
        gear_ratios=[1.0, 1.0],
        stiffness=6.0,
        damping=3.0,
        rest_length=0.0,
    )

    self.sensor = sensors.Position(self.joint1)
    self.actuator = actuators.Position(self.joint1)


if __name__ == "__main__":
    view_model(lambda: Based.make(TwoFingerGripper()))

import effectful.handlers.jax.numpy as jnp

from robotl.examples.hand_with_wrist import HandWithWrist
from robotl.examples.leap_hand import LeapHand
from robotl.handlers.mujoco import view_model
from robotl.handlers.mujoco.process import total_actuation_power
from robotl.internals.utils import Colors
from robotl.ops import joints, shapes
from robotl.ops.coords import Rotation
from robotl.ops.losses import Maximize, Minimize, Nullify
from robotl.ops.syntax import (
    Component,
    Material,
    Origin,
    Port,
    Pose,
    assert_transform,
    defcomponent,
)

X, Y, Z = jnp.eye(3)


@defcomponent
def Cube(self):
    self.shape = shapes.centered_cube(0.05, 0.05, 0.05)
    self.base = self.place(Port())
    self.material = Material(name="cube_faces_mat", friction=0.3)


@defcomponent
def CubeOrientingEnv(
    self, robot: Component, target_rotation=Rotation(rv=jnp.pi / 3 * Z)
):
    """Rotate a cube to a desired orientation."""
    self.shape = shapes.translate(shapes.plane(), [0, 0, -1 / 2])
    self.base = self.place(Port())
    self.robot = robot
    self.cube = Cube()
    robot_to_cube_pose = Pose(pos=[0, 0.1, 0.15])
    assert_transform(self.robot.base, self.cube, robot_to_cube_pose)
    self.cube.color = Colors.olive
    self.reference = Cube()
    self._welds = [
        joints.Weld(Origin.base, self.base),
        joints.Weld(self.base, self.robot.base, Pose(pos=0.3 * Z, rv=jnp.pi / 2 * X)),
        joints.Weld(
            self.base,
            self.reference.base,
            Pose(pos=[0.3, 0, 0.15], rot=target_rotation),
        ),
    ]
    self.losses = dict(
        orientation=Nullify(
            (~self.reference.pose.rotational @ self.cube.pose.rotational).rv
        ),
        offground=Maximize(jnp.log(jnp.maximum(1e-6, self.cube.pos[2]))),
        power=Minimize(total_actuation_power(), weight=1e-2),
    )


if __name__ == "__main__":
    view_model(lambda: CubeOrientingEnv(HandWithWrist(LeapHand())))

"""Geometry and servo choices for LEAP hands.

The catalog uses ROBOTIS specifications at 5 V. The torque cap uses the
stall torque/current ratio; ``kv`` uses the stall torque/no-load speed
ratio as a damping estimate. These are simulation approximations.
The position gain comes from the LEAP simulation configuration:
https://github.com/leap-hand/LEAP_Hand_Sim/blob/master/leapsim/cfg/task/LeapHandRot.yaml.
"""

from __future__ import annotations

import math
from collections.abc import Callable
from dataclasses import replace
from enum import StrEnum
from typing import Annotated, Literal

import jax
import jax.numpy as jnp
import unxt
from pydantic import (
    AfterValidator,
    BaseModel,
    ConfigDict,
    Field,
    model_validator,
    validate_call,
)

from robotl.examples import leap_hand
from robotl.examples.dynamixel import X330Parameters
from robotl.examples.leap_hand_menagerie import (
    Actuation,
    LeapHandConfig,
    ParameterizedLeapHand,
)
from robotl.examples.parameterized_leap_hand import CircularPalm, PalmShape
from robotl.handlers.cad.bbox import bbox_from_shape
from robotl.ops.syntax import Component, LegacyComponent
from robotl.ops.units import (
    Amp,
    Kg,
    Mm,
    MmOrOff,
    NewtonMeter,
    NOrOff,
    RadPerS,
    SignedDeg,
    Volt,
    amp,
    deg,
    kg,
    mm,
    newton,
    newton_meter,
    rpm,
    volt,
    within,
)


class DynamixelModel(StrEnum):
    """ROBOTIS X330 servos: the body the LEAP frames are printed for, in the
    5 V variants the hand's supply and the LEAP Hand API cover."""

    XC330_M288 = "XC330-M288-T"
    XC330_M181 = "XC330-M181-T"
    XL330_M288 = "XL330-M288-T"
    XL330_M077 = "XL330-M077-T"


class DynamixelSpec(BaseModel):
    """One servo's datasheet lines at its rated voltage."""

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    name: DynamixelModel
    datasheet: str
    """The e-manual page every number below is read from."""
    mass: Kg
    rated_voltage: Volt
    stall_torque: NewtonMeter
    stall_current: Amp
    no_load_speed: RadPerS
    api_current_limit: Amp
    """Maximum searched current, from the LEAP API's Goal Current setting:
    https://github.com/leap-hand/LEAP_Hand_API/blob/main/python/main.py.
    """

    @property
    def torque_constant(self) -> unxt.AbstractQuantity:
        """Torque per ampere from the stall point, N m/A."""
        return (self.stall_torque / self.stall_current).to("N m / A")

    @property
    def kv(self) -> unxt.AbstractQuantity:
        """Damping estimate from the stall/free-speed line, N m s/rad."""
        return (self.stall_torque / self.no_load_speed).to("N m s / rad")

    def torque_limit(
        self, current_limit: unxt.AbstractQuantity
    ) -> unxt.AbstractQuantity:
        """Torque the servo delivers under a current limit, at most its stall torque."""
        capped = float((self.torque_constant * current_limit).to("N m").value)
        stall = float(self.stall_torque.to("N m").value)
        return newton_meter(min(capped, stall))


_EMANUAL = "https://emanual.robotis.com/docs/en/dxl/x/"

DYNAMIXELS: dict[DynamixelModel, DynamixelSpec] = {
    spec.name: spec
    for spec in (
        DynamixelSpec(
            name=DynamixelModel.XC330_M288,
            datasheet=_EMANUAL + "xc330-m288/",
            mass=kg(0.023),
            rated_voltage=volt(5.0),
            stall_torque=newton_meter(0.93),
            stall_current=amp(1.80),
            no_load_speed=rpm(81.0),
            api_current_limit=amp(0.550),
        ),
        DynamixelSpec(
            name=DynamixelModel.XC330_M181,
            datasheet=_EMANUAL + "xc330-m181/",
            mass=kg(0.023),
            rated_voltage=volt(5.0),
            stall_torque=newton_meter(0.60),
            stall_current=amp(1.80),
            no_load_speed=rpm(129.0),
            api_current_limit=amp(0.550),
        ),
        DynamixelSpec(
            name=DynamixelModel.XL330_M288,
            datasheet=_EMANUAL + "xl330-m288/",
            mass=kg(0.018),
            rated_voltage=volt(5.0),
            stall_torque=newton_meter(0.52),
            stall_current=amp(1.47),
            no_load_speed=rpm(103.0),
            api_current_limit=amp(0.350),
        ),
        DynamixelSpec(
            name=DynamixelModel.XL330_M077,
            datasheet=_EMANUAL + "xl330-m077/",
            mass=kg(0.018),
            rated_voltage=volt(5.0),
            stall_torque=newton_meter(0.215),
            stall_current=amp(1.47),
            no_load_speed=rpm(383.0),
            api_current_limit=amp(0.350),
        ),
    )
}
"""The X330 family, by model, from the ROBOTIS e-manual."""


class ServoChoice(BaseModel):
    """A catalog servo with searchable current limit and position gain.

    Current is bounded by the LEAP API setting for the selected model.
    ``kp`` is in N m/rad; its default is the LEAP simulation gain.
    ``kv`` is the catalog's damping estimate.
    """

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    name: DynamixelModel = DynamixelModel.XC330_M288
    current_limit: Amp = Field(
        default_factory=lambda data: DYNAMIXELS[data["name"]].api_current_limit
    )
    kp: Annotated[float, Field(gt=0, allow_inf_nan=False)] = 3.0

    @model_validator(mode="after")
    def _current_at_most_the_api_figure(self) -> ServoChoice:
        api = self.spec.api_current_limit
        if float(self.current_limit.to("A").value) > float(api.to("A").value):
            raise ValueError(
                f"the LEAP Hand API writes {api} to the {self.name}; "
                f"{self.current_limit} is more than the hand is known to run it at"
            )
        return self

    @property
    def spec(self) -> DynamixelSpec:
        return DYNAMIXELS[self.name]

    @property
    def torque_limit(self) -> unxt.AbstractQuantity:
        """Torque cap under this current limit, N m."""
        return self.spec.torque_limit(self.current_limit)

    def motor_kwargs(self) -> X330Parameters:
        """Keyword arguments for :func:`robotl.examples.dynamixel.X330`."""
        return dict(
            kp=self.kp,
            kv=float(self.spec.kv.value),
            torque_limit=float(self.torque_limit.value),
            mass=self.spec.mass,
        )

    def actuation(self) -> Actuation:
        """Gains and torque cap for a menagerie digit."""
        return Actuation(
            kp=self.kp,
            kv=float(self.spec.kv.value),
            force=float(self.torque_limit.value),
        )


def api_servos() -> list[ServoChoice]:
    """The catalog at the currents the LEAP Hand API writes, lightest first
    and faster first among equals."""
    lightest_then_fastest = sorted(
        DYNAMIXELS.values(),
        key=lambda s: (
            float(s.mass.to("kg").value),
            -float(s.no_load_speed.to("rad/s").value),
        ),
    )
    return [ServoChoice(name=s.name) for s in lightest_then_fastest]


SERVO_LENGTH = mm(34.0)
"""The X330 body end to end: what one servo adds to a finger's reach."""

FINGER_HARDWARE_MASS = kg(0.015)
"""Plates, spacers and tip of one finger, beyond its four servos."""

GRAVITY = unxt.Quantity(jnp.asarray(9.81), "m / s2")


SPACER_MIN = mm(3.0)
SPACER_MAX = mm(60.0)
SpacerMm = Annotated[
    Mm,
    AfterValidator(
        within(
            SPACER_MIN,
            SPACER_MAX,
            "a printed spacer under 3 mm cannot seat the plate screws, one over "
            "60 mm is twice the stock lateral spacer; the stock hand sits at "
            "6, 22 and 28.6 mm",
        )
    ),
]
"""Search bounds for printed finger spacers, in millimetres."""

MIN_FINGER_PITCH = mm(36.0)
"""Mount pitch clearing the 34.6 mm FPX330-H101 hinge plates."""

RAIL_SPAN = mm(100.0)
"""Usable finger rail on :func:`~robotl.examples.leap_hand.RectangularPalm`:
the 120 mm rail minus 10 mm at each end."""

PalmWidthMm = Annotated[
    Mm,
    AfterValidator(
        within(
            mm(60.0),
            mm(120.0),
            "the thumb mount sits 54 mm from the rail, so a palm under 60 mm "
            "leaves it hanging off the body; 120 mm is 1.5 times stock",
        )
    ),
]

MIN_RIM_CHORD = mm(56.0)
"""Mount chord clearing the proximal joints on a 60 mm rim."""

PalmRadiusMm = Annotated[
    Mm,
    AfterValidator(
        within(
            mm(60.0),
            mm(120.0),
            "under 60 mm the thumb at the back of the rim reaches the fingers "
            "at the ends of the front semicircle; 120 mm is 1.5 times stock",
        )
    ),
]


class TipShape(StrEnum):
    """Fingertips with inertia support in the shape handler."""

    CAPSULE = "capsule"
    BALL = "ball"
    CUBE = "cube"
    HOOK = "hook"

    @property
    def length(self) -> unxt.AbstractQuantity:
        """Axial extension from the mounting face of the stock tip geometry."""
        bbox = bbox_from_shape(_TIPS[self]().shape)
        return mm(float(bbox.hi[2] - bbox.lo[2]) * 1000)


_TIPS: dict[TipShape, Callable[[], LegacyComponent]] = {
    TipShape.CAPSULE: leap_hand.CapsuleTip,
    TipShape.BALL: leap_hand.BallTip,
    TipShape.CUBE: leap_hand.CubeTip,
    TipShape.HOOK: leap_hand.HookTip,
}


def spacer_budget(
    servo: ServoChoice, tip_force: unxt.AbstractQuantity, tip: TipShape
) -> unxt.AbstractQuantity:
    """Total spacer length a finger on this servo can carry at ``tip_force``.

    Inverts :meth:`FingerSpec.load_torque`: the reach the servo's torque cap
    allows, less the three servo bodies and the tip. Negative when the servo
    cannot carry even a spacerless finger.
    """
    mass = 4 * servo.spec.mass + FINGER_HARDWARE_MASS
    per_reach = (mass * GRAVITY / 2 + tip_force).to("N")
    reach = (servo.torque_limit / per_reach).to("mm")
    return reach - 3 * SERVO_LENGTH - tip.length


class FingerSpec(BaseModel):
    """One hardware finger: its three printed spacers, tip and servo.

    Defaults are the stock finger. The four servos of a finger are the same
    model at the same current limit, as on the real hand.
    """

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    middle_length: SpacerMm = mm(6.0)
    lateral_lower: SpacerMm = mm(22.0)
    lateral_upper: SpacerMm = mm(28.6)
    tip: TipShape = TipShape.CAPSULE
    servo: ServoChoice = Field(default_factory=ServoChoice)

    @property
    def reach(self) -> unxt.AbstractQuantity:
        """Proximal hinge to fingertip with the finger straight: three servo
        bodies, the three spacers and the tip."""
        return (
            3 * SERVO_LENGTH
            + self.middle_length
            + self.lateral_lower
            + self.lateral_upper
            + self.tip.length
        ).to("mm")

    def load_torque(self, tip_force: unxt.AbstractQuantity) -> unxt.AbstractQuantity:
        """Torque the proximal servo needs to hold the finger straight out
        against gravity and press ``tip_force`` at its end."""
        mass = 4 * self.servo.spec.mass + FINGER_HARDWARE_MASS
        reach = self.reach
        return (mass * GRAVITY * reach / 2 + tip_force * reach).to("N m")

    def build(self) -> Component:
        return leap_hand.Finger(
            tip=_TIPS[self.tip](),
            middle_length_mm=float(self.middle_length.to("mm").value),
            lateral_lower_mm=float(self.lateral_lower.to("mm").value),
            lateral_upper_mm=float(self.lateral_upper.to("mm").value),
            motor_kwargs=self.servo.motor_kwargs(),
        )


class ThumbSpec(BaseModel):
    """The hardware thumb: tip and servo; its links are not printed spacers."""

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    tip: TipShape = TipShape.CAPSULE
    servo: ServoChoice = Field(default_factory=ServoChoice)

    @property
    def reach(self) -> unxt.AbstractQuantity:
        """Base to tip with the thumb straight: its four servos and the tip."""
        return (4 * SERVO_LENGTH + self.tip.length).to("mm")

    def load_torque(self, tip_force: unxt.AbstractQuantity) -> unxt.AbstractQuantity:
        """As :meth:`FingerSpec.load_torque`."""
        mass = 4 * self.servo.spec.mass + FINGER_HARDWARE_MASS
        reach = self.reach
        return (mass * GRAVITY * reach / 2 + tip_force * reach).to("N m")

    def build(self) -> Component:
        return leap_hand.Thumb(
            tip=_TIPS[self.tip](), motor_kwargs=self.servo.motor_kwargs()
        )


class RectangularPalmSpec(BaseModel):
    """The stock LEAP palm: fingers along one rail, thumb on the side.

    ``finger_offsets`` are the mount positions along the rail from the start
    of its usable span, increasing. The stock hand has three fingers at the
    menagerie's 45.4 mm pitch.
    """

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    shape: Literal[PalmShape.RECTANGULAR] = PalmShape.RECTANGULAR
    width: PalmWidthMm = mm(80.0)
    finger_offsets: tuple[MmOrOff, ...] = (mm(0.0), mm(45.4), mm(90.8))

    @model_validator(mode="after")
    def _mounts_fit_the_rail(self) -> RectangularPalmSpec:
        offsets = [float(o.to("mm").value) for o in self.finger_offsets]
        if not offsets:
            raise ValueError("a palm needs at least one finger mount")
        pitch = float(MIN_FINGER_PITCH.value)
        for a, b in zip(offsets, offsets[1:]):
            if b - a < pitch:
                raise ValueError(
                    f"finger mounts at {a:g} mm and {b:g} mm are closer than "
                    f"the {pitch:g} mm hinge plate; their proximal joints "
                    "would run into each other"
                )
        span = float(RAIL_SPAN.value)
        if offsets[-1] > span:
            raise ValueError(
                f"finger mount at {offsets[-1]:g} mm is past the {span:g} mm rail"
            )
        return self

    @property
    def n_fingers(self) -> int:
        return len(self.finger_offsets)

    def build(self) -> Component:
        return leap_hand.RectangularPalm(
            n_fingers=self.n_fingers,
            palm_width=float(self.width.to("m").value),
            finger_positions=[float(o.to("m").value) for o in self.finger_offsets],
        )


class CircularPalmSpec(BaseModel):
    """A disc palm with the fingers at set rim angles on the front semicircle.

    Angles increase from the -90 degree end of the semicircle to the +90
    degree end; the thumb sits at the back of the rim, 180 degrees.
    The spacing bound clears stock fingers. Other digit geometries need
    the compiler's whole-hand collision check.
    """

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    shape: Literal[PalmShape.CIRCULAR] = PalmShape.CIRCULAR
    radius: PalmRadiusMm = mm(80.0)
    finger_angles: tuple[SignedDeg, ...] = (deg(-60.0), deg(0.0), deg(60.0))

    @model_validator(mode="after")
    def _mounts_fit_the_rim(self) -> CircularPalmSpec:
        angles = [float(a.to("rad").value) for a in self.finger_angles]
        if not angles:
            raise ValueError("a palm needs at least one finger mount")
        # compared in degrees: pi/2 in the angle's float32 radians lands just
        # past the float64 pi/2 the bound would be written with
        degrees = [float(a.to("deg").value) for a in self.finger_angles]
        if degrees[0] < -90.0 or degrees[-1] > 90.0:
            raise ValueError(
                "finger angles must lie on the front semicircle, -90 to 90 "
                "degrees; the thumb takes the back of the rim"
            )
        radius = float(self.radius.to("mm").value)
        min_chord = float(MIN_RIM_CHORD.value)
        for a, b in zip(angles, angles[1:]):
            if b <= a:
                raise ValueError("finger angles must increase along the rim")
            chord = 2 * radius * math.sin((b - a) / 2)
            if chord < min_chord:
                raise ValueError(
                    f"finger mounts {math.degrees(b - a):.1f} degrees apart on "
                    f"a {radius:g} mm rim are {chord:.1f} mm apart, closer "
                    f"than the {min_chord:g} mm their turned hinge plates need"
                )
        return self

    @property
    def n_fingers(self) -> int:
        return len(self.finger_angles)

    def build(self) -> Component:
        return CircularPalm(
            n_fingers=self.n_fingers,
            palm_radius=float(self.radius.to("m").value),
            finger_angles=[float(a.to("rad").value) for a in self.finger_angles],
        )


PalmSpec = Annotated[
    RectangularPalmSpec | CircularPalmSpec, Field(discriminator="shape")
]


class LeapHandDesign(BaseModel):
    """A point in the hardware LEAP hand family.

    The palm fixes how many fingers there are; the fingers and the thumb
    each carry their own spacers, tip and servo. Every servo shares the
    hand's one supply.
    """

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    palm: PalmSpec = Field(default_factory=RectangularPalmSpec)
    fingers: tuple[FingerSpec, ...] = Field(default_factory=lambda: (FingerSpec(),) * 3)
    thumb: ThumbSpec = Field(default_factory=ThumbSpec)

    @model_validator(mode="after")
    def _fingers_match_the_palm(self) -> LeapHandDesign:
        if len(self.fingers) != self.palm.n_fingers:
            raise ValueError(
                f"{len(self.fingers)} fingers for a palm with "
                f"{self.palm.n_fingers} finger mounts"
            )
        return self

    @property
    def servos(self) -> tuple[ServoChoice, ...]:
        return (*(f.servo for f in self.fingers), self.thumb.servo)

    def build(self) -> Component:
        return leap_hand.LeapHand(
            palm=self.palm.build(),
            fingers=[f.build() for f in self.fingers],
            thumb=self.thumb.build(),
        )

    @classmethod
    def leap_v1(cls) -> LeapHandDesign:
        """The LEAP hand as built: XC330-M288-T at 550 mA, stock spacers and tips."""
        return cls()


class MenagerieDesign(BaseModel):
    """A point in the menagerie LEAP hand family.

    Geometry is the :class:`~robotl.examples.leap_hand_menagerie.LeapHandConfig`
    it wraps; the servos set each digit's gains and torque cap. One
    :class:`ServoChoice` serves every finger, or give one per finger.
    """

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    config: LeapHandConfig = Field(default_factory=LeapHandConfig)
    finger_servos: tuple[ServoChoice, ...] | ServoChoice = Field(
        default_factory=ServoChoice
    )
    thumb_servo: ServoChoice = Field(default_factory=ServoChoice)

    @model_validator(mode="after")
    def _servos_match_the_fingers(self) -> MenagerieDesign:
        servos = self.servos_per_finger
        if len(servos) != self.config.n_fingers:
            raise ValueError(
                f"{len(servos)} finger servos for {self.config.n_fingers} fingers"
            )
        return self

    @property
    def servos_per_finger(self) -> tuple[ServoChoice, ...]:
        if isinstance(self.finger_servos, ServoChoice):
            return (self.finger_servos,) * self.config.n_fingers
        return self.finger_servos

    def build(self) -> Component:
        config = replace(
            self.config,
            finger_actuation=[s.actuation() for s in self.servos_per_finger],
            thumb_actuation=self.thumb_servo.actuation(),
        )
        return ParameterizedLeapHand(config=config)

    @classmethod
    def stock(cls) -> MenagerieDesign:
        """The menagerie hand as shipped: stock config, XC330-M288-T at 550 mA."""
        return cls()


@validate_call(config=ConfigDict(arbitrary_types_allowed=True))
def sample_leap_hand(
    key: jax.Array,
    n_fingers: int = 3,
    tip_force: NOrOff = newton(1.0),
) -> LeapHandDesign:
    """Sample one servo model and geometry within its estimated load budget.

    The load model holds a straight finger horizontally and applies
    ``tip_force`` at its end. Every digit uses the selected servo.
    """
    pitch = float(MIN_FINGER_PITCH.value)
    slack = float(RAIL_SPAN.value) - (n_fingers - 1) * pitch
    if n_fingers < 1 or slack < 0:
        raise ValueError("the rail supports one to three fingers")

    k_servo, k_gap, k_spacer, k_total, k_tip, k_width = jax.random.split(key, 6)
    lo, hi = float(SPACER_MIN.value), float(SPACER_MAX.value)
    shapes = list(TipShape)
    tips = jax.random.randint(k_tip, (n_fingers + 1,), 0, len(shapes))
    finger_tips = [shapes[int(tips[i])] for i in range(n_fingers)]
    thumb = ThumbSpec(tip=shapes[int(tips[n_fingers])])
    able = [
        s
        for s in api_servos()
        if all(
            float(spacer_budget(s, tip_force, tip).value) >= 3 * lo
            for tip in finger_tips
        )
        and float(s.torque_limit.value)
        >= float(thumb.model_copy(update=dict(servo=s)).load_torque(tip_force).value)
    ]
    if not able:
        raise ValueError(
            f"no X330 carries a LEAP finger at {tip_force} at the current the "
            "API writes; the space is empty there, ask less of the tip"
        )
    servo = able[int(jax.random.randint(k_servo, (), 0, len(able)))]
    budget = jnp.asarray(
        [float(spacer_budget(servo, tip_force, tip).value) for tip in finger_tips]
    )

    gaps = jax.random.dirichlet(k_gap, jnp.ones(n_fingers + 1)) * slack
    offsets = jnp.cumsum(gaps[:-1]) + jnp.arange(n_fingers) * pitch
    spacers = jax.random.uniform(k_spacer, (n_fingers, 3), minval=lo, maxval=hi)
    # scaling the excess over the minimum down to a drawn total keeps every
    # spacer in its range and the finger inside the servo's budget
    excess = spacers - lo
    total_max = jnp.minimum(budget, spacers.sum(axis=1))
    total = jax.random.uniform(k_total, (n_fingers,), minval=3 * lo, maxval=total_max)
    spacers = lo + excess * ((total - 3 * lo) / excess.sum(axis=1))[:, None]
    width = jax.random.uniform(k_width, (), minval=60.0, maxval=120.0)
    return LeapHandDesign(
        palm=RectangularPalmSpec(
            width=mm(float(width)),
            finger_offsets=tuple(mm(float(o)) for o in offsets),
        ),
        fingers=tuple(
            FingerSpec(
                middle_length=mm(float(spacers[i, 0])),
                lateral_lower=mm(float(spacers[i, 1])),
                lateral_upper=mm(float(spacers[i, 2])),
                tip=finger_tips[i],
                servo=servo,
            )
            for i in range(n_fingers)
        ),
        thumb=thumb.model_copy(update={"servo": servo}),
    )

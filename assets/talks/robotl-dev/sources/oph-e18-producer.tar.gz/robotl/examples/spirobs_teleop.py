"""Teleoperate a SpiRob from the keyboard.

Each press pulls a cable in by a tenth of its full pull, and the letter under
the arrow pays that cable out by the same step. Planar body: the left arrow
and A work the left cable, the right arrow and D the right one. Spatial body:
the up arrow and W work the front cable, the left arrow and A and the right
arrow and D the two off-axis cables. The down arrow slackens every cable.
Controls ramp toward their targets at a fixed rate, three seconds from slack
to the full pull: in the renders a step to the full pull packed the body in
about eight seconds, so this rate keeps the curl following the hand. As in
the renders, gravity is off so the cables are the only thing acting on the
body.

On Linux ``uv run python -m robotl.examples.spirobs_teleop`` runs it; add
``--spatial`` for the three-cable arm. On macOS the passive viewer needs the
``mjpython`` launcher, and a uv venv does not expose the shared libpython the
launcher loads, so link it in once::

    libdir=$(uv run python -c 'import sysconfig; print(sysconfig.get_config_var("LIBDIR"))')
    ln -s "$libdir/libpython3.14.dylib" .venv/
    uv run mjpython -m robotl.examples.spirobs_teleop
"""

import argparse
import time
from pathlib import Path

import glfw
import mujoco
import mujoco.viewer
import numpy as np

from robotl.examples.based import Based
from robotl.examples.spirobs import SpiRob, SpiRob3, settings
from robotl.handlers.mujoco import compile_model

RAMP_TIME = 3.0  # seconds from slack to the full pull
STEP = 0.1  # of the full pull, per press
FRAME_RATE = 60.0


def main(spatial: bool) -> None:
    model, ctx, mj = compile_model(
        lambda: Based.make(SpiRob3.make() if spatial else SpiRob.make()),
        build_path=Path("build/spirobs_teleop"),
    )
    settings().apply(mj)
    mj.opt.gravity[:] = 0

    body = model.c
    if isinstance(body, SpiRob3):
        front, left, right = (ctx.actuators[m.id].idx for m in body.motors)
        keys = {glfw.KEY_UP: (front, STEP), glfw.KEY_W: (front, -STEP)}
    else:
        assert isinstance(body, SpiRob)
        left = ctx.actuators[body.motor_left.id].idx
        right = ctx.actuators[body.motor_right.id].idx
        keys = {}
    keys |= {
        glfw.KEY_LEFT: (left, STEP),
        glfw.KEY_A: (left, -STEP),
        glfw.KEY_RIGHT: (right, STEP),
        glfw.KEY_D: (right, -STEP),
    }

    # The pull is the end of each motor's control range farther from zero.
    lo, hi = mj.actuator_ctrlrange.T
    full = np.where(abs(lo) > abs(hi), lo, hi)
    rate = abs(full) / RAMP_TIME
    pulls = np.zeros(mj.nu)  # targets, as fractions of the full pull

    def press(key: int) -> None:
        # The viewer reports presses and never releases, so a press is a step.
        if key == glfw.KEY_DOWN:
            pulls[:] = 0.0
        elif key in keys:
            motor, step = keys[key]
            pulls[motor] = np.clip(pulls[motor] + step, 0.0, 1.0)

    data = mujoco.MjData(mj)
    dt = mj.opt.timestep
    steps_per_frame = max(1, round(1.0 / (FRAME_RATE * dt)))
    with mujoco.viewer.launch_passive(mj, data, key_callback=press) as viewer:
        while viewer.is_running():
            started = time.perf_counter()
            for _ in range(steps_per_frame):
                gap = pulls * full - data.ctrl
                data.ctrl[:] += np.clip(gap, -rate * dt, rate * dt)
                mujoco.mj_step(mj, data)
            viewer.sync()
            ahead = steps_per_frame * dt - (time.perf_counter() - started)
            if ahead > 0:
                time.sleep(ahead)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spatial", action="store_true", help="the three-cable arm")
    main(parser.parse_args().spatial)

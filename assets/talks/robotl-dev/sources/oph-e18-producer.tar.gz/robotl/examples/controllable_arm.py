import effectful.handlers.jax.numpy as jnp

from robotl.examples.based import Based
from robotl.examples.link import Link
from robotl.handlers.mujoco import view_model
from robotl.ops import actuators, joints, sensors
from robotl.ops.syntax import Port, defcomponent


@defcomponent
def Arm(self, num_elbows: int = 3):
    assert num_elbows >= 1
    elbow_height = 0.1

    self.elbows = [Link(elbow_height, radius=2e-2) for _ in range(num_elbows)]
    self.joints = [
        joints.Hinge(a.tip, b.base, axis=jnp.array([0, 1, 0]))
        for a, b in zip(self.elbows[:-1], self.elbows[1:])
    ]
    self.actuators = [actuators.Position(j) for j in self.joints]
    self.sensors = [sensors.Position(j) for j in self.joints]
    self.base = self.place(Port())
    self._weld_base = joints.Weld(self.base, self.elbows[0].base)
    self.tip = self.elbows[-1].tip


@defcomponent
def ArmHand(self, hand, num_elbows: int = 3):
    self.arm = Arm(num_elbows)
    self.hand = hand
    self.base = self.place(Port())
    self._weld_arm = joints.Weld(self.base, self.arm.base)
    self._weld_hand = joints.Weld(self.arm.tip, self.hand.base)
    self.tip = self.hand.tip


ReachHighArm = Arm
PassThroughArm = Arm


if __name__ == "__main__":
    view_model(lambda: Based.make(Arm()))

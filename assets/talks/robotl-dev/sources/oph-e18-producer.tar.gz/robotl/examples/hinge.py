import effectful.handlers.jax.numpy as jnp

from robotl.examples.based import Based
from robotl.handlers.mujoco import view_model
from robotl.ops import actuators, joints, sensors, shapes
from robotl.ops.syntax import Port, Pose, defcomponent


@defcomponent
def Bottom(self, plateR, plateT, legR, legH):
    self.shape = shapes.union(
        shapes.cylinder(r=plateR, h=plateT),
        shapes.translate(shapes.capsule(r=legR, h=legH), [-0.7 * plateR, 0, plateT]),
        shapes.translate(shapes.capsule(r=legR, h=legH), [+0.7 * plateR, 0, plateT]),
    )
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, plateT + legH]))


@defcomponent
def Top(self, plateR, plateT, legR, legH):
    self.shape = shapes.union(
        shapes.cylinder(r=plateR, h=plateT),
        shapes.translate(shapes.capsule(r=legR, h=legH), [0, 0, plateT]),
    )
    # rotate ports so top is oriented downward
    rv = jnp.pi * jnp.array([1, 0, 0])
    self.base = self.place(Port(), Pose(rv=rv))
    self.tip = self.place(Port(), Pose(pos=[0, 0, plateT + legH], rv=rv))


@defcomponent
def HingeJoint(
    self,
    axis=jnp.array([1, 0, 0]),
    plateD=0.032,
    plateT=0.005,
    pinD=0.008,
    collarT=0.003,
    ctrlrange=(-3.14, 3.14),
    forcerange=(-50.0, 50.0),
    kp=50.0,
    kv=5.0,
    armature=0.1,
    damping=0.0,
    spring=None,
):
    """Hinge joint with position actuator and armature for numerical stability."""
    legD = pinD
    legH = pinD + 2 * collarT

    self.bottom = Bottom(plateD / 2, plateT, legD / 2, legH)
    self.top = Top(plateD / 2, plateT, legD / 2, legH)

    self.base = self.place(Port())
    self._weld_bottom = joints.Weld(self.base, self.bottom.base)
    self.tip = self.top.base

    self.joint = joints.Hinge(
        self.bottom.tip,
        self.top.tip,
        axis=axis,
        armature=armature,
        damping=damping,
        spring=spring,
    )
    self.sensor = sensors.Position(self.joint)
    self.actuator = actuators.Position(
        self.joint, ctrlrange=ctrlrange, forcerange=forcerange, kp=kp, kv=kv
    )


if __name__ == "__main__":
    view_model(lambda: Based.make(HingeJoint()))

from functools import partial

import effectful.handlers.jax.numpy as jnp
import jax
import jax.random as rax

from robotl.examples.triad import Triad
from robotl.handlers.mujoco import view_model
from robotl.internals.utils import Bbox, Colors, deepunstack
from robotl.ops import joints, shapes
from robotl.ops.losses import Nullify
from robotl.ops.syntax import (
    Component,
    Origin,
    Port,
    Pose,
    defcomponent,
)


@defcomponent
def Obstacles(self, poses, r=0.1):
    # all obstacles in one component so mujoco doesn't need to consider pairwise collisions
    self.shape = shapes.union(
        *[shapes.transform(shapes.sphere(r), pose) for pose in poses]
    )
    self.base = self.place(Port())
    self.color = Colors.orange


@defcomponent
def ObstructedReachingEnv(
    self,
    robot: Component,
    rng: jax.Array = rax.key(1),
    obstacle_count: int = 8,
    obstacle_radius: float = 0.1,
):
    bbox = Bbox(jnp.array([-1, -1, obstacle_radius]), jnp.array([1, 1, 1]))
    poses = jax.vmap(partial(Pose.make_random, bbox=bbox))(
        rax.split(rng, 1 + obstacle_count)
    )
    goal_pose, *obstacle_poses = deepunstack(poses)

    self.base = self.place(Port())
    self.obstacles = Obstacles(obstacle_poses, r=obstacle_radius)
    self.robot = robot
    self.robot_triad = Triad(size=obstacle_radius)
    self.goal = Triad(size=obstacle_radius)

    self.welds = [
        joints.Weld(Origin.base, self.base),
        joints.Weld(self.base, self.obstacles.base),
        joints.Weld(self.base, self.robot.base),
        joints.Weld(self.robot.tip, self.robot_triad.base),
        joints.Weld(self.base, self.goal.base, goal_pose),
    ]

    pose_delta = ~self.goal.pose @ self.robot.tip.pose
    self.losses = dict(
        pos=Nullify(pose_delta.pos),
        angle=Nullify(pose_delta.rv, weight=0.1),
        linvel=Nullify(self.robot.tip.linvel, weight=0.1),
        angvel=Nullify(self.robot.tip.angvel, weight=0.1),
    )


if __name__ == "__main__":
    from robotl.examples.panda import PandaArm

    view_model(lambda: ObstructedReachingEnv(PandaArm.make()))

"""Cube-spinning task environment for the LEAP hand.

Defines :func:`CubeSpinningEnv` — a 5 cm cube resting on a robot palm, with
a non-negative task loss that is zero only when the cube spins on-axis at the
target rate while staying cradled in the hand. The loss bundles a spin-rate
term, an off-axis penalty, a saturating "bowl" barrier + centering spring that
keep the cube near a hold pose, a tip-only "no nail" term that rewards keeping
the cube on the pad side of each distal segment, and a contact-gated
kinetic penalty that discourages free-space finger flailing.

Pair the ``robot`` component with :func:`~robotl.examples.leap_hand_menagerie.ParameterizedLeapHand`
for the LEAP hand. Run as a script to open the interactive viewer.
"""

from dataclasses import dataclass

import effectful.handlers.jax.numpy as jnp
import mujoco

from robotl.examples.leap_hand_menagerie import (
    ParameterizedLeapHand,
    apply_hand_physics,
    setup_hand_collisions,
)
from robotl.handlers.mujoco import view_model
from robotl.handlers.mujoco.compiler import MujocoContext
from robotl.internals.utils import Colors, normalized, rv_solve
from robotl.ops import joints, shapes
from robotl.ops.losses import Minimize, Nullify
from robotl.ops.syntax import (
    Component,
    Inertia,
    LegacyComponent,
    Material,
    Origin,
    Port,
    Pose,
    assert_transform,
    defcomponent,
)


@defcomponent
def Cube(self):
    side = 0.05
    mass = 0.108
    self.shape = shapes.centered_cube(side, side, side)
    self.inertia = Inertia(mass=mass, diag=(mass / 6.0) * (side**2) * jnp.ones(3))
    # Textured faces (cube_faces_mat, registered on demand by the compiler) so
    # the spin orientation is visible; friction lives in the same Material.
    self.material = Material(name="cube_faces_mat", friction=0.3)
    self.base = self.place(Port())


@defcomponent
def Axis(self, r=0.005, l=0.15):
    self.inertia = Inertia(mass=1e-5, diag=1e-5 * jnp.ones(3))
    self.shape = shapes.translate(shapes.capsule(r=r, h=l), [0, 0, -l / 2])
    self.base = self.place(Port())
    self.disable_collision = True


@defcomponent
def CubeSpinningEnv(
    self,
    robot: Component,
    spin_axis=normalized(jnp.array([0, 1, 1])),
    cube_offset=jnp.array([0, 0.1, 0.15]),
    target_speed: float = 2.0,
    hold_offset=jnp.array([0.0, 0.0, 0.0]),
):
    """Rotate a cube around ``spin_axis`` at ``target_speed`` rad/s.

    The loss is **non-negative**: every term is zero when the cube is
    spinning perfectly on-axis at ``target_speed`` and positive
    otherwise. This makes per-term contributions directly comparable
    and the total loss a proper cost that descent methods can drive
    toward zero.

    :param hold_offset: 3-vector in world frame added to the cube's
        initial position to form the centering-spring / bowl target.
        Defaults to zero (target = spawn location). Use a positive
        +Y component to pull the cube back toward the palm; negative
        +Y to push it out toward the fingertips.
    """
    self.shape = shapes.plane()

    self.base = self.place(Port())
    self._weld_origin = joints.Weld(Origin.base, self.base)

    self.robot = robot
    self._weld_robot = joints.Weld(
        self.base,
        self.robot.base,
        Pose(pos=[0, 0, 0.3], rv=jnp.pi / 2 * jnp.array([1, 0, 0])),
    )

    self.cube = Cube()
    assert_transform(self.robot.base, self.cube, Pose(pos=cube_offset))

    self.target = Axis()
    self._weld_target = joints.Weld(
        self.base,
        self.target.base,
        Pose(pos=[0, 0.3, 0.45], rv=rv_solve([0, 0, 1], spin_axis)),
    )

    self.target.color = Colors.orange

    # ``cube.angvel`` returns angular velocity in the env's frame (world frame
    # when the env is placed at identity) — the FRAMEANGVEL sensor is
    # world-frame and the cube sits directly under ``self``, so the
    # ``context_pose`` rotation in :meth:`Component.angvel` is identity. No
    # further rotation is needed; a previous fix applied ``cube.axes @`` which
    # actually rotates world→body (``axes`` is the transpose of the rotation
    # matrix per :class:`Rotation`), drifting the measurement as the cube
    # rotated. ``spin_axis`` is the same env/world frame, so the dot product
    # below is consistent.
    # World-frame anchor for the cube's intended hold position. The
    # cube spawns at ``cube_offset`` in the robot's base frame, which
    # the π/2·X rotation + ``[0,0,0.3]`` translation maps into the
    # world frame. ``hold_offset`` shifts the *target* (but not the
    # spawn) — useful for e.g. pulling the cube back toward the palm
    # via a +Y offset while still spawning at the grasp clearance.
    init_cube_pos = jnp.array(
        [
            cube_offset[0],
            -cube_offset[2],
            cube_offset[1] + 0.3,
        ]
    )
    target_cube_pos = init_cube_pos + hold_offset

    # Symmetric ±5 cm safe-zone around the target hold position on all
    # three axes. Measured from the hand anatomy:
    #   * ±5 cm lateral (X, across fingers);
    #   * +5 cm palm-ward / -5 cm fingertip-ward (Y); the palm side was
    #     shrunk from 10 cm because once the cube drifts past ~5 cm
    #     toward the thumb-end of the palm the three fingers can no
    #     longer reach it and the thumb alone can't recover;
    #   * ±5 cm vertical (Z); the down-side catches drops (was a
    #     separate ``nodrop`` term; now folded in here), the up-side
    #     catches the cube escaping above the fingertips.
    # Inside this rectangle the cube is safely cradled; once outside,
    # recovery is difficult and the penalty ramps up quadratically.
    _LEEWAY = 0.05

    d_cube = self.cube.pos - target_cube_pos
    x_excess = jnp.maximum(0.0, jnp.abs(d_cube[0]) - _LEEWAY)
    y_excess = jnp.maximum(0.0, jnp.abs(d_cube[1]) - _LEEWAY)
    z_excess = jnp.maximum(0.0, jnp.abs(d_cube[2]) - _LEEWAY)

    # Bowl barrier: ``excess`` is L∞ distance past the safe box. The
    # ``tanh`` wall saturates at ``WALL_HEIGHT`` far outside (caps the
    # penalty so a dropped cube doesn't explode the loss) and has a
    # strong non-zero slope right at the boundary.
    #
    #   excess =  0 cm -> 0.00 · H = 0     (at edge)
    #   excess =  1 cm -> 0.46 · H ≈ 23    (halfway up wall)
    #   excess =  2 cm -> 0.76 · H ≈ 38    (knee)
    #   excess =  5 cm -> 0.99 · H ≈ 49    (plateau)
    #   excess = 10 cm -> 1.00 · H ≈ 50    (saturated)
    _WALL_HEIGHT = 50.0
    _WALL_KNEE = 0.02  # metres past edge to 0.76·H (= tanh(1))
    excess = jnp.maximum(jnp.maximum(x_excess, y_excess), z_excess)

    # Tip-only "no nail" penalty: for each finger's and the thumb's
    # distal chain segment, define a halfplane through the segment
    # origin perpendicular to the segment-local "pad direction". The
    # cube should sit on the pad side of every plane; any cube position
    # on the nail side contributes a linear penalty proportional to the
    # depth past the plane. Because the pad direction is expressed in
    # segment-local coordinates, each plane rotates adaptively with
    # joint motion.
    #
    # Tip-only (seg3) is the distal segment where the pad geometry is
    # most informative and where halfplane orientation changes most
    # under curl. A previous all-segments variant (4a02180, reverted)
    # added 16 halfplanes and measurably slowed rollouts; keeping only
    # seg3 reduces that to ``n_fingers + 1`` with the same qualitative
    # signal.
    #
    # Pad axes measured from the rest pose (see 4a02180 commit):
    #   finger.seg3 -> local -X        thumb.seg3  -> local -Z
    _fingers = getattr(self.robot, "fingers", [])
    _has_seg3 = (
        bool(_fingers)
        and all(hasattr(f, "seg3") for f in _fingers)
        and hasattr(getattr(self.robot, "thumb", object()), "seg3")
    )
    if _has_seg3:

        def _nail_depth(seg, pad_local):
            cube_local = seg.axes @ (self.cube.pos - seg.pos)
            return jnp.maximum(0.0, -(cube_local @ pad_local))

        _finger_pad = jnp.array([-1.0, 0.0, 0.0])
        _thumb_pad = jnp.array([0.0, 0.0, -1.0])
        no_nail_total = sum(
            _nail_depth(f.seg3, _finger_pad) for f in _fingers
        ) + _nail_depth(self.robot.thumb.seg3, _thumb_pad)
    else:
        no_nail_total = jnp.array(0.0)

    w = self.cube.angvel
    self.losses = dict(
        # Squared deviation from target spin rate along the spin axis.
        # Zero only when ``w @ spin_axis == target_speed``.
        onaxis=Minimize((w @ spin_axis - target_speed) ** 2, weight=1.0),
        # Squared magnitude of the off-axis component of angular velocity.
        offaxis=Nullify(jnp.cross(w, spin_axis), weight=1e-1),
        # Saturating tanh wall outside the safe box (see block above).
        bowl=Minimize(jnp.tanh(excess / _WALL_KNEE), weight=_WALL_HEIGHT),
        # Soft centering spring — always on. Linear in Euclidean
        # distance, so the gradient is constant-magnitude pointing
        # toward the target. Weight 40: 1 cm off = 0.4, 5 cm off = 2.0,
        # 15 cm off (dropped) = 6.0. Still polite inside the box;
        # the bowl carries the heavy barrier at the edge.
        spring=Nullify(self.cube.pos - target_cube_pos, weight=4e1),
        # Tip-only "inside the hand" reward: sum of per-fingertip and
        # thumbtip nail-side depths (see block above). Zero when the
        # cube is on the pad side of every distal segment — i.e. not
        # behind the hand. Adaptive: as joints bend, the pad planes
        # rotate with them.
        no_nail=Minimize(no_nail_total, weight=2e1),
        # Keep cube translation still (squared linvel).
        nolinvel=Nullify(self.cube.linvel, weight=5e-1),
    )

    # Kinetic-energy penalty on the hand to discourage "flailing" fingers:
    # sum of squared fingertip body velocities (linear + angular) over all
    # digits.
    #
    # Contact-aware gating: we only penalise *free-space* flailing, NOT
    # fingers actively manipulating the cube (that motion is the whole point).
    # Each fingertip's penalty is scaled by a smooth gate on its distance to
    # the cube — ~0 inside the contact shell (`r_near`), ramping to 1 in free
    # space (`r_far`). A tip resting on / driving the cube contributes
    # nothing; a tip waving in the air contributes fully. The distance gate
    # (vs. true contact detection) keeps the loss smooth for sampling MPC.
    # ``ft``/``tt`` fingertip *bodies* (with measurable velocity) only exist
    # on the leap-menagerie profile; other hands expose just a ``tip`` Port,
    # so the flail penalty degrades to zero for them.
    tips = [f.ft for f in _fingers if hasattr(f, "ft")]
    if hasattr(getattr(self.robot, "thumb", object()), "tt"):
        tips.append(self.robot.thumb.tt)
    cube_pos = self.cube.pos
    r_near, r_far = 0.05, 0.10  # metres: contact shell → clearly free

    def _flail(t):
        dist = jnp.linalg.norm(t.pos - cube_pos)
        gate = jnp.clip((dist - r_near) / (r_far - r_near), 0.0, 1.0)
        ke = jnp.sum(t.linvel**2) + jnp.sum(t.angvel**2)
        return gate * ke

    flail_ke = sum(_flail(t) for t in tips)
    self.losses["kinetic"] = Minimize(flail_ke, weight=0.01)


# ── Cube MuJoCo contact properties (post-compile) ─────────────
# Like the hand's, the cube's contact response can't be expressed in the
# RoboTL Component model (solref/solimp + torsional/rolling friction), so it
# is patched onto the compiled model. Set explicitly rather than relying on
# compiler defaults (which can drift).
_CUBE_SOLREF = (0.02, 1.0)
_CUBE_SOLIMP = (0.9, 0.95, 0.001)
# Sliding 0.5 — midway between hydrax's 0.3 and IsaacGym's 1.0. At fingertip↔
# cube contact MuJoCo uses max(fingertip, cube), so the effective μ stays 0.7
# there. Other contacts use the larger coefficient of the two geoms; the
# floor's default 1.0 therefore dominates cube↔floor contacts.
_CUBE_FRICTION = (0.5, 0.05, 0.01)
# Free-joint damping; 0.0 = freely tumbling rigid body (its mass + inertia
# govern motion). Bump to ~0.01 only to smooth high-frequency MPC jitter.
_CUBE_DAMPING = 0.0


def patch_cube(mj_model) -> str:
    """Patch the compiled model with the cube's MuJoCo-only contact settings.

    Sets the cube geom's solref/solimp + friction, tags its faces with the
    ``cube_faces_mat`` palette so the spin orientation is visible, and applies
    free-joint damping. Pair with the hand setup
    (:func:`robotl.examples.leap_hand_menagerie.apply_hand_physics`).

    Returns a short summary string.
    """
    cube_mat_id = mujoco.mj_name2id(
        mj_model, mujoco.mjtObj.mjOBJ_MATERIAL, "cube_faces_mat"
    )
    n = 0
    for gi in range(mj_model.ngeom):
        if "cube" not in mj_model.body(int(mj_model.geom_bodyid[gi])).name:
            continue
        mj_model.geom_solref[gi] = _CUBE_SOLREF
        mj_model.geom_solimp[gi, :3] = _CUBE_SOLIMP
        for k in range(3):
            mj_model.geom_friction[gi, k] = _CUBE_FRICTION[k]
        if cube_mat_id >= 0:
            mj_model.geom_matid[gi] = cube_mat_id
            mj_model.geom_rgba[gi] = [1.0, 1.0, 1.0, 1.0]
        n += 1

    # Cube free-joint damping (the cube is the only free body).
    for ji in range(mj_model.njnt):
        if mj_model.jnt_type[ji] == 0:  # mjJNT_FREE
            dof_start = mj_model.jnt_dofadr[ji]
            mj_model.dof_damping[dof_start : dof_start + 6] = _CUBE_DAMPING

    return (
        f"cube: {n} geoms | solref={list(_CUBE_SOLREF)} friction={list(_CUBE_FRICTION)}"
    )


# ── Compiled bundle for MPC (shared type re-exported above) ───────────


# Scene defaults mirror docs/source/cube-spinning.ipynb.
CUBE_SPINNING_DEFAULTS = dict(
    spin_axis=jnp.array([0.0, 0.0, 1.0]),
    cube_offset=jnp.array([0.0, 0.05, 0.15]),
    hold_offset=jnp.array([0.0, 0.06, 0.0]),
    sim_preset="standard",  # one of standard | fast | precise
)


@dataclass
class CompiledEnv:
    """Compiled cube-spinning env + solver config, ready for :meth:`EnvProcess.make`."""

    model: LegacyComponent
    context: MujocoContext
    mj_model: mujoco.MjModel
    sim_config: object


def build_cube_spinning(
    *,
    spin_axis=None,
    cube_offset=None,
    hold_offset=None,
    sim_preset: str = "standard",
    dt: float | None = None,
) -> CompiledEnv:
    """Build + compile the LEAP-hand cube-spinning env for MPC.

    ``sim_preset`` selects the solver/timestep config:

    * ``"standard"`` (default) — :meth:`MujocoSettings.standard`, dt=0.005,
      iter=10/20, pyramidal, impratio=1.0. Mirrors the notebook.
    * ``"fast"`` — :meth:`MujocoSettings.fast`, hydrax-style soft contacts
      (dt=0.01, impratio=0.1). For coarse exploration.
    * ``"precise"`` — :meth:`MujocoSettings.precise`, dt=0.001 reference.

    Compiled with the preset's contact caps so MJX's contact buffers match.
    """
    from robotl.handlers.mujoco import compile_model
    from robotl.handlers.mujoco.config import MujocoSettings

    sim_presets = {
        "standard": lambda: MujocoSettings.standard(),
        "fast": lambda: MujocoSettings.fast(),
        "precise": lambda: MujocoSettings.precise(),
    }
    if sim_preset not in sim_presets:
        raise ValueError(
            f"unknown sim_preset {sim_preset!r}; pick one of {sorted(sim_presets)}"
        )

    if spin_axis is None:
        spin_axis = CUBE_SPINNING_DEFAULTS["spin_axis"]
    if cube_offset is None:
        cube_offset = CUBE_SPINNING_DEFAULTS["cube_offset"]
    if hold_offset is None:
        hold_offset = CUBE_SPINNING_DEFAULTS["hold_offset"]

    factory = lambda: CubeSpinningEnv(
        ParameterizedLeapHand(),
        spin_axis=spin_axis,
        cube_offset=cube_offset,
        hold_offset=hold_offset,
    )

    def compile_with(caps):
        model, ctx, mj = compile_model(
            factory,
            memory=100 * 1024 * 1024,
            settings=caps,
        )
        setup_hand_collisions(mj)
        apply_hand_physics(mj)
        patch_cube(mj)
        return model, ctx, mj

    sim_config = sim_presets[sim_preset]()
    if dt is not None:
        from dataclasses import replace

        sim_config = replace(sim_config, dt=float(dt))
    model, ctx, mj_model = compile_with(sim_config)
    sim_config.apply(mj_model)

    return CompiledEnv(
        model=model,
        context=ctx,
        mj_model=mj_model,
        sim_config=sim_config,
    )


if __name__ == "__main__":
    view_model(lambda: CubeSpinningEnv(ParameterizedLeapHand()))

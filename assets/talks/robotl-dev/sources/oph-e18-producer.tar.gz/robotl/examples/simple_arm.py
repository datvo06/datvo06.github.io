import dataclasses

import effectful.handlers.jax.numpy as jnp

from robotl.examples.based import Based
from robotl.handlers.mujoco import view_model
from robotl.ops import actuators, joints, shapes
from robotl.ops.losses import KeepBelow
from robotl.ops.syntax import Port, Pose, defcomponent


@dataclasses.dataclass(eq=False)
class BoltPattern(Port):
    """Define a bolt pattern component with metric size and diameter.

    :param M: Metric thread size
    :type M: float
    :param D: Bolt diameter
    :type D: float
    :param kwargs: Additional component attributes
    """

    M: float = dataclasses.field(default=4.0)
    D: float = dataclasses.field(default=0.040)


@defcomponent
def Foot(self, radius=0.200, height=0.050):
    self.shape = shapes.cylinder(r=radius, h=height)
    self.base = self.place(Port())
    self.tip = self.place(BoltPattern(M=4, D=0.040), Pose(pos=[0, 0, height]))


@defcomponent
def Link(self, length=0.150, radius=0.025):
    self.shape = shapes.cylinder(r=radius, h=length)
    self.base = self.place(BoltPattern(M=4, D=0.040))
    self.tip = self.place(BoltPattern(M=4, D=0.040), Pose(pos=[0, 0, length]))


@defcomponent
def Gripper(self, width=0.080, height=0.040):
    self.shape = shapes.cube(width, width, height)
    self.base = self.place(BoltPattern(M=4, D=0.040))
    self.tip = self.place(Port(), Pose(pos=[0, 0, height]))


@defcomponent
def SimpleArm(self):
    """Simple robotic arm with base, links, and gripper.

    Basic robotic arm example showing component assembly with bolt patterns,
    position constraints, and runtime structural integrity checks.
    """
    self.foot = Foot()
    self.link1 = Link(length=0.300)
    self.link2 = Link(length=0.200)
    self.link3 = Link(length=0.100)
    self.gripper = Gripper()

    self.base = self.place(Port())
    self._weld_foot = joints.Weld(self.base, self.foot.base)

    self.joints = [
        joints.Hinge(self.foot.tip, self.link1.base, axis=jnp.array([1, 0, 0])),
        joints.Hinge(self.link1.tip, self.link2.base, axis=jnp.array([0, 1, 0])),
        joints.Hinge(self.link2.tip, self.link3.base, axis=jnp.array([1, 0, 0])),
        joints.Hinge(self.link3.tip, self.gripper.base, axis=jnp.array([1, 0, 0])),
    ]
    self.actuators = [actuators.Position(j) for j in self.joints]

    # Runtime constraint for structural integrity
    self.loss = KeepBelow(jnp.linalg.norm((self.foot.pos - self.gripper.pos)[:2]), 0.3)


if __name__ == "__main__":
    view_model(lambda: Based.make(SimpleArm()))

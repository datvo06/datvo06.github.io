from robotl.handlers.mujoco import view_model
from robotl.ops import joints, shapes
from robotl.ops.syntax import Origin, Port, Pose, defcomponent


@defcomponent
def SimpleBox(self, w=1, d=1, h=1):
    self.shape = shapes.translate(shapes.cube(w, d, h), [-w / 2, -d / 2, 0])
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, h]))


@defcomponent
def Tower(self):
    """Stacked block tower example.

    Simple example demonstrating vertical stacking of cubic blocks with decreasing
    sizes connected through mounting ports.
    """
    self.boxes = [(SimpleBox(w=1 / i, d=1 / i, h=1 / i)) for i in range(1, 5)]
    self.base = self.place(Port())
    self._weld_origin = joints.Weld(Origin.base, self.base)
    self._weld_base = joints.Weld(self.base, self.boxes[0].base)
    self._welds = [
        joints.Weld(a.tip, b.base) for a, b in zip(self.boxes[:-1], self.boxes[1:])
    ]


if __name__ == "__main__":
    view_model(Tower)

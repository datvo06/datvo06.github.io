from robotl.ops import joints, shapes
from robotl.ops.losses import Maximize
from robotl.ops.syntax import Component, Origin, Port, defcomponent


@defcomponent
def EndEffector(self):
    self.shape = shapes.sphere(0.01)
    self.base = self.place(Port())


@defcomponent
def ReachHighEnv(self, robot: Component, height: float = 1e2):
    """
    Reach some height.

    - Description & evaluation metrics
        - The robot needs to reach specified height.

    - Success criteria
        - Minimize distance to desired height.
    """
    self.base = self.place(Port())
    self.ee = EndEffector()
    self.robot = robot
    self._weld_origin = joints.Weld(Origin.base, self.base)
    self._weld_robot = joints.Weld(self.base, self.robot.base)
    self._weld_ee = joints.Weld(self.robot.tip, self.ee.base)
    self.loss = Maximize(self.ee.pos[2])

import effectful.handlers.jax.numpy as jnp

from robotl.examples.based import Based
from robotl.handlers.mujoco import view_model
from robotl.ops import joints, shapes
from robotl.ops.syntax import Inertia, Port, Pose, defcomponent


@defcomponent
def Triad(self, size):
    """Three rods indicating X,Y,Z colored R,G,B"""

    @defcomponent
    def Box(self, d):
        self.inertia = Inertia(mass=1e-3, diag=1e-3 * jnp.ones(3))
        self.shape = shapes.cube(*d)
        self.base = self.place(Port())
        self.disable_collision = True

    self.base = self.place(Port())
    self.links = [Box(size * 10 ** (axis - 1)) for axis in jnp.eye(3)]
    self._welds = []
    for i, link in enumerate(self.links):
        self._welds.append(
            joints.Weld(self.base, link.base, Pose(pos=jnp.eye(3)[i] * size / 10))
        )
        link.color = jnp.zeros([4]).at[i].set(1).at[3].set(1)


if __name__ == "__main__":
    view_model(lambda: Based.make(Triad(1)))

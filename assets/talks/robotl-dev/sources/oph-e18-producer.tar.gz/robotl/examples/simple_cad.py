import effectful.handlers.jax.numpy as jnp

from robotl.ops import shapes
from robotl.ops.shapes import cube, intersection, sphere, translate, union
from robotl.ops.syntax import Port, Pose, defcomponent


@defcomponent
def IntersectBoxSphere(self, **kwargs):
    """Boolean intersection operation between cube and sphere geometries.

    Demonstrates CAD boolean operations by intersecting a cube with a translated
    sphere, showcasing solid modeling capabilities for complex geometry creation.
    """
    self.shape = intersection(
        cube(10, 10, 10),
        translate(sphere(10), [5, 0, 0]),
    )


@defcomponent
def UnionBox(self, **kwargs):
    """Union operation with full CAD pipeline to MuJoCo visualization.

    Complete CAD workflow example showing union of two translated cubes,
    CAD handler construction, evaluation, export to MuJoCo XML, and 3D visualization.
    """
    self.shape = union(
        translate(cube(10, 10, 10), [0, 0, 0]),
        translate(cube(20, 20, 20), [5, 5, 5]),
    )


@defcomponent
def Box(self, width: float, depth: float, height: float, **kwargs) -> None:
    """Define a box component with automatic face port generation.

    :param width: Box width (X dimension)
    :type width: float
    :param depth: Box depth (Y dimension)
    :type depth: float
    :param height: Box height (Z dimension)
    :type height: float
    :param kwargs: Additional component attributes
    """
    self.shape = shapes.centered_cube(width, depth, height)

    self.width = width
    self.depth = depth
    self.height = height

    self.center = self.place(Port())
    self.faces = dict()
    radii = jnp.array([width, depth, height]) / 2
    for i, direction in enumerate("XYZ"):
        axis = i == jnp.arange(3)
        for sign in [-1, +1]:
            # TODO set port orientation
            self.faces[f"{direction}{' +-'[sign]}"] = self.place(
                Port(), Pose(pos=sign * axis * radii)
            )


@defcomponent
def Cylinder(self, d: float, h: float, **kwargs) -> None:
    """Define a cylinder component with automatic port generation.

    :param d: Cylinder diameter
    :type d: float
    :param h: Cylinder height
    :type h: float
    :param kwargs: Additional component attributes
    """
    self.d = d
    self.h = h
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, h]))
    self.shape = shapes.cylinder(r=d / 2, h=h)

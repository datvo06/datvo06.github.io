import effectful.handlers.jax.numpy as jnp

from robotl.examples.link import Link
from robotl.handlers.mujoco import view_model
from robotl.internals.utils import Colors
from robotl.ops import actuators, joints, sensors, shapes
from robotl.ops.coords import Angle
from robotl.ops.losses import Equalize
from robotl.ops.syntax import (
    Component,
    Origin,
    Port,
    Pose,
    defcomponent,
    time,
)

tau = 2 * jnp.pi
X = jnp.array([1, 0, 0])
Y = jnp.array([0, 1, 0])
Z = jnp.array([0, 0, 1])


@defcomponent
def Container(self, size=1, entrance_width=0.2, entrance_length=0.2):
    ew, el = entrance_width, entrance_length
    gg = ew / 8  # wall thickness
    y_wall = -size / 2  # outer face of the wall pierced by the entrance

    # Positive and negative parts each overlap into their neighbours so no two
    # faces coincide (coincident CSG faces yield sliver triangles that break
    # convex decomposition): the tube ends halfway into the wall, the bore runs
    # one wall thickness past the mouth and one wall thickness into the cavity.
    shell = shapes.centered_cube(size, size, size)
    tube = shapes.translate(  # y from y_wall - el to y_wall + gg / 2
        shapes.centered_cube(ew + 2 * gg, el + gg / 2, ew + 2 * gg),
        [0, y_wall - el / 2 + gg / 4, 0],
    )
    cavity = shapes.centered_cube(size - 2 * gg, size - 2 * gg, size - 2 * gg)
    bore = shapes.translate(  # y from y_wall - el - gg to y_wall + 2 * gg
        shapes.centered_cube(ew, el + 3 * gg, ew),
        [0, y_wall - el / 2 + gg / 2, 0],
    )
    # The hollow container and its entrance need more convex parts than the
    # decompose default of 8: six shell walls, of which one is pierced by the
    # entrance, plus the four entrance-tube walls.
    self.shape = shapes.decompose(
        shapes.difference(shapes.union(shell, tube), shapes.union(cavity, bore)),
        max_parts=16,
    )
    # set base to center of floor exterior
    self.base = self.place(Port(), Pose(pos=[0, 0, -size / 2 - gg / 2]))
    self.center = self.place(Port())
    self.entrance_center = self.place(Port(), Pose(pos=[0, -size / 2 - 2 * el, 0]))
    self.color = jnp.array(Colors.blue).at[3].set(0.5)


@defcomponent
def Knob(self, size):
    # hexagon out of rectangles
    sidelength = size / jnp.sqrt(3)
    thickness = sidelength
    box = shapes.centered_cube(thickness, sidelength, size)
    self.shape = shapes.union(
        *[
            shapes.transform(box, Pose(rv=angle * Y))
            for angle in jnp.arange(3) / 6 * tau
        ]
    )
    self.base = self.place(Port())
    self.color = Colors.orange


@defcomponent
def KnobTarget(self, size):
    self.base = self.place(Port())
    self.knob = Knob(size)
    self.knob_joint = joints.Hinge(
        self.base,
        self.knob.base,
        axis=Y,
        range=(-tau / 4, 0),
        frictionloss=0.1,
    )
    self.knob_angle = sensors.Position(self.knob_joint)
    # goal: rotate the knob by a quarter turn
    self.loss = Equalize(self.knob_angle.get(), Angle(-tau / 4))


@defcomponent
def BottleneckEnv(
    self,
    robot: Component,
    target: Component,
    container_size=0.5,
    entrance_width=0.2,
    entrance_length=0.2,
):
    self.shape = shapes.plane()
    self.base = self.place(Port())
    self._weld_origin = joints.Weld(Origin.base, self.base)
    self.container = Container(
        size=container_size,
        entrance_width=entrance_width,
        entrance_length=entrance_length,
    )
    self._weld_container = joints.Weld(
        self.base,
        self.container.base,
        Pose(pos=[0, 1 + container_size / 2 + entrance_length, 0]),
    )
    self.robot = robot
    self._weld_robot = joints.Weld(
        self.base,
        self.robot.base,
        Pose(pos=[0, 0, container_size / 2 + entrance_width / 8], rv=-tau / 4 * X),
    )
    self.target = target
    self._weld_target = joints.Weld(self.container.center, self.target.base)
    stage = jnp.floor(time() / 2)
    self.lead_to_entrance = Equalize(
        self.robot.tip.pos,
        self.container.entrance_center.pos,
        weight=1e-1 * (stage == 0),
    )
    self.lead_to_target = Equalize(
        self.robot.tip.pos,
        self.target.pos,
        weight=1e-1 * (stage == 1),
    )
    self.duration = 5


@defcomponent
def Robot(self, entrance_width):
    self.base = self.place(Port())
    self.extender = Extender(length=0.75, radius=0.02)
    self._weld_extender = joints.Weld(self.base, self.extender.base)
    self.manipulator = Manipulator(max_width=entrance_width)
    self._hinge_manipulator = joints.Hinge(
        self.extender.tip, self.manipulator.base, axis=Z
    )
    self.tip = self.manipulator.tip
    self.extender_actuator = actuators.Position(
        self.extender.joint,
        ctrlrange=self.extender.joint.range,
        forcerange=(-200.0, 200.0),
        kp=200.0,
        kv=20.0,
    )
    self.manipulator_actuators = [
        actuators.Position(
            joint,
            ctrlrange=joint.range,
            forcerange=(-20.0, 20.0),
            kp=40.0,
            kv=4.0,
        )
        for joint in self.manipulator.joints
    ]
    self.extender_pos = sensors.Position(self.extender.joint)


@defcomponent
def Extender(self, length, radius):
    self.link1 = Link(length, radius)
    self.link2 = Link(length, radius)
    offset = Pose(pos=[2 * radius + 0.01, 0, 0])
    self.base = self.place(Port())
    self._weld_link1 = joints.Weld(self.base, self.link1.base, ~offset)
    self.joint = joints.Slide(
        self.link1.base,
        self.link2.base,
        axis=Z,
        range=(0, length),
        frictionloss=0.05,
        pose=offset,
    )
    self.tip = self.link2.tip


@defcomponent
def Manipulator(self, max_width):
    @defcomponent
    def Finger(self, width, length, radius=0.01):
        self.shape = shapes.union(
            shapes.capsule(r=radius, h=width),
            shapes.transform(
                shapes.capsule(r=radius, h=length),
                Pose(pos=width * Z, rv=tau / 4 * Y),
            ),
        )
        self.base = self.place(Port())

    d = max_width * 3 / 4
    fl = d * 3 / 8  # <d/2 to leave room for opposing finger
    self.shape = shapes.centered_cube(d, d, d / 4)  # palm
    self.finger_ports = [
        self.place(
            Port(),
            Pose(rv=jnp.atan2(xsign, ysign) * Z)
            @ Pose(pos=[0, d * 3 / 16, d / 8], rv=-tau / 4 * Y),
        )
        for xsign in [-1, +1]
        for ysign in [-1, +1]
    ]
    self.fingers = [Finger(fl, d / 2) for _ in self.finger_ports]
    self.joints = [
        joints.Slide(port, finger.base, axis=Z, range=(0, fl), frictionloss=0.01)
        for port, finger in zip(self.finger_ports, self.fingers)
    ]
    self.base = self.place(Port())
    self.center = self.place(Port())
    self.tip = self.center


def factory(robot_factory=Robot, target_factory=KnobTarget, entrance_width=0.2):
    ew = entrance_width
    return BottleneckEnv(
        robot=robot_factory(ew), target=target_factory(ew), entrance_width=ew
    )


if __name__ == "__main__":
    view_model(factory)

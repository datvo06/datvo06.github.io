from importlib import resources

import effectful.handlers.jax.numpy as jnp

from robotl.handlers.mujoco import view_model
from robotl.ops import actuators, joints, shapes
from robotl.ops.shapes import rotate_quat, scale, translate
from robotl.ops.syntax import Inertia, Port, defcomponent

MESHSCALE = 1 * jnp.ones([3])
from robotl.ops.syntax import Pose

meshes = {
    name: str(
        resources.files("robotl").parent.joinpath(  # type: ignore
            "assets", "open_duck_mini_v2", name + ".stl"
        )
    )
    for name in [
        "antenna",
        "battery_pack_lid",
        "bms",
        "bno055",
        "board",
        "body_back",
        "body_front",
        "body_middle_bottom",
        "body_middle_top",
        "cell",
        "drive_palonier",
        "foot_bottom_pla",
        "foot_bottom_tpu",
        "foot_side",
        "foot_top",
        "head",
        "head_bot_sheet",
        "head_pitch_to_yaw",
        "head_roll_mount",
        "head_yaw_to_roll",
        "holder",
        "left_antenna_holder",
        "left_cache",
        "left_knee_to_ankle_left_sheet",
        "left_knee_to_ankle_right_sheet",
        "left_roll_to_pitch",
        "leg_spacer",
        "neck_left_sheet",
        "neck_right_sheet",
        "passive_palonier",
        "power_switch",
        "raspberrypizerow",
        "right_antenna_holder",
        "right_cache",
        "right_roll_to_pitch",
        "roll_bearing",
        "roll_motor_bottom",
        "roll_motor_top",
        "sg90",
        "trunk_bottom",
        "trunk_top",
        "usb_c_charger",
        "wj-wk00-0122topcabinetcase_95",
        "wj-wk00-0123middlecase_56",
        "wj-wk00-0124bottomcase_45",
    ]
}


@defcomponent
def OpenDuckMini(self):
    self.base = self.place(Port())
    self.trunk = Trunk()


@defcomponent
def Trunk(self):
    self.inertia = Inertia(
        mass=0.698526,
        pose=Pose(
            pos=jnp.array([-0.0483259, -9.97823e-05, 0.0384971]),
            quat=jnp.array([0.505499, 0.490695, 0.496207, 0.507413]),
        ),
        diag=jnp.array([0.00344489, 0.00292719, 0.00167606]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                shapes.external_mesh(meshes["body_front"]), (-0.019, 0.0, 0.0648909)
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["usb_c_charger"]), (0.5, 0.5, -0.5, 0.5)
                ),
                (-0.1263, -0.0257, 0.0576079),
            ),
            translate(
                shapes.external_mesh(meshes["body_back"]), (-0.019, 0.0, 0.0648909)
            ),
            translate(
                shapes.external_mesh(meshes["body_middle_bottom"]),
                (-0.019, 0.0, 0.0648909),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["power_switch"]),
                    (0.901303, 0.0, -0.433189, 0.0),
                ),
                (-0.12034, 0.0, 0.0899126),
            ),
            translate(
                rotate_quat(shapes.external_mesh(meshes["bms"]), (0.5, 0.5, 0.5, -0.5)),
                (-0.0752028, -0.0249, 0.0294899),
            ),
            translate(
                shapes.external_mesh(meshes["battery_pack_lid"]),
                (-0.019, 0.0, 0.0648909),
            ),
            translate(
                shapes.external_mesh(meshes["body_middle_top"]),
                (-0.019, 0.0, 0.0648909),
            ),
            translate(
                shapes.external_mesh(meshes["bno055"]), (-0.08711, 0.0, 0.0417909)
            ),
            translate(
                shapes.external_mesh(meshes["roll_bearing"]), (-0.019, 0.0, 0.0648909)
            ),
            translate(
                shapes.external_mesh(meshes["trunk_bottom"]), (-0.019, 0.0, 0.0648909)
            ),
            translate(
                shapes.external_mesh(meshes["trunk_top"]), (-0.019, 0.0, 0.0648909)
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["board"]), (0.0, 0.0, 0.0, -1.0)
                ),
                (-0.06349, 0.0165, 0.0603909),
            ),
            translate(
                shapes.external_mesh(meshes["roll_bearing"]), (-0.019, -0.07, 0.0648909)
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["cell"]),
                    (0.0, -0.457466, -0.889227, 0.0),
                ),
                (-0.129625, -0.0105, 0.0650134),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["holder"]),
                    (0.707107, 0.0, 0.707107, 0.0),
                ),
                (-0.139625, -0.0635245, 0.031455),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["cell"]), (0.930459, 0.0, 0.0, 0.366396)
                ),
                (-0.129625, 0.0105, 1.34322e-05),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.707107, 0.0, 0.707107, 0.0),
                ),
                (0.001, 0.0097, 0.0645009),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.707107, 0.0, 0.707107, 0.0),
                ),
                (0.001, 0.0097, 0.0645009),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.707107, 0.0, 0.707107, 0.0),
                ),
                (0.001, 0.0097, 0.0645009),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.707107, 0.0, 0.707107, 0.0),
                ),
                (0.001, 0.0097, 0.0645009),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.707107, 0.0, 0.707107, 0.0),
                ),
                (0.001, 0.0126, 0.0645009),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.0, 0.0, -0.707107, 0.707107),
                ),
                (-0.0445, -0.035, 0.0553909),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.0, 0.0, -0.707107, 0.707107),
                ),
                (-0.0445, -0.035, 0.0553909),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.0, 0.0, -0.707107, 0.707107),
                ),
                (-0.0445, -0.035, 0.0553909),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.0, 0.0, -0.707107, 0.707107),
                ),
                (-0.0445, -0.035, 0.0553909),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.0, 0.0, -0.707107, 0.707107),
                ),
                (-0.0445, -0.035, 0.0524909),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.0, 0.0, 0.707107, -0.707107),
                ),
                (-0.0445, 0.035, 0.0553909),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.0, 0.0, 0.707107, -0.707107),
                ),
                (-0.0445, 0.035, 0.0553909),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.0, 0.0, 0.707107, -0.707107),
                ),
                (-0.0445, 0.035, 0.0553909),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.0, 0.0, 0.707107, -0.707107),
                ),
                (-0.0445, 0.035, 0.0553909),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.0, 0.0, 0.707107, -0.707107),
                ),
                (-0.0445, 0.035, 0.0524909),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.trunk_tip = self.place(Port(), Pose(pos=jnp.array([-0.024, 0.0, 0.0881909])))
    self.left_inner_hip_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([-0.019, 0.035, 0.0459409]),
            quat=jnp.array([1.0, 0.0, 0.0, 0.0]),
        ),
    )
    self.neck_base_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.001, 0.01915, 0.0900009]),
            quat=jnp.array([0.707107, 0.707107, 0.0, 0.0]),
        ),
    )
    self.right_inner_hip_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([-0.019, -0.035, 0.0459409]),
            quat=jnp.array([1.0, 0.0, 0.0, 0.0]),
        ),
    )
    self.left_inner_hip = LeftInnerHip()
    self.neck_base = NeckBase()
    self.right_inner_hip = RightInnerHip()

    self.left_hip_yaw = joints.Hinge(
        self.left_inner_hip_mount,
        self.left_inner_hip.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-0.523599, 0.523599),
    )
    self.left_hip_yaw_actuator = actuators.Position(self.left_hip_yaw)

    self.neck_pitch = joints.Hinge(
        self.neck_base_mount,
        self.neck_base.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-0.349066, 1.13446),
    )
    self.neck_pitch_actuator = actuators.Position(self.neck_pitch)

    self.right_hip_yaw = joints.Hinge(
        self.right_inner_hip_mount,
        self.right_inner_hip.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-0.523599, 0.523599),
    )
    self.right_hip_yaw_actuator = actuators.Position(self.right_hip_yaw)


@defcomponent
def LeftInnerHip(self):
    self.inertia = Inertia(
        mass=0.06648,
        pose=Pose(
            pos=jnp.array([0.000795081, -5.46541e-06, -0.03306]),
            quat=jnp.array([0.70723, 0.0130259, 0.0134112, 0.706737]),
        ),
        diag=jnp.array([2.81818e-05, 2.44554e-05, 1.42544e-05]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["roll_motor_bottom"]),
                    (1.0, 0.0, 0.0, 0.0),
                ),
                (0.0, -0.035, 0.01905),
            ),
            translate(
                shapes.external_mesh(meshes["roll_motor_top"]), (0.0, -0.035, 0.01905)
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.5, -0.5, -0.5, -0.5),
                ),
                (0.0096, 0.0, -0.020515),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.5, -0.5, -0.5, -0.5),
                ),
                (0.0096, 0.0, -0.020515),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.5, -0.5, -0.5, -0.5),
                ),
                (0.0096, 0.0, -0.020515),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.5, -0.5, -0.5, -0.5),
                ),
                (0.0096, 0.0, -0.020515),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.5, -0.5, -0.5, -0.5),
                ),
                (0.0125, 0.0, -0.020515),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.left_outer_hip_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.01905, 0.0, -0.046015]),
            quat=jnp.array([0.5, -0.5, -0.5, 0.5]),
        ),
    )
    self.left_outer_hip = LeftOuterHip()

    self.left_hip_roll = joints.Hinge(
        self.left_outer_hip_mount,
        self.left_outer_hip.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-0.436332, 0.436332),
    )
    self.left_hip_roll_actuator = actuators.Position(self.left_hip_roll)


@defcomponent
def LeftOuterHip(self):
    self.inertia = Inertia(
        mass=0.07516,
        pose=Pose(
            pos=jnp.array([0.0508042, -0.00041105, 0.0204704]),
            quat=jnp.array([0.549997, 0.448819, 0.449902, 0.541898]),
        ),
        diag=jnp.array([4.13874e-05, 2.82416e-05, 2.5117e-05]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["left_roll_to_pitch"]),
                    (0.5, 0.5, 0.5, -0.5),
                ),
                (-0.035, -0.065, 0.01905),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.5, 0.5, 0.5, -0.5),
                ),
                (0.0647, 0.0, 0.00961),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.5, 0.5, 0.5, -0.5),
                ),
                (0.0647, 0.0, 0.00961),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.5, 0.5, 0.5, -0.5),
                ),
                (0.0647, 0.0, 0.00961),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.5, 0.5, 0.5, -0.5),
                ),
                (0.0647, 0.0, 0.00961),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.5, 0.5, 0.5, -0.5),
                ),
                (0.0676, 0.0, 0.00961),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.left_upper_leg_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.07415, 0.0, 0.03511]),
            quat=jnp.array([0.0, 0.707107, 0.0, -0.707107]),
        ),
    )
    self.left_upper_leg = LeftUpperLeg()

    self.left_hip_pitch = joints.Hinge(
        self.left_upper_leg_mount,
        self.left_upper_leg.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-1.22173, 0.523599),
    )
    self.left_hip_pitch_actuator = actuators.Position(self.left_hip_pitch)


@defcomponent
def LeftUpperLeg(self):
    self.inertia = Inertia(
        mass=0.12407,
        pose=Pose(
            pos=jnp.array([0.00253369, -0.0390636, 0.0102776]),
            quat=jnp.array([0.576793, 0.413738, -0.51125, 0.484515]),
        ),
        diag=jnp.array([0.000228502, 0.000216625, 7.02746e-05]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["left_cache"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.065, 0.10915),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["leg_spacer"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.14365, 0.10925),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["left_knee_to_ankle_right_sheet"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.14365, 0.10915),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["left_knee_to_ankle_left_sheet"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.14365, 0.10915),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00665),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.left_lower_leg_mount = self.place(
        Port(), Pose(pos=jnp.array([0.0, -0.07865, 0.0001]))
    )
    self.left_lower_leg = LeftLowerLeg()

    self.left_knee = joints.Hinge(
        self.left_lower_leg_mount,
        self.left_lower_leg.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-1.5708, 1.5708),
    )
    self.left_knee_actuator = actuators.Position(self.left_knee)


@defcomponent
def LeftLowerLeg(self):
    self.inertia = Inertia(
        mass=0.07259,
        pose=Pose(
            pos=jnp.array([5.01859e-06, -0.0577465, 0.0181136]),
            quat=jnp.array([0.708422, 0.705789, 1.07934e-05, 0.00022447]),
        ),
        diag=jnp.array([4.99575e-05, 4.23935e-05, 1.8727e-05]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["leg_spacer"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.14365, 0.10925),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["left_knee_to_ankle_right_sheet"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.14365, 0.10915),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["left_knee_to_ankle_left_sheet"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.14365, 0.10915),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00665),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.left_foot_mount = self.place(
        Port(), Pose(pos=jnp.array([0.0, -0.07865, 0.0001]))
    )
    self.left_foot = LeftFoot()

    self.left_ankle = joints.Hinge(
        self.left_foot_mount,
        self.left_foot.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-1.5708, 1.5708),
    )
    self.left_ankle_actuator = actuators.Position(self.left_ankle)


@defcomponent
def LeftFoot(self):
    self.inertia = Inertia(
        mass=0.07524,
        pose=Pose(
            pos=jnp.array([0.0110718, -0.0246608, 0.0190626]),
            quat=jnp.array([0.506106, 0.51004, 0.489653, 0.49392]),
        ),
        diag=jnp.array([6.74949e-05, 6.06095e-05, 1.86965e-05]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["foot_side"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.2223, 0.10905),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["foot_bottom_tpu"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01656, 0.2228, 0.10955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["foot_bottom_pla"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01656, 0.2228, 0.10955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["foot_top"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.2223, 0.10905),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.left_foot_tip = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.0005, -0.036225, 0.01955]),
            quat=jnp.array([0.707107, -0.707107, 0.0, 0.0]),
        ),
    )


@defcomponent
def NeckBase(self):
    self.inertia = Inertia(
        mass=0.06618,
        pose=Pose(
            pos=jnp.array([-5.63137e-06, 0.0492968, 0.0181786]),
            quat=jnp.array([0.70651, 0.707703, 0.000283172, 6.23387e-05]),
        ),
        diag=jnp.array([3.49456e-05, 2.80043e-05, 1.70231e-05]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["neck_left_sheet"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (-0.02, -0.02511, 0.01905),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["neck_right_sheet"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (-0.02, -0.02511, 0.01905),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.5, -0.5, 0.5, -0.5),
                ),
                (0.0, 0.0405, 0.00945),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.5, -0.5, 0.5, -0.5),
                ),
                (0.0, 0.0405, 0.00945),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.5, -0.5, 0.5, -0.5),
                ),
                (0.0, 0.0405, 0.00945),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.5, -0.5, 0.5, -0.5),
                ),
                (0.0, 0.0405, 0.00945),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.5, -0.5, 0.5, -0.5),
                ),
                (0.0, 0.0405, 0.00655),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.neck_lower_mount = self.place(
        Port(),
        Pose(pos=jnp.array([0.0, 0.066, 0.0]), quat=jnp.array([1.0, 0.0, 0.0, 0.0])),
    )
    self.neck_lower = NeckLower()

    self.head_pitch = joints.Hinge(
        self.neck_lower_mount,
        self.neck_lower.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-0.785398, 0.785398),
    )
    self.head_pitch_actuator = actuators.Position(self.head_pitch)


@defcomponent
def NeckLower(self):
    self.inertia = Inertia(
        mass=0.0169378,
        pose=Pose(
            pos=jnp.array([-0.00766247, 0.026015, 0.0186681]),
            quat=jnp.array([0.692632, 0.709794, 0.0901532, 0.091239]),
        ),
        diag=jnp.array([9.7861e-06, 8.03124e-06, 4.28979e-06]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["head_pitch_to_yaw"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (-0.02, -0.09111, 0.01905),
            )
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.neck_upper_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.0, 0.057, 0.01905]),
            quat=jnp.array([0.707107, -0.707107, 0.0, 0.0]),
        ),
    )
    self.neck_upper = NeckUpper()

    self.head_yaw = joints.Hinge(
        self.neck_upper_mount,
        self.neck_upper.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-2.79253, 2.79253),
    )
    self.head_yaw_actuator = actuators.Position(self.head_yaw)


@defcomponent
def NeckUpper(self):
    self.inertia = Inertia(
        mass=0.0918099,
        pose=Pose(
            pos=jnp.array([0.00412907, 3.95745e-06, -0.0222828]),
            quat=jnp.array([-0.00110425, 0.66693, -0.00105488, 0.745118]),
        ),
        diag=jnp.array([7.08927e-05, 6.94935e-05, 3.06805e-05]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["head_yaw_to_roll"]),
                    (1.0, 0.0, 0.0, 0.0),
                ),
                (-0.02, 0.0, -0.14821),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.0255, 0.0, -0.00945),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.0255, 0.0, -0.00945),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.0255, 0.0, -0.00945),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.0255, 0.0, -0.00945),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.0255, 0.0, -0.00655),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.head_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.04095, 0.0, -0.01915]),
            quat=jnp.array([0.707107, 0.0, -0.707107, 0.0]),
        ),
    )
    self.head = Head()

    self.head_roll = joints.Hinge(
        self.head_mount,
        self.head.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-0.523599, 0.523599),
    )
    self.head_roll_actuator = actuators.Position(self.head_roll)


@defcomponent
def Head(self):
    self.inertia = Inertia(
        mass=0.352583,
        pose=Pose(
            pos=jnp.array([0.00761779, 0.00018098, 0.0242575]),
            quat=jnp.array([0.999221, -0.0025776, -0.0393431, -0.00138049]),
        ),
        diag=jnp.array([0.00207104, 0.00144128, 0.000909578]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["head_bot_sheet"]),
                    (0.707107, 0.0, 0.707107, 0.0),
                ),
                (-0.12906, 0.0, 0.06095),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["head"]), (0.707107, 0.0, 0.707107, 0.0)
                ),
                (-0.12906, 0.0, 0.06095),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["head_roll_mount"]),
                    (0.707107, 0.0, 0.707107, 0.0),
                ),
                (-0.12906, 0.0, 0.06095),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["raspberrypizerow"]),
                    (0.5, 0.5, -0.5, 0.5),
                ),
                (0.03205, 0.048, 0.00595),
            ),
            translate(
                shapes.external_mesh(meshes["roll_bearing"]), (0.0, -0.035, 0.167325)
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["sg90"]),
                    (0.488321, -0.47889, -0.372991, -0.626964),
                ),
                (-0.00624594, 0.0331408, 0.102812),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["sg90"]),
                    (0.488321, 0.47889, -0.372991, 0.626964),
                ),
                (-0.00624594, -0.0331408, 0.102812),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["board"]), (0.5, -0.5, 0.5, -0.5)
                ),
                (0.03205, -0.034, -0.00555001),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.0255, 0.0, -0.00945),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.0255, 0.0, -0.00945),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.0255, 0.0, -0.00945),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.0255, 0.0, -0.00945),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.0255, 0.0, -0.00655),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.head_tip = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.04245, 0.0, 0.03595]),
            quat=jnp.array([0.707107, 0.0, 0.707107, 0.0]),
        ),
    )
    self.left_antenna_holder_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.000704069, 0.0606628, 0.116435]),
            quat=jnp.array([-0.372991, -0.626964, -0.488321, 0.47889]),
        ),
    )
    self.right_antenna_holder_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.000704069, -0.0606628, 0.116435]),
            quat=jnp.array([-0.372991, 0.626964, -0.488321, -0.47889]),
        ),
    )
    self.left_antenna_holder = LeftAntennaHolder()
    self.right_antenna_holder = RightAntennaHolder()

    self.left_antenna = joints.Hinge(
        self.left_antenna_holder_mount,
        self.left_antenna_holder.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-1.5708, 1.5708),
    )
    self.left_antenna_actuator = actuators.Position(self.left_antenna)

    self.right_antenna = joints.Hinge(
        self.right_antenna_holder_mount,
        self.right_antenna_holder.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-1.5708, 1.5708),
    )
    self.right_antenna_actuator = actuators.Position(self.right_antenna)


@defcomponent
def LeftAntennaHolder(self):
    self.inertia = Inertia(
        mass=0.00421629,
        pose=Pose(
            pos=jnp.array([-0.00493985, 0.00813032, -0.00233374]),
            quat=jnp.array([0.51481, 0.48387, -0.510153, 0.490495]),
        ),
        diag=jnp.array([3.80836e-06, 3.59678e-06, 2.45273e-07]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["antenna"]),
                    (0.781957, -0.60904, -0.104704, -0.0815507),
                ),
                (0.0791392, -0.110974, -0.079315),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["left_antenna_holder"]),
                    (0.60904, -0.781957, -0.0815507, -0.104704),
                ),
                (0.0296981, -0.110962, 0.101994),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())


@defcomponent
def RightAntennaHolder(self):
    self.inertia = Inertia(
        mass=0.00421629,
        pose=Pose(
            pos=jnp.array([-0.00493986, -0.00826213, -0.00233374]),
            quat=jnp.array([0.483867, 0.514746, -0.490555, 0.510162]),
        ),
        diag=jnp.array([3.86998e-06, 3.6585e-06, 2.45146e-07]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["right_antenna_holder"]),
                    (0.60904, 0.781957, -0.0815507, 0.104704),
                ),
                (0.0296981, 0.110962, 0.101994),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["antenna"]),
                    (0.60904, 0.781957, -0.0815507, 0.104704),
                ),
                (0.0296981, 0.109951, 0.101994),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())


@defcomponent
def RightInnerHip(self):
    self.inertia = Inertia(
        mass=0.06648,
        pose=Pose(
            pos=jnp.array([0.000795081, -5.46541e-06, -0.03306]),
            quat=jnp.array([0.70723, 0.0130259, 0.0134112, 0.706737]),
        ),
        diag=jnp.array([2.81818e-05, 2.44554e-05, 1.42544e-05]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                shapes.external_mesh(meshes["roll_motor_bottom"]),
                (0.0, -0.035, 0.01905),
            ),
            translate(
                shapes.external_mesh(meshes["roll_motor_top"]), (0.0, -0.035, 0.01905)
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.5, -0.5, -0.5, -0.5),
                ),
                (0.0096, 0.0, -0.020515),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.5, -0.5, -0.5, -0.5),
                ),
                (0.0096, 0.0, -0.020515),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.5, -0.5, -0.5, -0.5),
                ),
                (0.0096, 0.0, -0.020515),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.5, -0.5, -0.5, -0.5),
                ),
                (0.0096, 0.0, -0.020515),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.5, -0.5, -0.5, -0.5),
                ),
                (0.0125, 0.0, -0.020515),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.right_outer_hip_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.01905, 0.0, -0.046015]),
            quat=jnp.array([0.5, -0.5, -0.5, 0.5]),
        ),
    )
    self.right_outer_hip = RightOuterHip()

    self.right_hip_roll = joints.Hinge(
        self.right_outer_hip_mount,
        self.right_outer_hip.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-0.436332, 0.436332),
    )
    self.right_hip_roll_actuator = actuators.Position(self.right_hip_roll)


@defcomponent
def RightOuterHip(self):
    self.inertia = Inertia(
        mass=0.07516,
        pose=Pose(
            pos=jnp.array([-0.0508042, -0.000420742, 0.0204704]),
            quat=jnp.array([0.449467, 0.542039, 0.549858, 0.449254]),
        ),
        diag=jnp.array([4.13872e-05, 2.82413e-05, 2.51163e-05]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["right_roll_to_pitch"]),
                    (0.5, 0.5, 0.5, -0.5),
                ),
                (0.035, -0.065, 0.01905),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.5, -0.5, 0.5, 0.5),
                ),
                (-0.0647, 0.0, 0.00961),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.5, -0.5, 0.5, 0.5),
                ),
                (-0.0647, 0.0, 0.00961),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.5, -0.5, 0.5, 0.5),
                ),
                (-0.0647, 0.0, 0.00961),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.5, -0.5, 0.5, 0.5),
                ),
                (-0.0647, 0.0, 0.00961),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.5, -0.5, 0.5, 0.5),
                ),
                (-0.0676, 0.0, 0.00961),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.right_upper_leg_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([-0.07415, 0.0, 0.03511]),
            quat=jnp.array([0.707107, 0.0, 0.707107, 0.0]),
        ),
    )
    self.right_upper_leg = RightUpperLeg()

    self.right_hip_pitch = joints.Hinge(
        self.right_upper_leg_mount,
        self.right_upper_leg.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-0.523599, 1.22173),
    )
    self.right_hip_pitch_actuator = actuators.Position(self.right_hip_pitch)


@defcomponent
def RightUpperLeg(self):
    self.inertia = Inertia(
        mass=0.12407,
        pose=Pose(
            pos=jnp.array([0.00253369, 0.0390636, 0.010809]),
            quat=jnp.array([0.411107, 0.577419, -0.487141, 0.510169]),
        ),
        diag=jnp.array([0.000228782, 0.00021758, 7.09527e-05]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["right_cache"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.01606, -0.065, 0.1092),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["leg_spacer"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.01606, -0.14365, -0.07215),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["left_knee_to_ankle_right_sheet"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.01606, -0.14365, -0.07205),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["left_knee_to_ankle_left_sheet"]),
                    (0.707107, 0.707107, 0.0, 0.0),
                ),
                (0.01606, -0.14365, -0.07205),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.5, 0.5, -0.5, -0.5),
                ),
                (0.0, 0.05315, 0.02755),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.5, 0.5, -0.5, -0.5),
                ),
                (0.0, 0.05315, 0.02755),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.5, 0.5, -0.5, -0.5),
                ),
                (0.0, 0.05315, 0.02755),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.5, 0.5, -0.5, -0.5),
                ),
                (0.0, 0.05315, 0.02755),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.5, 0.5, -0.5, -0.5),
                ),
                (0.0, 0.05315, 0.03045),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.right_lower_leg_mount = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.0, 0.07865, 0.037]), quat=jnp.array([0.0, 1.0, 0.0, 0.0])
        ),
    )
    self.right_lower_leg = RightLowerLeg()

    self.right_knee = joints.Hinge(
        self.right_lower_leg_mount,
        self.right_lower_leg.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-1.5708, 1.5708),
    )
    self.right_knee_actuator = actuators.Position(self.right_knee)


@defcomponent
def RightLowerLeg(self):
    self.inertia = Inertia(
        mass=0.07259,
        pose=Pose(
            pos=jnp.array([5.01859e-06, -0.0577465, 0.0181136]),
            quat=jnp.array([0.708422, 0.705789, 1.07934e-05, 0.00022447]),
        ),
        diag=jnp.array([4.99575e-05, 4.23935e-05, 1.8727e-05]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["leg_spacer"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.14365, 0.10925),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["left_knee_to_ankle_right_sheet"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.14365, 0.10915),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["left_knee_to_ankle_left_sheet"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.14365, 0.10915),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0123middlecase_56"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["drive_palonier"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0124bottomcase_45"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["wj-wk00-0122topcabinetcase_95"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["passive_palonier"]),
                    (0.5, -0.5, -0.5, 0.5),
                ),
                (0.0, -0.05315, 0.00665),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.right_foot_mount = self.place(
        Port(), Pose(pos=jnp.array([0.0, -0.07865, 0.0001]))
    )
    self.right_foot = RightFoot()

    self.right_ankle = joints.Hinge(
        self.right_foot_mount,
        self.right_foot.base,
        axis=jnp.array([0.0, 0.0, 1.0]),
        range=(-1.5708, 1.5708),
    )
    self.right_ankle_actuator = actuators.Position(self.right_ankle)


@defcomponent
def RightFoot(self):
    self.inertia = Inertia(
        mass=0.07524,
        pose=Pose(
            pos=jnp.array([0.0110718, -0.0246608, 0.0190626]),
            quat=jnp.array([0.506106, 0.51004, 0.489653, 0.49392]),
        ),
        diag=jnp.array([6.74949e-05, 6.06095e-05, 1.86965e-05]),
    )

    self.shape = scale(
        shapes.union(
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["foot_side"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.2223, 0.10905),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["foot_bottom_tpu"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01656, 0.2228, 0.10955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["foot_bottom_pla"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01656, 0.2228, 0.10955),
            ),
            translate(
                rotate_quat(
                    shapes.external_mesh(meshes["foot_top"]),
                    (0.707107, -0.707107, 0.0, 0.0),
                ),
                (0.01606, 0.2223, 0.10905),
            ),
        ),
        MESHSCALE,
    )
    self.base = self.place(Port())
    self.right_foot_tip = self.place(
        Port(),
        Pose(
            pos=jnp.array([0.0005, -0.036225, 0.01955]),
            quat=jnp.array([0.707107, -0.707107, 0.0, 0.0]),
        ),
    )


if __name__ == "__main__":
    view_model(OpenDuckMini)

import effectful.handlers.jax.numpy as jnp

from robotl.examples.based import Based
from robotl.handlers.mujoco import view_model
from robotl.ops import actuators, joints, shapes, tendons
from robotl.ops.syntax import Port, Pose, defcomponent


@defcomponent
def JointedLink(self, length, radius, joint_radius):
    self.shape = shapes.union(
        shapes.capsule(r=radius, h=length),
        shapes.sphere(joint_radius),
        shapes.translate(shapes.sphere(joint_radius), [0, 0, length]),
    )
    self.base = self.place(Port())
    self.tip = self.place(Port(), Pose(pos=[0, 0, length]))


@defcomponent
def TendonCoupling(self, length=0.25, radius=0.04):
    joint_radius = radius * 0.6
    self.link1 = JointedLink(length, radius, joint_radius)
    self.link2 = JointedLink(length, radius, joint_radius)
    self.link3 = JointedLink(length, radius, joint_radius)
    self.link1.color = jnp.array([0.9, 0.2, 0.2, 1.0])
    self.link2.color = jnp.array([0.2, 0.9, 0.2, 1.0])
    self.link3.color = jnp.array([0.2, 0.2, 0.9, 1.0])

    self.base = self.place(Port())
    self._weld_link1 = joints.Weld(self.base, self.link1.base)

    self.joint1 = joints.Hinge(
        self.link1.tip, self.link2.base, axis=jnp.array([1, 0, 0])
    )
    self.joint2 = joints.Hinge(
        self.link2.tip, self.link3.base, axis=jnp.array([0, 1, 0])
    )
    self.tip = self.link3.tip

    self.actuator1 = actuators.Position(
        self.joint1, ctrlrange=(-1.0, 1.0), forcerange=(-5.0, 5.0), kp=10.0
    )
    self.actuator2 = actuators.Position(
        self.joint2, ctrlrange=(-1.0, 1.0), forcerange=(-5.0, 5.0), kp=10.0
    )

    self.tendon = tendons.SpatialTendon(
        path=[
            self.link1.base,
            self.link3.tip,
        ],
        stiffness=10.0,
        damping=1.0,
        rest_length=0.0,
        offset=0.0,
        width=0.01,
    )


if __name__ == "__main__":
    view_model(lambda: Based.make(TendonCoupling()))

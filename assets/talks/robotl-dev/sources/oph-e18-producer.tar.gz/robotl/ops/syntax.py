"""Core syntax and data structures for RoboTL components.

This module defines the fundamental component system, coordinate transformations,
constraints, and the component definition decorator.
"""

import collections.abc
import enum
import functools
import typing
from dataclasses import dataclass, field, fields

import effectful.handlers.jax.numpy as jnp
import jax
import numpy as np
import numpyro.distributions as dist
from effectful.ops.syntax import defop
from effectful.ops.types import NotHandled, Operation

from robotl.internals.utils import parallel_axis, safeproperty
from robotl.ops import sensors
from robotl.ops.coords import Pose, PoseTangent, context_pose, frame
from robotl.ops.id import NULL_ID, Id, make_id
from robotl.ops.losses import Loss


@defop
def time() -> float:
    """Get the environment time, in seconds.

    :rtype: float"""
    raise NotHandled


class Fidelity(enum.StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    DEFAULT = "default"


@defop
def fidelity() -> Fidelity:
    """Get the level of fidelity."""
    return Fidelity.DEFAULT


@typing.runtime_checkable
class ComponentProtocol(typing.Protocol):
    """The structural surface of :class:`Component`.

    :class:`Component` conforms structurally without inheriting this, so
    components match by shape wherever the protocol is spelled. Exists so
    port protocols can compose with it into spellable pseudo-intersections
    (e.g. ``HasBaseAndTip``) without Python having intersection types.
    """

    name: str
    pose: Pose
    velocity: PoseTangent
    acceleration: PoseTangent


@dataclass(eq=False)
class Component:
    """Represents part of a robot. Components have their own position and rotation in space.

    :param name: Name of the component. Only used for debugging.
    :type name: str
    :param pose: Position and orientation of the component.
    :type pose: Pose
    :param disable_collision: If True, the compiled body's geometry is
        excluded from collision checking (visual-only geometry).
    :type disable_collision: bool
    """

    name: str = field(default="Component")
    pose: Pose = field(default_factory=lambda: defop(Pose)())
    velocity: PoseTangent = field(default_factory=lambda: defop(PoseTangent)())  # type: ignore
    acceleration: PoseTangent = field(default_factory=lambda: defop(PoseTangent)())  # type: ignore
    disable_collision: bool = False
    id: Id = NULL_ID
    _linpos: sensors.FrameLinPos = field(default_factory=sensors.FrameLinPos)
    _angpos: sensors.FrameAngPos = field(default_factory=sensors.FrameAngPos)
    _linvel: sensors.FrameLinVel = field(default_factory=sensors.FrameLinVel)
    _angvel: sensors.FrameAngVel = field(default_factory=sensors.FrameAngVel)
    _linacc: sensors.FrameLinAcc = field(default_factory=sensors.FrameLinAcc)
    _angacc: sensors.FrameAngAcc = field(default_factory=sensors.FrameAngAcc)

    def __post_init__(self):
        if self.id == NULL_ID:
            self.id = make_id()

    @safeproperty
    def pos(self) -> jax.Array:
        """Position relative to current transform context.

        :returns: 3D position vector relative to the current transformation context
        :rtype: jax.Array
        """
        return (~context_pose() @ self.pose).pos

    @safeproperty
    def axes(self) -> jax.Array:
        """3x3 rotation matrix relative to current transform context.

        :returns: Rotation matrix representing component orientation relative to current transformation context
        :rtype: jax.Array
        """
        return (~context_pose() @ self.pose).axes

    @safeproperty
    def quat(self) -> jax.Array:
        """Quaternion representation of rotation.

        :returns: Quaternion in scalar-first canonical form representing component rotation
        :rtype: jax.Array
        """
        return (~context_pose() @ self.pose).unit_quat

    @safeproperty
    def rv(self) -> jax.Array:
        """Orientation as a rotation vector.

        :returns: Rotation vector, axis * angle in radians
        """
        return (~context_pose() @ self.pose).rv

    @safeproperty
    def linvel(self) -> jax.Array:
        # Only rotate (not translate) since velocity is a tangent vector, not a point
        return ~context_pose().rotational @ self.velocity.linear.dx

    @safeproperty
    def angvel(self) -> jax.Array:
        # Only rotate (not translate) since velocity is a tangent vector, not a point
        return ~context_pose().rotational @ self.velocity.angular.rv

    @safeproperty
    def linacc(self) -> jax.Array:
        # Only rotate (not translate) since acceleration is a tangent vector, not a point
        return ~context_pose().rotational @ self.acceleration.linear.dx

    @safeproperty
    def angacc(self) -> jax.Array:
        # Only rotate (not translate) since acceleration is a tangent vector, not a point
        return ~context_pose().rotational @ self.acceleration.angular.rv

    def components(self) -> collections.abc.Iterator["Component"]:
        """Yield logical component bodies once, excluding ports."""
        seen: set[Id] = set()
        pending = [self]
        while pending:
            node = pending.pop()
            if isinstance(node, Port) or node.id in seen:
                continue
            seen.add(node.id)
            yield node
            pending.extend(_collect_children(node).values())


#: The per-frame sensor fields every ``Component`` carries.
FRAME_SENSOR_FIELDS = ("_linpos", "_angpos", "_linvel", "_angvel", "_linacc", "_angacc")

_STRUCTURAL_FIELDS = (
    {f.name for f in fields(Component)} - set(FRAME_SENSOR_FIELDS)
) | {"attributes"}


def _component_state(c: Component) -> dict[str, object]:
    """Return declared and legacy child-bearing component content."""
    content = {
        f.name: getattr(c, f.name)
        for f in fields(c)
        if f.name not in _STRUCTURAL_FIELDS
    }
    attributes = c.attributes if isinstance(c, LegacyComponent) else {}
    collisions = attributes.keys() & content.keys()
    if collisions:
        raise ValueError(
            f"{type(c).__name__} stores {sorted(collisions)} both as declared "
            f"dataclass field(s) and in the attributes dict; pick one."
        )
    return {**attributes, **content}


def _collect_children(c: Component) -> dict[jax.tree_util.KeyPath, Component]:
    return {
        k: v
        for k, v in jax.tree.leaves_with_path(_component_state(c))
        if isinstance(v, Component)
    }


@dataclass(eq=False)
class LegacyComponent(Component):
    """A component whose children are stored in a dynamic ``attributes`` dict.

    ``@defcomponent`` constructors assign child ports and sub-components as
    plain attributes (``self.base = self.place(Port())``); undeclared writes are
    redirected into ``attributes`` and reads fall back to it. Typed components
    subclass :class:`Component` directly and declare their children as fields,
    leaving this machinery behind.

    :param attributes: Dictionary of custom component attributes.
    :type attributes: dict[str, object]
    """

    attributes: dict[str, object] = field(default_factory=dict)

    def __getattr__(self, key: str):
        if key in self.attributes:
            return self.attributes[key]
        raise AttributeError(key)

    def __setattr__(self, key: str, value):
        if any(key == f.name for f in fields(self)):
            super().__setattr__(key, value)
        else:
            self.attributes[key] = value

    def place(self, child: "Port", pose: Pose = Pose()) -> "Port":
        """Register *child* port at *pose* relative to this component.

        Restricted to ports because attaching a port is the common case worth a
        shorthand; to place a sub-component, call :func:`assert_transform`
        directly.

        :param child: Child port to attach.
        :param pose: Relative pose of the child in this component's frame.
        :returns: ``child``, for fluent chaining
            (``self.tip = self.place(Port())``).
        """
        assert_transform(self, child, pose)
        return child


@dataclass
class Inertia:
    mass: jax.Array
    diag: jax.Array
    pose: Pose

    def __init__(
        self,
        *,
        mass: jax.typing.ArrayLike,
        diag: np.typing.ArrayLike | None = None,
        pose=Pose(),
        offdiag: np.typing.ArrayLike | None = None,
        tensor: jax.Array | None = None,
    ):
        self.mass = jnp.asarray(mass)
        if tensor is not None:
            diag = jnp.diag(tensor)
            offdiag = jnp.array([tensor[0, 1], tensor[0, 2], tensor[1, 2]])
        assert diag is not None, "must provide diag or tensor"
        diag = jnp.asarray(diag)
        if offdiag is None:
            self.pose = pose
            self.diag = diag
        else:
            # construct and diagonalize full matrix, absorbing rotation into pose
            # NOTE the inertial matrix is 3x3 symmetric so only has 6 dof
            # mujoco's fullinertia = M11 M22 M33 M12 M13 M23 = [*diag, *offdiag]
            offdiag = jnp.asarray(offdiag)
            m11, m22, m33 = diag[0], diag[1], diag[2]
            m12, m13, m23 = offdiag[0], offdiag[1], offdiag[2]
            matrix = jnp.array([[m11, m12, m13], [m12, m22, m23], [m13, m23, m33]])
            w, v = jnp.linalg.eigh(matrix)
            order = jnp.argsort(-w)
            w, v = w[order], v[:, order]
            # if det(v) == -1, flip one axis to get a proper rotation
            v = jnp.where(jnp.linalg.det(v) < 0, v.at[:, -1].multiply(-1), v)
            self.pose = pose @ Pose(axes=jnp.swapaxes(v, -1, -2))
            self.diag = w

    @safeproperty
    def tensor(self) -> jax.Array:
        """Full 3x3 inertia tensor about the center of mass in world frame."""
        R = self.pose.axes.T  # columns of R are principal axes
        return R @ jnp.diag(self.diag) @ R.T

    def __add__(self, other: "Inertia") -> "Inertia":
        """The inertia of both bodies together, by the parallel axis theorem.

        Associative, so a chain of ``+`` sums any number of parts. A part with
        negative mass subtracts, which is how a difference of shapes is
        summed; the running center of mass is then a weighted mean with a
        negative weight, exact as long as the total mass stays nonzero.
        """
        M = self.mass + other.mass
        com = (self.mass * self.pose.pos + other.mass * other.pose.pos) / M
        I = sum(
            (
                p.tensor + p.mass * parallel_axis(p.pose.pos - com)
                for p in (self, other)
            ),
            start=jnp.zeros([3, 3], dtype=float),
        )
        return Inertia(mass=M, tensor=I, pose=Pose(pos=com))


@dataclass
class Material:
    """Bulk material properties for a component's geometry.

    Groups physical properties that MuJoCo exposes as geom attributes:
    density for inertia computation, friction for contacts, and color
    for visualization.

    :param density: Mass density in kg/m^3.
    :param friction: Coulomb friction coefficient.
    :param color: RGBA color.
    :param name: Name of a material registered on the compiled ``MjSpec``
        (e.g. by the visual-defaults pass). When set, the geom references
        this material instead of a flat ``color``; takes precedence over
        ``color``.
    :param solref: MuJoCo contact solver reference ``(timeconst,
        damping_ratio)`` for this geometry's contacts.
    :param solimp: MuJoCo contact solver impedance, up to five values.
        MuJoCo's default contact force scales with the effective inertia at
        the contact, so a near-massless part exerts almost none however deep
        it penetrates; impedance near 1 makes the contact behave rigidly
        regardless of the part's mass, which is how a light part made of a
        hard material stops what pushes into it.
    """

    density: float | None = None
    friction: float | None = None
    color: np.typing.ArrayLike | None = None
    name: str | None = None
    solref: tuple[float, float] | None = None
    solimp: tuple[float, ...] | None = None


@defop
def assert_transform(
    parent: Component,
    child: Component,
    pose: Pose = Pose(),
) -> None:
    """
    Args:
        parent: Parent component
        child: Child coordinate frame to transform
        pose: Relative pose
    """
    raise NotHandled


@Operation.define
def choose(choices: dist.Distribution) -> jax.Array:
    raise NotHandled


@Operation.define
def constrain(constraint: Loss) -> None:
    raise NotHandled


@Operation.define
def enable_pair_collisions(c1: "Component", c2: "Component") -> None:
    """Declare that *c1* and *c2* must produce contacts with each other.

    The pair is checked for collision even where the backend's default
    filtering would drop it. MuJoCo filters out contacts between a body
    and its kinematic parent, which hides the touching of jointed
    neighbours that some mechanisms rely on, such as a chain of units
    that pack against each other; declaring each such pair restores
    exactly those contacts while the filter keeps protecting everything
    else, so the mechanism composes with models that rely on it.

    The unhandled result of this op must be stored on a component
    attribute so the compiler can find it, just like joints are stored::

        self._contact_ab = enable_pair_collisions(self.a, self.b)

    The compiler walks each component's attributes, finds these stored
    terms, and translates them into the backend's explicit contact pairs.

    :param c1: First component of the touching pair.
    :param c2: Second component of the touching pair.
    """
    raise NotHandled


@Operation.define
def disable_pair_collisions(c1: "Component", c2: "Component") -> None:
    """Declare that *c1* and *c2* should never produce contacts with each other.

    The pair is excluded from collision checking regardless of geometry
    overlap, leaving each component's collisions with everything else
    untouched. Useful for suppressing spurious self-contacts between
    kinematically adjacent parts.

    The unhandled result of this op must be stored on a component
    attribute so the compiler can find it, just like joints are stored::

        self._exclude_ab = disable_pair_collisions(self.a, self.b)

    The compiler walks each component's attributes, finds these stored
    terms, and translates them into the backend's exclusion mechanism.

    :param c1: First component of the excluded pair.
    :param c2: Second component of the excluded pair.
    """
    raise NotHandled


def defcomponent[**P](
    constr: collections.abc.Callable[typing.Concatenate[LegacyComponent, P], None],
) -> collections.abc.Callable[P, LegacyComponent]:
    """Decorator for defining component constructors.

    :param constr: Component constructor function
    :returns: Wrapped component constructor
    :rtype: callable
    """

    @functools.wraps(constr)
    def wrapper(*args, **kwargs) -> LegacyComponent:
        comp = LegacyComponent(name=kwargs.get("name", constr.__name__))
        with frame(pose=comp.pose):
            ret = constr(comp, *args, **kwargs)  # type: ignore[func-returns-value]
            assert ret is None, "unexpected return from component definition"

        return comp

    return wrapper


@defop
def non_overlap(c1: "Component", c2: "Component") -> None:
    """Assert that two components' geometries do not overlap.

    Uses convex support functions and a separating hyperplane to check
    non-intersection.  A separating direction is introduced as a free
    variable and the solver finds a direction that certifies separation.

    :param c1: First component (must have a ``shape`` attribute)
    :param c2: Second component (must have a ``shape`` attribute)
    """
    raise NotHandled


class Port(Component):
    """Define a basic port component for mechanical connections."""


@dataclass(eq=False)
class _Origin(Component):
    """Used for positioning/attaching components to the worldbody"""

    base: Port = field(default_factory=lambda: Port(pose=Pose()))


Origin = _Origin(pose=Pose())

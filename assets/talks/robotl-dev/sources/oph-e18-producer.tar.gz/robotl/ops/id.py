import itertools

Id = int

_counter = itertools.count()


def make_id() -> Id:
    return next(_counter)


NULL_ID = make_id()

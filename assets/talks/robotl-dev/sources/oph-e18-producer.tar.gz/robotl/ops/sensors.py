"""Sensor definitions for RoboTL components.

This module defines various sensor types that can observe component states.
"""

import abc
import dataclasses
from typing import TYPE_CHECKING, Any, cast

from effectful.ops.syntax import defdata, defop
from effectful.ops.types import NotHandled, Term

from robotl.ops.coords import (
    Coordinate,
    CoordinateTangent,
    Displacement,
    DisplacementTangent,
    Image,
    RawCoordinate,
    Rotation,
    RotationTangent,
    ScalarForce,
    ScalarTorque,
)
from robotl.ops.id import Id, make_id

if TYPE_CHECKING:
    from robotl.ops import actuators, joints
    from robotl.ops.syntax import Component

type SensorValue = Coordinate | CoordinateTangent | ScalarTorque | ScalarForce | Image

# runtime counterpart of :data:`SensorValue` for ``issubclass`` checks
_SENSOR_VALUE_TYPES = (
    Coordinate,
    CoordinateTangent,
    ScalarTorque,
    ScalarForce,
    Image,
)


def _refine[T](value, ty: type[T]) -> T:
    """Narrow *value* to *ty*: assert concrete values, retype symbolic terms."""
    if isinstance(value, Term):
        return defdata.dispatch(ty)(ty, value.op, *value.args, **value.kwargs)
    assert isinstance(value, ty), (value, ty)
    return value


class Sensor[V: SensorValue](abc.ABC):
    id: Id

    @property
    @abc.abstractmethod
    def quantity(self) -> type[V]:
        """Sensor value type."""

    # effectful cannot type terms by a union like SensorValue, so the op is
    # typed `object` and `get` narrows it via `quantity`
    @defop
    def _get(self) -> object:
        raise NotHandled

    def get(self) -> V:
        """Read the sensor's current value.

        Meaningful only under an interpretation that handles the read, e.g.
        ``with handler(env.intp()):`` for an environment's state (its runner
        needs a :class:`~robotl.handlers.mujoco.render.Renderer` if the
        sensor renders a camera). Outside any interpretation the call is
        symbolic and returns a term, which is how :class:`Virtual` sensors
        are defined.
        """
        return _refine(self._get(), self.quantity)


@dataclasses.dataclass
class Position[Q: Coordinate](Sensor[Q]):
    joint: "joints.DofJoint[Q, Any]"
    id: Id = dataclasses.field(default_factory=make_id)

    @property
    def quantity(self) -> type[Q]:
        return self.joint.q_type


@dataclasses.dataclass
class Velocity[DQ: CoordinateTangent](Sensor[DQ]):
    joint: "joints.DofJoint[Any, DQ]"
    id: Id = dataclasses.field(default_factory=make_id)

    @property
    def quantity(self) -> type[DQ]:
        return self.joint.dq_type


@dataclasses.dataclass
class ActuatorFrc[F: ScalarTorque | ScalarForce](Sensor[F]):
    actuator: "actuators.Actuator[Any, Any, F]"
    id: Id = dataclasses.field(default_factory=make_id)

    @property
    def quantity(self) -> type[F]:
        return self.actuator.target.frc_type


@dataclasses.dataclass
class ActuatorVel[DQ: CoordinateTangent](Sensor[DQ]):
    actuator: "actuators.Actuator[Any, DQ, Any]"
    id: Id = dataclasses.field(default_factory=make_id)

    @property
    def quantity(self) -> type[DQ]:
        return self.actuator.target.dq_type


class Contact(Sensor[RawCoordinate]):
    """Fixed-capacity native contacts between two component bodies.

    Each slot contains ``[found, normal_force, tangent_force_1,
    tangent_force_2, distance]``. ``found`` is zero for empty slots and
    otherwise the total number of matching contacts, repeated in each
    occupied slot. Consumers must check that this total does not exceed
    ``capacity`` before reducing the per-contact readings.

    :param first: First body participating in the contact.
    :param second: Second body participating in the contact.
    :param capacity: Number of contact slots; native compilation requires
        a positive value.

    Readings are a flat :class:`~robotl.ops.coords.RawCoordinate` of length
    ``5 * capacity``. Native MuJoCo 3.14 or newer is required; MJX body-body
    matching is not supported.
    """

    first_id: Id
    second_id: Id
    capacity: int

    def __init__(
        self,
        first: "Component",
        second: "Component",
        capacity: int,
    ) -> None:
        # A sensor can target its owner. Keep body IDs, not recursive component
        # graphs, opaque to symbolic expression and shape analysis.
        self.first_id = first.id
        self.second_id = second.id
        self.capacity = capacity
        self.id = make_id()

    @property
    def quantity(self) -> type[RawCoordinate]:
        return RawCoordinate


def subtree_contact_sensors(
    component1: "Component", component2: "Component", *, capacity: int = 8
) -> list[Contact]:
    """Create body-pair sensors across two RoboTL component graphs.

    Each component and its logical children are included once, excluding
    ports. Mechanical joint connections do not extend either selection.
    The returned sensors must be stored on a component to be compiled.

    :param component1: Root of the first logical component graph.
    :param component2: Root of the second logical component graph.
    :param capacity: Contact slots per body pair.
    :returns: One native body-body sensor per distinct unordered body pair.
    """
    pairs: dict[frozenset[Id], Contact] = {}
    second_bodies = list(component2.components())
    for first in component1.components():
        for second in second_bodies:
            key = frozenset((first.id, second.id))
            if first.id != second.id and key not in pairs:
                pairs[key] = Contact(first, second, capacity)
    return list(pairs.values())


@dataclasses.dataclass
class FrameSensor[V: SensorValue](Sensor[V]):
    id: Id = dataclasses.field(default_factory=make_id)


class FrameLinPos(FrameSensor[Displacement]):
    @property
    def quantity(self) -> type[Displacement]:
        return Displacement


class FrameAngPos(FrameSensor[Rotation]):
    @property
    def quantity(self) -> type[Rotation]:
        return Rotation


class FrameLinVel(FrameSensor[DisplacementTangent]):
    @property
    def quantity(self) -> type[DisplacementTangent]:
        return DisplacementTangent


class FrameAngVel(FrameSensor[RotationTangent]):
    @property
    def quantity(self) -> type[RotationTangent]:
        return RotationTangent


class FrameLinAcc(FrameSensor[DisplacementTangent]):
    @property
    def quantity(self) -> type[DisplacementTangent]:
        return DisplacementTangent


class FrameAngAcc(FrameSensor[RotationTangent]):
    @property
    def quantity(self) -> type[RotationTangent]:
        return RotationTangent


# eq=False: ``expr`` holds a graph, so instances hash by identity
@dataclasses.dataclass(eq=False)
class Virtual[V: SensorValue](Sensor[V]):
    """A sensor computed from other sensors instead of read from MuJoCo.

    ``expr`` is a typed quantity built from sensor reads made *outside* any
    interpretation, so the reads are symbolic and the value is recomputed
    against the current state every time the sensor is read::

        self.doubled = sensors.Virtual(Angle(2.0 * self.angle.get().theta))
        self.view = sensors.Virtual(render_camera(camera))
        self.latent = sensors.Virtual(RawCoordinate(encode_image(render_camera(camera))))

    The value's type is the reading's type, so pick the box that says what the
    sensor reports: ``view`` reads a frame, hence an
    :class:`~robotl.ops.coords.Image`; ``latent`` reads a feature vector, hence
    a :class:`~robotl.ops.coords.RawCoordinate`.

    No MuJoCo sensor is emitted for a virtual sensor and it occupies no
    ``sensordata`` slice; :attr:`quantity` is the type of ``expr``. Camera
    sensors (reading ``render_camera``) are evaluated with a
    :class:`~robotl.handlers.mujoco.render.Renderer`, the one held by the
    spec's :class:`~robotl.handlers.mujoco.rollouts.Runner`.

    :param expr: A :data:`SensorValue` (possibly a symbolic term, or a
        quantity whose fields are symbolic terms).
    :raises TypeError: If ``expr`` is a closure, or is not a typed quantity
        (a bare array or array-typed term must be wrapped, e.g. in
        :class:`~robotl.ops.coords.RawCoordinate`).
    """

    expr: V
    id: Id = dataclasses.field(default_factory=make_id)

    def __post_init__(self):
        # Virtual takes a symbolic expression, not a per-state function.
        if callable(self.expr):
            raise TypeError(
                "Virtual takes an expression, not a closure: read the sensors "
                "outside an interpretation so the reads build a graph, e.g. "
                "Virtual(Angle(2.0 * self.angle.get().theta)), not "
                "Virtual(lambda: Angle(2.0 * self.angle.get().theta))"
            )
        ty = self.quantity
        if not issubclass(ty, _SENSOR_VALUE_TYPES):
            raise TypeError(
                f"Virtual expression must be a typed quantity, got {ty!r}: wrap "
                "it in a Coordinate, CoordinateTangent, scalar box, or Image, "
                "e.g. Virtual(Angle(2.0 * self.angle.get().theta)) or "
                "Virtual(RawCoordinate(latent))"
            )

    @property
    def quantity(self) -> type[V]:
        cls = type(self.expr)
        if isinstance(self.expr, Term):
            # a typed term is an ``_XTerm(Term, X)``: recover ``X`` from the
            # bases (``typeof`` would report the op's declared ``object``)
            for base in cls.__mro__:
                if not issubclass(base, Term) and issubclass(base, _SENSOR_VALUE_TYPES):
                    return cast(type[V], base)
        return cast(type[V], cls)  # untyped terms are rejected by __post_init__

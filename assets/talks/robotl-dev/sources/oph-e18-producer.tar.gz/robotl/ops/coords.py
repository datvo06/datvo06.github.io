import abc
import contextlib
import dataclasses
import functools
from typing import Literal, Self, cast, overload

import effectful.handlers.jax.numpy as jnp
import jax
import jax._src.core
import numpy as np
from effectful.ops.semantics import fvsof, handler, typeof
from effectful.ops.syntax import defop
from effectful.ops.types import NotHandled, Operation, Term

from robotl.internals.utils import Bbox, matrix_from_quat, quat_from_matrix

type Scalar = jax.typing.ArrayLike


_TAYLOR_EPS: float = 1e-5


def _is_jax_arrayish(x) -> bool:
    """True if *x* can flow through JAX ops without ``jnp.asarray`` conversion.

    Matches anything whose (effectful) type is a JAX array or a JAX tracer:
    concrete :class:`jax.Array`s, symbolic effectful Terms typed as an array,
    and JAX ``Tracer``s captured under ``jit``/``vmap``/``grad``. Callers fall
    back to ``jnp.asarray(x, float)`` for anything that does not match.

    ``typeof(x)`` is ``type(x)`` for non-Terms and the Term's declared type
    otherwise, so a single ``issubclass`` covers both. The ``Tracer`` arm is
    load-bearing: a tracer's *class* is not a subclass of :class:`jax.Array`
    (only its ``isinstance`` is registered), so ``issubclass(typeof(tracer),
    jax.Array)`` alone would miss it.
    """
    return issubclass(typeof(x), jax.Array | jax._src.core.Tracer)


def _lift_to_operation(method):
    """Build an Operation from *method* with resolved type annotations."""

    @Operation.define
    @functools.wraps(method)
    def impl(*args, **kwargs):
        if fvsof((args, kwargs)):
            raise NotHandled
        return method(*args, **kwargs)

    return impl


class CoordinateTangent(abc.ABC):
    r"""Abstract base class for Lie algebra (tangent space) elements.

    The Lie algebra $\mathfrak{m} = T_\mathcal{E}\mathcal{M}$ is the tangent
    space at the identity of a Lie group $\mathcal{M}$.

    Subclasses must implement:

    - ``_exp()``: Exponential map $\tau \mapsto \text{Exp}(\tau)$ (Eq. 21)
    - ``jr``, ``jl``: Right/left Jacobians of the exponential map (Eqs. 67, 71)
    - ``+``, ``*``, ``norm``: Vector space structure

    Calling the constructor with no arguments must return the zero element.

    Instances carry a static ``order`` field (:math:`\geq 1`), the tangent
    order: the same class represents elements of every iterated tangent
    bundle :math:`T^k\mathcal{M}` (the tangent space is a vector space, hence
    canonically its own tangent space).  ``log`` — the identity map of the
    abelian group :math:`(\mathfrak{m}, +)` — increments the order; ``exp``
    decrements it, applying the true exponential ``_exp`` only at order 1.

    Reference:
        "A micro Lie theory for state estimation in robotics" (arxiv:1812.01537)
    """

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if issubclass(cls, Term):
            return
        abstract_names = set()
        for base in cls.__mro__[1:]:
            abstract_names |= getattr(base, "__abstractmethods__", frozenset())
        for name, method in tuple(cls.__dict__.items()):
            if name in abstract_names:
                setattr(cls, name, _lift_to_operation(method))

    @abc.abstractmethod
    def exp(self) -> "Coordinate":
        r"""Exponential map: tangent space → group.

        Maps this tangent vector to a group element by wrapping the
        tangent element around the manifold following the geodesic.

        .. math::
            \text{Exp}: \mathbb{R}^m \to \mathcal{M}; \quad
            \tau \mapsto \mathcal{X} = \exp(\tau^\wedge)
            \quad \text{(Eqs. 14, 21)}

        At ``order > 1`` this is the identity map of the vector space:
        the result is the same tangent with ``order - 1`` (despite the
        return annotation, which drives ``typeof`` on symbolic terms).

        Returns:
            The corresponding group element (or lower-order tangent).
        """
        raise NotImplementedError

    @abc.abstractmethod
    def _exp(self) -> "Coordinate":
        """True exponential map onto the group, applied by ``exp`` at order 1."""
        raise NotImplementedError

    @abc.abstractmethod
    def log(self) -> "CoordinateTangent":
        r"""Logarithm map of the abelian group :math:`(\mathfrak{m}, +)`.

        The identity map on data: returns the same tangent with ``order + 1``.
        """
        raise NotImplementedError

    def __add__[T: "CoordinateTangent | Coordinate"](self, other: T) -> T:
        """Vector addition in tangent space."""
        if _is_coordinate(other):
            return NotImplemented  # type: ignore
        else:
            return self._add(other)  # type: ignore

    # ==================== Jacobians ====================

    @abc.abstractmethod
    def jr(self, delta: "CoordinateTangent") -> "CoordinateTangent":
        r"""Right Jacobian of the exponential map $\mathbf{J}_r(\tau)$.

        Applies the right Jacobian to a tangent vector perturbation.

        .. math::
            \mathbf{J}_r(\tau) \triangleq
            \frac{{}^{\tau}D\,\text{Exp}(\tau)}{D\tau}
            \quad \text{(Eq. 67)}

        Key approximations:

        .. math::
            \text{Exp}(\tau + \delta\tau) &\approx
                \text{Exp}(\tau) \circ \text{Exp}(\mathbf{J}_r(\tau)\delta\tau)
                & \text{(Eq. 68)} \\
            \text{Exp}(\tau) \circ \text{Exp}(\delta\tau) &\approx
                \text{Exp}(\tau + \mathbf{J}_r^{-1}(\tau)\delta\tau)
                & \text{(Eq. 69)}

        Derived via forward-mode autodiff through the identity:
        :math:`\mathbf{J}_r(\tau)\delta = \log(\text{Exp}(\tau)^{-1} \circ \text{Exp}(\tau + \delta))`

        Args:
            delta: Tangent vector perturbation $\delta\tau$.

        Returns:
            $\mathbf{J}_r(\text{self}) \, \delta\tau$
        """
        raise NotImplementedError

    @abc.abstractmethod
    def jl(self, delta: "CoordinateTangent") -> "CoordinateTangent":
        r"""Left Jacobian of the exponential map $\mathbf{J}_l(\tau)$.

        Applies the left Jacobian to a tangent vector perturbation.

        .. math::
            \mathbf{J}_l(\tau) \triangleq
            \frac{{}^{\mathcal{E}}D\,\text{Exp}(\tau)}{D\tau}
            \quad \text{(Eq. 71)}

        Key approximations:

        .. math::
            \text{Exp}(\tau + \delta\tau) &\approx
                \text{Exp}(\mathbf{J}_l(\tau)\delta\tau) \circ \text{Exp}(\tau)
                & \text{(Eq. 72)} \\
            \text{Exp}(\delta\tau) \circ \text{Exp}(\tau) &\approx
                \text{Exp}(\tau + \mathbf{J}_l^{-1}(\tau)\delta\tau)
                & \text{(Eq. 73)}

        Relationship to right Jacobian:

        .. math::
            \mathbf{Ad}_{\text{Exp}(\tau)} &=
                \mathbf{J}_l(\tau) \mathbf{J}_r^{-1}(\tau)
                & \text{(Eq. 75)} \\
            \mathbf{J}_r(-\tau) &= \mathbf{J}_l(\tau) & \text{(Eq. 76)}

        Args:
            delta: Tangent vector perturbation $\delta\tau$.

        Returns:
            $\mathbf{J}_l(\text{self}) \, \delta\tau$
        """
        raise NotImplementedError

    # ==================== Vector Space Operations ====================

    @abc.abstractmethod
    def norm(self) -> jax.Array:
        """Compute the norm of the tangent vector.

        Returns:
            Scalar norm.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def _add(self, other: "CoordinateTangent") -> "Self":
        """Vector addition in tangent space."""
        raise NotImplementedError

    @abc.abstractmethod
    def __mul__(self, scalar: Scalar) -> "CoordinateTangent":
        """Scalar multiplication."""
        raise NotImplementedError

    def __rmul__(self, scalar: Scalar) -> "CoordinateTangent":
        return self * scalar

    @abc.abstractmethod
    def __sub__(self, other: "CoordinateTangent") -> "CoordinateTangent":
        """Vector subtraction in tangent space."""
        raise NotImplementedError

    @abc.abstractmethod
    def __neg__(self) -> "CoordinateTangent":
        """Negation."""
        raise NotImplementedError


class Coordinate(abc.ABC):
    r"""Abstract base class for Lie group elements.

    A Lie group $\mathcal{M}$ is a smooth manifold whose elements satisfy the
    group axioms (closure, identity, inverse, associativity).

    Subclasses must implement:

    - ``_product``: Group composition $\mathcal{X} \circ \mathcal{Y}$ (Eq. 1)
    - ``_action``: Group action on a vector (e.g. rotating a point)
    - ``~`` ($^{-1}$): Group inverse (Eq. 3)
    - ``log``: Logarithm map $\mathcal{X} \mapsto \text{Log}(\mathcal{X})$ (Eq. 22)
    - ``_adjoint``: Adjoint representation $\text{Ad}_{\mathcal{X}}$ (Eq. 30)
    - ``jlog``: Jacobian of the logarithm map

    Calling the constructor with no arguments must return the identity element.

    The ``@`` operator dispatches to ``_product``, ``_action``, or
    ``_adjoint`` depending on the operand type (Coordinate, array, or
    CoordinateTangent respectively).

    Reference:
        "A micro Lie theory for state estimation in robotics" (arxiv:1812.01537)
    """

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if issubclass(cls, Term):
            return
        abstract_names = set()
        for base in cls.__mro__[1:]:
            abstract_names |= getattr(base, "__abstractmethods__", frozenset())
        for name, method in tuple(cls.__dict__.items()):
            if name in abstract_names:
                setattr(cls, name, _lift_to_operation(method))

    # ==================== Group Axioms ====================

    @overload
    def __matmul__(self, other: Self) -> Self: ...
    @overload
    def __matmul__(self, other: jax.Array) -> jax.Array: ...
    @overload
    def __matmul__(self, other: CoordinateTangent) -> CoordinateTangent: ...

    def __matmul__(self, other: "CoordinateTangent | jax.Array | Coordinate"):  # type: ignore[overload-overlap]
        r"""Group composition: $\text{self} \circ \text{other}$.

        .. math::
            \mathcal{X} \circ \mathcal{Y} \in \mathcal{M}
            \quad \text{(Eq. 1)}

        Args:
            other: Another group element.

        Returns:
            The composed group element.
        """
        if isinstance(other, Coordinate) or issubclass(typeof(other), Coordinate):
            return self._product(other)  # type: ignore
        elif isinstance(other, CoordinateTangent) or issubclass(
            typeof(other), CoordinateTangent
        ):
            # Group action on tangent space (Eq. 31)
            return self._adjoint(other)  # type: ignore
        elif isinstance(other, jax.Array) or issubclass(typeof(other), jax.Array):
            # Group action on a vector (e.g. rotating a point)
            return self._action(other)
        else:
            raise TypeError(
                f"Unsupported operand type(s) for @: "
                f"{type(self).__name__} and {type(other).__name__}"
            )

    def __add__(self, shift: CoordinateTangent) -> "Coordinate":
        """Group addition: $\text{self} \\oplus \text{shift}$.

        Args:
            shift: Tangent vector to add.

        Returns:
            The resulting group element.
        """
        return self @ shift.exp()

    def __radd__(self, shift: CoordinateTangent) -> "Coordinate":  # type: ignore[misc]
        return shift.exp() @ self

    def __sub__(self, other: "Coordinate") -> CoordinateTangent:
        """
        Compute the tangent vector from other to self: $\text{self} \\ominus \text{other}$.
        """
        return (~other @ self).log()

    @abc.abstractmethod
    def __invert__(self) -> "Coordinate":
        r"""Group inverse: $\text{self}^{-1}$, via ``~x`` syntax.

        .. math::
            \mathcal{X}^{-1} \circ \mathcal{X} =
            \mathcal{X} \circ \mathcal{X}^{-1} = \mathcal{E}
            \quad \text{(Eq. 3)}

        Returns:
            The inverse group element.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def log(self) -> CoordinateTangent:
        r"""Logarithm map: group → tangent space.

        Maps this group element to a tangent vector by unwrapping the
        manifold element to the tangent space.

        .. math::
            \text{Log}: \mathcal{M} \to \mathbb{R}^m; \quad
            \mathcal{X} \mapsto \tau = \log(\mathcal{X})^\vee
            \quad \text{(Eqs. 15, 22)}

        Returns:
            The corresponding tangent vector.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def _product(self, other: Self) -> Self:
        """Group composition operation"""
        raise NotImplementedError

    @abc.abstractmethod
    def _action(self, vector: jax.Array) -> jax.Array:
        """Canonical choice of group action on a vector (e.g. rotating a point)"""
        raise NotImplementedError

    @abc.abstractmethod
    def _adjoint(self, tangent: CoordinateTangent) -> CoordinateTangent:
        r"""Adjoint representation $\text{Ad}_{\mathcal{X}}$.

        Applies the adjoint to a tangent vector, transforming it between
        tangent spaces:

        .. math::
            {}^{\mathcal{E}}\tau = \mathbf{Ad}_{\mathcal{X}} \,
            {}^{\mathcal{X}}\tau
            \quad \text{(Eq. 30)}

        It satisfies the identity:

        .. math::
            \mathcal{X} \circ \text{Exp}(\tau) =
            \text{Exp}(\mathbf{Ad}_{\mathcal{X}} \tau) \circ \mathcal{X}
            \quad \text{(from Eqs. 25, 27, 32)}

        Properties:

        .. math::
            \mathcal{X} \oplus \tau &= (\mathbf{Ad}_{\mathcal{X}} \tau)
                \oplus \mathcal{X} & \text{(Eq. 32)} \\
            \mathbf{Ad}_{\mathcal{X}^{-1}} &= \mathbf{Ad}_{\mathcal{X}}^{-1}
                & \text{(Eq. 33)} \\
            \mathbf{Ad}_{\mathcal{X} \circ \mathcal{Y}} &=
                \mathbf{Ad}_{\mathcal{X}} \mathbf{Ad}_{\mathcal{Y}}
                & \text{(Eq. 34)}

        Args:
            tangent: Tangent vector to transform.

        Returns:
            $\mathbf{Ad}_{\text{self}} \, \tau$ — the tangent vector
            transformed from the local frame at ``self`` to the global
            frame (Lie algebra).
        """
        raise NotImplementedError

    @abc.abstractmethod
    def jlog(self, tangent: CoordinateTangent) -> CoordinateTangent:
        r"""Jacobian of the logarithm map.

        Applies the log Jacobian to a tangent vector. This is the derivative
        of the logarithm composed with right perturbation:

        .. math::
            \frac{d}{d\tau} \text{Log}(\mathcal{X} \circ \text{Exp}(\tau))
            \big|_{\tau=0} = \mathbf{J}_r^{-1}(\text{Log}(\mathcal{X}))

        This is the inverse of the right Jacobian evaluated at
        $\text{Log}(\mathcal{X})$.

        Args:
            tangent: Tangent vector to transform.

        Returns:
            The transformed tangent vector.
        """
        raise NotImplementedError


def norm(a) -> jax.Array:
    r"""Norm of a value.

    For a :class:`Coordinate` this is the geodesic distance
    :math:`\|\text{Log}(a)\|` from the identity element; for a
    :class:`CoordinateTangent` the vector norm; for :class:`ScalarTorque`
    and :class:`ScalarForce` the absolute value; for arrays the Euclidean
    norm.
    """
    if _is_coordinate(a):
        return a.log().norm()
    if _is_tangent(a):
        return a.norm()
    if _is_effort(a):
        return a.norm()
    return jnp.linalg.norm(a)


def distance(a, b) -> jax.Array:
    r"""Norm of the difference between two values of the same type.

    For :class:`Coordinate` operands this is the geodesic distance
    :math:`\|\text{Log}(a^{-1} \circ b)\|`.
    """
    return norm(a - b)


class AutodiffCoordinateTangent(CoordinateTangent):
    r"""CoordinateTangent with autodiff-derived Jacobians and order tracking.

    Provides default implementations of ``jr`` and ``jl`` via ``jax.jvp``
    through the group operations, and of ``exp``/``log`` order bookkeeping
    via ``dataclasses.replace`` on the static ``order`` field.  Subclasses
    still need to implement ``_exp``, ``+``, ``*``, and ``norm``.
    """

    def exp(self) -> "Coordinate":
        if self.order > 1:  # type: ignore[attr-defined]
            return dataclasses.replace(self, order=self.order - 1)  # type: ignore
        return self._exp()

    def log(self) -> "CoordinateTangent":
        return dataclasses.replace(self, order=self.order + 1)  # type: ignore[attr-defined, type-var]

    def jr(self, delta: "CoordinateTangent") -> "CoordinateTangent":
        if self.order != delta.order:  # type: ignore[attr-defined]
            raise ValueError("cannot apply Jacobian across different orders")
        if self.order > 1:  # type: ignore[attr-defined]
            return delta
        return jax.jvp(lambda t: (~self.exp() @ t.exp()).log(), (self,), (delta,))[1]

    def jl(self, delta: "CoordinateTangent") -> "CoordinateTangent":
        return (-self).jr(delta)

    def __sub__(self, other: "CoordinateTangent") -> "CoordinateTangent":
        """Vector subtraction in tangent space."""
        return self + (-other)

    def __neg__(self) -> "CoordinateTangent":
        """Negation."""
        return self * -1.0


class AutodiffCoordinate(Coordinate):
    r"""Coordinate with autodiff-derived adjoint and log-Jacobian.

    Provides default implementations of ``_adjoint`` and ``jlog`` via
    ``jax.jvp`` through the group operations.  Subclasses still need to
    implement ``__invert__``, ``_product``, ``_action``, and ``log``.

    Higher-order tangents are handled functorially: :math:`\mathbf{Ad}_X`
    and the log-Jacobian are linear, so they extend to :math:`T^k\mathfrak{m}`
    as the same map — the tangent is normalized to order 1, mapped, and its
    order restored.
    """

    def _adjoint(self, tangent: CoordinateTangent) -> CoordinateTangent:
        if tangent.order > 1:  # type: ignore[attr-defined]
            result = self._adjoint(dataclasses.replace(tangent, order=1))  # type: ignore[type-var]
            return dataclasses.replace(result, order=tangent.order)  # type: ignore
        zero = tangent * 0.0
        _, result = jax.jvp(
            lambda t: (self @ t.exp() @ ~self).log(), (zero,), (tangent,)
        )
        return result

    def jlog(self, tangent: CoordinateTangent) -> CoordinateTangent:
        if tangent.order > 1:  # type: ignore[attr-defined]
            result = self.jlog(dataclasses.replace(tangent, order=1))  # type: ignore[type-var]
            return dataclasses.replace(result, order=tangent.order)  # type: ignore
        zero = tangent * 0.0
        _, result = jax.jvp(lambda t: (self @ t.exp()).log(), (zero,), (tangent,))
        return result


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class Rotation(AutodiffCoordinate):
    r"""SO(3) rotation (Lie group element).

    Represents a 3D rotation, stored internally as a quaternion (scalar-first,
    unnormalized).  The corresponding Lie algebra is :class:`RotationTangent`.

    Constructing with no arguments gives the identity rotation::

        Rotation()          # identity
        Rotation(rv=omega)  # from rotation vector
        Rotation(quat=q)    # from [w, x, y, z] quaternion
        Rotation(axes=R)    # from rotation matrix (v @ axes rotates v)

    Group operations (inherited from :class:`Coordinate`)::

        R1 @ R2     # composition
        R @ v       # rotate a vector
        ~R          # inverse
        R.log()     # -> RotationTangent  (rotation vector)
        R @ delta    # adjoint map (derived via autodiff)
        R.jlog(delta)     # log-Jacobian  (derived via autodiff)
    """

    quat: jax.Array  # float[4] quaternion, unnormalized

    def __init__(
        self,
        *,
        quat: np.typing.ArrayLike | None = None,
        axes: np.typing.ArrayLike | None = None,
        rv: np.typing.ArrayLike | None = None,
    ):
        if quat is not None:
            quat = quat if _is_jax_arrayish(quat) else jnp.asarray(quat, float)
        elif axes is not None:
            axes = axes if _is_jax_arrayish(axes) else jnp.asarray(axes, float)
            quat = quat_from_matrix(jnp.swapaxes(axes, -1, -2))  # type: ignore[arg-type]
        elif rv is not None:
            rv = rv if _is_jax_arrayish(rv) else jnp.asarray(rv, float)
            quat = RotationTangent(rv).exp().quat
        else:
            quat = jnp.array([1.0, 0.0, 0.0, 0.0])
        self.quat = quat  # type: ignore

    @classmethod
    def make_random(cls, rng):
        return cls(quat=jax.random.normal(rng, shape=[4]))

    @classmethod
    def from_euler(
        cls,
        axis: Literal["x", "y", "z"],
        angle: np.typing.ArrayLike,
        degrees: bool = False,
    ) -> "Rotation":
        """Construct a rotation from a single-axis Euler angle.

        :param axis: The axis to rotate around (``"x"``, ``"y"``, or ``"z"``).
        :param angle: The rotation angle.
        :param degrees: If ``True``, interpret *angle* in degrees; otherwise radians.
        """
        match axis:
            case "x":
                axis_arr = jnp.array([1, 0, 0])
            case "y":
                axis_arr = jnp.array([0, 1, 0])
            case "z":
                axis_arr = jnp.array([0, 0, 1])
            case _:
                raise ValueError("Unexpected axis", axis)
        angle_arr = jnp.asarray(angle)
        angle_rad = angle_arr if not degrees else 2 * jnp.pi * (angle_arr / 360)
        return cls(rv=axis_arr * angle_rad)

    @property
    def axes(self) -> jax.Array:
        # Use swapaxes to only transpose the last two dims (supports batching)
        return jnp.swapaxes(matrix_from_quat(self.quat), -1, -2)

    @property
    @Operation.define
    def unit_quat(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        q = self.quat / jnp.linalg.norm(self.quat, axis=-1, keepdims=True)
        # Canonicalize to the w >= 0 hemisphere (q and -q are the same rotation)
        return jnp.where(q[..., :1] < 0, -q, q)  # type: ignore

    # ==================== Lie Group Operations ====================

    def __invert__(self) -> "Rotation":
        # Quaternion conjugate [w, -x, -y, -z] gives the inverse rotation
        return Rotation(quat=self.quat * jnp.array([1.0, -1.0, -1.0, -1.0]))

    def _action(self, vector: jax.Array) -> jax.Array:
        # Rodrigues via quaternion: v' = v + 2w(u × v) + 2(u × (u × v))
        q = self.quat / jnp.linalg.norm(self.quat, axis=-1, keepdims=True)
        w = q[..., :1]
        u = q[..., 1:]
        t = 2.0 * jnp.cross(u, vector)
        return vector + w * t + jnp.cross(u, t)

    def _product(self, other: "Rotation") -> "Rotation":  # type: ignore[override]
        # Hamilton product: (self ∘ other).quat = self.quat ⊗ other.quat
        p, q = self.quat, other.quat
        pw, pv = p[..., :1], p[..., 1:]
        qw, qv = q[..., :1], q[..., 1:]
        w = pw * qw - jnp.sum(pv * qv, axis=-1, keepdims=True)
        xyz = pw * qv + qw * pv + jnp.cross(pv, qv)
        return Rotation(quat=jnp.concatenate([w, xyz], axis=-1))

    def log(self) -> "RotationTangent":
        r"""SO(3) logarithm map: rotation → rotation vector.

        Computes :math:`\text{Log}(R) = \theta \hat{u}` where :math:`\theta`
        is the rotation angle and :math:`\hat{u}` the unit axis.  Uses a
        quaternion-based formula with a Taylor expansion near :math:`\theta=0`
        to avoid the :math:`\sin\theta/\theta` singularity at the identity,
        and an :math:`\text{arctan2}` branch for numerical stability near
        :math:`\theta=\pi`.

        Reference: Eq. 103 of arxiv:1812.01537; Taylor coefficients from
        the series expansion of :math:`2\,\text{atan2}(\|q_{xyz}\|, q_w)/\|q_{xyz}\|`.
        """
        quat = self.quat / jnp.linalg.norm(self.quat, axis=-1, keepdims=True)
        w = quat[..., 0]
        xyz = quat[..., 1:]
        norm_xyz_sq = jnp.sum(jnp.square(xyz), axis=-1)
        use_taylor = norm_xyz_sq < _TAYLOR_EPS
        norm_xyz_safe = jnp.sqrt(jnp.where(use_taylor, 1.0, norm_xyz_sq))
        w_safe = jnp.where(use_taylor, w, 1.0)
        atan_n_over_w = jnp.arctan2(
            jnp.where(w < 0, -norm_xyz_safe, norm_xyz_safe),
            jnp.abs(w),
        )
        factor = jnp.where(
            use_taylor,
            2.0 / w_safe - 2.0 / 3.0 * norm_xyz_sq / w_safe**3,
            jnp.where(
                jnp.abs(w) < _TAYLOR_EPS,
                jnp.where(w > 0, 1.0, -1.0) * jnp.pi / norm_xyz_safe,
                2.0 * atan_n_over_w / norm_xyz_safe,
            ),
        )
        return RotationTangent(factor[..., None] * xyz)


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class RotationTangent(AutodiffCoordinateTangent):
    r"""$\mathfrak{so}(3)$ tangent vector (Lie algebra element).

    Represents an element of the tangent space at the identity of SO(3),
    stored as a rotation vector (axis scaled by angle).  The corresponding
    Lie group is :class:`Rotation`.

    Constructing with no arguments gives the zero element::

        RotationTangent()              # zero
        RotationTangent(jnp.array(v))  # from rotation vector

    Algebra operations (inherited from :class:`CoordinateTangent`)::

        tau.exp()       # -> Rotation
        tau1 + tau2     # vector addition
        tau * s         # scalar multiplication
        tau.norm()      # rotation angle (vector norm)
        tau.jr(delta)   # right Jacobian (derived via autodiff)
        tau.jl(delta)   # left  Jacobian (derived via autodiff)
    """

    _rv: jax.Array
    order: int = dataclasses.field(default=1, metadata=dict(static=True))

    def __init__(self, _rv: np.typing.ArrayLike = jnp.zeros([3]), *, order: int = 1):
        self._rv = _rv if _is_jax_arrayish(_rv) else jnp.asarray(_rv, float)  # type: ignore[assignment]
        self.order = order

    @property
    @Operation.define
    def rv(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        return self._rv

    # ==================== Lie Algebra Operations ====================

    def _exp(self) -> Rotation:
        r"""SO(3) exponential map: rotation vector → quaternion.

        Computes :math:`\text{Exp}(\omega) = [\cos(\theta/2),\;
        \sin(\theta/2)\,\hat{u}]` where :math:`\theta = \|\omega\|`
        and :math:`\hat{u} = \omega/\theta`.  Uses a Taylor expansion
        of :math:`\cos` and :math:`\text{sinc}` near :math:`\theta=0`
        for numerical stability at the identity.

        Reference: Eq. 101 of arxiv:1812.01537.
        """
        rv = self.rv
        theta_squared = jnp.sum(jnp.square(rv), axis=-1)
        theta_pow_4 = theta_squared * theta_squared
        use_taylor = theta_squared < _TAYLOR_EPS
        safe_theta = jnp.sqrt(jnp.where(use_taylor, 1.0, theta_squared))
        safe_half_theta = 0.5 * safe_theta
        real = jnp.where(
            use_taylor,
            1.0 - theta_squared / 8.0 + theta_pow_4 / 384.0,
            jnp.cos(safe_half_theta),
        )
        imag = jnp.where(
            use_taylor,
            0.5 - theta_squared / 48.0 + theta_pow_4 / 3840.0,
            jnp.sin(safe_half_theta) / safe_theta,
        )
        quat = jnp.concatenate([real[..., None], imag[..., None] * rv], axis=-1)
        return Rotation(quat=quat)

    def exp(self) -> Rotation:  # type: ignore[override]
        return super().exp()  # type: ignore[return-value]

    def log(self) -> "RotationTangent":
        return super().log()  # type: ignore[return-value]

    def _add(self, other: "RotationTangent") -> "RotationTangent":  # type: ignore[override]
        if self.order != other.order:
            raise ValueError("cannot add tangents with different orders")
        return RotationTangent(self.rv + other.rv, order=self.order)

    def __mul__(self, scalar: Scalar) -> "RotationTangent":
        return RotationTangent(self.rv * scalar, order=self.order)

    def norm(self) -> jax.Array:
        return jnp.linalg.norm(self.rv, axis=-1)


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class Angle(AutodiffCoordinate):
    r"""SO(2) planar rotation (Lie group element).

    Represents a 2D rotation, stored as an angle in radians.  Composition
    adds angles; the action rotates 2D vectors.  The corresponding Lie
    algebra is :class:`AngleTangent`.

    Constructing with no arguments gives the identity rotation::

        Angle()       # identity
        Angle(theta)  # from an angle in radians

    Group operations (inherited from :class:`Coordinate`)::

        a1 @ a2     # composition (angle addition)
        a @ v       # rotate a 2D vector
        ~a          # inverse (negated angle)
        a.log()     # -> AngleTangent  (angle wrapped to (-pi, pi])
    """

    theta: jax.Array

    def __init__(self, theta: np.typing.ArrayLike = 0.0):
        self.theta = theta if _is_jax_arrayish(theta) else jnp.asarray(theta, float)  # type: ignore[assignment]

    @classmethod
    def make_random(cls, rng):
        return cls(jnp.pi * jax.random.normal(rng))

    def __invert__(self) -> "Angle":
        return Angle(-self.theta)

    def _product(self, other: "Angle") -> "Angle":  # type: ignore[override]
        return Angle(self.theta + other.theta)

    def _action(self, vector: jax.Array) -> jax.Array:
        c, s = jnp.cos(self.theta), jnp.sin(self.theta)
        x, y = vector[..., 0], vector[..., 1]
        return jnp.stack([c * x - s * y, s * x + c * y], axis=-1)

    def log(self) -> "AngleTangent":
        return AngleTangent((self.theta + jnp.pi) % (2 * jnp.pi) - jnp.pi)


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class AngleTangent(AutodiffCoordinateTangent):
    r"""$\mathfrak{so}(2)$ tangent vector (Lie algebra element).

    Represents an element of the tangent space at the identity of SO(2),
    stored as a scalar angular rate.  The corresponding Lie group is
    :class:`Angle`.

    Constructing with no arguments gives the zero element::

        AngleTangent()       # zero
        AngleTangent(omega)  # from a scalar angular rate

    Algebra operations (inherited from :class:`CoordinateTangent`)::

        tau.exp()       # -> Angle
        tau1 + tau2     # vector addition
        tau * s         # scalar multiplication
        tau.norm()      # absolute angle
        tau.jr(delta)   # right Jacobian (derived via autodiff)
        tau.jl(delta)   # left  Jacobian (derived via autodiff)
    """

    _omega: jax.Array
    order: int = dataclasses.field(default=1, metadata=dict(static=True))

    def __init__(self, _omega: np.typing.ArrayLike = 0.0, *, order: int = 1):
        self._omega = _omega if _is_jax_arrayish(_omega) else jnp.asarray(_omega, float)  # type: ignore[assignment]
        self.order = order

    @property
    @Operation.define
    def omega(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        return self._omega

    def _exp(self) -> Angle:
        return Angle(self.omega)

    def exp(self) -> Angle:  # type: ignore[override]
        return super().exp()  # type: ignore[return-value]

    def log(self) -> "AngleTangent":
        return super().log()  # type: ignore[return-value]

    def _add(self, other: "AngleTangent") -> "AngleTangent":  # type: ignore[override]
        if self.order != other.order:
            raise ValueError("cannot add tangents with different orders")
        return AngleTangent(self.omega + other.omega, order=self.order)

    def __mul__(self, scalar: Scalar) -> "AngleTangent":
        return AngleTangent(self.omega * scalar, order=self.order)

    def norm(self) -> jax.Array:
        return jnp.abs(self.omega)


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class Displacement(AutodiffCoordinate):
    r"""3D translation (Lie group element).

    Represents an element of the translation group
    :math:`(\mathbb{R}^3, +)`, stored as a 3D vector.  Composition adds
    vectors; the action translates a point.  The corresponding Lie algebra
    is :class:`DisplacementTangent`.

    Constructing with no arguments gives the identity (zero) translation::

        Displacement()   # identity
        Displacement(x)  # from a 3D vector

    Group operations (inherited from :class:`Coordinate`)::

        d1 @ d2     # composition (vector addition)
        d @ v       # translate a point
        ~d          # inverse (negated vector)
        d.log()     # -> DisplacementTangent  (trivial for translations)
    """

    x: jax.Array

    def __init__(self, x: np.typing.ArrayLike = jnp.zeros([3], float)):
        self.x = x if _is_jax_arrayish(x) else jnp.asarray(x, float)  # type: ignore[assignment]

    @classmethod
    def make_random(cls, rng, bbox: Bbox | None = None):
        if bbox is None:
            x = jax.random.normal(rng, shape=[3])
        else:
            x = jax.random.uniform(rng, shape=[3]) * (bbox.hi - bbox.lo) + bbox.lo
        return cls(x)

    def __invert__(self) -> "Displacement":
        return Displacement(-self.x)

    def _product(self, other: "Displacement") -> "Displacement":  # type: ignore[override]
        return Displacement(self.x + other.x)

    def _action(self, vector: jax.Array) -> jax.Array:
        return vector + self.x

    def log(self) -> "DisplacementTangent":
        return DisplacementTangent(self.x)


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class DisplacementTangent(AutodiffCoordinateTangent):
    r"""Tangent vector of the 3D translation group (Lie algebra element).

    Represents an element of the tangent space at the identity of
    :math:`(\mathbb{R}^3, +)`, stored as a 3D vector.  Since the group is
    a vector space, the exponential map is trivial.  The corresponding Lie
    group is :class:`Displacement`.

    Constructing with no arguments gives the zero element::

        DisplacementTangent()    # zero
        DisplacementTangent(dx)  # from a 3D vector

    Algebra operations (inherited from :class:`CoordinateTangent`)::

        tau.exp()       # -> Displacement
        tau1 + tau2     # vector addition
        tau * s         # scalar multiplication
        tau.norm()      # Euclidean norm
        tau.jr(delta)   # right Jacobian (derived via autodiff)
        tau.jl(delta)   # left  Jacobian (derived via autodiff)
    """

    _dx: jax.Array
    order: int = dataclasses.field(default=1, metadata=dict(static=True))

    def __init__(
        self, _dx: np.typing.ArrayLike = jnp.zeros([3], float), *, order: int = 1
    ):
        self._dx = _dx if _is_jax_arrayish(_dx) else jnp.asarray(_dx, float)  # type: ignore[assignment]
        self.order = order

    @property
    @Operation.define
    def dx(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        return self._dx

    def _exp(self) -> Displacement:
        return Displacement(self.dx)

    def exp(self) -> Displacement:  # type: ignore[override]
        return super().exp()  # type: ignore[return-value]

    def log(self) -> "DisplacementTangent":
        return super().log()  # type: ignore[return-value]

    def _add(self, other: "DisplacementTangent") -> "DisplacementTangent":  # type: ignore[override]
        if self.order != other.order:
            raise ValueError("cannot add tangents with different orders")
        return DisplacementTangent(self.dx + other.dx, order=self.order)

    def __mul__(self, scalar: Scalar) -> "DisplacementTangent":
        return DisplacementTangent(self.dx * scalar, order=self.order)

    def norm(self) -> jax.Array:
        return jnp.linalg.norm(self.dx, axis=-1)


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class RawCoordinate(AutodiffCoordinate):
    r"""Unconstrained vector coordinate (Lie group element).

    Represents a raw :math:`\mathbb{R}^n` value treated as an element of
    the additive group :math:`(\mathbb{R}^n, +)`.  For :math:`n = 3` it is
    structurally identical to :class:`Displacement`, but denotes a plain
    coordinate value rather than a translation; it also boxes arbitrary
    feature vectors (e.g. a camera latent read by a virtual sensor).  The
    corresponding Lie algebra is :class:`RawCoordinateTangent`.

    Constructing with no arguments gives the 3D identity (zero) element::

        RawCoordinate()   # identity in R^3
        RawCoordinate(x)  # from a vector of any length

    Group operations (inherited from :class:`Coordinate`)::

        c1 @ c2     # composition (vector addition)
        c @ v       # translate a point
        ~c          # inverse (negated vector)
        c.log()     # -> RawCoordinateTangent  (trivial)
    """

    _x: jax.Array

    def __init__(self, _x: np.typing.ArrayLike = jnp.zeros([3], float)):
        self._x = _x if _is_jax_arrayish(_x) else jnp.asarray(_x, float)  # type: ignore[assignment]

    @property
    @Operation.define
    def x(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        return self._x

    @classmethod
    def make_random(cls, rng, bbox: Bbox | None = None, shape=(3,)):
        if bbox is None:
            x = jax.random.normal(rng, shape=shape)
        else:
            x = jax.random.uniform(rng, shape=shape) * (bbox.hi - bbox.lo) + bbox.lo
        return cls(x)

    def __invert__(self) -> "RawCoordinate":
        return RawCoordinate(-self.x)

    def _product(self, other: "RawCoordinate") -> "RawCoordinate":  # type: ignore[override]
        return RawCoordinate(self.x + other.x)

    def _action(self, vector: jax.Array) -> jax.Array:
        return vector + self.x

    def log(self) -> "RawCoordinateTangent":
        return RawCoordinateTangent(self.x)


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class RawCoordinateTangent(AutodiffCoordinateTangent):
    r"""Tangent vector of :class:`RawCoordinate` (Lie algebra element).

    Represents an element of the tangent space at the identity of the
    additive group :math:`(\mathbb{R}^n, +)`, stored as a vector.
    Since the group is a vector space, the exponential map is trivial.

    Constructing with no arguments gives the 3D zero element::

        RawCoordinateTangent()    # zero in R^3
        RawCoordinateTangent(dx)  # from a vector of any length

    Algebra operations (inherited from :class:`CoordinateTangent`)::

        tau.exp()       # -> RawCoordinate
        tau1 + tau2     # vector addition
        tau * s         # scalar multiplication
        tau.norm()      # Euclidean norm
        tau.jr(delta)   # right Jacobian (derived via autodiff)
        tau.jl(delta)   # left  Jacobian (derived via autodiff)
    """

    _dx: jax.Array
    order: int = dataclasses.field(default=1, metadata=dict(static=True))

    def __init__(
        self, _dx: np.typing.ArrayLike = jnp.zeros([3], float), *, order: int = 1
    ):
        self._dx = _dx if _is_jax_arrayish(_dx) else jnp.asarray(_dx, float)  # type: ignore[assignment]
        self.order = order

    @property
    @Operation.define
    def dx(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        return self._dx

    def _exp(self) -> RawCoordinate:
        return RawCoordinate(self.dx)

    def exp(self) -> RawCoordinate:  # type: ignore[override]
        return super().exp()  # type: ignore[return-value]

    def log(self) -> "RawCoordinateTangent":
        return super().log()  # type: ignore[return-value]

    def _add(self, other: "RawCoordinateTangent") -> "RawCoordinateTangent":  # type: ignore[override]
        if self.order != other.order:
            raise ValueError("cannot add tangents with different orders")
        return RawCoordinateTangent(self.dx + other.dx, order=self.order)

    def __mul__(self, scalar: Scalar) -> "RawCoordinateTangent":
        return RawCoordinateTangent(self.dx * scalar, order=self.order)

    def norm(self) -> jax.Array:
        return jnp.linalg.norm(self.dx, axis=-1)


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class ScalarDisplacement(AutodiffCoordinate):
    r"""1D translation (Lie group element).

    Represents an element of the scalar translation group
    :math:`(\mathbb{R}, +)`, e.g. the position of a prismatic joint.
    Composition adds scalars.  The corresponding Lie algebra is
    :class:`ScalarDisplacementTangent`.

    Constructing with no arguments gives the identity (zero) translation::

        ScalarDisplacement()   # identity
        ScalarDisplacement(x)  # from a scalar

    Group operations (inherited from :class:`Coordinate`)::

        d1 @ d2     # composition (scalar addition)
        d @ v       # translate a value
        ~d          # inverse (negated scalar)
        d.log()     # -> ScalarDisplacementTangent  (trivial)
    """

    x: jax.Array

    def __init__(self, x: np.typing.ArrayLike = 0.0):
        self.x = x if _is_jax_arrayish(x) else jnp.asarray(x, float)  # type: ignore[assignment]

    @classmethod
    def make_random(cls, rng, bbox: Bbox | None = None):
        if bbox is None:
            return cls(jax.random.normal(rng))
        return cls(jax.random.uniform(rng) * (bbox.hi - bbox.lo) + bbox.lo)

    def __invert__(self) -> "ScalarDisplacement":
        return ScalarDisplacement(-self.x)

    def _product(self, other: "ScalarDisplacement") -> "ScalarDisplacement":  # type: ignore[override]
        return ScalarDisplacement(self.x + other.x)

    def _action(self, vector: jax.Array) -> jax.Array:
        return vector + self.x

    def log(self) -> "ScalarDisplacementTangent":
        return ScalarDisplacementTangent(self.x)


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class ScalarDisplacementTangent(AutodiffCoordinateTangent):
    r"""Tangent vector of the 1D translation group (Lie algebra element).

    Represents an element of the tangent space at the identity of
    :math:`(\mathbb{R}, +)`, stored as a scalar, e.g. the velocity of a
    prismatic joint.  Since the group is a vector space, the exponential
    map is trivial.  The corresponding Lie group is
    :class:`ScalarDisplacement`.

    Constructing with no arguments gives the zero element::

        ScalarDisplacementTangent()    # zero
        ScalarDisplacementTangent(dx)  # from a scalar

    Algebra operations (inherited from :class:`CoordinateTangent`)::

        tau.exp()       # -> ScalarDisplacement
        tau1 + tau2     # vector addition
        tau * s         # scalar multiplication
        tau.norm()      # absolute value
        tau.jr(delta)   # right Jacobian (derived via autodiff)
        tau.jl(delta)   # left  Jacobian (derived via autodiff)
    """

    _dx: jax.Array
    order: int = dataclasses.field(default=1, metadata=dict(static=True))

    def __init__(self, _dx: np.typing.ArrayLike = 0.0, *, order: int = 1):
        self._dx = _dx if _is_jax_arrayish(_dx) else jnp.asarray(_dx, float)  # type: ignore[assignment]
        self.order = order

    @property
    @Operation.define
    def dx(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        return self._dx

    def _exp(self) -> ScalarDisplacement:
        return ScalarDisplacement(self.dx)

    def exp(self) -> ScalarDisplacement:  # type: ignore[override]
        return super().exp()  # type: ignore[return-value]

    def log(self) -> "ScalarDisplacementTangent":
        return super().log()  # type: ignore[return-value]

    def _add(self, other: "ScalarDisplacementTangent") -> "ScalarDisplacementTangent":  # type: ignore[override]
        if self.order != other.order:
            raise ValueError("cannot add tangents with different orders")
        return ScalarDisplacementTangent(self.dx + other.dx, order=self.order)

    def __mul__(self, scalar: Scalar) -> "ScalarDisplacementTangent":
        return ScalarDisplacementTangent(self.dx * scalar, order=self.order)

    def norm(self) -> jax.Array:
        return jnp.abs(self.dx)


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class ScalarTorque:
    tau: jax.Array

    def __init__(self, tau: np.typing.ArrayLike = 0.0):
        self.tau = tau if _is_jax_arrayish(tau) else jnp.asarray(tau, float)  # type: ignore[assignment]

    def __add__(self, other: "ScalarTorque") -> "ScalarTorque":
        return ScalarTorque(self.tau + other.tau)

    def __neg__(self) -> "ScalarTorque":
        return ScalarTorque(-self.tau)

    def __sub__(self, other: "ScalarTorque") -> "ScalarTorque":
        return ScalarTorque(self.tau - other.tau)

    def __mul__(self, scalar: Scalar) -> "ScalarTorque":
        return ScalarTorque(self.tau * scalar)  # type: ignore[operator]

    __rmul__ = __mul__

    def norm(self) -> jax.Array:
        return jnp.abs(self.tau)


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class ScalarForce:
    f: jax.Array

    def __init__(self, f: np.typing.ArrayLike = 0.0):
        self.f = f if _is_jax_arrayish(f) else jnp.asarray(f, float)  # type: ignore[assignment]

    def __add__(self, other: "ScalarForce") -> "ScalarForce":
        return ScalarForce(self.f + other.f)

    def __neg__(self) -> "ScalarForce":
        return ScalarForce(-self.f)

    def __sub__(self, other: "ScalarForce") -> "ScalarForce":
        return ScalarForce(self.f - other.f)

    def __mul__(self, scalar: Scalar) -> "ScalarForce":
        return ScalarForce(self.f * scalar)  # type: ignore[operator]

    __rmul__ = __mul__

    def norm(self) -> jax.Array:
        return jnp.abs(self.f)


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class Image:
    """An image: a rendered camera frame, or one derived from it.

    ``[height, width, 3]``, or ``[height, width]`` once reduced to a single
    channel.

    A sensor whose reading is a frame holds one directly::

        self.view = sensors.Virtual(render_camera(camera))

    Encode first if the reading is meant to be a feature vector -- that is a
    :class:`RawCoordinate`, not an ``Image``::

        self.latent = sensors.Virtual(RawCoordinate(encode_image(...)))

    Reach through :attr:`data` for the pixels, the way other boxed quantities
    expose ``.x`` or ``.theta``. The accessor is an operation, so it works on a
    symbolic image too.
    """

    _data: jax.Array

    @property
    @Operation.define
    def data(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        return self._data


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class Pose(AutodiffCoordinate):
    r"""SE(3) rigid transformation (Lie group element).

    Represents a rigid body pose (rotation + translation), stored
    internally as a :class:`Displacement` and a :class:`Rotation`.  The
    corresponding Lie algebra is :class:`PoseTangent`.  Group operations
    are expressed in terms of :class:`Rotation`.

    Constructing with no arguments gives the identity pose::

        Pose()                        # identity
        Pose(pos=p, rv=omega)         # from position and rotation vector
        Pose(pos=p, quat=q)           # from position and quaternion
        Pose(pos=p, axes=R)           # from position and rotation matrix

    Group operations (inherited from :class:`Coordinate`)::

        T1 @ T2     # composition
        T @ v       # transform a point
        ~T          # inverse
        T.log()     # -> PoseTangent  (6D twist)
        T @ delta    # adjoint map (derived via autodiff)
        T.jlog(delta)     # log-Jacobian  (derived via autodiff)
    """

    lin: Displacement
    rot: Rotation

    def __init__(
        self,
        *,
        lin: Displacement | None = None,
        rot: Rotation | None = None,
        pos: np.typing.ArrayLike = jnp.zeros([3], float),
        quat: np.typing.ArrayLike | None = None,
        axes: np.typing.ArrayLike | None = None,
        rv: np.typing.ArrayLike | None = None,
    ):
        self.lin = lin if lin is not None else Displacement(pos)
        self.rot = rot if rot is not None else Rotation(quat=quat, axes=axes, rv=rv)

    @property
    @Operation.define
    def pos(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        return self.lin.x

    @property
    def matrix(self) -> jax.Array:
        """4x4 homogeneous transform matrix. Supports batched inputs [..., 4, 4]."""
        # rotation: [..., 3, 3]
        rotation = jnp.swapaxes(self.rot.axes, -1, -2)
        # translation: [..., 3, 1]
        translation = self.pos[..., None]
        # top_rows: [..., 3, 4]
        top_rows = jnp.concatenate([rotation, translation], axis=-1)
        # bottom_row: [..., 1, 4] - construct without explicit shape unpacking
        # (avoids issues with symbolic arrays from effectful)
        batch_zeros = jnp.zeros_like(self.pos)  # [..., 3]
        batch_ones = jnp.ones_like(self.pos[..., :1])  # [..., 1]
        bottom_row = jnp.concatenate([batch_zeros, batch_ones], axis=-1)[..., None, :]
        # result: [..., 4, 4]
        return jnp.concatenate([top_rows, bottom_row], axis=-2)

    @property
    @Operation.define
    def quat(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        return self.rot.quat

    @property
    @Operation.define
    def axes(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        return self.rot.axes

    @property
    @Operation.define
    def unit_quat(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        return self.rot.unit_quat

    @property
    @Operation.define
    def rv(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        return self.rot.log().rv

    @property
    @Operation.define
    def angle(self) -> jax.Array:
        if isinstance(self, Term):
            raise NotHandled
        return jnp.linalg.norm(self.rv)

    @classmethod
    def from_matrix(cls, transform) -> "Pose":
        """Create Pose from 4x4 homogeneous transform. Supports batched inputs [..., 4, 4]."""
        return cls(
            pos=transform[..., :3, 3],
            rot=Rotation(axes=jnp.swapaxes(transform[..., :3, :3], -1, -2)),
        )

    @classmethod
    def make_random(cls, rng, bbox: Bbox | None = None) -> "Pose":
        return cls(
            lin=Displacement.make_random(jax.random.fold_in(rng, 0), bbox=bbox),
            rot=Rotation.make_random(jax.random.fold_in(rng, 1)),
        )

    @property
    def rotational(self) -> "Pose":
        return Pose(rot=self.rot)

    @property
    def translational(self) -> "Pose":
        return Pose(pos=self.pos)

    # ==================== Lie Group Operations ====================

    def __invert__(self) -> "Pose":
        rot_inv = ~self.rot
        return Pose(pos=-(rot_inv @ self.pos), rot=rot_inv)

    def _product(self, other: "Pose") -> "Pose":  # type: ignore[override]
        return Pose(pos=self.pos + self.rot @ other.pos, rot=self.rot @ other.rot)

    def _action(self, vector: jax.Array) -> jax.Array:
        return self.pos + self.rot @ vector

    def log(self) -> "PoseTangent":
        r"""SE(3) logarithm map (Eq. 173).

        .. math::
            \boldsymbol{\tau} = \text{Log}(\mathbf{M}) \triangleq
            \begin{bmatrix}
            \mathbf{V}^{-1}(\boldsymbol{\theta})\,\mathbf{t} \\
            \text{Log}(\mathbf{R})
            \end{bmatrix}

        where :math:`\mathbf{V}(\boldsymbol{\theta}) = \mathbf{J}_l(\boldsymbol{\theta})`
        is the SO(3) left Jacobian (Eq. 174 = Eq. 145).

        The angular part is :math:`\text{Log}(\mathbf{R})` directly.  For the
        linear part we need :math:`\mathbf{J}_l^{-1}(\boldsymbol{\theta})\,\mathbf{t}`.
        Rather than implementing :math:`\mathbf{V}^{-1}` explicitly, we reuse
        :meth:`Rotation.jlog` which computes
        :math:`\mathbf{J}_r^{-1}(\text{Log}(\mathcal{X}))\,\delta`, and evaluate
        it at :math:`\mathbf{R}^{-1}`:

        .. math::
            \mathbf{J}_r^{-1}(\text{Log}(\mathbf{R}^{-1}))\,\mathbf{t}
            = \mathbf{J}_r^{-1}(-\boldsymbol{\theta})\,\mathbf{t}
            = \mathbf{J}_l^{-1}(\boldsymbol{\theta})\,\mathbf{t}

        using the identity :math:`\mathbf{J}_r(-\boldsymbol{\tau})
        = \mathbf{J}_l(\boldsymbol{\tau})` (Eq. 76).
        """
        linear = cast(RotationTangent, (~self.rot).jlog(RotationTangent(self.pos)))
        return PoseTangent(linear.rv, self.rot.log())


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class PoseTangent(AutodiffCoordinateTangent):
    r"""$\mathfrak{se}(3)$ tangent vector (Lie algebra element).

    Represents an element of the tangent space at the identity of SE(3),
    stored as a 6D twist with linear and angular components.  The
    corresponding Lie group is :class:`Pose`.  The exponential and
    logarithm maps are expressed in terms of :class:`RotationTangent`.

    Constructing with no arguments gives the zero element::

        PoseTangent()                  # zero
        PoseTangent(linear, angular)   # from 3D linear and angular parts

    Algebra operations (inherited from :class:`CoordinateTangent`)::

        tau.exp()       # -> Pose
        tau1 + tau2     # vector addition
        tau * s         # scalar multiplication
        tau.norm()      # twist norm (6D vector norm)
        tau.jr(delta)   # right Jacobian (derived via autodiff)
        tau.jl(delta)   # left  Jacobian (derived via autodiff)

    Additional methods::

        tau.linear      # linear component (:class:`DisplacementTangent`)
        tau.angular     # angular component (:class:`RotationTangent`)
    """

    _linear: DisplacementTangent
    _angular: RotationTangent
    order: int = dataclasses.field(default=1, metadata=dict(static=True))

    def __init__(
        self,
        _linear: np.typing.ArrayLike | DisplacementTangent | None = None,
        _angular: np.typing.ArrayLike | RotationTangent = RotationTangent(),
        *,
        order: int = 1,
    ):
        self._linear = (
            _linear
            if isinstance(_linear, DisplacementTangent)
            else DisplacementTangent(jnp.zeros([3]) if _linear is None else _linear)
        )
        self._angular = (
            _angular
            if isinstance(_angular, RotationTangent)
            else RotationTangent(_angular)
        )
        self.order = order

    @property
    @Operation.define
    def linear(self) -> DisplacementTangent:
        if isinstance(self, Term):
            raise NotHandled
        return self._linear

    @property
    @Operation.define
    def angular(self) -> RotationTangent:
        if isinstance(self, Term):
            raise NotHandled
        return self._angular

    # ==================== Class Methods ====================

    # ==================== Lie Group Operations ====================

    def _exp(self) -> Pose:
        r"""SE(3) exponential map (Eq. 172).

        .. math::
            \mathbf{M} = \text{Exp}(\boldsymbol{\tau}) \triangleq
            \begin{bmatrix}
            \text{Exp}(\boldsymbol{\theta}) & \mathbf{V}(\boldsymbol{\theta})\,\boldsymbol{\rho} \\
            \mathbf{0} & 1
            \end{bmatrix}

        where :math:`\boldsymbol{\tau} = [\boldsymbol{\rho},\,\boldsymbol{\theta}]^\top`
        and :math:`\mathbf{V}(\boldsymbol{\theta}) = \mathbf{J}_l(\boldsymbol{\theta})`
        is the SO(3) left Jacobian (Eq. 174 = Eq. 145).

        The rotation is computed via :meth:`RotationTangent.exp`.  The
        translation :math:`\mathbf{V}(\boldsymbol{\theta})\,\boldsymbol{\rho}`
        is computed by applying the SO(3) left Jacobian
        :meth:`RotationTangent.jl` to the linear component, avoiding an
        explicit :math:`\mathbf{V}` implementation.
        """
        translation = cast(
            RotationTangent, self.angular.jl(RotationTangent(self.linear.dx))
        )
        return Pose(pos=translation.rv, rot=self.angular.exp())

    def exp(self) -> Pose:  # type: ignore[override]
        return super().exp()  # type: ignore[return-value]

    def log(self) -> "PoseTangent":
        return super().log()  # type: ignore[return-value]

    # ==================== Arithmetic Operations ====================

    def _add(self, other: "PoseTangent") -> "PoseTangent":  # type: ignore[override]
        if self.order != other.order:
            raise ValueError("cannot add tangents with different orders")
        return PoseTangent(
            self.linear + other.linear, self.angular + other.angular, order=self.order
        )

    def __mul__(self, scalar: Scalar) -> "PoseTangent":
        return PoseTangent(
            self.linear * scalar, self.angular * scalar, order=self.order
        )

    def norm(self) -> jax.Array:
        """Compute the norm of the tangent vector.

        Returns:
            Scalar norm of the 6D tangent vector.
        """
        return jnp.linalg.norm(
            jnp.concatenate([self.linear.dx, self.angular.rv], axis=-1), axis=-1
        )


def _is_coordinate(x) -> bool:
    return isinstance(x, Coordinate) or (
        isinstance(x, Term) and issubclass(typeof(x), Coordinate)
    )


def _is_tangent(x) -> bool:
    return isinstance(x, CoordinateTangent) or (
        isinstance(x, Term) and issubclass(typeof(x), CoordinateTangent)
    )


def _is_effort(x) -> bool:
    return isinstance(x, ScalarTorque | ScalarForce) or (
        isinstance(x, Term) and issubclass(typeof(x), ScalarTorque | ScalarForce)
    )


def _is_group(x) -> bool:
    return _is_coordinate(x) or _is_tangent(x)


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class ProductCoordinate[P](Coordinate):
    r"""Direct product of coordinates (Lie group element).

    Wraps a pytree whose leaves are :class:`Coordinate`\ s; all group
    operations act leaf-wise::

        ProductCoordinate({"a": Pose(...), "b": Rotation(...)})  # M1 x M2
    """

    parts: P

    def __init__(self, parts: P):
        self.parts = parts
        # validate only if all leaves are group types (i.e. there are no opaque
        # terms that could return pytrees containing groups, and no placeholders
        # from pytree unflattening)
        leaves = jax.tree.leaves(parts, is_leaf=_is_group)
        if all(isinstance(x, (Coordinate, CoordinateTangent, Term)) for x in leaves):
            if not all(map(_is_coordinate, leaves)):
                raise ValueError("leaves must be Coordinates")

    def __invert__(self) -> "ProductCoordinate":
        return ProductCoordinate(
            jax.tree.map(lambda a: ~a, self.parts, is_leaf=_is_group)
        )

    def _product(self, other: "ProductCoordinate") -> "ProductCoordinate":  # type: ignore[override]
        return ProductCoordinate(
            jax.tree.map(lambda a, b: a @ b, self.parts, other.parts, is_leaf=_is_group)
        )

    def _action(self, vector: jax.Array) -> jax.Array:
        raise TypeError("ProductCoordinate has no canonical action on vectors")

    def log(self) -> "ProductCoordinateTangent":
        return ProductCoordinateTangent(
            jax.tree.map(lambda a: a.log(), self.parts, is_leaf=_is_group)
        )

    def _adjoint(
        self,
        tangent: "ProductCoordinateTangent",  # type: ignore[override]
    ) -> "ProductCoordinateTangent":
        return ProductCoordinateTangent(
            jax.tree.map(
                lambda a, t: a @ t, self.parts, tangent.parts, is_leaf=_is_group
            )
        )

    def jlog(self, tangent: "ProductCoordinateTangent") -> "ProductCoordinateTangent":  # type: ignore[override]
        return ProductCoordinateTangent(
            jax.tree.map(
                lambda a, t: a.jlog(t), self.parts, tangent.parts, is_leaf=_is_group
            )
        )


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class ProductCoordinateTangent[P](AutodiffCoordinateTangent):
    r"""Direct product of tangent vectors (Lie algebra element).

    The tangent space of :class:`ProductCoordinate`: a pytree of
    :class:`CoordinateTangent` leaves sharing a common ``order``; all
    operations act leaf-wise.
    """

    parts: P

    def __init__(self, parts: P):
        self.parts = parts
        leaves = jax.tree.leaves(parts, is_leaf=_is_group)
        if all(isinstance(x, (Coordinate, CoordinateTangent, Term)) for x in leaves):
            if not all(map(_is_tangent, leaves)):
                raise ValueError("leaves must be CoordinateTangents")

    def exp(self) -> Coordinate:
        parts = jax.tree.map(lambda t: t.exp(), self.parts, is_leaf=_is_group)
        leaves = jax.tree.leaves(parts, is_leaf=_is_group)
        if leaves and not any(map(_is_coordinate, leaves)):
            return ProductCoordinateTangent(parts)  # type: ignore[return-value]
        return ProductCoordinate(parts)

    def _exp(self) -> Coordinate:
        return self.exp()

    def log(self) -> "ProductCoordinateTangent":
        return ProductCoordinateTangent(
            jax.tree.map(lambda t: t.log(), self.parts, is_leaf=_is_group)
        )

    def _add(self, other: "ProductCoordinateTangent") -> "ProductCoordinateTangent":  # type: ignore[override]
        return ProductCoordinateTangent(
            jax.tree.map(lambda a, b: a + b, self.parts, other.parts, is_leaf=_is_group)
        )

    def __mul__(self, scalar: Scalar) -> "ProductCoordinateTangent":
        return ProductCoordinateTangent(
            jax.tree.map(lambda t: t * scalar, self.parts, is_leaf=_is_group)
        )

    def norm(self) -> jax.Array:
        leaves = jax.tree.leaves(self.parts, is_leaf=_is_group)
        return jnp.sqrt(sum((jnp.square(t.norm()) for t in leaves), jnp.asarray(0.0)))

    def jr(self, delta: "ProductCoordinateTangent") -> "ProductCoordinateTangent":  # type: ignore[override]
        return ProductCoordinateTangent(
            jax.tree.map(
                lambda t, dt: t.jr(dt), self.parts, delta.parts, is_leaf=_is_group
            )
        )

    def jl(self, delta: "ProductCoordinateTangent") -> "ProductCoordinateTangent":  # type: ignore[override]
        return ProductCoordinateTangent(
            jax.tree.map(
                lambda t, dt: t.jl(dt), self.parts, delta.parts, is_leaf=_is_group
            )
        )


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class TangentBundle[X: Coordinate, DX: CoordinateTangent](Coordinate):
    r"""Point of a tangent bundle :math:`TM \cong M \times \mathfrak{m}`.

    Pairs a base point ``x`` on a :class:`Coordinate` manifold with a fiber
    element ``dx`` in its Lie algebra, as a direct product group: base points
    compose, fibers add.
    """

    x: X
    dx: DX

    def __init__(self, x: X, dx: DX):
        self.x = x
        self.dx = dx
        # validate only group-typed components (i.e. no opaque terms that could
        # return groups, and no placeholders from pytree unflattening)
        if isinstance(x, (Coordinate, CoordinateTangent, Term)):
            if not _is_coordinate(x):
                raise ValueError("x must be a Coordinate")
        if isinstance(dx, (Coordinate, CoordinateTangent, Term)):
            if not _is_tangent(dx):
                raise ValueError("dx must be a CoordinateTangent")

    def __invert__(self) -> "TangentBundle":
        return TangentBundle(~self.x, -self.dx)

    def _product(self, other: "TangentBundle") -> "TangentBundle":  # type: ignore[override]
        return TangentBundle(self.x @ other.x, self.dx + other.dx)

    def _action(self, vector: jax.Array) -> jax.Array:
        raise TypeError("TangentBundle has no canonical action on vectors")

    def log(self) -> "TangentBundleTangent":
        return TangentBundleTangent(self.x.log(), self.dx.log())

    def _adjoint(self, tangent: "TangentBundleTangent") -> "TangentBundleTangent":  # type: ignore[override]
        return TangentBundleTangent(self.x @ tangent.dx, tangent.ddx)

    def jlog(self, tangent: "TangentBundleTangent") -> "TangentBundleTangent":  # type: ignore[override]
        return TangentBundleTangent(self.x.jlog(tangent.dx), tangent.ddx)

    def __sub__(self, other: "TangentBundle") -> "TangentBundleTangent":  # type: ignore[override]
        return super().__sub__(other)  # type: ignore[return-value]


@jax.tree_util.register_dataclass
@dataclasses.dataclass
class TangentBundleTangent[DX: CoordinateTangent, DDX: CoordinateTangent](
    AutodiffCoordinateTangent
):
    r"""Tangent of a :class:`TangentBundle`.

    Pairs a base perturbation ``dx`` with a fiber perturbation ``ddx``, with
    ``ddx`` one ``order`` above ``dx``; all operations act component-wise.
    """

    dx: DX
    ddx: DDX

    def __init__(self, dx: DX, ddx: DDX):
        self.dx = dx
        self.ddx = ddx
        for name, t in (("dx", dx), ("ddx", ddx)):
            if isinstance(t, (Coordinate, CoordinateTangent, Term)):
                if not _is_tangent(t):
                    raise ValueError(f"{name} must be a CoordinateTangent")

    def exp(self) -> Coordinate:
        x, dx = self.dx.exp(), self.ddx.exp()
        if _is_coordinate(x):
            return TangentBundle(x, dx)  # type: ignore[type-var]
        return TangentBundleTangent(x, dx)  # type: ignore[return-value, type-var]

    def _exp(self) -> Coordinate:
        return self.exp()

    def log(self) -> "TangentBundleTangent":
        return TangentBundleTangent(self.dx.log(), self.ddx.log())

    def _add(self, other: "TangentBundleTangent") -> "TangentBundleTangent":  # type: ignore[override]
        return TangentBundleTangent(self.dx + other.dx, self.ddx + other.ddx)

    def __mul__(self, scalar: Scalar) -> "TangentBundleTangent":
        return TangentBundleTangent(self.dx * scalar, self.ddx * scalar)

    def norm(self) -> jax.Array:
        return jnp.sqrt(jnp.square(self.dx.norm()) + jnp.square(self.ddx.norm()))

    def jr(self, delta: "TangentBundleTangent") -> "TangentBundleTangent":  # type: ignore[override]
        return TangentBundleTangent(self.dx.jr(delta.dx), self.ddx.jr(delta.ddx))

    def jl(self, delta: "TangentBundleTangent") -> "TangentBundleTangent":  # type: ignore[override]
        return TangentBundleTangent(self.dx.jl(delta.dx), self.ddx.jl(delta.ddx))


@Operation.define
def context_pose() -> Pose:
    """Return the relative transformation matrix of a component.

    :returns: 4x4 transformation matrix
    :rtype: jax.Array
    """
    return Pose()


@contextlib.contextmanager
def frame(pose: Pose | None = None):
    """
    Context manager to set the current transformation context.

    With no argument a fresh symbolic pose is opened, so ``with frame() as
    pose:`` both installs the context and yields the pose it binds.
    """
    if pose is None:
        pose = defop(Pose)()

    with handler({context_pose: lambda: pose}):
        yield pose

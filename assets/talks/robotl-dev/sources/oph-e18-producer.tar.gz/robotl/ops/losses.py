from abc import ABC, abstractmethod

import effectful.handlers.jax.numpy as jnp
import jax
from effectful.ops.types import Expr
from flax import struct
from jaxtyping import ScalarLike

from robotl.ops.coords import distance


class Loss(ABC):
    weight: ScalarLike

    @property
    @abstractmethod
    def value(self) -> jax.Array: ...


class Maximize(struct.PyTreeNode, Loss):
    expr: Expr
    weight: ScalarLike = struct.field(pytree_node=False, default=1)

    @property
    def value(self):
        return -self.weight * jnp.sum(self.expr)


class Minimize(struct.PyTreeNode, Loss):
    expr: Expr
    weight: ScalarLike = struct.field(pytree_node=False, default=1)

    @property
    def value(self):
        return self.weight * jnp.sum(self.expr)


class Nullify(struct.PyTreeNode, Loss):
    expr: Expr
    weight: ScalarLike = struct.field(pytree_node=False, default=1)

    @property
    def value(self):
        # smoothed norm: ‖·‖ itself has a NaN gradient at zero
        return self.weight * jnp.sqrt(jnp.sum(self.expr**2) + 1e-12)


class Equalize(struct.PyTreeNode, Loss):
    expr1: Expr
    expr2: Expr
    weight: ScalarLike = struct.field(pytree_node=False, default=1)

    @property
    def value(self):
        return self.weight * distance(self.expr1, self.expr2)


class KeepBelow(struct.PyTreeNode, Loss):
    expr1: Expr
    expr2: Expr
    weight: ScalarLike = struct.field(pytree_node=False, default=1)

    @property
    def value(self):
        return self.weight * jnp.maximum(0, self.expr1 - self.expr2)


class KeepAbove(struct.PyTreeNode, Loss):
    expr1: Expr
    expr2: Expr
    weight: ScalarLike = struct.field(pytree_node=False, default=1)

    @property
    def value(self):
        return self.weight * jnp.maximum(0, self.expr2 - self.expr1)

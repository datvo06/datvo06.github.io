"""Tendon definitions for RoboTL components."""

import dataclasses
import math
from collections.abc import Sequence

import jax

from robotl.ops import shapes
from robotl.ops.actuators import Actuatable
from robotl.ops.coords import (
    ScalarDisplacement,
    ScalarDisplacementTangent,
    ScalarForce,
)
from robotl.ops.id import NULL_ID, Id, make_id
from robotl.ops.joints import Joint
from robotl.ops.syntax import Component, LegacyComponent, Port, Pose


@dataclasses.dataclass(frozen=True)
class TendonWrap:
    """Route over an existing analytic sphere or cylinder, without extra mass.

    Both the component and side port must belong to the owning model graph.
    Compiler graph lookup resolves IDs without recursive component ownership.
    The dataclass constructor also supports effectful's value reconstruction.
    """

    component_id: Id
    side_id: Id

    @classmethod
    def make(cls, component: Component, side: Port) -> "TendonWrap":
        """Reference geometry and a branch selector already owned by the graph."""
        return cls(component.id, side.id)


class TendonPulley(LegacyComponent):
    """Simple wrap geometry (cylinder) with a stable geom identity."""

    def __init__(self, radius: float = 0.03, thickness: float = 0.01):
        super().__init__(name="TendonPulley")
        self.shape = shapes.cylinder(r=radius, h=thickness)
        # disable collision for MJX as it doesn't support cylinder collisions
        self.disable_collision = True
        self.base = self.place(Port())
        self.side = self.place(Port(), Pose(pos=[radius, 0, thickness / 2]))


@dataclasses.dataclass(kw_only=True)
class Tendon:
    """Base class for all tendons."""

    stiffness: jax.typing.ArrayLike = 0
    limit_stiffness: jax.typing.ArrayLike = 0
    damping: jax.typing.ArrayLike = 0
    rest_length: (
        jax.typing.ArrayLike | tuple[jax.typing.ArrayLike, jax.typing.ArrayLike]
    ) = 0
    """A scalar spring rest length, or two endpoints of a force-free deadband."""
    offset: jax.typing.ArrayLike = 0
    range: None | tuple[jax.typing.ArrayLike, jax.typing.ArrayLike] = None
    width: jax.typing.ArrayLike | None = None
    """Drawn radius in metres; rendering only."""
    color: Sequence[float] | None = None
    """Drawn RGBA; rendering only."""
    id: Id = NULL_ID

    def __post_init__(self):
        if self.id == NULL_ID:
            self.id = make_id()


@dataclasses.dataclass
class SpatialTendon(
    Tendon, Actuatable[ScalarDisplacement, ScalarDisplacementTangent, ScalarForce]
):
    """Spatial tendon routed over sites and wrap geoms.

    An actuator on a spatial tendon drives its length: the cable's length is a
    :class:`~robotl.ops.coords.ScalarDisplacement`, its rate a
    :class:`~robotl.ops.coords.ScalarDisplacementTangent` and the pull a
    :class:`~robotl.ops.coords.ScalarForce`.

    Args:
        path: Routing entries; first/last must be Port sites. Use TendonPulley
            for wrap segments.
        stiffness: Spring stiffness driving the tendon toward rest_length.
    """

    q_type, dq_type, frc_type = (
        ScalarDisplacement,
        ScalarDisplacementTangent,
        ScalarForce,
    )

    path: Sequence[Port | TendonPulley | TendonWrap]
    slack_length: float | None = None
    """Cut a tension-only cable to the neutral route plus this slack, in metres.

    When set, native compilation measures the assembled reference route once
    and replaces rest_length with the deadband (0, reference_length + slack).
    Damping must be zero: native viscous damping also acts on a slack cable.
    Omit this for an explicitly measured rest_length or a conventional spring.
    """

    def __post_init__(self):
        needs_init = self.id == NULL_ID
        super().__post_init__()
        if needs_init:
            if self.slack_length is not None:
                if not math.isfinite(self.slack_length) or self.slack_length < 0:
                    raise ValueError("slack_length must be finite and nonnegative")
                if self.damping != 0 or self.offset != 0:
                    raise ValueError(
                        "a reference-cut cable requires zero damping and offset"
                    )
                if isinstance(self.rest_length, tuple) or self.rest_length != 0:
                    raise ValueError(
                        "slack_length and explicit rest_length are exclusive"
                    )
            if len(self.path) < 2:
                raise ValueError("tendon path must contain at least two entries")
            if any(
                not isinstance(entry, Port | TendonPulley | TendonWrap)
                for entry in self.path
            ):
                raise TypeError("spatial paths require sites or analytic wraps")
            if not isinstance(self.path[0], Port) or not isinstance(
                self.path[-1], Port
            ):
                raise TypeError("spatial tendon endpoints must be Port sites")


@dataclasses.dataclass
class FixedTendon(Tendon):
    """Fixed tendon that couples joint positions directly (no spatial routing).

    One that declares neither ``width`` nor ``color`` is a plain joint
    coupling and is not drawn; a cable declares either, and is drawn through
    its joints with ``gear_ratios`` as moment arms in metres.

    Args:
        joints: Ordered joints to couple.
        gear_ratios: Per-joint coefficients (defaults to 1.0).
        stiffness: Spring stiffness driving the tendon toward rest_length.
    """

    joints: Sequence[Joint]
    gear_ratios: Sequence[jax.typing.ArrayLike] | None = None

    def __post_init__(self):
        needs_init = self.id == NULL_ID
        super().__post_init__()
        if needs_init:
            if len(self.joints) == 0:
                raise ValueError("fixed tendon must reference at least one joint")
            if self.gear_ratios is None:
                self.gear_ratios = [1.0 for _ in self.joints]
            if len(self.gear_ratios) != len(self.joints):
                raise ValueError("gear_ratios must match joints length")

"""Actuator definitions for RoboTL components.

This module defines various actuator types that can control component states.
"""

import abc
import dataclasses

import jax
from effectful.ops.syntax import defop
from effectful.ops.types import NotHandled

from robotl.ops.coords import (
    Angle,
    AngleTangent,
    Coordinate,
    CoordinateTangent,
    ScalarDisplacement,
    ScalarDisplacementTangent,
    ScalarForce,
    ScalarTorque,
)
from robotl.ops.id import Id, make_id

type ControlValue = (
    Angle
    | AngleTangent
    | ScalarDisplacement
    | ScalarDisplacementTangent
    | ScalarTorque
    | ScalarForce
)


class Actuatable[
    Q: Coordinate,
    DQ: CoordinateTangent,
    F: ScalarTorque | ScalarForce,
](abc.ABC):
    """Something an actuator can drive: a joint or a tendon.

    Subclasses set ``q_type``, ``dq_type`` and ``frc_type`` to the coordinate,
    tangent and force types of the driven quantity.
    """

    id: Id
    q_type: type[Q]
    dq_type: type[DQ]
    frc_type: type[F]


class Actuator[
    Q: Coordinate,
    DQ: CoordinateTangent,
    F: ScalarTorque | ScalarForce,
](abc.ABC):
    id: Id
    target: Actuatable[Q, DQ, F]

    @property
    @abc.abstractmethod
    def quantity(self) -> type[ControlValue]:
        """Actuator control signal type."""

    @defop
    def set(self, value: ControlValue) -> None:
        raise NotHandled

    @defop
    def _power(self) -> jax.Array:
        raise NotHandled

    power = property(_power)


@dataclasses.dataclass
class Position[Q: Coordinate, DQ: CoordinateTangent, F: ScalarTorque | ScalarForce](
    Actuator[Q, DQ, F]
):
    """Position servo on a joint or a tendon.

    :param target: What the servo tracks. A :class:`~robotl.ops.joints.Joint`
        tracks that joint's position; a
        :class:`~robotl.ops.tendons.SpatialTendon` tracks the cable's
        length, the way a winch spooling to a setpoint does.
    """

    target: Actuatable[Q, DQ, F]

    gear: jax.typing.ArrayLike = 1
    forcerange: None | tuple[jax.typing.ArrayLike, jax.typing.ArrayLike] = None
    ctrlrange: None | tuple[jax.typing.ArrayLike, jax.typing.ArrayLike] = None
    kp: jax.typing.ArrayLike = 1
    kv: jax.typing.ArrayLike = 0

    id: Id = dataclasses.field(default_factory=make_id)

    @property
    def quantity(self) -> type[Q]:  # type: ignore[override]  # Actuatable quantities are ControlValue members
        return self.target.q_type


@dataclasses.dataclass
class Velocity[Q: Coordinate, DQ: CoordinateTangent, F: ScalarTorque | ScalarForce](
    Actuator[Q, DQ, F]
):
    """Velocity servo on a joint or a tendon.

    :param target: What the servo tracks. A :class:`~robotl.ops.joints.Joint`
        tracks that joint's velocity; a
        :class:`~robotl.ops.tendons.SpatialTendon` tracks the rate the
        cable pays out or reels in.
    """

    target: Actuatable[Q, DQ, F]

    gear: jax.typing.ArrayLike = 1
    forcerange: None | tuple[jax.typing.ArrayLike, jax.typing.ArrayLike] = None
    ctrlrange: None | tuple[jax.typing.ArrayLike, jax.typing.ArrayLike] = None
    kv: jax.typing.ArrayLike = 0

    id: Id = dataclasses.field(default_factory=make_id)

    @property
    def quantity(self) -> type[DQ]:  # type: ignore[override]  # Actuatable quantities are ControlValue members
        return self.target.dq_type


@dataclasses.dataclass
class Force[Q: Coordinate, DQ: CoordinateTangent, F: ScalarTorque | ScalarForce](
    Actuator[Q, DQ, F]
):
    """Motor driving a joint or pulling a tendon.

    :param target: What the motor acts on. A :class:`~robotl.ops.joints.Joint`
        drives that joint directly; a
        :class:`~robotl.ops.tendons.SpatialTendon` pulls the cable, the way a
        winch does.
    """

    target: Actuatable[Q, DQ, F]

    gear: jax.typing.ArrayLike = 1
    forcerange: None | tuple[jax.typing.ArrayLike, jax.typing.ArrayLike] = None
    ctrlrange: None | tuple[jax.typing.ArrayLike, jax.typing.ArrayLike] = None

    id: Id = dataclasses.field(default_factory=make_id)

    @property
    def quantity(self) -> type[F]:  # type: ignore[override]  # Actuatable quantities are ControlValue members
        return self.target.frc_type

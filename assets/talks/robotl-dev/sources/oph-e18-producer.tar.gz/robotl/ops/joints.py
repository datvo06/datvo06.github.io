"""Joint definitions for RoboTL components.

This module defines various joint types that can connect components together.
"""

import abc
import dataclasses

import effectful.handlers.jax.numpy as jnp
import jax

from robotl.internals.utils import normalized
from robotl.ops.actuators import Actuatable
from robotl.ops.coords import (
    Angle,
    AngleTangent,
    Coordinate,
    CoordinateTangent,
    Rotation,
    RotationTangent,
    ScalarDisplacement,
    ScalarDisplacementTangent,
    ScalarForce,
    ScalarTorque,
)
from robotl.ops.id import NULL_ID, Id, make_id
from robotl.ops.syntax import Port, Pose, assert_transform


class Joint(abc.ABC):
    a: Port
    b: Port
    id: Id
    damping: jax.typing.ArrayLike
    armature: jax.typing.ArrayLike
    frictionloss: jax.typing.ArrayLike


class DofJoint[Q: Coordinate, DQ: CoordinateTangent](Joint):
    """Joint with degrees of freedom, positioned by ``Q`` and moving in ``DQ``."""

    q_type: type[Q]
    dq_type: type[DQ]


@dataclasses.dataclass(frozen=True)
class JointSpring:
    """A passive spring pulling a joint toward ``rest``.

    The spring is a property of the mechanism, so ``rest`` is required and
    independent of the pose the joint is built at: the same spring behaves the
    same way whatever ``theta0`` its joint was posed with.

    Damping stays on the joint, where MuJoCo keeps it: one value per degree of
    freedom, whatever drives it.

    :param stiffness: Spring stiffness.
    :param rest: Joint value the spring pulls toward, an angle for
        :class:`Hinge` and a displacement for :class:`Slide`.
    """

    stiffness: jax.typing.ArrayLike
    rest: jax.typing.ArrayLike


def _require_ports(j):
    if not isinstance(j.a, Port):
        raise TypeError("joint can only connect ports, not", j.a)
    if not isinstance(j.b, Port):
        raise TypeError("joint can only connect ports, not", j.b)


@dataclasses.dataclass
class Weld(Joint):
    a: Port
    b: Port
    pose: Pose = dataclasses.field(default_factory=Pose)
    id: Id = NULL_ID

    def __post_init__(self):
        if self.id == NULL_ID:
            self.id = make_id()
            _require_ports(self)
            assert_transform(self.a, self.b, self.pose)


@dataclasses.dataclass
class Hinge2(
    DofJoint[Angle, AngleTangent], Actuatable[Angle, AngleTangent, ScalarTorque]
):
    """Similar to Hinge, but does not use theta0 to set the initial pose."""

    q_type, dq_type, frc_type = Angle, AngleTangent, ScalarTorque

    a: Port
    b: Port
    axis: jax.Array = dataclasses.field(default_factory=lambda: jnp.array([0, 0, 1]))
    theta0: float = 0
    range: None | tuple[jax.typing.ArrayLike, jax.typing.ArrayLike] = None
    damping: jax.typing.ArrayLike = 0
    armature: jax.typing.ArrayLike = 0
    frictionloss: jax.typing.ArrayLike = 0
    spring: JointSpring | None = None
    id: Id = NULL_ID

    def __post_init__(self):
        if self.id == NULL_ID:
            self.id = make_id()
            _require_ports(self)


@dataclasses.dataclass
class Hinge(
    DofJoint[Angle, AngleTangent], Actuatable[Angle, AngleTangent, ScalarTorque]
):
    q_type, dq_type, frc_type = Angle, AngleTangent, ScalarTorque

    a: Port
    b: Port
    axis: jax.Array = dataclasses.field(default_factory=lambda: jnp.array([0, 0, 1]))
    theta0: float = 0
    range: None | tuple[jax.typing.ArrayLike, jax.typing.ArrayLike] = None
    damping: jax.typing.ArrayLike = 0
    armature: jax.typing.ArrayLike = 0
    frictionloss: jax.typing.ArrayLike = 0
    spring: JointSpring | None = None
    id: Id = NULL_ID

    def __post_init__(self):
        if self.id == NULL_ID:
            self.id = make_id()
            _require_ports(self)
            axis = normalized(self.axis)
            theta0 = (self.theta0 + jnp.pi) % (2 * jnp.pi) - jnp.pi
            assert_transform(self.a, self.b, Pose(rv=theta0 * axis))


@dataclasses.dataclass
class Ball(DofJoint[Rotation, RotationTangent]):
    q_type, dq_type = Rotation, RotationTangent

    a: Port
    b: Port
    pose0: Pose = dataclasses.field(default_factory=Pose)
    range: None | jax.typing.ArrayLike = None
    damping: jax.typing.ArrayLike = 0
    armature: jax.typing.ArrayLike = 0
    frictionloss: jax.typing.ArrayLike = 0
    id: Id = NULL_ID

    def __post_init__(self):
        if self.id == NULL_ID:
            self.id = make_id()
            _require_ports(self)
            assert_transform(self.a, self.b, self.pose0.rotational)


@dataclasses.dataclass
class Slide(
    DofJoint[ScalarDisplacement, ScalarDisplacementTangent],
    Actuatable[ScalarDisplacement, ScalarDisplacementTangent, ScalarForce],
):
    q_type, dq_type, frc_type = (
        ScalarDisplacement,
        ScalarDisplacementTangent,
        ScalarForce,
    )

    a: Port
    b: Port
    axis: jax.Array
    pose: Pose = dataclasses.field(default_factory=Pose)
    range: None | tuple[jax.typing.ArrayLike, jax.typing.ArrayLike] = None
    damping: jax.typing.ArrayLike = 0
    armature: jax.typing.ArrayLike = 0
    frictionloss: jax.typing.ArrayLike = 0
    spring: JointSpring | None = None
    id: Id = NULL_ID

    def __post_init__(self):
        if self.id == NULL_ID:
            self.id = make_id()
            _require_ports(self)
            assert_transform(self.a, self.b, self.pose)

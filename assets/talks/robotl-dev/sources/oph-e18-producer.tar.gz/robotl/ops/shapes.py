"""CAD operations for RoboTL using OpenSCAD primitives.

This module provides basic 3D modeling operations including primitive creation,
boolean operations, and transformations.
"""

import abc

import effectful.handlers.jax.numpy as jnp
import numpy as np
from effectful.ops.syntax import defdata, defop
from effectful.ops.types import NotHandled, Term
from jax.scipy.spatial.transform import Rotation

from robotl.internals.utils import Mesh, Polygon
from robotl.ops.syntax import Pose


class Shape(abc.ABC):
    @abc.abstractmethod
    def __add__(self, other: "Shape") -> "Shape":
        raise NotImplementedError

    @abc.abstractmethod
    def __and__(self, other: "Shape") -> "Shape":
        raise NotImplementedError

    @abc.abstractmethod
    def __sub__(self, other: "Shape") -> "Shape":
        raise NotImplementedError

    @abc.abstractmethod
    def __radd__(self, other: "Shape") -> "Shape":
        raise NotImplementedError

    @abc.abstractmethod
    def __rand__(self, other: "Shape") -> "Shape":
        raise NotImplementedError

    @abc.abstractmethod
    def __rsub__(self, other: "Shape") -> "Shape":
        raise NotImplementedError


@defdata.register(Shape)
class _ShapeTerm[T: Shape](Term[T], Shape):
    def __init__(self, ty, op, *args, **kwargs):
        self._op = op
        self._args = args
        self._kwargs = kwargs

    op = property(lambda self: self._op)
    args = property(lambda self: self._args)
    kwargs = property(lambda self: self._kwargs)

    def __add__(self, other: Shape) -> Shape:
        return union(self, other)

    def __and__(self, other: Shape) -> Shape:
        return intersection(self, other)

    def __sub__(self, other: Shape) -> Shape:
        return difference(self, other)

    def __radd__(self, other: Shape) -> Shape:
        return union(other, self)

    def __rand__(self, other: Shape) -> Shape:
        return intersection(other, self)

    def __rsub__(self, other: Shape) -> Shape:
        return difference(other, self)


@defop
def union(*args: Shape) -> Shape:
    """Construct the union of CAD geometries.

    :param args: CAD geometries
    :returns: Union of the geometries
    """
    raise NotHandled


@defop
def difference(a: Shape, b: Shape) -> Shape:
    """Construct the set difference of CAD geometries.

    :param a: Geometry from which to subtract
    :param b: Geometry to subtract
    :returns: Remainder of a after removing overlap with b
    """
    raise NotHandled


@defop
def intersection(*args: Shape) -> Shape:
    """Construct the intersection of CAD geometries.

    :param args: CAD geometries
    :returns: Intersection of the geometries
    """
    raise NotHandled


@defop
def decompose(x: Shape, *, max_parts: int = 8) -> Shape:
    """Approximate a shape as a union of convex parts for simulation.

    Geometrically ``decompose(x)`` denotes ``x``. The op is an annotation:
    the MuJoCo compiler emits the annotated shape as a union of convex
    mesh parts, one geom each, instead of a single mesh that collides as
    its convex hull. Every other interpreter treats it as identity.

    :param x: CAD geometry, possibly nonconvex
    :param max_parts: Maximum number of convex parts
    :returns: The annotated geometry
    """
    raise NotHandled


@defop
def cube(dx: float, dy: float, dz: float) -> Shape:
    """Create a cube with given extents in the x, y and z directions.

    The cube has a corner at the origin and extends into the positive octant.

    :param dx: Size in x
    :param dy: Size in y
    :param dz: Size in z
    :returns: A cube geometry
    """
    raise NotHandled


def centered_cube(dx: float, dy: float, dz: float) -> Shape:
    """Create a cube with given extents in the x, y and z directions.

    The cube is centered on the origin.

    :param dx: Size in x
    :param dy: Size in y
    :param dz: Size in z
    :returns: A cube geometry
    """
    return translate(cube(dx, dy, dz), [-dx / 2, -dy / 2, -dz / 2])


@defop
def sphere(r: float) -> Shape:
    """Create a sphere.

    :param r: Sphere radius
    :returns: A sphere geometry
    """
    raise NotHandled


@defop
def cylinder(*, r: float, h: float, r2: float | None = None) -> Shape:
    """Create a cylinder.

    The cylinder has two circular ends, one of radius r centered on the origin
    and the other of radius r2 centered on [0, 0, h].  If r2 is not given, its
    value is equal to that of r.

    :param r: Cylinder base radius
    :param h: Cylinder length
    :param r2: Cylinder top radius
    :returns: A cylinder geometry
    """
    raise NotHandled


@defop
def capsule(*, r: float, h: float) -> Shape:
    """Create a capsule.

    The capsule has two spherical ends of radius r, one centered on the origin and the
    other on [0, 0, h].

    :param r: Capsule base radius
    :param h: Capsule length
    :param r2: Capsule top radius
    :returns: A capsule geometry
    """
    raise NotHandled


@defop
def extrude(polygon: Polygon, h: float) -> Shape:
    """Extrude a polygon along +Z.

    The polygon lies in the XY plane, and the solid spans z in [0, h],
    matching the cylinder convention.

    :param polygon: The outline to sweep.
    :param h: Extrusion height along +Z.
    :returns: The extruded prism
    """
    raise NotHandled


@defop
def revolve(polygon: Polygon) -> Shape:
    """Revolve a polygon one full turn about the +Z axis.

    The polygon lies in the meridian half-plane as (radial, axial) rows
    with nonnegative radial coordinates; each vertex traces the circle of
    its radius at its height.

    :param polygon: The meridian outline to sweep.
    :returns: The solid of revolution
    """
    raise NotHandled


@defop
def external_mesh(path: str) -> Shape:
    """Import an external 3D mesh from an STL file.

    :param path: Path to the STL mesh file
    :returns: Cad object representing the imported mesh
    """
    raise NotHandled


@defop
def mesh(m: Mesh) -> Shape:
    """A mesh given by its vertices and faces.

    The mesh goes into the scad source vertex by vertex as a polyhedron, so
    this is for meshes already in memory, such as the convex hulls COACD
    returns, which run to a few hundred vertices each. A full scan stays an
    :func:`external_mesh`, which imports the STL instead.

    :param m: The mesh, in the shape's own frame
    :returns: Cad object representing the mesh
    """
    raise NotHandled


@defop
def plane() -> Shape:
    """Create a plane at z = 0."""
    raise NotHandled


@defop
def translate(x: Shape, v: np.typing.ArrayLike) -> Shape:
    """Translate a geometry.

    :param x: CAD geometry
    :param v: Translation vector [x, y, z]
    :returns: Translated geometry
    """
    raise NotHandled


@defop
def rotate(x: Shape, rot: Rotation) -> Shape:
    """Rotate a geometry.

    :param x: CAD geometry
    :param rot: Rotation to apply
    :returns: Rotated geometry
    """
    raise NotHandled


@defop
def rotation_from_quat(v: np.typing.ArrayLike) -> Rotation:
    if isinstance(v, Term):
        raise NotHandled

    q = jnp.roll(jnp.asarray(v), -1)  # move scalar last
    return Rotation.from_quat(q)


def rotate_quat(x: Shape, v: np.typing.ArrayLike) -> Shape:
    """Rotate a geometry using a quaternion.

    :param x: CAD geometry
    :param v: Unit quaternion, scalar-first.
    :returns: Rotated geometry
    """
    return rotate(x, rotation_from_quat(v))


def transform(x: Shape, pose: Pose) -> Shape:
    """Affine transform a geometry using a pose.

    Each point `p` in `x` will be mapped to `pose @ p`.

    :param x: CAD geometry
    :param pose: Pose to apply
    :returns: Transformed geometry
    """
    return translate(rotate_quat(x, pose.quat), pose.pos)


@defop
def scale(x: Shape, v: np.typing.ArrayLike) -> Shape:
    """Scale a geometry in all dimensions.

    :param x: Geometry
    :param v: Scaling factors [x, y, z]
    :returns: Scaled geometry
    """
    raise NotHandled

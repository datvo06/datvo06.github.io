"""Search and record native Panda + LEAP pickup trajectories over fixed poses."""

import argparse
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from functools import partial
from pathlib import Path
from typing import Annotated, Literal, Self, TypedDict, cast

import effectful.handlers.jax.numpy as ejnp
import jax
import jax.numpy as jnp
import mujoco
import mujoco.rollout
import numpy as np
from annotated_types import Ge, Le
from effectful.handlers.llm import Encodable, Skill
from effectful.ops.semantics import evaluate, handler
from effectful.ops.types import NotHandled
from flax import struct
from numpy.typing import NDArray
from pydantic import (
    AfterValidator,
    BaseModel,
    ConfigDict,
    Field,
    TypeAdapter,
    computed_field,
)
from scipy.spatial.transform import Rotation

from experiments.pickup_director import (
    PickupDirector,
    RewardFn,
    Session,
    bind_auxiliary_terms,
    check_reward,
    probe_env,
)
from robotl.examples.based import Based
from robotl.examples.panda import (
    JOINT_ACCELERATION_LIMITS_RAD_S2,
    JOINT_VELOCITY_LIMITS_RAD_S,
)
from robotl.examples.panda_leap_teleop import (
    BodyPoseReference,
    HandDesign,
    PandaLeapYcbAssembly,
    PandaLeapYcbScene,
    Recording,
    SceneConfig,
    create_session,
)
from robotl.examples.ycb_artifacts import OBJECT_CONFIGS
from robotl.handlers.cad.bbox import bbox_from_shape
from robotl.handlers.cad.sdf import SDFShape, ShapeToSDF
from robotl.handlers.mujoco.compiler import MujocoContext, make_context
from robotl.handlers.mujoco.control import MPCController, SamplingPlanner
from robotl.handlers.mujoco.control.ik_solver import site_pose_ik_step
from robotl.handlers.mujoco.control.planners import SamplingState
from robotl.handlers.mujoco.control.plans import BoundedDensePlan, colored_noise
from robotl.handlers.mujoco.control.stages import Stage
from robotl.handlers.mujoco.process import Action, EnvProcess, EnvSpec, EnvState
from robotl.handlers.mujoco.rollouts import JaxableThreadedRunner
from robotl.handlers.mujoco.wrench import WrenchMargin, wrench_margin
from robotl.internals.utils import matrix_from_quat
from robotl.ops import sensors
from robotl.ops.coords import RawCoordinate
from robotl.ops.losses import Equalize, KeepAbove, KeepBelow, Loss, Minimize
from robotl.ops.syntax import (
    Component,
    Origin,
    component_state,
)

type Floats = NDArray[np.float64]
type Indices = NDArray[np.int64]

IK_MAX_ITERATIONS = 150
IK_JOINT_STEP_RAD = 0.08
IK_POSITION_TOLERANCE_M = 0.00001
IK_ANGLE_TOLERANCE_RAD = 0.001
LIFT_TARGET_M = 0.15
LIFT_TRANSITION_S = 3.75
# HOLD settles onto its pose over this time, long enough for the arm to stay
# within its acceleration limit.
HOLD_TRANSITION_S = 1.0
# Hand sampling σ (dimensionless, see knot_sigma) while the arm lifts and holds;
# the hand only needs to keep the grip it formed.
LIFT_HAND_SIGMA = 0.1
# Hand controls are commanded this far past the contact pose, toward closed,
# when the arm starts lifting: the wrench margin scales with the pad loads,
# and the position servos saturate at their force range rather than crush.
LIFT_SQUEEZE_RAD = 0.15
UPRIGHT_LIFT_TRANSITION_S = 2.0
UPRIGHT_CLEARANCE_TRANSITION_S = 1.5
# The pregrasp wrist pose sits this far above the planned grasp pose; no digit
# may touch the object before CAPTURE plans the close from a resting object.
PREGRASP_CLEARANCE_M = 0.06
LIFT_THRESHOLD_M = 0.1
HOLD_DURATION_S = 2.0
WAYPOINT_DURATION_S = 1.5
CLOSE_SCORE_START_S = 3.8
APPROACH_SCORE_START_S = 1.0
APPROACH_SCORE_END_S = 6.0
PROXIMITY_RADIUS_M = 0.035
FLOOR_CLEARANCE_M = 0.002
ACTIVE_CONTACT_FORCE_N = 1e-5
MINIMUM_HAND_CONTACT_FRACTION = 0.99
MAXIMUM_PENETRATION_M = 0.003
HAMMER_GRASP_TIMEOUT_S = 8.0
MAXIMUM_JOINT_VIOLATION_RAD = 0.02
CAPTURE_WRIST_FREEDOM = np.array([0.05, 0.05, 0.08, np.pi / 2])
"""Capture search freedom for the flange: world x, y, z offsets in metres and a
yaw about the approach axis in radians, so the closing axis can turn across an
elongated object."""
# Pad centre distance outside the surface for the first IK targets; the contact
# refinement then closes each pad onto its nearest surface.
CAPTURE_PAD_STANDOFF_M = 0.008
# Pad centre distance outside the surface for the preshape that the hand holds
# while the wrist arrives, so closing starts beside the object rather than on it.
CAPTURE_PRESHAPE_STANDOFF_M = 0.025
# Closing schedules the capture rollout chooses between, as (wrist, hand) order.
CLOSING_SCHEDULES = ("together", "wrist first", "hand first", "preshape then close")
# Capture IK solutions, best static score first, that are rolled out in physics.
CAPTURE_ROLLOUTS = 16
# Pinch span (thumb target to finger targets) that costs one unit of static
# score; an end-to-end pinch along a long object scores far worse than one
# across its handle, so the shortlist prefers closing across the thin direction.
CAPTURE_PINCH_SPAN_M = 0.03
# Largest lateral offset of a finger target from the finger centroid, so the
# three fingers land on the same handle rather than spanning a long object.
CAPTURE_LATERAL_M = 0.02
MAXIMUM_HAMMER_TILT_RAD = float(np.deg2rad(15))
SUPPORT_LOSS_TOLERANCE = 1e-8
# Contact slots per digit-body pair; every slot is stored at every rollout step.
# Grasps fill at most 10, and overflow raises through require_capacity.
CONTACT_CAPACITY = 16
SUPPORT_ACTIVE_FORCE_N = 1e-6
MAXIMUM_OPPOSITION_COSINE = -0.5
EXCESS_FORCE_LOSS_WEIGHT = 0.01
MINIMUM_FINGER_WEIGHT_FRACTION = 0.10
# Spacing of the penetration samples that rank capture rollouts.
PENETRATION_SAMPLE_S = 0.2
FRICTION_ADAPTER: TypeAdapter[float] = TypeAdapter(Annotated[float, Field(gt=0)])
ARM_FEEDBACK_RAMP_S = 0.5
ARM_FEEDBACK_SCALE = 0.01
MPC_REPLAN_INTERVAL_S = 0.1
# A pad in a settled grasp leaves ``data.contact`` for single ticks, which
# zeroes the wrench margin for those ticks; the GRASP dwell survives a lapse
# shorter than this: three and a half 2.5 ms physics ticks, so four dropped
# ticks are tolerated and the fifth restarts the dwell.
GRASP_LAPSE_S = 0.00875
MPC_NOISE_COLOR = 2.5
# A hand correction lands fully before the next replan replaces it.
HAND_FEEDBACK_RAMP_S = MPC_REPLAN_INTERVAL_S


class LiftPlan(BoundedDensePlan):
    """Ramp new feedback from the carried command boundary."""

    arm_actuators: tuple[int, ...] = struct.field(pytree_node=False)
    feedback_scale: float = struct.field(pytree_node=False, default=ARM_FEEDBACK_SCALE)

    def with_params(self, params: jax.Array, spec: EnvSpec) -> Self:
        indices = jnp.asarray(self.arm_actuators)
        fraction = jnp.clip(
            jnp.arange(len(self.x)) * self.dt / ARM_FEEDBACK_RAMP_S, 0, 1
        )
        envelope = fraction**3 * (10 - 15 * fraction + 6 * fraction**2)
        reference = self.x[..., indices]
        arm = reference + (
            self.feedback_scale * envelope[:, None] * (params[..., indices] - reference)
        )
        hand_fraction = jnp.clip(
            jnp.arange(len(self.x)) * self.dt / HAND_FEEDBACK_RAMP_S, 0, 1
        )
        hand_envelope = hand_fraction**3 * (
            10 - 15 * hand_fraction + 6 * hand_fraction**2
        )
        continuous = self.x + hand_envelope[:, None] * (params - self.x)
        return super().with_params(continuous.at[..., indices].set(arm), spec)


class SmoothArmLiftPlan(LiftPlan):
    """Sample arm corrections on quarter-second knots, retaining dense hand control."""

    def with_params(self, params: jax.Array, spec: EnvSpec) -> Self:
        indices = jnp.asarray(self.arm_actuators)
        stride = max(1, round(0.25 / self.dt))
        knots = jnp.arange(0, len(self.x) + stride, stride)
        sampled = jnp.clip(knots, 0, len(self.x) - 1)
        delta = (params - self.x)[sampled][:, indices]
        delta = delta.at[0].set(self.previous_control[indices] - self.x[0, indices])
        position = jnp.arange(len(self.x)) / stride
        left = jnp.floor(position).astype(int)
        fraction = position - left
        blend = fraction**3 * (10 - 15 * fraction + 6 * fraction**2)
        correction = delta[left] + blend[:, None] * (delta[left + 1] - delta[left])
        arm = self.x[:, indices] + correction
        fraction = jnp.clip(
            jnp.arange(len(self.x)) * self.dt / HAND_FEEDBACK_RAMP_S, 0, 1
        )
        blend = fraction**3 * (10 - 15 * fraction + 6 * fraction**2)
        hand = self.x + blend[:, None] * (params - self.x)
        return BoundedDensePlan.with_params(self, hand.at[:, indices].set(arm), spec)


@dataclass(eq=False, kw_only=True)
class PickupScene(PandaLeapYcbScene):
    """Contact-directed pickup goals on the existing free-object assembly."""

    grip_contacts: tuple[tuple[sensors.Contact, ...], ...]
    contact_overflow: sensors.Virtual[RawCoordinate]
    contact_distance: sensors.MinimumContactDistance
    contact_penetration: sensors.Virtual[RawCoordinate]
    support: dict[str, Loss]
    capture: dict[str, KeepBelow]
    task_losses: dict[str, Loss]

    @classmethod
    def make(cls, config: SceneConfig) -> Self:
        """Construct native contact roots and fixed pickup objectives before compile."""
        assembly = PandaLeapYcbAssembly.make(config)
        robot, obj = assembly.robot, assembly.obj
        grasp_point = assembly.grasp_point
        digits = (robot.hand.thumb, *robot.hand.fingers)
        vertices = jnp.asarray(obj.whole_vertices)
        # Only the fields the pickup losses read are stored.
        fields = frozenset(
            {
                sensors.ContactField.FOUND,
                sensors.ContactField.FORCE,
                sensors.ContactField.POSITION,
                sensors.ContactField.NORMAL,
            }
        )
        contacts = tuple(
            tuple(
                sensors.subtree_contact_sensors(
                    obj, digit, capacity=CONTACT_CAPACITY, fields=fields
                )
            )
            for digit in digits
        )
        bodies = {
            body.id: body for root in (obj, *digits) for body in root.components()
        }
        loads = []
        supports = []
        centroids = []
        normal_sums = []
        excess_counts = []
        for group in contacts:
            group_load = ejnp.asarray(0.0)
            group_support = ejnp.asarray(0.0)
            group_normal = ejnp.zeros(3)
            group_position = ejnp.zeros(3)
            for contact in group:
                found = contact.field(sensors.ContactField.FOUND)[:, 0]
                excess_counts.append(ejnp.any(found > contact.capacity))
                pair = (bodies[contact.first_id], bodies[contact.second_id])
                # Logical containers and disabled bodies cannot carry collision load.
                if any(
                    component_state(body).get("shape") is None or body.disable_collision
                    for body in pair
                ):
                    continue
                mu = max(
                    FRICTION_ADAPTER.validate_python(body.get_material().friction)
                    for body in pair
                )
                force = contact.field(sensors.ContactField.FORCE)[:, 0]
                weight = ejnp.where(
                    (found > 0) & (force > SUPPORT_ACTIVE_FORCE_N), force, 0
                )
                load = ejnp.sum(weight)
                group_load = group_load + load
                group_support = group_support + mu * load
                group_normal = group_normal + ejnp.sum(
                    weight[:, None] * contact.field(sensors.ContactField.NORMAL),
                    axis=0,
                )
                group_position = group_position + ejnp.sum(
                    weight[:, None] * contact.field(sensors.ContactField.POSITION),
                    axis=0,
                )
            loads.append(sensors.Virtual(RawCoordinate(group_load[None])))
            supports.append(sensors.Virtual(RawCoordinate(group_support[None])))
            centroids.append(
                sensors.Virtual(
                    RawCoordinate(group_position / ejnp.maximum(group_load, 1e-9))
                )
            )
            normal_sums.append(group_normal)
        thumb_normal = normal_sums[0]
        finger_normal = sum(normal_sums[1:], ejnp.zeros(3))
        cosine = ejnp.sum(thumb_normal * finger_normal) / ejnp.sqrt(
            ejnp.sum(thumb_normal**2) * ejnp.sum(finger_normal**2) + 1e-18
        )
        opposition = sensors.Virtual(RawCoordinate(cosine[None]))
        overflow = sensors.Virtual(
            RawCoordinate(ejnp.any(ejnp.stack(excess_counts))[None])
        )
        contact_distance = sensors.MinimumContactDistance()
        penetration = sensors.Virtual(
            RawCoordinate(ejnp.maximum(0, -contact_distance.get().x)[None])
        )
        weight_N = (
            sum(float(mass.to("kg").value) for _, _, mass in obj.parts_info) * 9.81
        )
        support_terms = {
            "thumb": KeepAbove(supports[0].get().x[0] / (weight_N / 2), 1.0),
            "fingers": KeepAbove(
                sum(s.get().x[0] for s in supports[1:]) / (weight_N / 2), 1.0
            ),
            "opposition": KeepBelow(opposition.get().x[0], MAXIMUM_OPPOSITION_COSINE),
        }
        support_terms.update(
            {
                f"finger{i}": KeepAbove(
                    support.get().x[0] / (weight_N * MINIMUM_FINGER_WEIGHT_FRACTION),
                    1.0,
                )
                for i, support in enumerate(supports[1:])
            }
        )
        target = obj.pose @ jnp.asarray(grasp_point)
        label = (
            "handle"
            if any(name == "handle" for name, _, _ in obj.parts_info)
            else "body"
        )
        mesh = next(mesh for name, mesh, _ in obj.parts_info if name == label)
        points = np.asarray(mesh.vertices)
        chosen = [int(np.argmin(np.linalg.norm(points - grasp_point, axis=1)))]
        separation = np.full(len(points), np.inf)
        for _ in range(31):
            separation = np.minimum(
                separation, np.sum((points - points[chosen[-1]]) ** 2, axis=1)
            )
            chosen.append(int(np.argmax(separation)))
        surface = jnp.asarray(points[chosen])
        tips = (robot.hand.thumb.tt, *(finger.ft for finger in robot.hand.fingers))
        positions = []
        for tip in tips:
            bounds = bbox_from_shape(tip.shape)
            positions.append(tip.pose @ ((bounds.lo + bounds.hi) / 2))
        thumb_offset = positions[0] - target
        finger_center = sum(positions[1:], ejnp.zeros(3)) / 3
        finger_offset = finger_center - target
        closing_axis = positions[0] - finger_center
        world_surface = obj.pose @ surface
        side = ejnp.sum((world_surface - target) * closing_axis, axis=-1)
        capture_terms: dict[str, KeepBelow] = {}
        for name, tip, sign in zip(
            ("thumb", "finger0", "finger1", "finger2"),
            tips,
            (1, -1, -1, -1),
            strict=True,
        ):
            with handler(ShapeToSDF()):
                pad = cast(SDFShape, evaluate(tip.shape))
            local = (~tip.pose @ obj.pose) @ surface
            gap = ejnp.min(ejnp.where(sign * side >= 0, ejnp.abs(pad(local)), 1.0))
            capture_terms[f"capture_{name}"] = KeepBelow(gap / 0.015, 1.0)
        capture_cosine = ejnp.sum(thumb_offset * finger_offset) / ejnp.sqrt(
            ejnp.sum(thumb_offset**2) * ejnp.sum(finger_offset**2) + 1e-18
        )
        capture_terms["capture_opposition"] = KeepBelow(capture_cosine, -0.25)
        task_terms = {
            "lift": KeepAbove(
                ejnp.min((obj.pose @ jnp.asarray(obj.lift_vertices))[:, 2]),
                LIFT_THRESHOLD_M,
            ),
            "whole_clearance": KeepAbove(
                ejnp.min((obj.pose @ vertices)[:, 2]), FLOOR_CLEARANCE_M
            ),
            "region": Minimize(
                sum(
                    ejnp.where(
                        load.get().x[0] > SUPPORT_ACTIVE_FORCE_N,
                        ejnp.sum((centroid.get().x - target) ** 2),
                        0,
                    )
                    for load, centroid in zip(loads, centroids, strict=True)
                )
            ),
            "excess_force": Minimize(
                ejnp.square(sum(load.get().x[0] for load in loads) / weight_N),
                weight=EXCESS_FORCE_LOSS_WEIGHT,
            ),
        }
        if obj.upright_axis is not None:
            task_terms["upright"] = KeepAbove(
                (obj.pose.rotational @ jnp.asarray(obj.upright_axis))[2],
                np.cos(MAXIMUM_HAMMER_TILT_RAD),
            )
        return Based.anchor(
            assembly,
            lambda pose, base, welds: cls(
                pose=pose,
                assembly=assembly,
                base=base,
                welds=welds,
                grip_contacts=contacts,
                contact_overflow=overflow,
                contact_distance=contact_distance,
                contact_penetration=penetration,
                support=support_terms,
                capture=capture_terms,
                task_losses=task_terms,
            ),
        )


class TargetPose(BaseModel):
    """An object placement fixed before training or evaluation."""

    name: str
    xy_m: tuple[float, float]
    yaw_rad: float
    tilt_rad: tuple[float, float] = (0.0, 0.0)


TRAINING_POSES = (
    TargetPose(name="train-center", xy_m=(0.4, 0.0), yaw_rad=0.0),
    TargetPose(name="train-left", xy_m=(0.38, -0.025), yaw_rad=0.6),
    TargetPose(name="train-right", xy_m=(0.42, 0.025), yaw_rad=-0.6),
    TargetPose(name="train-turned", xy_m=(0.4, -0.02), yaw_rad=1.4),
)
EVALUATION_POSES = tuple(
    TargetPose(name=f"eval-{i}", xy_m=xy, yaw_rad=yaw, tilt_rad=tilt)
    for i, (xy, yaw, tilt) in enumerate(
        (
            ((0.37, 0.02), 0.3, (0.2, 0.0)),
            ((0.43, -0.02), -0.3, (0.0, 0.2)),
            ((0.4, 0.035), 1.0, (-0.2, 0.0)),
            ((0.4, -0.035), -1.0, (0.0, -0.2)),
            ((0.38, 0.0), 2.0, (0.0, 0.0)),
            ((0.42, 0.0), -2.0, (0.0, 0.0)),
            ((0.39, 0.025), 2.8, (0.1, 0.1)),
            ((0.41, -0.025), -2.8, (-0.1, -0.1)),
        )
    )
)


class Grasp(BaseModel):
    """Wrist offsets and bounded preshape angles, in metres and radians."""

    model_config = ConfigDict(extra="forbid")

    x: float = Field(default=0.0, ge=-0.05, le=0.05)
    y: float = Field(default=0.0, ge=-0.05, le=0.05)
    z: float = Field(default=0.01, ge=-0.015, le=0.06)
    yaw: float = Field(default=0.0, ge=-np.pi, le=np.pi)
    pitch: float = Field(default=0.0, ge=-np.pi / 2, le=np.pi / 2)
    roll: float = Field(default=0.0, ge=-np.pi, le=np.pi)
    base: float = Field(default=1.6, ge=0.4, le=2.1)
    spread: float = Field(default=0.0, ge=-0.35, le=0.35)
    middle: float = Field(default=0.5, ge=-0.2, le=1.7)
    distal: float = Field(default=0.4, ge=-0.2, le=1.5)
    thumb_base: float = Field(default=1.2, ge=0.0, le=1.9)
    thumb_spread: float = Field(default=1.4, ge=-0.2, le=2.0)
    thumb_middle: float = Field(default=0.9, ge=-0.1, le=2.0)
    thumb_distal: float = Field(default=0.6, ge=-0.8, le=1.5)
    preshape: float = Field(default=0.75, ge=0.5, le=0.95)


class GraspPlan(BaseModel):
    """A bounded wrist pose and object-local grasp region for one attempt."""

    model_config = ConfigDict(extra="forbid")

    grasp: Grasp
    grasp_point_m: Encodable[
        tuple[
            Annotated[float, Field(ge=-0.25, le=0.25, allow_inf_nan=False)],
            Annotated[float, Field(ge=-0.25, le=0.25, allow_inf_nan=False)],
            Annotated[float, Field(ge=-0.25, le=0.25, allow_inf_nan=False)],
        ]
    ]


GRASP_BOUNDS = np.array(
    [
        [
            next(bound.ge for bound in field.metadata if isinstance(bound, Ge)),
            next(bound.le for bound in field.metadata if isinstance(bound, Le)),
        ]
        for field in Grasp.model_fields.values()
    ],
    dtype=float,
)


class ObjectHold(BaseModel):
    """Sustained whole-object clearance for pickup without an orientation target."""

    kind: Literal["object"] = "object"
    minimum_hold_lift_m: float = Field(
        description="Minimum whole-object bottom height above the floor during hold."
    )

    @property
    def achieved(self) -> bool:
        return self.minimum_hold_lift_m >= LIFT_THRESHOLD_M


class UprightHammerHold(BaseModel):
    """Head raised above the handle while the whole hammer clears the floor."""

    kind: Literal["upright_hammer"] = "upright_hammer"
    minimum_hold_lift_m: float = Field(
        description="Minimum hammer-head bottom height during hold, in metres."
    )
    minimum_hold_ground_clearance_m: float
    maximum_hold_tilt_rad: float

    @property
    def achieved(self) -> bool:
        return (
            self.minimum_hold_lift_m >= LIFT_THRESHOLD_M
            and self.minimum_hold_ground_clearance_m >= FLOOR_CLEARANCE_M
            and self.maximum_hold_tilt_rad <= MAXIMUM_HAMMER_TILT_RAD
        )


class PhysicalMeasurements(TypedDict):
    """Scalar native measurements copied from one physics tick."""

    time_s: float
    force_n: float
    penetration_m: float
    object_floor: bool
    target_bottom_m: float
    whole_bottom_m: float
    tilt_rad: float
    joint_violation_rad: float


class Outcome(BaseModel):
    """Inputs to physical pickup acceptance and design comparison."""

    pose: TargetPose
    hold: Annotated[ObjectHold | UprightHammerHold, Field(discriminator="kind")]
    hold_duration_s: float = Field(ge=0)
    hand_contact_fraction: float
    maximum_grip_force_n: float
    maximum_penetration_m: float
    object_ground_contact_during_hold: bool
    joint_limit_violation_rad: float

    @computed_field  # type: ignore[prop-decorator]
    @property
    def lifted(self) -> bool:
        """Accept a sustained held pickup within physical contact and joint limits."""
        return (
            self.hold_duration_s >= HOLD_DURATION_S
            and self.hold.achieved
            and self.hand_contact_fraction >= MINIMUM_HAND_CONTACT_FRACTION
            and not self.object_ground_contact_during_hold
            and self.maximum_penetration_m <= MAXIMUM_PENETRATION_M
            and self.joint_limit_violation_rad <= MAXIMUM_JOINT_VIOLATION_RAD
        )


class UnreachablePose(BaseModel):
    """A rejected wrist waypoint, with no fabricated physical measurements."""

    pose: TargetPose
    reason: Literal["unreachable-wrist-waypoint"] = "unreachable-wrist-waypoint"
    lifted: Literal[False] = False


class PoseSet(BaseModel):
    """Frozen training and evaluation placements shared with co-design."""

    training_poses: tuple[TargetPose, ...]
    evaluation_poses: tuple[TargetPose, ...]


class SearchSettings(BaseModel):
    """Validated full-episode trajectory search budget."""

    model_config = ConfigDict(extra="forbid")

    generations: int = Field(default=5, ge=1)
    population: int = Field(default=32, ge=4)
    workers: int = Field(default=4, ge=1)
    duration_s: float = Field(default=8.0, ge=8.0)
    seed: int = 20261006


class PickupObjective(BaseModel):
    """Search weights; physical pickup thresholds are independent of these."""

    model_config = ConfigDict(extra="forbid")

    lift: float = Field(default=10.0, gt=0)
    height_reward: float = Field(default=0.1, ge=0)
    drift: float = Field(default=0.1, ge=0)
    steadiness: float = Field(default=2.0, ge=0)
    proximity: float = Field(default=3.0, ge=0)
    clearance: float = Field(default=100.0, gt=0)
    upright: float = Field(default=3.0, ge=0)


class SparseObjective(BaseModel):
    """Canonical reaching, lift and no-drop terms, including height-only ablation."""

    model_config = ConfigDict(extra="forbid")

    mode: Literal["sparse"]
    reaching: float = Field(default=0.01, ge=0)
    lift: float = Field(default=3.0, gt=0)
    nodrop: float = Field(default=5.0, ge=0)
    upright: float = Field(default=3.0, ge=0)


type Objective = PickupObjective | SparseObjective


@jax.jit
def sparse_pickup_score(
    positions: Floats,
    tips: Floats,
    heights: Floats,
    reaching: float,
    lift: float,
    nodrop: float,
) -> jax.Array:
    """Average canonical sparse loss terms over a native episode."""
    return jax.vmap(
        lambda tip, obj, height: (
            Equalize(tip, obj, weight=reaching).value
            + KeepAbove(height, LIFT_THRESHOLD_M, weight=lift).value
            + KeepAbove(height, 0.0, weight=nodrop).value
        )
    )(tips, positions, heights).mean()


class SearchResult(BaseModel):
    """Selected training candidate and its independent evaluation outcomes."""

    scene: SceneConfig
    grasp: Grasp
    training: list[Outcome | UnreachablePose]
    evaluation: list[Outcome | UnreachablePose]
    episode_duration_s: float
    generation_scores: list[float]
    objective: Objective


class Generation(BaseModel):
    """Candidates and full training scores for one search iteration."""

    candidates: list[Grasp]
    scores: list[float | None]


def object_bottom_m(qpos: Floats, vertices: Floats) -> Floats:
    """Return lowest mesh height for free-joint poses, scalar or batched."""
    matrices = Rotation.from_quat(qpos[..., 3:7][..., [1, 2, 3, 0]]).as_matrix()
    offsets = np.einsum("...j,nj->...n", matrices[..., 2, :], vertices)
    return np.asarray(qpos[..., 2] + offsets.min(axis=-1))


@dataclass(frozen=True)
class CollisionShape:
    """A native collision shape's support points in its owning component frame."""

    position_channel: int
    quaternion_channel: int
    points: Floats
    radius: float

    def bottom(self, readings: Floats) -> Floats:
        """Return the lowest surface height above the horizontal floor."""
        p, q = self.position_channel, self.quaternion_channel
        rotations = Rotation.from_quat(readings[:, q : q + 4][:, [1, 2, 3, 0]])
        return (
            readings[:, p + 2]
            + np.min(rotations.as_matrix()[:, 2, :] @ self.points.T, axis=-1)
            - self.radius
        )


@dataclass
class Pickup:
    """One compiled scene and logical component bindings reused by the search."""

    model: mujoco.MjModel
    scene: PickupScene
    context: MujocoContext
    template: Floats
    initial_controls: Floats
    flange: int
    arm_dofs: Indices
    recording: Recording
    object_qpos: int
    arm_actuators: Indices
    arm_qpos: Indices
    hand_actuators: Indices
    object_geoms: set[int]
    hand_geoms: set[int]
    mobile_geoms: set[int]
    floor_geoms: set[int]
    fingertip_geoms: Indices
    fingertip_channels: Indices
    hand_collision_shapes: list[CollisionShape]
    duration: float
    objective: Objective

    @classmethod
    def make(
        cls,
        scene: SceneConfig,
        output: Path,
        duration: float,
        objective: Objective,
    ) -> "Pickup":
        """Compile once and bind native indices from the RoboTL component graph."""
        object_profile = OBJECT_CONFIGS[scene.object_name]
        minimum_hammer_duration = 5 * WAYPOINT_DURATION_S + HOLD_DURATION_S
        if (
            object_profile.upright_axis is not None
            and duration < minimum_hammer_duration
        ):
            raise ValueError(
                f"Upright hammer trajectory requires at least {minimum_hammer_duration:g} seconds"
            )
        model, data, control, recording = create_session(
            scene, output, scene_factory=PickupScene.make
        )

        def geoms(component: Component) -> set[int]:
            bodies = {
                control.context.components[id].idx
                for id in make_context(component).components
                if id != Origin.id
            }
            return {
                int(i) for i in np.flatnonzero(np.isin(model.geom_bodyid, list(bodies)))
            }

        object_reference = next(
            reference
            for reference in recording.info.poses
            if isinstance(reference, BodyPoseReference)
            and reference.name == scene.object_name
        )
        object_body = model.body(object_reference.body_name).id
        object_joint = int(model.body_jntadr[model.body_weldid[object_body]])
        object_component = control.scene.assembly.obj
        object_geoms = geoms(object_component)
        arm_actuators = np.array(
            [
                control.context.actuators[a.id].idx
                for a in control.robot.arm.hinge_actuators
            ]
        )
        arm_qpos = model.jnt_qposadr[model.actuator_trnid[arm_actuators, 0]].copy()
        hand_actuators = np.array(
            [control.context.actuators[a.id].idx for a in control.hand_actuators]
        )
        mobile_geoms = geoms(control.robot.hand)
        for link in control.robot.arm.links[1:]:
            mobile_geoms |= geoms(link)
        floor_geoms = {
            int(i)
            for i in np.flatnonzero(model.geom_type == mujoco.mjtGeom.mjGEOM_PLANE)
        }
        pad_geoms = []
        for pad in [
            *(finger.ft for finger in control.robot.hand.fingers),
            control.robot.hand.thumb.tt,
        ]:
            [geom] = [
                g
                for g in geoms(pad)
                if model.geom_contype[g] or model.geom_conaffinity[g]
            ]
            pad_geoms.append(geom)

        def channel(
            component: Component,
            kind: type[sensors.FrameLinPos] | type[sensors.FrameAngPos],
        ) -> int:
            sensor = next(
                info
                for info in control.context.sensors.values()
                if info.owner.object.id == component.id
                and isinstance(info.object, kind)
            )
            return int(model.sensor_adr[sensor.idx])

        tip_channels = np.array(
            [
                [channel(t, sensors.FrameLinPos) + axis for axis in range(3)]
                for t in control.robot.hand.fingertips
            ]
        )
        components = {
            control.context.components[id].idx: info.object
            for id, info in make_context(control.robot.hand).components.items()
            if id != Origin.id
        }
        collision_shapes = []
        for geom in sorted(geoms(control.robot.hand)):
            if not (model.geom_contype[geom] or model.geom_conaffinity[geom]):
                continue
            component = components[int(model.geom_bodyid[geom])]
            size = model.geom_size[geom]
            if model.geom_type[geom] == mujoco.mjtGeom.mjGEOM_BOX:
                points = (
                    np.array(
                        [[x, y, z] for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)]
                    )
                    * size
                )
                radius = 0.0
            elif model.geom_type[geom] == mujoco.mjtGeom.mjGEOM_CAPSULE:
                points = np.array([[0, 0, -size[1]], [0, 0, size[1]]])
                radius = float(size[0])
            else:
                raise ValueError(
                    "Pickup clearance supports box and capsule hand collisions, "
                    f"got {mujoco.mjtGeom(model.geom_type[geom]).name} on {model.geom(geom).name}"
                )
            rotation = Rotation.from_quat(model.geom_quat[geom][[1, 2, 3, 0]])
            collision_shapes.append(
                CollisionShape(
                    channel(component, sensors.FrameLinPos),
                    channel(component, sensors.FrameAngPos),
                    rotation.apply(points) + model.geom_pos[geom],
                    radius,
                )
            )
        return cls(
            model,
            control.scene,
            control.context,
            data.qpos.copy(),
            data.ctrl.copy(),
            control.flange,
            np.asarray(control.dofs),
            recording,
            int(model.jnt_qposadr[object_joint]),
            arm_actuators,
            arm_qpos,
            hand_actuators,
            object_geoms,
            geoms(control.robot.hand),
            mobile_geoms,
            floor_geoms,
            np.array(pad_geoms),
            tip_channels,
            collision_shapes,
            duration,
            objective,
        )

    def reset(self, pose: TargetPose) -> mujoco.MjData:
        """Place and settle a free object while holding the stock arm at home."""
        data = mujoco.MjData(self.model)
        data.qpos[:] = self.template
        data.ctrl[:] = self.initial_controls
        rotation = Rotation.from_euler("xyz", [*pose.tilt_rad, pose.yaw_rad])
        points = self.scene.assembly.obj.whole_vertices @ rotation.as_matrix().T
        index = self.object_qpos
        data.qpos[index : index + 3] = [*pose.xy_m, -points[:, 2].min() + 0.002]
        xyzw = rotation.as_quat()
        data.qpos[index + 3 : index + 7] = xyzw[[3, 0, 1, 2]]
        mujoco.mj_forward(self.model, data)
        for _ in range(round(0.5 / self.model.opt.timestep)):
            mujoco.mj_step(self.model, data)
        mujoco.mj_kinematics(self.model, data)
        return data

    def lift_margin(self, data: mujoco.MjData) -> WrenchMargin:
        """Multiples of the object's weight the robot carries in ``data`` without the table."""
        bodies = sorted({int(self.model.geom_bodyid[g]) for g in self.object_geoms})
        weight = -float(self.model.body_mass[bodies].sum()) * self.model.opt.gravity
        return wrench_margin(
            self.model,
            data,
            self.object_geoms,
            self.mobile_geoms,
            self.floor_geoms,
            np.concatenate([weight, np.zeros(3)]),
        )

    @property
    def swept_radius(self) -> float:
        """Farthest object point from the grasp point, which a turning tool sweeps."""
        obj = self.scene.assembly.obj
        return float(
            np.linalg.norm(
                obj.whole_vertices - self.scene.assembly.grasp_point, axis=1
            ).max()
        )

    @property
    def required_lift_margin(self) -> float:
        """Weight multiple a grasp carries at the planned lift's peak acceleration.

        Lifting stages track quintic blends, which over height ``h`` and time
        ``T`` peak at ``10 / sqrt(3) * h / T**2``. An upright tool first rises
        by its swept radius to clear the table, then lifts; the faster of the
        two sets the requirement. Reorienting torque is not included.
        """
        obj = self.scene.assembly.obj
        if obj.upright_axis is None:
            lifts = [(LIFT_TARGET_M, LIFT_TRANSITION_S)]
        else:
            lifts = [
                (max(LIFT_TARGET_M, self.swept_radius), UPRIGHT_CLEARANCE_TRANSITION_S),
                (LIFT_TARGET_M, UPRIGHT_LIFT_TRANSITION_S),
            ]
        gravity = float(np.linalg.norm(self.model.opt.gravity))
        peak = max(10 / np.sqrt(3) * height / time**2 for height, time in lifts)
        return 1 + peak / gravity

    def trajectory(
        self,
        data: mujoco.MjData,
        grasp: Grasp,
        *,
        grasp_point_m: tuple[float, float, float] | None = None,
    ) -> Floats | None:
        """Solve wrist waypoints; reject a sample whose IK fails convergence."""
        model = self.model
        grasp_point = (
            self.scene.assembly.grasp_point
            if grasp_point_m is None
            else np.asarray(grasp_point_m)
        )
        scratch = mujoco.MjData(model)
        scratch.qpos[:] = data.qpos
        closed = np.array(
            [
                *([grasp.base, grasp.spread, grasp.middle, grasp.distal] * 3),
                grasp.thumb_base,
                grasp.thumb_spread,
                grasp.thumb_middle,
                grasp.thumb_distal,
            ]
        )
        closed = np.clip(closed, *model.actuator_ctrlrange[self.hand_actuators].T)
        opened = closed.copy()
        opened[[0, 4, 8, 12]] *= grasp.preshape
        opened[[2, 3, 6, 7, 10, 11, 14, 15]] *= 0.3
        joints = model.actuator_trnid[self.hand_actuators, 0]
        scratch.qpos[model.jnt_qposadr[joints]] = (
            closed / model.actuator_gear[self.hand_actuators, 0]
        )
        mujoco.mj_kinematics(model, scratch)
        flange = self.flange
        reference_rotation = scratch.site_xmat[flange].reshape(3, 3).copy()
        pads = scratch.geom_xpos[self.fingertip_geoms]
        local_center = reference_rotation.T @ (
            (pads[:3].mean(axis=0) + pads[3]) / 2 - scratch.site_xpos[flange]
        )
        object_rotation = Rotation.from_quat(
            data.qpos[self.object_qpos + 3 : self.object_qpos + 7][[1, 2, 3, 0]]
        )
        goal_rotation = (
            Rotation.from_euler(
                "xyz",
                [
                    grasp.roll,
                    grasp.pitch,
                    object_rotation.as_euler("xyz")[2] + grasp.yaw,
                ],
            ).as_matrix()
            @ reference_rotation
        )
        center = object_rotation.apply(grasp_point)
        center += data.qpos[self.object_qpos : self.object_qpos + 3]
        goal = center + [grasp.x, grasp.y, grasp.z] - goal_rotation @ local_center
        arm_joints = model.actuator_trnid[self.arm_actuators, 0]
        waypoints = [data.ctrl.copy()]
        targets = [
            (goal + [0, 0, LIFT_TARGET_M], goal_rotation, opened),
            (goal + [0, 0, PREGRASP_CLEARANCE_M], goal_rotation, opened),
            (goal, goal_rotation, closed),
        ]
        if self.scene.assembly.obj.upright_axis is None:
            targets.append((goal + [0, 0, LIFT_TARGET_M], goal_rotation, closed))
            times = [
                0,
                WAYPOINT_DURATION_S,
                2 * WAYPOINT_DURATION_S,
                3 * WAYPOINT_DURATION_S,
                self.duration - HOLD_DURATION_S,
            ]
        else:
            turn, _ = Rotation.align_vectors(
                np.array([[0.0, 0.0, 1.0]]),
                object_rotation.apply(self.scene.assembly.obj.upright_axis)[None],
            )
            final_object_rotation = turn * object_rotation
            final_rotation = turn.as_matrix() @ goal_rotation
            radius = np.linalg.norm(
                self.scene.assembly.obj.whole_vertices - grasp_point,
                axis=1,
            ).max()
            # Clear the full tool's swept radius before rotating the grasp.
            targets.append(
                (goal + [0, 0, max(LIFT_TARGET_M, radius)], goal_rotation, closed)
            )
            final_object_position = data.qpos[
                self.object_qpos : self.object_qpos + 3
            ].copy()
            final_object_position[2] = max(
                FLOOR_CLEARANCE_M
                - final_object_rotation.apply(self.scene.assembly.obj.whole_vertices)[
                    :, 2
                ].min(),
                LIFT_TARGET_M
                - final_object_rotation.apply(self.scene.assembly.obj.lift_vertices)[
                    :, 2
                ].min(),
            )
            grip_offset = object_rotation.inv().apply([grasp.x, grasp.y, grasp.z])
            final_position = (
                final_object_position
                + final_object_rotation.apply(grasp_point + grip_offset)
                - final_rotation @ local_center
            )
            targets.append((final_position, final_rotation, closed))
            times = [
                0,
                WAYPOINT_DURATION_S,
                2 * WAYPOINT_DURATION_S,
                3 * WAYPOINT_DURATION_S,
                4 * WAYPOINT_DURATION_S,
                self.duration - HOLD_DURATION_S,
            ]
        for position, rotation, hand in targets:
            for _ in range(IK_MAX_ITERATIONS):
                delta = site_pose_ik_step(
                    model, scratch, flange, self.arm_dofs, position, rotation
                )
                scratch.qpos[self.arm_qpos] = np.clip(
                    scratch.qpos[self.arm_qpos]
                    + np.clip(delta, -IK_JOINT_STEP_RAD, IK_JOINT_STEP_RAD),
                    *model.jnt_range[arm_joints].T,
                )
                mujoco.mj_kinematics(model, scratch)
                position_error = np.linalg.norm(scratch.site_xpos[flange] - position)
                angle_error = Rotation.from_matrix(
                    rotation @ scratch.site_xmat[flange].reshape(3, 3).T
                ).magnitude()
                if (
                    position_error <= IK_POSITION_TOLERANCE_M
                    and angle_error <= IK_ANGLE_TOLERANCE_RAD
                ):
                    break
            if (
                position_error > IK_POSITION_TOLERANCE_M
                or angle_error > IK_ANGLE_TOLERANCE_RAD
            ):
                return None
            target = self.initial_controls.copy()
            target[self.arm_actuators] = (
                scratch.qpos[self.arm_qpos] * model.actuator_gear[self.arm_actuators, 0]
            )
            target[self.hand_actuators] = hand
            waypoints.append(target)
        sample_times_of_waypoints = np.array([*times, self.duration])
        values = np.stack([*waypoints, waypoints[-1]])
        sample_times = (
            np.arange(1, round(self.duration / model.opt.timestep) + 1)
            * model.opt.timestep
        )
        controls = np.stack(
            [
                np.interp(sample_times, sample_times_of_waypoints, values[:, i])
                for i in range(model.nu)
            ],
            axis=-1,
        )
        return controls

    def score(self, states: Floats, readings: Floats, initial: mujoco.MjData) -> float:
        """Search objective over a full episode, before native contact verification."""
        index = 1 + self.object_qpos
        positions = states[:, index : index + 3]
        rotations = Rotation.from_quat(
            states[:, index + 3 : index + 7][:, [1, 2, 3, 0]]
        )
        matrices = rotations.as_matrix()
        bottom = object_bottom_m(
            states[:, index : index + 7], self.scene.assembly.obj.lift_vertices
        )
        hold = bottom[-round(HOLD_DURATION_S / self.model.opt.timestep) :]
        upright_penalty = 0.0
        if self.scene.assembly.obj.upright_axis is not None:
            tilt = np.arccos(
                np.clip((matrices @ self.scene.assembly.obj.upright_axis)[:, 2], -1, 1)
            )
            upright_penalty = np.maximum(
                tilt[-len(hold) :] - MAXIMUM_HAMMER_TILT_RAD, 0
            ).mean()
        if isinstance(self.objective, SparseObjective):
            tips = readings[:, self.fingertip_channels].mean(axis=1)
            with jax.enable_x64():
                return float(
                    sparse_pickup_score(
                        positions,
                        tips,
                        bottom,
                        self.objective.reaching,
                        self.objective.lift,
                        self.objective.nodrop,
                    )
                    + self.objective.upright * upright_penalty
                )
        center_local = self.scene.assembly.grasp_point
        centers = positions + matrices @ center_local
        close = slice(
            round(CLOSE_SCORE_START_S / self.model.opt.timestep),
            round(3 * WAYPOINT_DURATION_S / self.model.opt.timestep),
        )
        tip_distances = np.linalg.norm(
            readings[close][:, self.fingertip_channels] - centers[close, None, :],
            axis=-1,
        )
        approach = slice(
            round(APPROACH_SCORE_START_S / self.model.opt.timestep),
            round(APPROACH_SCORE_END_S / self.model.opt.timestep),
        )
        hand_bottom = np.minimum.reduce(
            [shape.bottom(readings[approach]) for shape in self.hand_collision_shapes]
        )
        final_xy = states[-1, 1 + self.object_qpos : 1 + self.object_qpos + 2]
        drift = np.linalg.norm(
            final_xy - initial.qpos[self.object_qpos : self.object_qpos + 2]
        )
        return float(
            self.objective.lift * np.maximum(LIFT_THRESHOLD_M - hold, 0).mean()
            - self.objective.height_reward * np.minimum(hold, LIFT_TARGET_M).mean()
            + self.objective.drift * drift
            + self.objective.steadiness * np.std(hold)
            + self.objective.proximity
            * np.maximum(tip_distances - PROXIMITY_RADIUS_M, 0).mean()
            + self.objective.clearance
            * np.maximum(FLOOR_CLEARANCE_M - hand_bottom, 0).max()
            + self.objective.upright * upright_penalty
        )

    def contact_state(self, data: mujoco.MjData) -> tuple[float, float, bool]:
        """Read grip force, all-contact penetration and active object-floor contact."""
        force = penetration = 0.0
        object_floor = False
        for i, contact in enumerate(data.contact):
            penetration = max(penetration, -float(contact.dist))
            a, b = int(contact.geom[0]), int(contact.geom[1])
            wrench = np.empty(6)
            mujoco.mj_contactForce(self.model, data, i, wrench)
            active = float(wrench[0]) > ACTIVE_CONTACT_FORCE_N
            if (a in self.object_geoms and b in self.hand_geoms) or (
                b in self.object_geoms and a in self.hand_geoms
            ):
                force += max(float(wrench[0]), 0.0)
            object_floor |= active and (
                (a in self.floor_geoms and b in self.object_geoms)
                or (b in self.floor_geoms and a in self.object_geoms)
            )
        return force, penetration, object_floor

    def staged_session(
        self,
        pose: TargetPose,
        grasp: Grasp,
        reward: RewardFn,
        *,
        seed: int = 0,
        threads: int = 4,
        batch_size: int = 2,
        rounds: int = 1,
        sigma: float = 0.002,
        enforce_penetration: bool = True,
    ) -> Session | UnreachablePose:
        """Bind one shared auxiliary loss to native observed pickup stages.

        The pilot uses full-rate native observations and does not assert real-time
        admission. A carried elite requires at least one fresh candidate and one
        refinement round. Session owns stepping resources; the caller must close it.
        Sampling settings are independent of Segment's runtime-admission horizon.
        """
        if batch_size < 2 or rounds < 1 or not np.isfinite(sigma) or sigma <= 0:
            raise ValueError(
                "Pickup loss search requires batch_size>=2, rounds>=1 and finite positive sigma"
            )
        penetration_limit = MAXIMUM_PENETRATION_M if enforce_penetration else np.inf
        data = self.reset(pose)
        controls = self.trajectory(data, grasp)
        if controls is None:
            return UnreachablePose(pose=pose)
        env = EnvProcess.make(
            self.scene,
            self.context,
            self.model,
            jax.random.key(seed),
            runner=partial(JaxableThreadedRunner.make, nthread=threads),
        )
        env = env.replace(state=env.spec.layout.state_from_data(data, env.state.rng))
        with handler({probe_env: lambda: env}):
            reward = check_reward(reward)
        terms = reward(self.scene)
        extra = bind_auxiliary_terms(env.spec, terms)
        support_values = bind_auxiliary_terms(env.spec, self.scene.support)
        lift_values = bind_auxiliary_terms(
            env.spec, {"lift": self.scene.task_losses["lift"]}
        )

        capture_values = bind_auxiliary_terms(
            env.spec, dict[str, Loss](self.scene.capture)
        )

        def capacity(state: EnvState) -> jax.Array:
            value: jax.Array = evaluate(  # type: ignore[assignment]
                self.scene.contact_overflow.get().x, intp=env.spec.intp(state)
            )
            return value[0]

        def require_capacity(overflow: jax.Array) -> None:
            if bool(jnp.any(overflow)):
                raise ValueError("Pickup contact observations exceed sensor capacity")

        batch_capacity = jax.jit(jax.vmap(jax.vmap(capacity)))

        def penetration(state: EnvState) -> jax.Array:
            value = evaluate(
                self.scene.contact_penetration.get().x, intp=env.spec.intp(state)
            )
            return value[0]

        batch_penetration = jax.jit(jax.vmap(jax.vmap(penetration)))
        pool = env.spec.runner
        assert isinstance(pool, JaxableThreadedRunner)
        dt = float(self.model.opt.timestep)
        # Support may flicker for the free-fall time from rest through FLOOR_CLEARANCE_M.
        recovery_s = float(
            np.sqrt(2 * FLOOR_CLEARANCE_M / np.linalg.norm(self.model.opt.gravity))
        )
        # The open hand above the object, before any capture close.
        pregrasp_target = controls[round(2 * WAYPOINT_DURATION_S / dt) - 1]
        targets = [
            controls[round(WAYPOINT_DURATION_S / dt) - 1],
            pregrasp_target,
            controls[round(3 * WAYPOINT_DURATION_S / dt) - 1],
            controls[-1],
            controls[-1],
        ]
        joint_ids = self.model.actuator_trnid[:, 0]
        qpos_ids = self.model.jnt_qposadr[joint_ids]
        gear = self.model.actuator_gear[:, 0]
        speed_limits = np.asarray(JOINT_VELOCITY_LIMITS_RAD_S)
        acceleration_limits = np.asarray(JOINT_ACCELERATION_LIMITS_RAD_S2)
        arm_joints = self.model.actuator_trnid[self.arm_actuators, 0]
        arm_span = np.ptp(self.model.jnt_range[arm_joints], axis=1)

        def sampling_sigma0(horizon: float, hand_sigma: float) -> tuple[float, ...]:
            """Per-actuator sampling σ; the arm's keeps a typical sampled knot
            within its acceleration limit, the hand's is ``hand_sigma``."""
            noise = np.asarray(
                colored_noise(
                    jax.random.key(0), (round(horizon / dt), 256), MPC_NOISE_COLOR
                )
            )
            # Acceleration of unit-σ noise, in rad/s^2 per rad of σ.
            unit = np.percentile(np.abs(np.diff(noise, 2, axis=0)), 95) / dt**2
            sigma0 = np.full(self.model.nu, hand_sigma)
            sigma0[self.arm_actuators] = np.minimum(
                sigma, acceleration_limits / unit * 6 / arm_span
            )
            return tuple(float(value) for value in sigma0)

        command_velocity = np.full(self.model.nu, np.inf)
        command_velocity[self.arm_actuators] = speed_limits * np.abs(
            gear[self.arm_actuators]
        )
        hinge_ids = np.flatnonzero(self.model.jnt_type == mujoco.mjtJoint.mjJNT_HINGE)

        def physical(observed: EnvProcess) -> bool:
            # The hand may rest on the table: table contact is bounded by the
            # penetration limit like any other contact.
            _, penetration, _ = self.contact_state(data)
            angles = data.qpos[self.model.jnt_qposadr[hinge_ids]]
            limits = self.model.jnt_range[hinge_ids]
            violation = np.maximum(limits[:, 0] - angles, angles - limits[:, 1]).max()
            return bool(
                penetration <= penetration_limit
                and violation <= MAXIMUM_JOINT_VIOLATION_RAD
                and (np.abs(data.qvel[self.arm_dofs]) <= speed_limits).all()
            )

        def motion(before: EnvProcess, after: EnvProcess) -> bool:
            _, previous = before.spec.layout.qv.pack(before.state.qv)
            _, current = after.spec.layout.qv.pack(after.state.qv)
            acceleration = (current[self.arm_dofs] - previous[self.arm_dofs]) / (
                after.state.t - before.state.t
            )
            return bool(
                jnp.isfinite(acceleration).all()
                and (jnp.abs(acceleration) <= acceleration_limits).all()
            )

        carried_terms = {
            name: self.scene.support[name]
            for name in ("thumb", "fingers", "opposition")
        }
        carried_values = bind_auxiliary_terms(env.spec, carried_terms)

        def carried(observed: EnvProcess) -> bool:
            """Require thumb and total finger support with opposed normals.

            Single fingers may unload while the object is carried; the wrench
            margin admitted the grasp against the lift load.
            """
            require_capacity(capacity(observed.state))
            return all(
                float(value) <= SUPPORT_LOSS_TOLERANCE
                for value in carried_values(observed.state).values()
            )

        def captured(observed: EnvProcess) -> bool:
            return all(
                float(value) <= SUPPORT_LOSS_TOLERANCE
                for value in capture_values(observed.state).values()
            )

        required_margin = self.required_lift_margin

        def graspable(observed: EnvProcess) -> bool:
            """The carried contacts can lift the object against the servo limits."""
            return carried(observed) and self.lift_margin(data).servo >= required_margin

        def lifted(observed: EnvProcess) -> bool:
            index = self.object_qpos
            qpos = data.qpos[index : index + 7][None]
            height = float(
                object_bottom_m(qpos, self.scene.assembly.obj.lift_vertices)[0]
            )
            _, _, floor = self.contact_state(data)
            if self.scene.assembly.obj.upright_axis is None:
                return height >= LIFT_THRESHOLD_M and not floor
            clearance = float(
                object_bottom_m(qpos, self.scene.assembly.obj.whole_vertices)[0]
            )
            rotation = Rotation.from_quat(qpos[0, 3:7][[1, 2, 3, 0]])
            tilt = float(
                np.arccos(
                    np.clip(
                        rotation.apply(self.scene.assembly.obj.upright_axis)[2], -1, 1
                    )
                )
            )
            return bool(
                height >= LIFT_THRESHOLD_M
                and clearance >= FLOOR_CLEARANCE_M
                and tilt <= MAXIMUM_HAMMER_TILT_RAD
                and not floor
            )

        def alignment(target: Floats):
            scratch = mujoco.MjData(self.model)
            scratch.qpos[:] = data.qpos
            scratch.qpos[qpos_ids] = target / gear
            mujoco.mj_kinematics(self.model, scratch)
            position = scratch.site_xpos[self.flange].copy()
            rotation = scratch.site_xmat[self.flange].reshape(3, 3).copy()

            def aligned(observed: EnvProcess) -> bool:
                actual = data.site_xmat[self.flange].reshape(3, 3)
                return bool(
                    np.linalg.norm(data.site_xpos[self.flange] - position) <= 0.01
                    and Rotation.from_matrix(rotation @ actual.T).magnitude() <= 0.1
                )

            return aligned

        def seeded_plan(
            observed: EnvProcess,
            horizon: float,
            target: Floats | jax.Array,
            transition_s: float,
        ) -> BoundedDensePlan:
            plan = BoundedDensePlan.from_env(
                observed, horizon, velocity_limits=tuple(command_velocity.tolist())
            )
            fraction = jnp.clip(
                (jnp.arange(len(plan.x)) + 1) * plan.dt / transition_s, 0, 1
            )
            blend = fraction**3 * (10 - 15 * fraction + 6 * fraction**2)
            seed = plan.previous_control + blend[:, None] * (
                target - plan.previous_control
            )
            return plan.with_params(seed, observed.spec)

        def controller(
            target: Floats,
            transition_s: float,
            plan_factory: Callable[
                [EnvProcess, float, Floats | jax.Array, float], BoundedDensePlan
            ] = seeded_plan,
            *,
            free_hand: bool = False,
            track_arm: bool = True,
            hold_hand: bool = False,
            lift_object: bool = False,
            hand_sigma: float = sigma,
            squeeze_rad: float = 0.0,
            horizon_scale: float = 1.0,
        ) -> MPCController:
            """Stage controller; ``hold_hand`` penalises hand control drift over
            the horizon so a free hand keeps the grip it has while the arm moves."""
            target_q = jnp.asarray(target / gear)
            # A capture plan may turn the wrist away from the stage target; its
            # stages leave the arm untracked so the loss does not pull it back.
            if not free_hand:
                tracked = np.arange(self.model.nu)
            elif track_arm:
                tracked = self.arm_actuators
            else:
                tracked = np.zeros(0, dtype=int)

            def feasible(spec: EnvSpec, states: EnvState) -> jax.Array:
                qpos, qvel = spec.layout.qv.pack(states.qv)
                speed = qvel[..., self.arm_dofs]
                acceleration = jnp.diff(speed, axis=1) / spec.dt
                angles = qpos[..., self.model.jnt_qposadr[hinge_ids]]
                limits = jnp.asarray(self.model.jnt_range[hinge_ids])
                violation = jnp.maximum(limits[:, 0] - angles, angles - limits[:, 1])
                accepted = (
                    jnp.isfinite(qpos).all(axis=(1, 2))
                    & (batch_penetration(states) <= penetration_limit).all(axis=1)
                    & jnp.isfinite(qvel).all(axis=(1, 2))
                    & (violation <= MAXIMUM_JOINT_VIOLATION_RAD).all(axis=(1, 2))
                    & (jnp.abs(speed) <= speed_limits).all(axis=(1, 2))
                    & (jnp.abs(acceleration) <= acceleration_limits).all(axis=(1, 2))
                )
                readings = jax.vmap(jax.vmap(spec.layout.y.pack))(states.y)
                for shape in self.hand_collision_shapes:
                    p, q = shape.position_channel, shape.quaternion_channel
                    rotations = matrix_from_quat(readings[..., q : q + 4])
                    bottom = (
                        readings[..., p + 2]
                        + jnp.min(
                            jnp.einsum(
                                "...j,nj->...n",
                                rotations[..., 2, :],
                                jnp.asarray(shape.points),
                            ),
                            axis=-1,
                        )
                        - shape.radius
                    )
                    accepted &= (bottom >= -penetration_limit).all(axis=1)
                return accepted

            def loss(spec: EnvSpec, states: EnvState) -> jax.Array:
                qpos, _ = spec.layout.qv.pack(states.qv)
                tracking = jnp.square(
                    qpos[..., qpos_ids[tracked]] - target_q[tracked]
                ).sum(axis=(-1, -2)) / (qpos.shape[-2] * max(len(tracked), 1))
                if hold_hand:
                    controls = jax.vmap(jax.vmap(spec.layout.u.pack))(states.u)[
                        ..., self.hand_actuators
                    ]
                    tracking += jnp.square(controls - controls[:, :1]).mean(
                        axis=(-1, -2)
                    )
                values = jax.vmap(jax.vmap(extra))(states)
                fixed = jax.vmap(jax.vmap(spec.get_loss))(states)
                if lift_object:
                    shortfall = jax.vmap(jax.vmap(lift_values))(states)["lift"]
                    # Normalize height shortfall in metres to the pickup threshold.
                    tracking += (
                        20.0
                        * (shortfall.mean(axis=1) + shortfall[:, -1])
                        / LIFT_THRESHOLD_M
                    )
                return (
                    tracking
                    + fixed.mean(axis=1)
                    + sum(values.values(), jnp.zeros_like(states.t)).mean(axis=1)
                )

            open_hand = jnp.asarray(pregrasp_target)[self.hand_actuators]
            hand_range = jnp.asarray(self.model.actuator_ctrlrange[self.hand_actuators])

            def plan_init(observed: EnvProcess, horizon: float) -> BoundedDensePlan:
                seed_target = jnp.asarray(target)
                if free_hand:
                    hand = observed.spec.layout.u.pack(observed.state.u)[
                        self.hand_actuators
                    ]
                    # Closing is the direction away from the open pregrasp hand.
                    hand = jnp.clip(
                        hand + squeeze_rad * jnp.sign(hand - open_hand),
                        hand_range[:, 0],
                        hand_range[:, 1],
                    )
                    seed_target = seed_target.at[self.hand_actuators].set(hand)
                return plan_factory(observed, horizon, seed_target, transition_s)

            def rollout(spec: EnvSpec, initial: EnvState, action: Action) -> EnvState:
                # Native sensors observe the pre-step state. A final held control
                # exposes contacts at the end of the executable horizon.
                action = jax.tree.map(
                    lambda values: jnp.concatenate((values, values[:, -1:]), axis=1),
                    action,
                )
                states = pool.rollout(spec, initial, action)
                require_capacity(batch_capacity(states))
                return jax.tree.map(
                    lambda first, series: jnp.concatenate(
                        (
                            jnp.broadcast_to(
                                first, (states.t.shape[0], 1, *jnp.shape(first))
                            ),
                            series,
                        ),
                        axis=1,
                    ),
                    initial,
                    states,
                )

            return MPCController(
                SamplingPlanner(
                    loss=jax.jit(loss),
                    feasible=jax.jit(feasible),
                    horizon=transition_s * horizon_scale,
                    batch_size=batch_size,
                    rounds=rounds,
                    replan_interval=MPC_REPLAN_INTERVAL_S,
                    sigma0=tuple(
                        0.1 if lift_object and i in self.arm_actuators else value
                        for i, value in enumerate(
                            sampling_sigma0(transition_s * horizon_scale, hand_sigma)
                        )
                    ),
                    noise_color=MPC_NOISE_COLOR,
                    plan_init=plan_init,
                    rollout=rollout,
                )
            )

        def arm_plan(
            observed: EnvProcess,
            horizon: float,
            target: Floats | jax.Array,
            transition_s: float,
            *,
            feedback_scale: float = ARM_FEEDBACK_SCALE,
        ) -> BoundedDensePlan:
            seed = seeded_plan(observed, horizon, target, transition_s)
            plan_type = SmoothArmLiftPlan if feedback_scale == 1.0 else LiftPlan
            return plan_type(
                x=seed.x,
                dt=seed.dt,
                previous_control=seed.previous_control,
                velocity_limits=seed.velocity_limits,
                arm_actuators=tuple(int(i) for i in self.arm_actuators),
                feedback_scale=feedback_scale,
            )

        def capture_plan(
            observed: EnvProcess,
            horizon: float,
            target: Floats | jax.Array,
            transition_s: float,
        ) -> BoundedDensePlan:
            scratch = observed.spec.layout.state_to_data(observed.state)
            # Every hand joint, abduction included, so the fingers can bunch up
            # on a narrow handle instead of landing along the whole object.
            selected = self.hand_actuators
            body = self.context.components[self.scene.assembly.obj.id].idx
            geoms = np.flatnonzero(
                (self.model.geom_bodyid == body)
                & ((self.model.geom_contype != 0) | (self.model.geom_conaffinity != 0))
            )
            ranges = self.model.actuator_ctrlrange[selected]
            # The search starts from the stage target's hand, not the observed
            # hand, so the solution does not depend on where in its motion the
            # hand was when the stage began.
            start = np.clip(np.asarray(target)[selected], *ranges.T)
            scratch.qpos[qpos_ids] = np.asarray(target) / gear
            mujoco.mj_forward(self.model, scratch)
            object_pose = scratch.qpos[self.object_qpos : self.object_qpos + 7]
            object_rotation = Rotation.from_quat(object_pose[3:7][[1, 2, 3, 0]])
            surface = object_pose[:3] + object_rotation.apply(
                self.scene.assembly.obj.whole_vertices
            )
            center = object_pose[:3] + object_rotation.apply(
                self.scene.assembly.grasp_point
            )
            # The hand reaches from the wrist toward the grasp point; the flange
            # axes do not follow the hand mount.
            approach = center - scratch.site_xpos[self.flange]
            approach /= np.linalg.norm(approach)
            # A world-frame flange twist (offset and yaw about the approach) is
            # realised by an inner arm IK from the stage target, re-linearised
            # each step, so a large yaw is reachable.
            flange_position = scratch.site_xpos[self.flange].copy()
            flange_rotation = scratch.site_xmat[self.flange].reshape(3, 3).copy()
            arm_qpos_ids = qpos_ids[self.arm_actuators]
            arm_range = self.model.jnt_range[
                self.model.actuator_trnid[self.arm_actuators, 0]
            ]
            target_arm = (
                np.asarray(target)[self.arm_actuators] / gear[self.arm_actuators]
            )
            twist_axes = np.zeros((6, len(CAPTURE_WRIST_FREEDOM)))
            twist_axes[:3, :3] = np.eye(3)
            twist_axes[3:, 3] = approach
            positional = np.empty((3, self.model.nv))
            rotational = np.empty((3, self.model.nv))
            hand_count = len(selected)

            def flange_jacobian() -> Floats:
                """Flange twist per unit arm joint velocity at the scratch pose."""
                mujoco.mj_jacSite(
                    self.model, scratch, positional, rotational, self.flange
                )
                return np.vstack((positional, rotational))[:, self.arm_dofs]

            def arm_for_twist(twist: Floats) -> Floats:
                """Arm angles placing the flange at the stage target moved by ``twist``."""
                goal_position = flange_position + twist[:3]
                goal_rotation = (
                    Rotation.from_rotvec(approach * twist[3]).as_matrix()
                    @ flange_rotation
                )
                arm = target_arm.copy()
                for _ in range(8):
                    scratch.qpos[arm_qpos_ids] = arm
                    mujoco.mj_kinematics(self.model, scratch)
                    mujoco.mj_comPos(self.model, scratch)
                    actual = scratch.site_xmat[self.flange].reshape(3, 3)
                    error = np.concatenate(
                        (
                            goal_position - scratch.site_xpos[self.flange],
                            Rotation.from_matrix(goal_rotation @ actual.T).as_rotvec(),
                        )
                    )
                    jacobian = flange_jacobian()
                    arm = np.clip(
                        arm
                        + jacobian.T
                        @ np.linalg.solve(
                            jacobian @ jacobian.T + 1e-6 * np.eye(6), error
                        ),
                        arm_range[:, 0],
                        arm_range[:, 1],
                    )
                return arm

            def desired_control(values: Floats) -> Floats:
                control = np.asarray(target).copy()
                control[selected] = values[:hand_count]
                control[self.arm_actuators] = (
                    arm_for_twist(values[hand_count:]) * gear[self.arm_actuators]
                )
                return control

            def nearest_surface(
                state_data: mujoco.MjData,
            ) -> list[tuple[float, Floats]]:
                """Signed gap and tip-to-object segment for each fingertip."""
                nearest = []
                for tip in self.fingertip_geoms:
                    candidates = []
                    for geom in geoms:
                        segment = np.empty(6)
                        gap = mujoco.mj_geomDistance(
                            self.model, state_data, int(tip), int(geom), 1.0, segment
                        )
                        candidates.append((gap, segment))
                    nearest.append(min(candidates, key=lambda pair: pair[0]))
                return nearest

            def geometry_score(state_data: mujoco.MjData) -> float:
                gaps, normals = [], []
                for gap, segment in nearest_surface(state_data):
                    gaps.append(gap)
                    normals.append(
                        (segment[3:] - segment[:3]) * np.sign(gap) / max(abs(gap), 1e-9)
                    )
                cosines = np.asarray(normals)[:3] @ np.asarray(normals)[3]
                return float(
                    np.square((np.asarray(gaps) + 0.001) / 0.002).sum()
                    + 3 * np.square(np.maximum(cosines + 0.6, 0) / 0.2).sum()
                )

            def static_score(values: Floats) -> float:
                control = desired_control(values)
                scratch.qpos[qpos_ids] = control / gear
                scratch.ctrl[:] = control
                mujoco.mj_forward(self.model, scratch)
                floor = min(
                    float(shape.bottom(scratch.sensordata[None])[0])
                    for shape in self.hand_collision_shapes
                )
                penetration = self.contact_state(scratch)[1]
                return geometry_score(scratch) + 1e4 * (
                    max(0, -floor / 0.001) ** 2
                    + max(0, (penetration - penetration_limit) / 0.001) ** 2
                )

            bounds = np.vstack(
                (
                    np.column_stack(
                        (
                            np.maximum(ranges[:, 0], start - 0.9),
                            np.minimum(ranges[:, 1], start + 0.9),
                        )
                    ),
                    np.column_stack((-CAPTURE_WRIST_FREEDOM, CAPTURE_WRIST_FREEDOM)),
                )
            )
            # Damped least squares over hand controls and the flange offset, from
            # opposed contact targets: thumb on one side of the grasp point,
            # fingers on the other, for a fan of closing directions and depths.
            tip_bodies = self.model.geom_bodyid[self.fingertip_geoms]
            hand_dofs = self.model.jnt_dofadr[self.model.actuator_trnid[selected, 0]]
            tips = scratch.geom_xpos[self.fingertip_geoms].copy()
            closing = tips[3] - tips[:3].mean(axis=0)
            closing -= (closing @ approach) * approach
            closing /= np.linalg.norm(closing)
            lateral = tips[:3] - tips[:3].mean(axis=0)
            lateral -= np.outer(lateral @ closing, closing)
            # Each finger target sits within CAPTURE_LATERAL_M of the centroid.
            lateral *= np.minimum(
                1.0, CAPTURE_LATERAL_M / np.linalg.norm(lateral, axis=1)
            )[:, None]

            def surface_along(origin: Floats, direction: Floats) -> Floats:
                """Surface point farthest along a ray, penalised off the ray."""
                relative = surface - origin
                along = relative @ direction
                off = np.linalg.norm(relative - np.outer(along, direction), axis=1)
                return surface[np.argmax(along - 4 * off)]

            intended = {
                frozenset((int(tip), int(geom)))
                for tip in self.fingertip_geoms
                for geom in geoms
            }

            def solve(
                values: Floats,
                goal: Callable[[], Floats],
                steps: int,
                *,
                hand_only: bool = False,
            ) -> Floats:
                """Damped least squares; ``hand_only`` keeps the wrist where it is."""

                def point_jacobian(
                    point: Floats, point_body: int, columns: Floats
                ) -> Floats:
                    """Point velocity per unit of the search variables; ``columns``
                    is the arm joint velocity per unit twist at the scratch pose."""
                    jacobian = np.empty((3, self.model.nv))
                    mujoco.mj_jac(
                        self.model, scratch, jacobian, None, point, point_body
                    )
                    return np.hstack(
                        (
                            jacobian[:, hand_dofs] / gear[selected],
                            jacobian[:, self.arm_dofs] @ columns,
                        )
                    )

                def collision_rows(
                    columns: Floats,
                ) -> tuple[list[Floats], list[float]]:
                    """Rows that separate every unintended penetrating contact."""
                    rows, residuals = [], []
                    for contact in scratch.contact[: scratch.ncon]:
                        pair = frozenset((int(contact.geom1), int(contact.geom2)))
                        if contact.dist >= 0 or pair in intended:
                            continue
                        normal = contact.frame[:3]
                        rows.append(
                            normal
                            @ (
                                point_jacobian(
                                    contact.pos,
                                    int(self.model.geom_bodyid[contact.geom2]),
                                    columns,
                                )
                                - point_jacobian(
                                    contact.pos,
                                    int(self.model.geom_bodyid[contact.geom1]),
                                    columns,
                                )
                            )
                        )
                        residuals.append(0.0005 - float(contact.dist))
                    return rows, residuals

                for _ in range(steps):
                    scratch.qpos[qpos_ids] = desired_control(values) / gear
                    mujoco.mj_fwdPosition(self.model, scratch)
                    columns = np.linalg.pinv(flange_jacobian()) @ twist_axes
                    rows = [
                        point_jacobian(scratch.geom_xpos[tip], int(tip_body), columns)
                        for tip, tip_body in zip(
                            self.fingertip_geoms, tip_bodies, strict=True
                        )
                    ]
                    # Separation outranks reaching: its rows carry three times
                    # the weight of a pad target.
                    separation, gaps = collision_rows(columns)
                    jacobian = np.vstack(rows + [3 * row for row in separation])
                    if hand_only:
                        jacobian[:, hand_count:] = 0
                    residual = np.concatenate((goal(), 3 * np.asarray(gaps)))
                    step = jacobian.T @ np.linalg.solve(
                        jacobian @ jacobian.T + 1e-4 * np.eye(len(residual)), residual
                    )
                    values = np.clip(values + step, *bounds.T)
                return values

            def reach(points: Floats) -> Callable[[], Floats]:
                """Residual that moves each pad centre onto its target point."""

                def residual() -> Floats:
                    return (points - scratch.geom_xpos[self.fingertip_geoms]).ravel()

                return residual

            def contact_residual() -> Floats:
                # Pads settle 1 mm into the nearest surface, as geometry_score asks.
                return np.concatenate(
                    [
                        (segment[3:] - segment[:3])
                        * (gap + 0.001)
                        / max(abs(gap), 1e-9)
                        * np.sign(gap)
                        for gap, segment in nearest_surface(scratch)
                    ]
                )

            solutions, preshapes, preshape_arms, spans = [], [], [], []
            # Each closing direction seeds the wrist yaw that aligns the hand.
            for angle in np.linspace(-np.pi / 2, np.pi / 2, 7):
                start_values = np.concatenate((start, np.zeros(3), [angle]))
                turn = Rotation.from_rotvec(approach * angle)
                axis = turn.apply(closing)
                spread = turn.apply(lateral)
                for depth in (-0.01, -0.005, 0.0, 0.005, 0.01):
                    origin = center + depth * approach
                    goals = [
                        surface_along(origin, axis) + CAPTURE_PAD_STANDOFF_M * axis
                    ]
                    goals.extend(
                        surface_along(origin + offset, -axis)
                        - CAPTURE_PAD_STANDOFF_M * axis
                        for offset in spread
                    )
                    # Fingertip geoms are ordered fingers then thumb.
                    targets = np.vstack((goals[1:], goals[:1]))
                    spans.append(
                        float(np.linalg.norm(goals[0] - np.mean(goals[1:], axis=0)))
                    )
                    values = solve(start_values, reach(targets), 25)
                    # Fingers open along -axis, the thumb along +axis.
                    wide = targets + (
                        CAPTURE_PRESHAPE_STANDOFF_M - CAPTURE_PAD_STANDOFF_M
                    ) * np.vstack((-axis, -axis, -axis, axis))
                    final = solve(values, contact_residual, 10)
                    solutions.append(final)
                    # The preshape keeps its own wrist pose: open pads at side
                    # height need a lower wrist than the closed hand does.
                    preshape = solve(final, reach(wide), 15)
                    preshapes.append(preshape[:hand_count])
                    preshape_arms.append(desired_control(preshape)[self.arm_actuators])
            solution_array = np.asarray(solutions)
            preshape_array = np.asarray(preshapes)
            preshape_arm_array = np.asarray(preshape_arms)
            static_scores = np.array(
                [static_score(values) for values in solution_array]
            ) + np.square(np.asarray(spans) / CAPTURE_PINCH_SPAN_M)
            # Full arm feedback: the MPC loss, floor clearance included, chooses
            # how far the wrist descends while the hand closes.
            base = seeded_plan(observed, horizon, target, transition_s)

            # Closing schedules over the transition, as (wrist, hand) blends:
            # together, wrist first, hand first. Fingers that arrive before the
            # thumb push a light object away, so the rollout score chooses.
            def smoothstep(fraction: jax.Array) -> jax.Array:
                return fraction**3 * (10 - 15 * fraction + 6 * fraction**2)

            fraction = jnp.clip((jnp.arange(len(base.x)) + 1) * dt / transition_s, 0, 1)
            first = smoothstep(jnp.clip(2 * fraction, 0, 1))
            second = smoothstep(jnp.clip(2 * fraction - 1, 0, 1))
            together = smoothstep(fraction)
            # "preshape then close" opens the hand to its preshape before the
            # wrist descends, so the open pads clear the object, then closes.
            # The staged schedule spans the whole horizon so its wrist descent
            # takes as long as the plain transition and stays within the arm's
            # acceleration limits.
            horizon_fraction = (jnp.arange(len(base.x)) + 1) / len(base.x)
            opening = smoothstep(jnp.clip(4 * horizon_fraction, 0, 1))
            descent = smoothstep(jnp.clip(4 * horizon_fraction - 1, 0, 1))
            staged_close = smoothstep(jnp.clip(2 * horizon_fraction - 1, 0, 1))
            arm_blends = jnp.stack((together, first, second, descent))
            hand_blends = jnp.stack((together, second, first, staged_close))
            offsets = slice(hand_count, hand_count + len(CAPTURE_WRIST_FREEDOM))
            preshape_values = slice(offsets.stop, offsets.stop + hand_count)
            arm_values = slice(
                preshape_values.stop, preshape_values.stop + len(self.arm_actuators)
            )
            preshape_arm_values = slice(
                arm_values.stop, arm_values.stop + len(self.arm_actuators)
            )
            target_arm_control = jnp.asarray(target)[self.arm_actuators]
            staged = len(CLOSING_SCHEDULES) - 1

            def contact_plan(values: jax.Array) -> BoundedDensePlan:
                """Plan for hand controls, wrist twist, preshape, solved arm
                controls and schedule index."""
                previous = base.previous_control[self.hand_actuators]
                desired = (
                    jnp.asarray(target)
                    .at[selected]
                    .set(values[:hand_count])[self.hand_actuators]
                )
                preshape = (
                    jnp.asarray(target)
                    .at[selected]
                    .set(values[preshape_values])[self.hand_actuators]
                )
                schedule = values[-1].astype(int)
                arm_final = values[arm_values] - target_arm_control
                arm_preshape = values[preshape_arm_values] - target_arm_control
                staged_path = descent[:, None] * arm_preshape + staged_close[
                    :, None
                ] * (arm_final - arm_preshape)
                direct_path = arm_blends[schedule][:, None] * arm_final
                x = base.x.at[:, self.arm_actuators].add(
                    jnp.where(schedule == staged, staged_path, direct_path)
                )
                start = jnp.where(schedule == staged, preshape, previous)
                reach_start = jnp.where(schedule == staged, opening, first)
                hand = (
                    previous
                    + reach_start[:, None] * (start - previous)
                    + hand_blends[schedule][:, None] * (desired - start)
                )
                return base.with_params(
                    x.at[:, self.hand_actuators].set(hand), observed.spec
                )

            score_steps = len(base.x)
            settle_steps = round(0.3 / dt)
            # Penetration is sampled along each rollout at this spacing; the
            # hand and object move slowly enough that it does not spike between
            # samples, and sampling every tick made a plan take twenty minutes.
            penetration_stride = round(PENETRATION_SAMPLE_S / dt)
            carried_batch = jax.jit(jax.vmap(jax.vmap(carried_values)))
            auxiliary_batch = jax.jit(jax.vmap(jax.vmap(extra)))
            action_batch = jax.jit(
                jax.vmap(
                    lambda values: contact_plan(values)(jnp.arange(score_steps) * dt)
                )
            )

            def prediction_at(states: EnvState, index: int, tick: int) -> EnvState:
                return observed.state.replace(
                    t=states.t[index, tick],
                    qv=jax.tree.map(lambda leaf: leaf[index, tick], states.qv),
                    fixed_q=jax.tree.map(
                        lambda leaf: leaf[index, tick], states.fixed_q
                    ),
                    y=jax.tree.map(lambda leaf: leaf[index, tick], states.y),
                    u=jax.tree.map(lambda leaf: leaf[index, tick], states.u),
                )

            def score_population(population: Floats) -> Floats:
                actions = action_batch(jnp.asarray(population))
                states = pool.rollout(
                    observed.spec,
                    observed.state,
                    observed.spec.layout.u.unpack(actions),
                )
                require_capacity(batch_capacity(states))
                penalties = carried_batch(states)
                # Acquisition is ranked after the wrist trajectory has settled,
                # on the carried terms that gate GRASP: a thumb-and-two-finger
                # pinch is a valid capture even if one finger never loads.
                scores = 3 * np.array(
                    sum(value[:, -settle_steps:] for value in penalties.values()).mean(
                        axis=1
                    )
                )
                auxiliary = auxiliary_batch(states)
                scores += np.asarray(
                    sum(value[:, -settle_steps:] for value in auxiliary.values()).mean(
                        axis=1
                    )
                )
                readings = np.asarray(
                    jax.vmap(jax.vmap(observed.spec.layout.y.pack))(states.y)
                )
                floors = np.minimum.reduce(
                    [
                        shape.bottom(readings.reshape(-1, readings.shape[-1])).reshape(
                            readings.shape[:2]
                        )
                        for shape in self.hand_collision_shapes
                    ]
                ).min(axis=1)
                scores += 1e4 * np.square(np.maximum(0, -floors / 0.001))
                # A schedule may not win by exceeding the arm's limits.
                _, velocity = observed.spec.layout.qv.pack(states.qv)
                arm_speed = np.asarray(velocity)[..., self.arm_dofs]
                arm_acceleration = np.diff(arm_speed, axis=1) / dt
                scores += 1e4 * (
                    np.square(np.maximum(0, np.abs(arm_speed) / speed_limits - 1)).max(
                        axis=(1, 2)
                    )
                    + np.square(
                        np.maximum(
                            0, np.abs(arm_acceleration) / acceleration_limits - 1
                        )
                    ).max(axis=(1, 2))
                )
                states = jax.device_get(states)
                # The ranking charges every admission condition, so the winner
                # is the best admissible candidate rather than the best scoring
                # one that then fails admission.
                for index in range(len(population)):
                    worst_penetration = 0.0
                    for tick in range(0, score_steps, penetration_stride):
                        check = observed.spec.layout.state_to_data(
                            prediction_at(states, index, tick)
                        )
                        mujoco.mj_forward(self.model, check)
                        worst_penetration = max(
                            worst_penetration, self.contact_state(check)[1]
                        )
                    endpoint = prediction_at(states, index, -1)
                    predicted = observed.spec.layout.state_to_data(endpoint)
                    mujoco.mj_forward(self.model, predicted)
                    worst_penetration = max(
                        worst_penetration, self.contact_state(predicted)[1]
                    )
                    shortfall = required_margin - self.lift_margin(predicted).servo
                    scores[index] += (
                        geometry_score(predicted)
                        + 1e4
                        * max(0, (worst_penetration - penetration_limit) / 0.001) ** 2
                        + 1e4 * max(0, shortfall) ** 2
                    )
                return scores

            order = np.argsort(static_scores)[:CAPTURE_ROLLOUTS]
            arm_controls = np.array(
                [
                    desired_control(values)[self.arm_actuators]
                    for values in solution_array[order]
                ]
            )
            shortlist = np.column_stack(
                (
                    solution_array[order],
                    preshape_array[order],
                    arm_controls,
                    preshape_arm_array[order],
                )
            )
            candidates = np.vstack(
                [
                    np.column_stack((shortlist, np.full(len(shortlist), schedule)))
                    for schedule in range(len(CLOSING_SCHEDULES))
                ]
            )
            # Four rollouts per batch keep the contact observations within capacity.
            dynamic_scores = np.concatenate(
                [
                    score_population(candidates[start : start + 4])
                    for start in range(0, len(candidates), 4)
                ]
            )
            best = candidates[np.argmin(dynamic_scores)]
            proposal = contact_plan(jnp.asarray(best))
            actions = proposal(jnp.arange(len(proposal.x)) * dt)[None]
            predicted = pool.rollout(
                observed.spec, observed.state, observed.spec.layout.u.unpack(actions)
            )
            require_capacity(batch_capacity(predicted))
            predicted = jax.device_get(predicted)
            _, velocity = observed.spec.layout.qv.pack(predicted.qv)
            _, previous_velocity = observed.spec.layout.qv.pack(observed.state.qv)
            arm_speed = np.asarray(velocity)[..., self.arm_dofs]
            arm_acceleration = (
                np.diff(
                    np.concatenate(
                        (
                            np.asarray(previous_velocity)[self.arm_dofs][None, None],
                            arm_speed,
                        ),
                        axis=1,
                    ),
                    axis=1,
                )
                / dt
            )
            admitted = bool(
                (np.abs(arm_speed) <= speed_limits).all()
                and (np.abs(arm_acceleration) <= acceleration_limits).all()
            )
            minimum_floor, maximum_penetration, maximum_joint_violation = (
                np.inf,
                0.0,
                0.0,
            )
            for tick in range(len(proposal.x)):
                state = prediction_at(predicted, 0, tick)
                check = observed.spec.layout.state_to_data(state)
                mujoco.mj_forward(self.model, check)
                floor = min(
                    float(shape.bottom(check.sensordata[None])[0])
                    for shape in self.hand_collision_shapes
                )
                penetration = self.contact_state(check)[1]
                angles = check.qpos[self.model.jnt_qposadr[hinge_ids]]
                limits = self.model.jnt_range[hinge_ids]
                violation = float(
                    np.maximum(limits[:, 0] - angles, angles - limits[:, 1]).max()
                )
                minimum_floor = min(minimum_floor, floor)
                maximum_penetration = max(maximum_penetration, penetration)
                maximum_joint_violation = max(maximum_joint_violation, violation)
                admitted &= (
                    penetration <= penetration_limit
                    and violation <= MAXIMUM_JOINT_VIOLATION_RAD
                )
            endpoint = prediction_at(predicted, 0, -1)
            capture = {
                name: float(value) for name, value in capture_values(endpoint).items()
            }
            admitted &= all(
                value <= SUPPORT_LOSS_TOLERANCE for value in capture.values()
            )
            endpoint_data = observed.spec.layout.state_to_data(endpoint)
            mujoco.mj_forward(self.model, endpoint_data)
            margin = self.lift_margin(endpoint_data)
            admitted &= margin.servo >= required_margin
            ratios = np.abs(arm_acceleration) / acceleration_limits
            _, worst_tick, worst_joint = np.unravel_index(
                np.argmax(ratios), ratios.shape
            )
            object_qpos = check.qpos[self.object_qpos : self.object_qpos + 7]
            target_world = object_qpos[:3] + Rotation.from_quat(
                object_qpos[3:7][[1, 2, 3, 0]]
            ).apply(self.scene.assembly.grasp_point)
            print(
                "CONTACT_PROPOSAL",
                {
                    "admitted": bool(admitted),
                    "static_cost": float(static_scores.min()),
                    "dynamic_cost": float(dynamic_scores.min()),
                    "closing_schedule": CLOSING_SCHEDULES[int(best[-1])],
                    "schedule_costs": dict(
                        zip(
                            CLOSING_SCHEDULES,
                            dynamic_scores.reshape(len(CLOSING_SCHEDULES), -1)
                            .min(axis=1)
                            .tolist(),
                            strict=True,
                        )
                    ),
                    "endpoint_control": np.asarray(proposal.x[-1]).tolist(),
                    "capture_penalties": capture,
                    "lift_margin": margin.model_dump(),
                    "required_lift_margin": required_margin,
                    "support_penalties": {
                        name: float(value)
                        for name, value in support_values(endpoint).items()
                    },
                    "minimum_floor_m": float(minimum_floor),
                    "maximum_penetration_m": float(maximum_penetration),
                    "maximum_joint_violation_rad": float(maximum_joint_violation),
                    "maximum_arm_speed_ratio": float(
                        (np.abs(arm_speed) / speed_limits).max()
                    ),
                    "maximum_arm_acceleration_ratio": float(ratios.max()),
                    "worst_acceleration_time_s": float((worst_tick + 1) * dt),
                    "worst_acceleration_joint": int(worst_joint),
                    "object_qpos": object_qpos.tolist(),
                    "grasp_target_world_m": target_world.tolist(),
                    "native_pad_centers_f0_f1_f2_thumb_m": check.geom_xpos[
                        self.fingertip_geoms
                    ].tolist(),
                },
                flush=True,
            )
            # The open-hand base reaches the capture depth with fingertips in the
            # table, so MPC always starts from the closing proposal.
            return proposal

        stages: tuple[Stage[SamplingState], ...] = (
            Stage(
                controller(targets[0], 1.9), alignment(targets[0]), physical, 0.1, 2.0
            ),
            Stage(
                controller(targets[1], 1.5), alignment(targets[1]), physical, 0.1, 1.6
            ),
            Stage(
                controller(
                    targets[2],
                    1.5,
                    capture_plan,
                    free_hand=True,
                    track_arm=False,
                    horizon_scale=2.0,
                ),
                captured,
                physical,
                0.1,
                4.0,
            ),
        )
        if self.scene.assembly.obj.upright_axis is None:
            # Acquire support and lift together; static capacity is not a pickup.
            stages += (
                Stage(
                    controller(
                        targets[3],
                        LIFT_TRANSITION_S,
                        partial(arm_plan, feedback_scale=1.0),
                        free_hand=True,
                        track_arm=False,
                        lift_object=True,
                        hand_sigma=LIFT_HAND_SIGMA,
                        squeeze_rad=LIFT_SQUEEZE_RAD,
                    ),
                    lifted,
                    physical,
                    0.25,
                    4.0,
                ),
                Stage(
                    controller(
                        targets[4],
                        HOLD_TRANSITION_S,
                        partial(arm_plan, feedback_scale=1.0),
                        free_hand=True,
                        track_arm=False,
                        lift_object=True,
                        hand_sigma=LIFT_HAND_SIGMA,
                        squeeze_rad=LIFT_SQUEEZE_RAD,
                    ),
                    lifted,
                    physical,
                    HOLD_DURATION_S,
                    2.0,
                ),
            )
        else:
            stages += (
                Stage(
                    controller(
                        targets[2],
                        1.5,
                        capture_plan,
                        free_hand=True,
                        track_arm=False,
                        horizon_scale=2.0,
                    ),
                    graspable,
                    physical,
                    0.15,
                    HAMMER_GRASP_TIMEOUT_S,
                    lapse_s=GRASP_LAPSE_S,
                ),
            )
            radius = self.swept_radius
            clearance_target = controls[round(4 * WAYPOINT_DURATION_S / dt) - 1]
            aligned_clearance = alignment(clearance_target)

            def swept_clear(observed: EnvProcess) -> bool:
                qpos = data.qpos[self.object_qpos : self.object_qpos + 7]
                rotation = Rotation.from_quat(qpos[3:7][[1, 2, 3, 0]])
                center = qpos[:3] + rotation.apply(self.scene.assembly.grasp_point)
                _, _, floor = self.contact_state(data)
                return bool(
                    center[2] >= radius + FLOOR_CLEARANCE_M
                    and not floor
                    and aligned_clearance(observed)
                )

            def cleared(observed: EnvProcess) -> bool:
                qpos = data.qpos[self.object_qpos : self.object_qpos + 7]
                _, _, floor = self.contact_state(data)
                return bool(
                    physical(observed)
                    and object_bottom_m(qpos, self.scene.assembly.obj.whole_vertices)
                    >= FLOOR_CLEARANCE_M
                    and not floor
                )

            stages += (
                Stage(
                    controller(
                        clearance_target,
                        UPRIGHT_CLEARANCE_TRANSITION_S,
                        arm_plan,
                        free_hand=True,
                    ),
                    swept_clear,
                    physical,
                    0.1,
                    3.0,
                    recoverable=carried,
                    recovery_s=recovery_s,
                ),
                Stage(
                    controller(
                        targets[3],
                        UPRIGHT_LIFT_TRANSITION_S,
                        arm_plan,
                        free_hand=True,
                        hold_hand=True,
                        hand_sigma=LIFT_HAND_SIGMA,
                        squeeze_rad=LIFT_SQUEEZE_RAD,
                    ),
                    lifted,
                    cleared,
                    0.25,
                    4.0,
                    recoverable=carried,
                    recovery_s=recovery_s,
                ),
                Stage(
                    controller(
                        targets[4],
                        HOLD_TRANSITION_S,
                        free_hand=True,
                        hold_hand=True,
                        hand_sigma=LIFT_HAND_SIGMA,
                        squeeze_rad=LIFT_SQUEEZE_RAD,
                    ),
                    lifted,
                    cleared,
                    HOLD_DURATION_S,
                    2.0,
                    recoverable=carried,
                    recovery_s=recovery_s,
                ),
            )
        return Session(env, stages, data=data, pool=pool, motion_invariant=motion)

    def measure(self, data: mujoco.MjData) -> PhysicalMeasurements:
        """Copy the native physical pickup measurements at one tick."""
        force, penetration, object_floor = self.contact_state(data)
        qpos = data.qpos[self.object_qpos : self.object_qpos + 7]
        axis = self.scene.assembly.obj.upright_axis
        tilt = (
            0.0
            if axis is None
            else float(
                np.arccos(
                    np.clip(
                        Rotation.from_quat(qpos[3:7][[1, 2, 3, 0]]).apply(axis)[2],
                        -1,
                        1,
                    )
                )
            )
        )
        hinges = np.flatnonzero(self.model.jnt_type == mujoco.mjtJoint.mjJNT_HINGE)
        angles = data.qpos[self.model.jnt_qposadr[hinges]]
        limits = self.model.jnt_range[hinges]
        return {
            "time_s": float(data.time),
            "force_n": force,
            "penetration_m": penetration,
            "object_floor": object_floor,
            "target_bottom_m": float(
                object_bottom_m(qpos, self.scene.assembly.obj.lift_vertices)
            ),
            "whole_bottom_m": float(
                object_bottom_m(qpos, self.scene.assembly.obj.whole_vertices)
            ),
            "tilt_rad": tilt,
            "joint_violation_rad": max(
                0.0,
                float(np.maximum(limits[:, 0] - angles, angles - limits[:, 1]).max()),
            ),
        }

    def outcome(
        self,
        pose: TargetPose,
        samples: Sequence[PhysicalMeasurements],
        *,
        hold_start_s: float,
    ) -> Outcome:
        """Reduce full-rate native endpoints over the actual hold window."""
        start_index = round(
            (hold_start_s - samples[0]["time_s"]) / self.model.opt.timestep
        )
        hold = samples[start_index:]
        minimum = min(sample["target_bottom_m"] for sample in hold)
        return Outcome(
            pose=pose,
            hold_duration_s=(len(hold) - 1) * self.model.opt.timestep,
            hold=(
                ObjectHold(minimum_hold_lift_m=minimum)
                if self.scene.assembly.obj.upright_axis is None
                else UprightHammerHold(
                    minimum_hold_lift_m=minimum,
                    minimum_hold_ground_clearance_m=min(
                        sample["whole_bottom_m"] for sample in hold
                    ),
                    maximum_hold_tilt_rad=max(sample["tilt_rad"] for sample in hold),
                )
            ),
            hand_contact_fraction=float(
                np.mean([sample["force_n"] > ACTIVE_CONTACT_FORCE_N for sample in hold])
            ),
            maximum_grip_force_n=max(sample["force_n"] for sample in samples),
            maximum_penetration_m=max(sample["penetration_m"] for sample in samples),
            object_ground_contact_during_hold=any(
                sample["object_floor"] for sample in hold
            ),
            joint_limit_violation_rad=max(
                sample["joint_violation_rad"] for sample in samples
            ),
        )

    def record(
        self, pose: TargetPose, grasp: Grasp, output: Path
    ) -> Outcome | UnreachablePose:
        """Execute a full episode, recording native active contacts and replay."""
        data = self.reset(pose)
        output.mkdir(parents=True, exist_ok=False)
        controls = self.trajectory(data, grasp)
        if controls is None:
            rejected = UnreachablePose(pose=pose)
            (output / "outcome.json").write_text(
                rejected.model_dump_json(indent=2) + "\n"
            )
            return rejected
        scene = self.recording.info.scene.model_copy(
            update={
                "object_xy_m": pose.xy_m,
                "object_yaw_rad": pose.yaw_rad,
                "object_tilt_rad": pose.tilt_rad,
            }
        )
        info = self.recording.info.model_copy(update={"scene": scene})
        recording = Recording(info, data.qacc_warmstart.copy())
        recording.append(data)
        samples = [self.measure(data)]
        start = data.time
        for target in controls:
            data.ctrl[:] = target
            mujoco.mj_step(self.model, data)
            mujoco.mj_kinematics(self.model, data)
            recording.append(data)
            samples.append(self.measure(data))
        outcome = self.outcome(
            pose, samples, hold_start_s=start + self.duration - HOLD_DURATION_S
        )
        recording.save(output)
        mujoco.mj_saveModel(self.model, str(output / "scene.mjb"))
        (output / "outcome.json").write_text(outcome.model_dump_json(indent=2) + "\n")
        return outcome


@dataclass
class GraspDesigner(PickupDirector):
    """Propose a physical grasp and shared auxiliary loss before reapproach."""

    pickup: Pickup = field(metadata={"persist": False}, repr=False)

    @Skill.define
    def design_grasp(
        self, scenes: Sequence[PickupScene], feedback: BaseModel
    ) -> tuple[
        GraspPlan,
        Annotated[Encodable[RewardFn], AfterValidator(check_reward)],
    ]:
        """Propose a grasp plan and one shared auxiliary factory for {self.goal}.

        Scenes: {scenes}
        Native grasp evidence: {feedback}
        Inspect object parts, axes, collision pads and contacts in the REPL.
        Choose an object-local point and bounded wrist/closure pose for the
        current object. Before returning, use the REPL to call
        self.pickup.trajectory(self.session.data, proposed.grasp,
            grasp_point_m=proposed.grasp_point_m).
        None is an authoritative bounded IK refusal: revise the proposal.
        CAPTURE admits only an endpoint whose contacts could carry the object
        off the table: CONTACT_PROPOSAL reports lift_margin, the multiples of
        the object's weight the hand carries without the table, and refuses a
        servo margin below required_lift_margin. Contacts below the object's
        centre of mass that do not press it into the table raise the margin.
        Return a reachable solution and inspect finite controls/native bounds.
        This is scratch IK, not physical grasp or collision/path safety.
        Do not mutate live data, scene or point. Reapproach queries must start
        from the original restored boundary, not a displaced object.
        The executor physically reapproaches; it does not teleport to the pose.
        During GRASP, MPC jointly adjusts the seven Panda and sixteen hand joints.
        CAPTURE first aligns pads with opposite material regions. Capture, grasp and
        retention optimize hand controls from the issued state; the grasp angles size
        the scratch IK proposal and do not prescribe an empty closed-hand trajectory.
        Your scene-dependent loss guides those coupled samples; grasp and lift are
        gated on thumb support, total finger support and opposed loaded normals,
        plus a servo wrench margin that covers the lift. Single fingers may unload
        while the object is carried; the hand may rest on the table within the
        penetration limit.
        Return a factory for both scenes, not terms captured from an old graph.
        Minimize nonnegative support shortfalls; raw contact forces are not
        penalties. Physical gates, masses, friction and limits remain fixed.
        """
        raise NotHandled


def main() -> None:
    """Run a reproducible native trajectory search and held-out pose evaluation."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--object", choices=tuple(OBJECT_CONFIGS), required=True)
    parser.add_argument("--mesh-path", type=Path, required=True)
    parser.add_argument("--object-mass", type=float)
    parser.add_argument("--grasp-friction", type=float)
    parser.add_argument("--output", type=Path, required=True)
    defaults = SearchSettings()
    parser.add_argument("--generations", type=int, default=defaults.generations)
    parser.add_argument("--population", type=int, default=defaults.population)
    parser.add_argument("--workers", type=int, default=defaults.workers)
    parser.add_argument("--duration", type=float, default=defaults.duration_s)
    parser.add_argument("--seed", type=int, default=defaults.seed)
    parser.add_argument("--training-count", type=int, choices=(1, 4), default=4)
    parser.add_argument("--initial-grasp", type=Path)
    parser.add_argument(
        "--grasp-point",
        type=float,
        nargs=3,
        help="object-local grasp reference in metres",
    )
    parser.add_argument("--hand-design", type=Path)
    parser.add_argument("--objective", type=Path)
    args = parser.parse_args()
    settings = SearchSettings(
        generations=args.generations,
        population=args.population,
        workers=args.workers,
        duration_s=args.duration,
        seed=args.seed,
    )
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / "settings.json").write_text(
        settings.model_dump_json(indent=2) + "\n"
    )
    scene = SceneConfig(
        object_name=args.object,
        mesh_path=args.mesh_path.resolve(),
        object_mass_kg=args.object_mass,
        grasp_friction=args.grasp_friction,
        grasp_point_m=args.grasp_point,
        hand_design=(
            HandDesign.model_validate_json(args.hand_design.read_text())
            if args.hand_design is not None
            else HandDesign()
        ),
    )
    objective = (
        TypeAdapter(Objective).validate_json(args.objective.read_text())
        if args.objective is not None
        else PickupObjective()
    )
    with jax.enable_x64():
        pickup = Pickup.make(
            scene,
            args.output / "base",
            settings.duration_s,
            objective,
        )
    training_poses = TRAINING_POSES[: args.training_count]
    poses = PoseSet(training_poses=training_poses, evaluation_poses=EVALUATION_POSES)
    (args.output / "poses.json").write_text(poses.model_dump_json(indent=2) + "\n")
    initial = [pickup.reset(pose) for pose in training_poses]
    full = mujoco.mjtState.mjSTATE_FULLPHYSICS
    initial_states = []
    for data in initial:
        state = np.empty(mujoco.mj_stateSize(pickup.model, full))
        mujoco.mj_getState(pickup.model, data, state, full)
        initial_states.append(state)
    rng = np.random.default_rng(settings.seed)
    seed_grasp = (
        Grasp.model_validate_json(args.initial_grasp.read_text())
        if args.initial_grasp is not None
        else Grasp()
    )
    mean = np.array(list(seed_grasp.model_dump().values()))
    sigma = (GRASP_BOUNDS[:, 1] - GRASP_BOUNDS[:, 0]) * 0.15
    best, best_score = seed_grasp, float("inf")
    history = []
    with mujoco.rollout.Rollout(nthread=settings.workers) as backend:
        workers = [mujoco.MjData(pickup.model) for _ in range(settings.workers)]
        for generation in range(settings.generations):
            samples = np.clip(
                rng.normal(mean, sigma, size=(settings.population, len(mean))),
                *GRASP_BOUNDS.T,
            )
            samples[0] = np.array(list(best.model_dump().values()))
            candidates = [
                Grasp.model_validate(dict(zip(Grasp.model_fields, row, strict=True)))
                for row in samples
            ]
            scores = np.zeros(settings.population)
            for data, state in zip(initial, initial_states, strict=True):
                trajectories = [pickup.trajectory(data, grasp) for grasp in candidates]
                reachable = [
                    i for i, controls in enumerate(trajectories) if controls is not None
                ]
                scores[
                    [i for i, controls in enumerate(trajectories) if controls is None]
                ] = np.inf
                if not reachable:
                    continue
                controls = np.stack(
                    [control for control in trajectories if control is not None]
                )
                states, readings = backend.rollout(
                    pickup.model,
                    workers,
                    state,
                    controls,
                    initial_warmstart=data.qacc_warmstart,
                )
                scores[reachable] += [
                    pickup.score(s, y, data)
                    for s, y in zip(states, readings, strict=True)
                ]
            order = np.argsort(scores)
            (args.output / f"generation-{generation:03d}.json").write_text(
                Generation(
                    candidates=candidates,
                    scores=[
                        float(score) if np.isfinite(score) else None for score in scores
                    ],
                ).model_dump_json(indent=2)
                + "\n"
            )
            if not np.isfinite(scores).any():
                raise RuntimeError(
                    f"No reachable candidate in generation {generation}; revise seed or target poses"
                )
            if scores[order[0]] < best_score:
                best_score, best = float(scores[order[0]]), candidates[order[0]]
            elites = samples[order[: max(3, settings.population // 5)]]
            mean = elites.mean(axis=0)
            sigma = np.maximum(
                elites.std(axis=0), (GRASP_BOUNDS[:, 1] - GRASP_BOUNDS[:, 0]) * 0.025
            )
            history.append(best_score)
            print(
                f"Generation {generation}: score {best_score:.6f}; {best.model_dump_json()}",
                flush=True,
            )
            (args.output / "best-grasp.json").write_text(
                best.model_dump_json(indent=2) + "\n"
            )
    training = [
        pickup.record(pose, best, args.output / pose.name) for pose in training_poses
    ]
    evaluation = [
        pickup.record(pose, best, args.output / pose.name) for pose in EVALUATION_POSES
    ]
    result = SearchResult(
        scene=scene,
        grasp=best,
        training=training,
        evaluation=evaluation,
        episode_duration_s=settings.duration_s,
        generation_scores=history,
        objective=objective,
    )
    (args.output / "summary.json").write_text(result.model_dump_json(indent=2) + "\n")
    print(
        f"Training {sum(o.lifted for o in training)}/{len(training)}; evaluation {sum(o.lifted for o in evaluation)}/{len(evaluation)}",
        flush=True,
    )


if __name__ == "__main__":
    main()

"""Run the canonical screwdriver grasp designer and staged native controller."""

import argparse
import json
import runpy
from collections.abc import Callable
from contextlib import closing
from inspect import getfile
from pathlib import Path
from time import perf_counter, sleep
from typing import Any, cast

import jax
import mujoco
import numpy as np
from effectful.handlers.llm import Encodable
from effectful.handlers.llm.harness import harness
from effectful.ops.semantics import evaluate, handler
from pydantic import TypeAdapter

from experiments.panda_leap_pickup import (
    TRAINING_POSES,
    WAYPOINT_DURATION_S,
    Grasp,
    GraspDesigner,
    GraspPlan,
    Outcome,
    Pickup,
    PickupObjective,
    UnreachablePose,
)
from experiments.pickup_director import (
    RewardFn,
    Session,
    Snapshot,
    bind_auxiliary_terms,
    check_reward,
    probe_budget,
    probe_env,
)
from robotl.examples.panda_leap_teleop import Recording, SceneConfig, replay
from robotl.handlers.mujoco.control.stages import StageStatus
from robotl.handlers.mujoco.process import EnvState


def support_loss(scene):
    return scene.support


def integration(model, data):
    result = np.empty(mujoco.mj_stateSize(model, mujoco.mjtState.mjSTATE_INTEGRATION))
    mujoco.mj_getState(model, data, result, mujoco.mjtState.mjSTATE_INTEGRATION)
    return result


def capture_proof(
    candidate: Pickup,
    session: Session,
    geometry: Callable[[EnvState], dict[str, jax.Array]],
    endpoint: EnvState,
) -> dict[str, Any]:
    scratch = session.env.spec.layout.state_to_data(endpoint)
    mujoco.mj_forward(candidate.model, scratch)
    values = {name: float(value) for name, value in geometry(endpoint).items()}
    return {
        "capture_values": values,
        "raw_normalized_pad_gaps_and_opposition": {
            name: float(evaluate(term.expr1, intp=session.env.spec.intp(endpoint)))
            for name, term in candidate.scene.capture.items()
        },
        "floor_clearance_m": min(
            float(shape.bottom(scratch.sensordata[None])[0])
            for shape in candidate.hand_collision_shapes
        ),
        "penetration_m": max(
            [0, *(-float(contact.dist) for contact in scratch.contact)]
        ),
        "geometric_capture_passed": all(value <= 1e-8 for value in values.values()),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coding-agent", action="store_true")
    parser.add_argument("--center-only-diagnostic", action="store_true")
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--loss", type=Path)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--rounds", type=int, default=1)
    parser.add_argument("--mesh-path", type=Path, required=True)
    parser.add_argument("--object", required=True)
    args = parser.parse_args()
    if (args.plan or args.loss) and not args.coding_agent:
        parser.error("--plan and --loss require --coding-agent")
    if args.coding_agent and (args.plan is None or args.loss is None):
        parser.error("--coding-agent requires --plan and --loss")
    proposal = (
        GraspPlan.model_validate_json(args.plan.read_text())
        if args.coding_agent
        else None
    )
    root = Path.cwd()
    output = args.output or root / "runs" / (
        "coding-agent-control-05" if args.coding_agent else "agent-control-04"
    )
    output.mkdir(exist_ok=False)
    config = SceneConfig(
        object_name=args.object,
        mesh_path=args.mesh_path,
        grasp_point_m=proposal.grasp_point_m
        if proposal is not None
        else (0.018, 0.025, 0.018),
        timestep_s=0.0025,
    )
    jax.config.update("jax_enable_x64", True)
    print("BUILD_OBSERVED_SCENE", flush=True)
    pickup = Pickup.make(config, output / "observed", 12, PickupObjective())
    observed = pickup.staged_session(
        TRAINING_POSES[0],
        Grasp(z=0.025),
        support_loss,
        threads=4,
        batch_size=4,
        rounds=1,
        sigma=0.1,
                enforce_penetration=False,
    )
    if isinstance(observed, UnreachablePose):
        raise ValueError("Original screwdriver seed is unreachable")
    with closing(observed):
        boundary = Snapshot(
            observed.env,
            observed.control,
            integration(pickup.model, observed.data),
            len(observed.frames),
        )
        budget = observed.calibrate() if not args.coding_agent else None
        np.testing.assert_array_equal(
            integration(pickup.model, observed.data), boundary.integration
        )
        feedback = Outcome.model_validate_json(
            (root / "runs/two-material-raised-03/outcome.json").read_text()
        )
        goal = (
            "Pick up the realistic 97 g YCB Phillips screwdriver with its steel shaft and assumed CAB1180 handle. "
            "Use all three fingers and thumb with opposed support and retain the whole tool at least0.10m above floor for2s. "
            "The prior raised seed touched but never lifted; it ended early, so do not infer a motor shortage. "
            "Choose a grasp point on the thick handle. Inspect parts_info and geometry in REPL; use self.pickup.trajectory scratchIK before returning. "
            "Stock .28Nm hand, native Panda motion/floor/penetration/joint gates and support/retention remain fixed. "
            "12s maximum simulation. Return a literal GraspPlan and loss factory for this scene. "
            "Loss.value is minimized positive penalty, not raw contact load. Use native scene support, not captured old graph terms."
        )
        designer = GraspDesigner(observed, goal=goal, budget=budget, pickup=pickup)
        print("DESIGN_START", flush=True)
        start = perf_counter()
        if not args.coding_agent:
            with (
                handler(
                    {probe_env: lambda: observed.env, probe_budget: lambda: budget}
                ),
                handler(
                    harness(
                        model="openrouter/anthropic/claude-sonnet-4.5",
                        eval_provider="builtin",
                        type_checker="ty",
                        tool_collection="explicit",
                        num_retries=0,
                        langfuse=False,
                        timeout=120,
                    )
                ),
            ):
                proposal, reward = designer.design_grasp((pickup.scene,), feedback)
        else:
            reward = runpy.run_path(str(args.loss))["reward_factory"]
            (output / "loss-module.py").write_text(args.loss.read_text())
        (output / "call.json").write_text(
            json.dumps(
                {
                    "origin": "coding agent"
                    if args.coding_agent
                    else "actual GraspDesigner Skill",
                    "provider_attempted": not args.coding_agent,
                    "center_only_diagnostic": args.center_only_diagnostic,
                    "wall_s": perf_counter() - start,
                },
                indent=2,
            )
        )
        (output / "grasp-plan.json").write_text(proposal.model_dump_json(indent=2))
        (output / "factory-framework.txt").write_text(
            TypeAdapter(Encodable[RewardFn]).dump_python(reward, mode="json")
        )
        (output / "conversation.json").write_text(
            json.dumps(list(designer.__history__), indent=2)
        )
        observed.restore(boundary)
        np.testing.assert_array_equal(
            integration(pickup.model, observed.data), boundary.integration
        )
        assert observed.env is boundary.env and observed.control is boundary.control
        assert len(observed.frames) == boundary.frame_count
        candidate = (
            pickup
            if proposal.grasp_point_m == config.grasp_point_m
            else Pickup.make(
                config.model_copy(update={"grasp_point_m": proposal.grasp_point_m}),
                output / "candidate",
                12,
                PickupObjective(),
            )
        )
        np.testing.assert_array_equal(
            candidate.model.actuator_forcerange[candidate.hand_actuators],
            np.full((16, 2), [-0.28, 0.28]),
        )
        failures = [
            pose.name
            for pose in TRAINING_POSES
            if candidate.trajectory(candidate.reset(pose), proposal.grasp) is None
        ]
        (output / "ik.json").write_text(
            json.dumps({"unreachable": failures, "four_training_poses_checked": True})
        )
        if failures and (
            not args.center_only_diagnostic or TRAINING_POSES[0].name in failures
        ):
            raise ValueError(f"Unreachable training poses: {failures}")
        with handler({probe_env: lambda: observed.env}):
            check_reward(reward)
        print("REWARD_CHECK_PASSED; BUILD_CANDIDATE_SESSION", flush=True)
        session = cast(
            Session,
            candidate.staged_session(
                TRAINING_POSES[0],
                proposal.grasp,
                reward,
                threads=4,
                batch_size=args.batch_size,
                rounds=args.rounds,
                sigma=0.1,
                enforce_penetration=False,
            ),
        )
        with closing(session):
            np.testing.assert_array_equal(
                integration(candidate.model, session.data), boundary.integration
            )
            print("CANDIDATE_SESSION_BUILT; CHECK_CAPTURE_ENDPOINT", flush=True)
            geometry = bind_auxiliary_terms(
                session.env.spec, dict(candidate.scene.capture)
            )
            (output / "pickup-source.py").write_text(Path(getfile(Pickup)).read_text())
            (output / "executor-source.py").write_text(Path(__file__).read_text())
            print("READY_FOR_FACTORY_REVIEW", output, flush=True)
            while not (output / "run-candidate").exists():
                sleep(5)
            native = output / "native"
            native.mkdir()
            mujoco.mj_saveModel(candidate.model, str(native / "scene.mjb"))
            recording = Recording(
                candidate.recording.info, session.data.qacc_warmstart.copy()
            )
            recording.append(session.data)
            samples = [candidate.measure(session.data)]
            transitions = []
            started = perf_counter()
            ticks = 0
            try:
                while (
                    ticks < round(12 / candidate.model.opt.timestep)
                    and session.control.state.status == StageStatus.ACTIVE
                ):
                    before = session.control.state.index
                    previous_time = float(session.data.time)
                    session.step()
                    if float(session.data.time) == previous_time:
                        break
                    recording.append(session.data)
                    samples.append(candidate.measure(session.data))
                    ticks += 1
                    if session.control.state.index != before:
                        transitions.append(
                            {
                                "time_s": float(session.data.time),
                                "stage": session.control.state.index,
                            }
                        )
                        if session.control.state.index == 2:
                            original_native = integration(candidate.model, session.data)
                            planner = session.stages[2].controller.planner
                            _, _, issued_seed_actions = planner.sample(
                                session.control.state.inner, session.env.spec, 1.0
                            )
                            predicted = planner.rollout(
                                session.env.spec,
                                session.env.state,
                                session.env.spec.layout.u.unpack(
                                    issued_seed_actions[:1]
                                ),
                            )
                            endpoint = jax.tree.map(lambda leaf: leaf[0, -1], predicted)
                            entry_proof = capture_proof(
                                candidate, session, geometry, endpoint
                            )
                            entry_proof["input"] = (
                                "native predicted carried CAPTURE seed from actual stage-entry state"
                            )
                            np.testing.assert_array_equal(
                                integration(candidate.model, session.data),
                                original_native,
                            )
                            (native / "warmstart-entry.json").write_text(
                                json.dumps(entry_proof, indent=2)
                            )
                            print("WARMSTART_ENTRY", entry_proof, flush=True)
                    if ticks % 100 == 0:
                        print(
                            "NATIVE_PROGRESS",
                            ticks,
                            session.control.state.index,
                            session.control.state.status.value,
                            flush=True,
                        )
            finally:
                recording.save(native)
            hold_start = (
                session.control.state.entered_at
                if session.control.state.index == len(session.stages) - 1
                else float(session.data.time)
            )
            outcome = candidate.outcome(
                TRAINING_POSES[0], samples, hold_start_s=hold_start
            )
            (native / "outcome.json").write_text(outcome.model_dump_json(indent=2))
            result = {
                "stage": session.control.state.index,
                "status": session.control.state.status.value,
                "native_ticks": ticks,
                "simulated_s": float(session.data.time),
                "wall_s": perf_counter() - started,
                "transitions": transitions,
            }
            (native / "result.json").write_text(json.dumps(result, indent=2))
            print("NATIVE_DONE", result, outcome.lifted, flush=True)
            print(
                "REPLAY_ERROR",
                replay(native / "recording.npz", headless=True),
                flush=True,
            )


if __name__ == "__main__":
    main()
